import 'package:flutter/material.dart';
import '../core/app_export.dart';

extension PoppinsTextStyle on TextStyle {
  TextStyle get poppins {
    return copyWith(
      fontFamily: 'Poppins',
    );
  }
}

/// A class that defines custom text styles for the application.
class CustomTextStyles {
  // Body text style
  static TextStyle get bodySmallBlueA200 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.blueA200,
      );

  static TextStyle get bodySmallGray80001 =>
      theme.textTheme.bodySmall!.copyWith(
        color: appTheme.gray80001,
      );

  // Headline text style
  static TextStyle get headlineSmallBlueA200 =>
      theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.blueA200,
      );

  static TextStyle get headlineSmallGray90001 =>
      theme.textTheme.headlineSmall!.copyWith(
        color: appTheme.gray90001,
      );

  // Label text style
  static TextStyle get labelLargeBlack900 =>
      theme.textTheme.labelLarge!.copyWith(
        color: appTheme.black900,
      );

  static TextStyle get labelLargeBlueA200 =>
      theme.textTheme.labelLarge!.copyWith(
        color: appTheme.blueA200,
      );

  static TextStyle get labelLargeGray500 =>
      theme.textTheme.labelLarge!.copyWith(
        color: appTheme.gray500,
      );

  static TextStyle get labelLargeGray90001 =>
      theme.textTheme.labelLarge!.copyWith(
        color: appTheme.gray90001,
      );

  static TextStyle get labelLargeGray900_1 =>
      theme.textTheme.labelLarge!.copyWith(
        color: appTheme.gray900,
      );
  static TextStyle get labelLargeOnPrimary =>
      theme.textTheme.labelLarge!.copyWith(
        color: theme.colorScheme.onPrimary,
      );
  static TextStyle get labelLargeSemiBold =>
      theme.textTheme.labelLarge!.copyWith(
        fontWeight: FontWeight.w600,
      );
  static TextStyle get labelMediumBlueA200 =>
      theme.textTheme.labelMedium!.copyWith(
        color: appTheme.blueA200,
      );
  static TextStyle get labelMediumGray40001 =>
      theme.textTheme.labelMedium!.copyWith(
        color: appTheme.gray40001,
      );

  // Title text style
  static TextStyle get titleMediumGray700 =>
      theme.textTheme.titleMedium!.copyWith(
        color: appTheme.gray700,
        fontWeight: FontWeight.w500,
      );

  static TextStyle get titleMediumGray90001 =>
      theme.textTheme.titleMedium!.copyWith(
        color: appTheme.gray90001,
      );

  static TextStyle get titleSmallBlueA200 =>
      theme.textTheme.titleSmall!.copyWith(
        color: appTheme.blueA200,
      );

  static TextStyle get titleSmallSemiBold =>
      theme.textTheme.titleSmall!.copyWith(
        fontWeight: FontWeight.w600,
      );

  static TextStyle get titleMediumOnPrimary =>
      theme.textTheme.titleMedium!.copyWith(
        color: theme.colorScheme.onPrimary,
        fontWeight: FontWeight.w500,
      );
}
