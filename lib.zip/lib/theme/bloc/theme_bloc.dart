import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../core/app_export.dart';
part 'theme_event.dart';
part 'theme_state.dart';

class ThemeBloc extends Bloc<ThemeEvent, ThemeState> {
  var themeType;

  ThemeBloc({required this.themeType}) : super(ThemeState(themeType: themeType)) {
    on<ThemeChangeEvent>(_changeTheme);
  }

  Future<void> _changeTheme(
    ThemeChangeEvent event,
    Emitter<ThemeState> emit,
  ) async {
    emit(state.copyWith(themeType: event.themeType));
  }
}
