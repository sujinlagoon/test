import 'package:flutter/material.dart';
import '../core/app_export.dart';

LightCodeColors get appTheme => ThemeHelper().themeColors();
ThemeData get theme => ThemeHelper().themeData();

/// Helper class for managing themes and colors.
class ThemeHelper {
  // The current app theme
  var _appTheme = PrefUtils().getThemeData();

  // A map of custom color themes supported by the app
  final Map<String, LightCodeColors> _supportedCustomColor = {
    'lightCode': LightCodeColors(),
  };

  // A map of color schemes supported by the app
  final Map<String, ColorScheme> _supportedColorScheme = {
    'lightCode': ColorSchemes.lightCodeColorScheme,
  };

  /// Returns the lightCode colors for the current theme.
  LightCodeColors themeColors() {
    return _supportedCustomColor[_appTheme] ?? LightCodeColors();
  }

  /// Returns the current theme data.
  ThemeData themeData() {
    var colorScheme =
        _supportedColorScheme[_appTheme] ?? ColorSchemes.lightCodeColorScheme;
    return ThemeData(
      visualDensity: VisualDensity.standard,
      colorScheme: colorScheme,
      textTheme: TextThemes.textTheme(colorScheme),
      scaffoldBackgroundColor: colorScheme.onPrimary,
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          shadowColor: appTheme.black900.withOpacity(0.25),
          elevation: 4,
          visualDensity: const VisualDensity(
            vertical: -4,
            horizontal: -4,
          ),
          padding: EdgeInsets.zero,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          backgroundColor: Colors.transparent,
          side: BorderSide(
            color: appTheme.blueA200,
            width: 1,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          visualDensity: const VisualDensity(
            vertical: -4,
            horizontal: -4,
          ),
          padding: EdgeInsets.zero,
        ),
      ),
      dividerTheme: DividerThemeData(
        thickness: 4,
        space: 4,
        color: appTheme.gray40001,
      ),
    );
  }
}

class TextThemes {
  static TextTheme textTheme(ColorScheme colorScheme) {
    return TextTheme(
      bodyMedium: TextStyle(
        color: appTheme.gray60001,
        fontSize: 14, // Adjust this as needed for your project
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w400,
      ),
      bodySmall: TextStyle(
        color: appTheme.black900,
        fontSize: 12, // Adjust this as needed for your project
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w400,
      ),
      headlineSmall: TextStyle(
        color: appTheme.black900,
        fontSize: 24, // Adjust this as needed for your project
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w600,
      ),
      labelLarge: TextStyle(
        color: appTheme.gray600,
        fontSize: 12, // Adjust this as needed for your project
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w500,
      ),
      labelMedium: TextStyle(
        color: appTheme.gray40001,
        fontSize: 10, // Adjust this as needed for your project
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w500,
      ),
      titleLarge: TextStyle(
        color: appTheme.gray90001,
        fontSize: 20, // Adjust this as needed for your project
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w600,
      ),
      titleMedium: TextStyle(
        color: colorScheme.onPrimary,
        fontSize: 16, // Adjust this as needed for your project
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w600,
      ),
      titleSmall: TextStyle(
        color: appTheme.gray90001,
        fontSize: 14, // Adjust this as needed for your project
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w500,
      ),
    );
  }
}

/// Class containing the supported color schemes.
class ColorSchemes {
  static final lightCodeColorScheme = ColorScheme.light(
    primary: Color(0XFF264D99),
    primaryContainer: Color(0XFF4F7FA),
    onPrimary: Color(0XFFFFFFFF),
    onPrimaryContainer: Color(0XFF26264F),
  );
}

class LightCodeColors {
  // Amber
  Color get amber400 => Color(0xFFFFC219);
  Color get amber700 => Color(0XFFD89E0B);

  // Black
  Color get black900 => Color(0XFF000000);
  //white
  Color get white => Color(0XFFFFFF);

  // Blue
  Color get blue100 => Color(0XFFCEE4F4);
  Color get blue10001 => Color(0XFFC4DCF2);
  Color get blue10002 => Color(0XFFCFDFFF);
  Color get blue10003 => Color(0XFFCBE3F4);
  Color get blue200 => Color(0XFF9FC0FF);
  Color get blue50 => Color(0XFFE0EAFF);
  Color get blueA200 => Color(0XFF4081FF);
  Color get blueA400 => Color(0XFF2683FF);

  // BlueGray
  Color get blueGray100 => Color(0XFFD9D9D9);
  Color get blueGray300 => Color(0XFF97A6B7);
  Color get blueGray400 => Color(0XFF8A8A8A);
  Color get blueGray600 => Color(0XFF3A6893);
  Color get blueGray900 => Color(0XFF33363F);
  Color get blueGray90001 => Color(0XFF26264F);

  // DeepOrange
  Color get deepOrange200 => Color(0xFFFFB49D);
  Color get deepOrange500 => Color(0xFFFF4B26);

  // Gray
  Color get gray200 => Color(0XFFEBEBEB);
//  Color get gray300 => Color(0XFFD8DEE8);
  Color get gray300 => Color(0XFFD8DEE8);
  Color get gray30001 => Color(0XFFE6E6E6);
  Color get gray30002 => Color(0XFFDDDDDD);
  Color get gray30003 => Color(0XFFE0E0E0);

  Color get gray30004 => Color(0XFFE3E3E3);

  Color get gray400 => Color(0XFFBDBDBD);

  Color get gray40001 => Color(0XFFB8B8B8);

  Color get gray40002 => Color(0XFFB3B3B3);

  Color get gray40003 => Color(0XFFAEAEAE);

  Color get gray500 => Color(0XFF9C9C9C);

  Color get gray600 => Color(0XFF737373);

  Color get gray60001 => Color(0XFF848484);

  Color get gray700 => Color(0XFF666666);

  Color get gray70001 => Color(0XFF626262);

  Color get gray70002 => Color(0XFF6A6A6A);

  Color get gray800 => Color(0XFF413E3F);

  Color get gray80001 => Color(0XFF404040);

  Color get gray80002 => Color(0XFF3F3F3F);

  Color get gray80003 => Color(0XFF444041);

  Color get gray80004 => Color(0XFF3A3A3A);

  Color get gray900 => Color(0XFF282828);

  Color get gray90001 => Color(0XFF1C1C23);

// Indigo

  Color get indigo400 => Color(0XFF5D78B5);

  Color get indigo800 => Color(0XFF2C4482);

  Color get indigo900 => Color(0XFF003A70);

// Orange

  Color get orange200 => Color(0XFFFFCA69);

// Red
  Color get red500 => Color(0XFFFF2929);
  Color get red50001 => Color(0XFFFF3535);
  Color get redA200 => Color(0XFFFF4A4A);
// Teal
  Color get teal50 => Color(0XFFFFCA69);
// Yellow
  Color get yellow700 => Color(0XFFFFC133);
  Color get yellow800 => Color(0XFFF2B327);
  Color get skyblue => Color(0X9FC0FF);
  Color get liteblack => Color(0xFF282828);
}
