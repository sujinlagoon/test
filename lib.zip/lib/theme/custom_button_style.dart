import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A class that offers pre-defined button styles for customizing button appearance.
class CustomButtonStyles {
  /// Gradient button style
  static BoxDecoration get gradientBlueAToPrimaryDecoration => BoxDecoration(
        borderRadius: BorderRadius.circular(
            12.0), // Use 12.0 instead of 12.h if h is not defined
        boxShadow: [
          BoxShadow(
            color: appTheme.black900.withOpacity(0.25),
            spreadRadius: 2.0, // Use 2.0 instead of 2.h if h is not defined
            blurRadius: 2.0, // Use 2.0 instead of 2.h if h is not defined
            offset: Offset(0, 4),
          )
        ],
        gradient: LinearGradient(
          begin: Alignment(0.38, 0),
          end: Alignment(0.87, 1),
          colors: [appTheme.blueA200, theme.colorScheme.primary],
        ),
      );
  static BoxDecoration get gradientBlueAToPrimaryTL6Decoration => BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        boxShadow: [
          BoxShadow(
            color: appTheme.black900.withOpacity(0.25),
            spreadRadius: 2,
            blurRadius: 2,
            offset: Offset(
              0,
              4,
            ),
          )
        ],
        gradient: LinearGradient(
          begin: Alignment(0.38, 0),
          end: Alignment(0.87, 1),
          colors: [appTheme.blueA200, theme.colorScheme.primary],
        ),
      );

  /// Outline button style
  static ButtonStyle get outlineGray => OutlinedButton.styleFrom(
        backgroundColor: theme.colorScheme.onPrimary,
        side: BorderSide(
          color: appTheme.gray300,
          width: 1,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(
              12.0), // Use 12.0 instead of 12.h if h is not defined
        ),
        padding: EdgeInsets.zero,
      );

  /// Text button style
  static ButtonStyle get none => ButtonStyle(
        backgroundColor: MaterialStateProperty.all<Color>(Colors.transparent),
        elevation: MaterialStateProperty.all<double>(0),
        padding: MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.zero),
        side: MaterialStateProperty.all<BorderSide>(
          BorderSide(color: Colors.transparent),
        ),
      );
}
