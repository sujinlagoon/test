import 'package:flutter/material.dart';
import '../core/app_export.dart';

class AppDecoration {
// Fill decorations
  static BoxDecoration get fillonPrimary => BoxDecoration(
        color: theme.colorScheme.onPrimary,
      );
// Outline decorations
  static BoxDecoration get outlineGray => BoxDecoration(
        border: Border.all(
          color: appTheme.gray30003,
          width: 1,
        ),
      );
  static BoxDecoration get outlineGray400 => BoxDecoration(
      color: theme.colorScheme.onPrimary,
      border: Border(
        top: BorderSide(
          color: appTheme.gray400,
          width: 1
        ),
      ));
}

class BorderRadiusStyle {
// Rounded borders
  static BorderRadius get roundedBorder6 => BorderRadius.circular(
        6,
      );
}
