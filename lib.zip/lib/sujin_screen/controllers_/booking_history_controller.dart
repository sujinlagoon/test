import 'package:fluttertickect365/presentation/utils/AppConstants.dart';
import 'package:fluttertickect365/sujin_screen/SharedPref/sharedPref.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import '../modals/bookingHistory_modal.dart';
import '../modals/booking_view_modal.dart';

class BookingHistoryController extends GetxController {
  List<BookingHistory> bookingHistory = [];
  List<Booking> bookings = [];
  List<Booking> bookedBookings = [];
  List<Booking> completedBookings = [];
  List<Booking> cancelledBookings = [];
  bool isLoadingg = false;

  bookingHistoryApi() async {
    try {
      isLoadingg = true;
      update();
      String? token = await sharedPrefer().getToken();
      var res = await http.post(
        Uri.parse('https://ticketapp365.akprojects.co/api/bus/BookingHistory'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (res.statusCode == 200) {
        var data = bookingHistoryFromJson(res.body);

        // Debugging: Print raw JSON response to verify data
        print("Raw JSON Response: ${res.body}");

        bookings = data.data!.bookings ?? [];
        print("Total Bookings: ${bookings.length}");

        // Clear lists before filtering
        bookedBookings.clear();
        completedBookings.clear();
        cancelledBookings.clear();

        for (var booking in bookings) {
          // String status = booking.bbookingStatus?.trim().toUpperCase() ?? '';
          String status = booking.bbookingStatus
                  ?.trim()
                  .replaceAll(RegExp(r'\s+'), '')
                  .toUpperCase() ??
              '';

          print("Booking Status: $status");
          if (status == 'BOOKED') {
            bookedBookings.add(booking);
          } else if (status == 'COMPLETED') {
            completedBookings.add(booking);
          } else if (status == 'CANCELLED') {
            cancelledBookings.add(booking);
          }
        }

        print("Total 'BOOKED' Bookings: ${bookedBookings.length}");
        print("Total 'COMPLETED' Bookings: ${completedBookings.length}");
        print("Total 'CANCELLED' Bookings: ${cancelledBookings.length}");
      } else {
        print('Failed to load data: ${res.statusCode}');
      }
    } catch (error) {
      print('Error: $error');
    } finally {
      isLoadingg = false;
      update();
    }
  }

  ///


  @override
  void onInit() {
    /*if (bookings.isEmpty) {*/
    bookingHistoryApi();
    /*  }*/
    super.onInit();
  }
}
