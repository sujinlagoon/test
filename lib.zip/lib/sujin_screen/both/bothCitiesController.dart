import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:fluttertickect365/presentation/utils/AppConstants.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import '../modals/both_cities_modal.dart';

class BothCitiesController extends GetxController {
  List<BothCity> bothCity = [];
  List<BothCity> filteredCities = [];
  bool isLoading = false;
  TextEditingController searchController = TextEditingController();
  String? fromLocationBoth;
  String? fromLocationCodeBoth;
  String? ToLocationBoth;
  String? toLocationCodeBoth;
  String? ProviderType;
  DateTime? bSelectedDate = DateTime.now();

  getAllStation() async {
    try {
      isLoading = true;
      update();
      var url = Uri.parse(
          'https://ticketapp365.akprojects.co/api/bus/list_all_cities');

      var formData = {
        "service_provider_type": ProviderType ?? "",
        "search": searchController.text.trim(),
      };

      var res = await http.post(
        url,
        body: formData, /*headers: headers*/
      );
      if (res.statusCode == 200) {
        var data = bothCitiesFromJson(res.body);

        bothCity = data.data?.cities ?? [];
        filteredCities = bothCity;
        update();
      } else {
        debugPrint("Failed to fetch data. Status code: ${res.statusCode}");
      }
    } catch (e) {
      debugPrint("Error fetching data: $e");
    } finally {
      isLoading = false;
      update();
    }
  }

  void filterCities(String query) {
    String trimUnwantedSpaces = query.trim();
    if (trimUnwantedSpaces.isEmpty) {
      filteredCities = bothCity;
    } else {
      filteredCities = bothCity
          .where(
              (city) => city.cityName!.toLowerCase().startsWith(trimUnwantedSpaces
                  .toLowerCase()) /*||
              city.cityState!.toLowerCase().contains(trimUnwantedSpaces.toLowerCase())*/
              )
          .toList();
      print("---->${filteredCities}");
    }
    update();
  }

  void setFromLocation(String location, String code, String providerType) {
    fromLocationCodeBoth = code;
    ProviderType = providerType;
    fromLocationBoth = location;
    update();
  }

  void setToLocation(String location, String code, String providerType) {
    toLocationCodeBoth = code;
    ProviderType = providerType;
    ToLocationBoth = location;
    update();
  }

  void clearLocation() {
    toLocationCodeBoth = null;
    ToLocationBoth = null;
    fromLocationCodeBoth = null;
    ProviderType = null;
    fromLocationBoth = null;
    update();
  }

  @override
  void onInit() {
    super.onInit();

    print("Inside BothCitiesController");

    // Always load all cities initially
    getAllStation();

    searchController.addListener(() {
      filterCities(searchController.text);
    });
  }
}
