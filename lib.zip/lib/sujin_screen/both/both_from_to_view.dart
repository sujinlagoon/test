import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertickect365/sujin_screen/Profile/profile__controller.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import 'bothCitiesController.dart';

class SelectBothSourceView extends StatefulWidget {
  final bool isSelectingFrom;

  SelectBothSourceView({required this.isSelectingFrom});

  @override
  State<SelectBothSourceView> createState() => _SelectBothSourceViewState();
}

class _SelectBothSourceViewState extends State<SelectBothSourceView> {
  BothCitiesController controller = Get.put(BothCitiesController());
  ProfileController controllerr = Get.put(ProfileController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF2684FF),
        title: Text(
          "Select Departure",
          style: TextStyle(fontWeight: FontWeight.normal, color: Colors.white),
        ),
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            )),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.center,
            colors: [Color(0xFF2684FF), Colors.white],
          ),
        ),
        child: GetBuilder<BothCitiesController>(builder: (context) {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: Offset(0, 3), // Shadow position
                      ),
                    ],
                  ),
                  child: GetBuilder<BothCitiesController>(builder: (v) {
                    return Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 5.0, left: 15),
                            child: TextField(
                              controller: v.searchController,
                              decoration: InputDecoration(
                                hintText: 'Select City / Place',
                                hintStyle: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 16,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                ),
                                border: InputBorder.none,
                                suffixIcon: GestureDetector(
                                  onTap: () {
                            /*        controller.getAllStation(
                                        searchController:
                                            controller.searchController);*/
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 16.0),
                                    child: SvgPicture.asset(
                                        'assets/images/search.svg'),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    );
                  }),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20.0, right: 20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    'Popular Cities',
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 16,
                        color: Color(0xFF282828)),
                  ),
                ),
              ),
              SizedBox(
                height: Get.height * 0.01,
              ),
              GetBuilder<BothCitiesController>(builder: (city) {
                return controller.isLoading
                    ? Center(child: CircularProgressIndicator())
                    : Flexible(
                        flex: 5,
                        child: controller.filteredCities.isEmpty
                            ? Center(
                                child: Text(
                                  'No cities available',
                                  style: TextStyle(
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16,
                                    color: Colors.grey,
                                  ),
                                ),
                              )
                            : ListView.builder(
                                scrollDirection: Axis.vertical,
                                itemCount: city.filteredCities.length,
                                itemBuilder: (context, index) {
                                  var data = city.filteredCities[index];
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10.0, vertical: 10.0),
                                    child: GestureDetector(
                                      onTap: () async {
                                        if (widget.isSelectingFrom) {
                                          controller.setFromLocation(
                                              data.cityName!,
                                              data.cityId.toString(),
                                              data.serviceProviderType!);
                                        } else {
                                          controller.setToLocation(
                                              data.cityName!,
                                              data.cityId.toString(),
                                              data.serviceProviderType!);
                                        }
                                        controller.update();
                                        Navigator.pop(context);
                                      },
                                      child: IntrinsicWidth(
                                        child: IntrinsicHeight(
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(15.0),
                                              border: Border.all(
                                                  color: Color(0xFFEBEBEB),
                                                  width:
                                                      1.0), // Optional border
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 15,
                                                      vertical: 10),
                                              // Reduced padding
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  SvgPicture.asset(
                                                    'assets/images/bus_dest_sv.svg',
                                                    height: 23.0,
                                                    width: 23.0,
                                                  ),
                                                  SizedBox(
                                                    width: 10,
                                                  ),
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        "${data.cityName!} ${data.serviceProviderType}",
                                                        style: TextStyle(
                                                            fontSize: 15.0,
                                                            // Reduced font size
                                                            fontFamily:
                                                                'Poppins',
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500),
                                                      ),
                                                      Text(
                                                        data.cityState!,
                                                        style: TextStyle(
                                                            fontSize: 15.0,
                                                            // Reduced font size
                                                            fontFamily:
                                                                'Poppins Medium',
                                                            color: Color(
                                                                0xFF5F5F5F)),
                                                      ),
                                                    ],
                                                  ),
                                                  // Returns an empty widget if the condition is not met
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                      );
              }),
            ],
          );
        }),
      ),
    );
  }
}
