// To parse this JSON data, do
//
//     final orbitSeatLayoutModal = orbitSeatLayoutModalFromJson(jsonString);

import 'dart:convert';

OrbitSeatLayoutModal orbitSeatLayoutModalFromJson(String str) => OrbitSeatLayoutModal.fromJson(json.decode(str));

String orbitSeatLayoutModalToJson(OrbitSeatLayoutModal data) => json.encode(data.toJson());

class OrbitSeatLayoutModal {
  int ?status;
  DateTime? datetime;
  Data ?data;

  OrbitSeatLayoutModal({
    this.status,
    this.datetime,
    this.data,
  });

  factory OrbitSeatLayoutModal.fromJson(Map<String, dynamic> json) => OrbitSeatLayoutModal(
    status: json["status"],
    datetime: DateTime.parse(json["datetime"]),
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "datetime": datetime!.toIso8601String(),
    "data": data!.toJson(),
  };
}

class Data {
  String ?tripCode;
  String ?tripStageCode;
  int ?availableSeatCount;
  Bus ?bus;
  Station ?fromStation;
  Station ?toStation;
  Status ?tripStatus;
  CancellationTerm ?cancellationTerm;
  Tax ?tax;

  Data({
    this.tripCode,
    this.tripStageCode,
    this.availableSeatCount,
    this.bus,
    this.fromStation,
    this.toStation,
    this.tripStatus,
    this.cancellationTerm,
    this.tax,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    tripCode: json["tripCode"],
    tripStageCode: json["tripStageCode"],
    availableSeatCount: json["availableSeatCount"],
    bus: Bus.fromJson(json["bus"]),
    fromStation: Station.fromJson(json["fromStation"]),
    toStation: Station.fromJson(json["toStation"]),
    tripStatus: Status.fromJson(json["tripStatus"]),
    cancellationTerm: CancellationTerm.fromJson(json["cancellationTerm"]),
    tax: Tax.fromJson(json["tax"]),
  );

  Map<String, dynamic> toJson() => {
    "tripCode": tripCode,
    "tripStageCode": tripStageCode,
    "availableSeatCount": availableSeatCount,
    "bus": bus!.toJson(),
    "fromStation": fromStation!.toJson(),
    "toStation": toStation!.toJson(),
    "tripStatus": tripStatus!.toJson(),
    "cancellationTerm": cancellationTerm!.toJson(),
    "tax": tax!.toJson(),
  };
}

class Bus {
  String ?code;
  String ?busType;
  String ?categoryCode;
  String ?displayName;
  String ?name;
  int ?totalSeatCount;
  List<SeatLayoutList> ?seatLayoutList;

  Bus({
    this.code,
    this.busType,
    this.categoryCode,
    this.displayName,
    this.name,
    this.totalSeatCount,
    this.seatLayoutList,
  });

  factory Bus.fromJson(Map<String, dynamic> json) => Bus(
    code: json["code"],
    busType: json["busType"],
    categoryCode: json["categoryCode"],
    displayName: json["displayName"],
    name: json["name"],
    totalSeatCount: json["totalSeatCount"],
    seatLayoutList: List<SeatLayoutList>.from(json["seatLayoutList"].map((x) => SeatLayoutList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "code": code,
    "busType": busType,
    "categoryCode": categoryCode,
    "displayName": displayName,
    "name": name,
    "totalSeatCount": totalSeatCount,
    "seatLayoutList": List<dynamic>.from(seatLayoutList!.map((x) => x.toJson())),
  };
}

class SeatLayoutList {
  String ?code;
  BusSeatType ?busSeatType;
  BusSeatType ?seatGendar;
  Status ?seatStatus;
  int ?rowPos;
  int ?colPos;
  int ?seatPos;
  int ?layer;
  int ?orientation;
  String ?seatName;
  int? seatFare;
  int? serviceTax;
  int ?passengerAge;

  SeatLayoutList({
    this.code,
    this.busSeatType,
    this.seatGendar,
    this.seatStatus,
    this.rowPos,
    this.colPos,
    this.seatPos,
    this.layer,
    this.orientation,
    this.seatName,
    this.seatFare,
    this.serviceTax,
    this.passengerAge,
  });

  factory SeatLayoutList.fromJson(Map<String, dynamic> json) => SeatLayoutList(
    code: json["code"],
    busSeatType: BusSeatType.fromJson(json["busSeatType"]),
    seatGendar: BusSeatType.fromJson(json["seatGendar"]),
    seatStatus: Status.fromJson(json["seatStatus"]),
    rowPos: json["rowPos"],
    colPos: json["colPos"],
    seatPos: json["seatPos"],
    layer: json["layer"],
    orientation: json["orientation"],
    seatName: json["seatName"],
    seatFare: json["seatFare"],
    serviceTax: (json["serviceTax"] is double) ? (json["serviceTax"] as double).toInt() : json["serviceTax"],

    passengerAge: json["passengerAge"],
  );

  Map<String, dynamic> toJson() => {
    "code": code,
    "busSeatType": busSeatType!.toJson(),
    "seatGendar": seatGendar!.toJson(),
    "seatStatus": seatStatus!.toJson(),
    "rowPos": rowPos,
    "colPos": colPos,
    "seatPos": seatPos,
    "layer": layer,
    "orientation": orientation,
    "seatName": seatName,
    "seatFare": seatFare,
    "serviceTax": serviceTax,
    "passengerAge": passengerAge,
  };
}

class BusSeatType {
  String ?code;
  String ?name;
  int? activeFlag;
  bool ?reservation;

  BusSeatType({
    this.code,
    this.name,
    this.activeFlag,
    this.reservation,
  });

  factory BusSeatType.fromJson(Map<String, dynamic> json) => BusSeatType(
    code: json["code"],
    name: json["name"],
    activeFlag: json["activeFlag"],
    reservation: json["reservation"],
  );

  Map<String, dynamic> toJson() => {
    "code": code,
    "name": name,
    "activeFlag": activeFlag,
    "reservation": reservation,
  };
}

class Status {
  String ?code;
  String ?name;

  Status({
    this.code,
    this.name,
  });

  factory Status.fromJson(Map<String, dynamic> json) => Status(
    code: json["code"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "code": code,
    "name": name,
  };
}

class CancellationTerm {
  String ?code;
  DateTime ?datetime;
  int ?activeFlag;
  List<PolicyList> ?policyList;

  CancellationTerm({
    this.code,
    this.datetime,
    this.activeFlag,
    this.policyList,
  });

  factory CancellationTerm.fromJson(Map<String, dynamic> json) => CancellationTerm(
    code: json["code"],
    datetime: DateTime.parse(json["datetime"]),
    activeFlag: json["activeFlag"],
    policyList: List<PolicyList>.from(json["policyList"].map((x) => PolicyList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "code": code,
    "datetime": datetime!.toIso8601String(),
    "activeFlag": activeFlag,
    "policyList": List<dynamic>.from(policyList!.map((x) => x.toJson())),
  };
}

class PolicyList {
  String ?code;
  int ?fromValue;
  int? toValue;
  double ?deductionAmount;
  String ?policyPattern;
  int? percentageFlag;

  PolicyList({
    this.code,
    this.fromValue,
    this.toValue,
    this.deductionAmount,
    this.policyPattern,
    this.percentageFlag,
  });

  factory PolicyList.fromJson(Map<String, dynamic> json) => PolicyList(
    code: json["code"],
    fromValue: json["fromValue"],
    toValue: json["toValue"],
    deductionAmount: json["deductionAmount"],
    policyPattern: json["policyPattern"],
    percentageFlag: json["percentageFlag"],
  );

  Map<String, dynamic> toJson() => {
    "code": code,
    "fromValue": fromValue,
    "toValue": toValue,
    "deductionAmount": deductionAmount,
    "policyPattern": policyPattern,
    "percentageFlag": percentageFlag,
  };
}

class Station {
  String ?name;
  String ?code;
  DateTime? dateTime;
  List<StationPoint>? stationPoint;

  Station({
    this.name,
    this.code,
    this.dateTime,
    this.stationPoint,
  });

  factory Station.fromJson(Map<String, dynamic> json) => Station(
    name: json["name"],
    code: json["code"],
    dateTime: DateTime.parse(json["dateTime"]),
    stationPoint: List<StationPoint>.from(json["stationPoint"].map((x) => StationPoint.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "code": code,
    "dateTime": dateTime!.toIso8601String(),
    "stationPoint": List<dynamic>.from(stationPoint!.map((x) => x.toJson())),
  };
}

class StationPoint {
  String ?code;
  String ?name;
  String? latitude;
  String ?longitude;
  String ?address;
  String ?landmark;
  String? number;
  DateTime? dateTime;
  int? additionalFare;
  List<dynamic> ?amenities;

  StationPoint({
    this.code,
    this.name,
    this.latitude,
    this.longitude,
    this.address,
    this.landmark,
    this.number,
    this.dateTime,
    this.additionalFare,
    this.amenities,
  });

  factory StationPoint.fromJson(Map<String, dynamic> json) => StationPoint(
    code: json["code"],
    name: json["name"],
    latitude: json["latitude"],
    longitude: json["longitude"],
    address: json["address"],
    landmark: json["landmark"],
    number: json["number"],
    dateTime: DateTime.parse(json["dateTime"]),
    additionalFare: json["additionalFare"],
    amenities: List<dynamic>.from(json["amenities"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "code": code,
    "name": name,
    "latitude": latitude,
    "longitude": longitude,
    "address": address,
    "landmark": landmark,
    "number": number,
    "dateTime": dateTime!.toIso8601String(),
    "additionalFare": additionalFare,
    "amenities": List<dynamic>.from(amenities!.map((x) => x)),
  };
}

/*class Tax {
  double ?cgstValue;
  double ?sgstValue;
  int? ugstValue;
  int? igstValue;
  String? tradeName;
  String ?gstin;

  Tax({
    this.cgstValue,
    this.sgstValue,
    this.ugstValue,
    this.igstValue,
    this.tradeName,
    this.gstin,
  });

  factory Tax.fromJson(Map<String, dynamic> json) => Tax(
    cgstValue: json["cgstValue"].toDouble(),
    sgstValue: json["sgstValue"].toDouble(),
    ugstValue: json["ugstValue"],
    igstValue: json["igstValue"],
    tradeName: json["tradeName"],
    gstin: json["gstin"],
  );

  Map<String, dynamic> toJson() => {
    "cgstValue": cgstValue,
    "sgstValue": sgstValue,
    "ugstValue": ugstValue,
    "igstValue": igstValue,
    "tradeName": tradeName,
    "gstin": gstin,
  };
}*/
class Tax {
  double? cgstValue;
  double? sgstValue;
  int? ugstValue;
  int? igstValue;
  String? tradeName;
  String? gstin;

  Tax({
    this.cgstValue,
    this.sgstValue,
    this.ugstValue,
    this.igstValue,
    this.tradeName,
    this.gstin,
  });

  factory Tax.fromJson(Map<String, dynamic> json) => Tax(
    cgstValue: json["cgstValue"] != null ? (json["cgstValue"] as num).toDouble() : null,
    sgstValue: json["sgstValue"] != null ? (json["sgstValue"] as num).toDouble() : null,
    ugstValue: json["ugstValue"],
    igstValue: json["igstValue"],
    tradeName: json["tradeName"],
    gstin: json["gstin"],
  );

  Map<String, dynamic> toJson() => {
    "cgstValue": cgstValue,
    "sgstValue": sgstValue,
    "ugstValue": ugstValue,
    "igstValue": igstValue,
    "tradeName": tradeName,
    "gstin": gstin,
  };
}
