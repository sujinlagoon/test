import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import '../OrbitSeat_Layout_Modal/orbit_seat_layout_modal.dart';

class OrbitSeatLayOutController extends GetxController {
  List<SeatLayoutList> seatLayoutLst = [];
  List<SeatLayoutList> lowerDeckSeats = [];
  List<SeatLayoutList> upperDeckSeats = [];
  List<double> selectedSeatPricesList = [];
  List<StationPoint> fromStation = [];
  List<StationPoint> toStation = [];
  String? storedTripCode;
  bool isLoading = false;
  double totalFare = 0.0;
  String? seatCode;
  List<String> selectedSeats = [];
  List<String> selectedSeatCode = [];
  String? busName;
  TabController? tabController;
  String? busType;
  bool isDroppingTabActive = false;
  String? errorDesc;

  void toggleSeatSelection(String seatName, String seatCode) {
    var selectedSeat =
        seatLayoutLst.firstWhere((seat) => seat.seatName == seatName);

    if (selectedSeats.contains(seatName)) {
      // Deselect the seat
      selectedSeats.remove(seatName);
      selectedSeatCode.remove(seatCode);
      //  selectedSeatPricesList.removeWhere((fare) => fare == selectedSeat.seatFare);
      int index =
          selectedSeatPricesList.indexOf(selectedSeat.seatFare!.toDouble());
      if (index != -1) {
        selectedSeatPricesList.removeAt(index);
      }
    } else {
      // Select the seat
      selectedSeats.add(seatName);
      selectedSeatCode.add(seatCode);
      selectedSeatPricesList.add(selectedSeat.seatFare!.toDouble() ?? 0.0);
    }

    totalFare = selectedSeatPricesList.fold(0.0, (sum, fare) => sum + fare);

    update();
  }

  Future<bool> orbitSeatLayoutApi({
    String? tripCode,
    String? fromCode,
    String? toCode,
    DateTime? selectedDate,
  }) async {
    try {
      String formattedDate = DateFormat('yyyy-MM-dd').format(selectedDate!);
      isLoading = true;
      update();
      var url =
          'http://staging.busticketagent.com/orbitservices/api/1.0/json/orbit/devapiuser/85838253YLGF049ZMF731A10YH814/busmap/$tripCode/$fromCode/$toCode/$formattedDate';
      print(url);
      var res = await http.get(Uri.parse(url));

      if (res.statusCode == 200) {
        var decodeData = jsonDecode(res.body);
        if (decodeData['status'] == 0) {
          errorDesc = decodeData['errorDesc'] ?? 'Unknown error';
          return false; // Return false to indicate an error has occurred
        } else {
          var datas = OrbitSeatLayoutModal.fromJson(decodeData);
          selectedSeats.clear();
          selectedSeatCode.clear();
          selectedSeatPricesList.clear();
          totalFare = 0.0;
          selectedSeats.clear();
          seatLayoutLst = datas.data?.bus?.seatLayoutList ?? [];

          if (seatLayoutLst.isEmpty) {
            print("No seat layout data available");
            return false; // Exit early to avoid errors
          }
          busType = datas.data!.bus!.busType;
          fromStation = datas.data!.fromStation!.stationPoint!;
          toStation = datas.data!.toStation!.stationPoint!;
          busName = datas.data!.bus!.name;
          clearSection();
          update();
          return true;
        }
      } else {
        print("Failed to fetch seat layout: ${res.body}");
        return false;
      }
    } catch (e) {
      print("Error in seat layout API: $e");
      return false;
    } finally {
      isLoading = false;
      update();
    }
  }


  void clearSection(){
    fromSelectedId =null;
    fromSelectedIndex = null;
    toSelectedId = null;
    toSelectedIndex = null;
    debugSelection();
    update();
  }


  void debugSelection() {
    print("FromSelectedId: $fromSelectedId");
    print("FromSelectedIndex: $fromSelectedIndex");
    print("ToSelectedId: $toSelectedId");
    print("ToSelectedIndex: $toSelectedIndex");
  }


  ///updated

  List<List<SeatLayoutList?>> generateSeatGrid(List<SeatLayoutList> seats) {
    if (seats.isEmpty) {
      return [];
    }

    int maxRow =
        seats.map((seat) => seat.rowPos ?? 0).reduce((a, b) => a > b ? a : b);
    int maxCol =
        seats.map((seat) => seat.colPos ?? 0).reduce((a, b) => a > b ? a : b);

    List<List<SeatLayoutList?>> grid = List.generate(
      maxRow,
      (_) => List<SeatLayoutList?>.filled(maxCol, null),
    );

    for (var seat in seats) {
      if (seat.rowPos != null && seat.colPos != null) {
        grid[seat.rowPos! - 1][seat.colPos! - 1] = seat;
      }
    }

    return grid;
  }

  DateTime? fromTime;
  DateTime? toTime;
  int? fromSelectedIndex;
  String? fromSelectedId;

  int? toSelectedIndex;
  String? toSelectedId;

  void updateFromStationPoint(int? selectedIndex) {

    fromSelectedIndex = selectedIndex;
    fromSelectedId = fromStation[selectedIndex!].code;
    fromTime = fromStation[selectedIndex].dateTime;
    update();
    /*if (tabController!.index != 1) {
      tabController!.animateTo(1);
    }*/
    update();
    print("Selected Boarding Point ID: $fromSelectedId");
  }

  void updateToStationPoint(int? selectedIndex) {
    toSelectedIndex = selectedIndex;
    toSelectedId = toStation[selectedIndex!].code;
    toTime = toStation[selectedIndex].dateTime;
    update();
    print("Selected Dropping Point ID: $toSelectedId");
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    /*  if (storedTripCode != null) {
      orbitSeatLayoutApi(tripCode: storedTripCode);
    }*/
  }
}
