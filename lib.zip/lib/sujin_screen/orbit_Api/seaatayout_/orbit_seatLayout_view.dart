import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertickect365/sujin_screen/Profile/profile__controller.dart';
import 'package:get/get.dart';
import '../PickupDrop_Points/pick_drop_points.dart';
import '../reuse_widget/customBottomSheet.dart';
import 'orbit_seatLayout_controller/orbit_seat_layout_controller.dart';

import 'OrbitSeat_Layout_Modal/orbit_seat_layout_modal.dart';

class OrbitSeatLayoutView extends StatefulWidget {
  final String? tripCode;
  String? fromLocation;
  String? toLocation;
  String? fromLocationCode;
  String? toLocationCode;
  DateTime? selectDate;
  String? busType;
  String? busname;

  OrbitSeatLayoutView(
      {super.key,
      this.tripCode,
      this.fromLocation,
      this.toLocation,
      this.toLocationCode,
      this.selectDate,
      this.busname,
      this.busType,
      this.fromLocationCode});

  @override
  State<OrbitSeatLayoutView> createState() => _OrbitSeatLayoutViewState();
}

class _OrbitSeatLayoutViewState extends State<OrbitSeatLayoutView> {
  final OrbitSeatLayOutController layOutController =
      Get.put(OrbitSeatLayOutController());
  ProfileController controller = Get.find<ProfileController>();

  @override
  void initState() {
    super.initState();
    layOutController.storedTripCode = widget.tripCode;
    /* layOutController.orbitSeatLayoutApi(tripCode: widget.tripCode);*/
  }

  @override
  void dispose() {
    layOutController.selectedSeats.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet: GetBuilder<OrbitSeatLayOutController>(builder: (context) {
        return CustomBottomSheet(
          seatNames: layOutController.selectedSeats,
          onNext: () {
            if (layOutController.selectedSeats.isEmpty) {
              Get.snackbar(
                "Selection Required",
                "Please select at least one seat to proceed.",
                snackPosition: SnackPosition.BOTTOM,
                backgroundColor: Colors.red.withOpacity(0.8),
                colorText: Colors.white,
              );
            } else {
              Get.to(() => OrbitPickupAndDropping(
                    selectedSeats: layOutController.selectedSeats,
                    selectedSeatCode: layOutController.selectedSeatCode,
                    fare: layOutController.totalFare,
                    fromLocation: widget.fromLocation,
                    toLocation: widget.toLocation,
                    tripCode: widget.tripCode,
                    seatFareList: layOutController.selectedSeatPricesList,
                    toLocationCode: widget.toLocationCode,
                    fromLocationCode: widget.fromLocationCode,
                    selectDate: widget.selectDate,
                    busType: widget.busType,
                    busName: widget.busname,
                    //

                    fromLocationCodeCommon: widget.fromLocationCode,
                    toLocationCodeCommon: widget.toLocationCode,
                    fromLocationNameCommon: widget.fromLocation,
                    toLocationNameCommon: widget.toLocation,
                  ));
            }
          },
          totalFare: layOutController.totalFare,
        );
      }),
      appBar: AppBar(
        bottom: PreferredSize(
            preferredSize: const Size.fromHeight(4.0),
            child: Container(
              color: Colors.grey[200],
              height: MediaQuery.sizeOf(context).height * 0.001,
            )),
        title: GetBuilder<OrbitSeatLayOutController>(builder: (v) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Select Seats',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16.sp),
              ),
              Text(
                "${widget.fromLocation} > ${widget.toLocation}",
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 14.sp,
                    color: Colors.grey),
              )
            ],
          );
        }),
        leading: IconButton(
            padding: EdgeInsets.zero,
            onPressed: () {
              Get.back();
            },
            icon: Icon(Icons.arrow_back_ios_new_outlined)),
      ),
      body: Stack(
        children: [
          GetBuilder<OrbitSeatLayOutController>(
            builder: (controller) {
              if (controller.isLoading) {
                return const Center(child: CircularProgressIndicator());
              }

              // Generate grids for lower and upper deck
              final lowerDeckSeats = controller.generateSeatGrid(
                controller.seatLayoutLst
                    .where((seat) => seat.layer == 1)
                    .toList(),
              );
              final upperDeckSeats = controller.generateSeatGrid(
                controller.seatLayoutLst
                    .where((seat) => seat.layer == 2)
                    .toList(),
              );
              if (controller.busType!.toLowerCase().contains("semi sleeper")) {
                return SeatOnlyWidget(seatGrid: lowerDeckSeats);
              }

              return Row(
                children: [
                  Expanded(
                      child: SeatGridWidget(
                    seatGrid: lowerDeckSeats,
                    deckName: "Lower Deck",
                  )),
                  const SizedBox(width: 5),
                  Expanded(
                      child: SeatGridWidget(
                    seatGrid: upperDeckSeats,
                    deckName: "Upper Deck",
                  )),
                ],
              );
            },
          ),
          Positioned(
            right: 20.w,
            top: MediaQuery.of(context).size.height * 0.018,
            child: InkWell(
              onTap: () {
                _showSeatTypeDialog(context);
              },
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(3),
                    decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(3.r)),
                    child: Center(
                      child: Text(
                        "Seat Info",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  Icon(
                    Icons.info_outline, // Replace with your desired icon
                    size: 25.sp, // Customize the size
                    color: Colors.blue, // Customize the color
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  void _showSeatTypeDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Know Your Seat Types"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _seatTypeRow("Available", Colors.green),
              _seatTypeRow("Already Booked", Colors.grey),
              _seatTypeRow("Available only for female passenger", Colors.pink),
              _seatTypeRow("Booked by female passenger", Colors.purple),
              _seatTypeRow("Available only for male passenger", Colors.blue),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text("Close"),
            ),
          ],
        );
      },
    );
  }

  Widget _seatTypeRow(String label, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(Icons.event_seat, color: color),
          SizedBox(width: 10),
          Expanded(child: Text(label)),
        ],
      ),
    );
  }
}

class SeatGridWidget extends StatelessWidget {
  final List<List<SeatLayoutList?>> seatGrid;
  String? deckName;

  SeatGridWidget({super.key, required this.seatGrid, this.deckName});

  @override
  Widget build(BuildContext context) {
    /*  bool hasSeats = seatGrid.any((row) => row.any((seat) => seat != null));

    if (!hasSeats) {
      return SizedBox();
    }*/

    return Padding(
      padding: const EdgeInsets.only(top: 60),
      child: SingleChildScrollView(
        //  scrollDirection: Axis.vertical,
        padding: EdgeInsets.zero,
        child: Container(
          height: MediaQuery.sizeOf(context).height * 0.60,
          //padding: EdgeInsets.symmetric(horizontal:10.r),
          //width: MediaQuery.sizeOf(context).width * 0.50,
          decoration: BoxDecoration(
              /*boxShadow: [
                BoxShadow(
                  color: Colors.grey,
                  offset: Offset(0.0, 1.0), //(x,y)
                  blurRadius: 6.0,
                ),
              ],*/
              borderRadius: BorderRadius.circular(12.r),
              border: Border.all(color: Colors.grey.withOpacity(0.2)),
              color: Colors.white),
          child: SingleChildScrollView(
            physics: NeverScrollableScrollPhysics(),
            child: Column(
              //crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: MediaQuery.of(context).size.height * 0.01),
                if (deckName == 'Lower Deck')
                  Padding(
                    padding: EdgeInsets.only(left: Get.width * 0.31),
                    child: Image.asset(
                      "assets/car_handle.png",
                      height: 22,
                      width: 22,
                    ),
                  ), // Upper Deck Handle - Only showing space, no image
                if (deckName == 'Upper Deck')
                  Padding(
                    padding: EdgeInsets.only(left: Get.width * 0.31),
                    child: SizedBox(
                      height: 22,
                      width: 22,
                    ),
                  ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: seatGrid.map((row) {
                    return Column(
                      children: row.map((seat) {
                        bool rotate = seat != null && seat.orientation == 1;
                        print("Seat: $seat, Rotate: $rotate");
                        return seat != null
                            ? Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: Get.width * 0.005,
                                    vertical: Get.height * 0.005),
                                child: SeatWidget(seat: seat),
                              )
                            : Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: Get.width * 0.0,
                                    vertical: Get.height * 0.005),
                                child: SizedBox(
                                  height:
                                      MediaQuery.sizeOf(context).height * 0.08,
                                  width: rotate
                                      ? MediaQuery.of(context).size.width * 0.04
                                      : MediaQuery.of(context).size.width *
                                          0.08,
                                ),
                              ); // Empty space
                      }).toList(),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SeatOnlyWidget extends StatelessWidget {
  final List<List<SeatLayoutList?>> seatGrid;

  SeatOnlyWidget({super.key, required this.seatGrid});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 60),
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        padding: EdgeInsets.zero,
        child: Center(
          child: Container(
            height: MediaQuery.sizeOf(context).height * 0.58,
            width: MediaQuery.sizeOf(context).width * 0.60,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12.r),
              border: Border.all(color: Colors.grey.withOpacity(0.2)),
              color: Colors.white,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: MediaQuery.of(context).size.height * 0.01),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: seatGrid.map((row) {
                      return Column(
                        children: row.map((seat) {
                          return seat != null
                              ? Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: Get.width * 0.01,
                                      vertical: Get.height * 0.0),
                                  child: SeatWidget(seat: seat),
                                )
                              : SizedBox(
                                  height:
                                      MediaQuery.sizeOf(context).height * 0.03,
                                  width:
                                      MediaQuery.of(context).size.width * 0.10,
                                ); // Empty space
                        }).toList(),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SeatWidget extends StatefulWidget {
  final SeatLayoutList seat;

  SeatWidget({super.key, required this.seat});

  @override
  State<SeatWidget> createState() => _SeatWidgetState();
}

class _SeatWidgetState extends State<SeatWidget> {
  OrbitSeatLayOutController controller = Get.put(OrbitSeatLayOutController());

  bool isBouncing = false;

  void onSeatTap() {
    if (widget.seat.seatStatus?.code == "BO") {
      print("Seat Already Booked");
      return;
    }

    // Trigger the bounce animation
    setState(() {
      isBouncing = true;
    });

    // Toggle seat selection
    controller.toggleSeatSelection(widget.seat.seatName!, widget.seat.code!);

    // Reset the bounce animation after a short delay
    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) {
        setState(() {
          isBouncing = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // Determine the seat's color based on its status

    bool hasSeater = controller.busType != null &&
        controller.busType!.toLowerCase().contains("semi sleeper");
    bool isSelected = controller.selectedSeats.contains(widget.seat.seatName);
    Color seatColor;
    if (isSelected) {
      seatColor = Colors.red;
    } else {
      switch (widget.seat.seatStatus?.code) {
        case 'AL': // Available for All
          seatColor = Colors.green;
          break;
        case 'AM': // Available for Male
          seatColor = Colors.blue;
          break;
        case 'AF': // Available for Female
          seatColor = Colors.pink;
          break;
        case 'BO': // Booked
          seatColor = Colors.grey;
          break;
        case 'BL': // Blocked
        case 'SDBL': // Social Distancing Blocked
          seatColor = Colors.grey;
          break;
        default:
          seatColor = Colors.grey;
      }
    }

    // bool isSelected = controller.selectedSeats.contains(seat.seatName);
    // Select the appropriate image based on seat type
    String seatImage = 'assets/Untitled_design-removebg-preview.png';
    switch (widget.seat.busSeatType?.code) {
      case 'SL':
      case 'LSL':
      case 'USL':
        seatImage = (widget.seat.orientation == 0)
            ? 'assets/seats_img/sleeper.svg'
            : 'assets/seats_img/sleeper.svg';
        break;
      case 'RRM':
        seatImage = 'assets/seats_img/image_restroom_.svg';
        break;
      case 'FRS':
        seatImage = 'assets/seats_img/sleeper.svg';
        break;
      default:
        seatImage = 'assets/seats_img/seat.svg';
    }

    // Display the widget
    return InkWell(
      highlightColor: Colors.transparent,
      splashColor: Colors.transparent,
      onTap: /*() {
        if (widget.seat.seatStatus?.code == "BO") {
          print("seat Already Booked");
        } else {
          controller.toggleSeatSelection(widget.seat.seatName!, widget.seat.code!);
        }
      },*/
          onSeatTap,
      child: AnimatedScale(
        scale: isBouncing ? 1.2 : 1.0,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOutBack,
        child: Stack(
          //alignment: Alignment.center,
          children: [
            if (seatImage.isNotEmpty)
              SvgPicture.asset(
                seatImage,
                color: seatColor,
                fit: BoxFit.contain,
                height: seatImage == 'assets/seats_img/sleeper.svg'
                    ? MediaQuery.sizeOf(context).height * 0.08
                    : MediaQuery.sizeOf(context).height * 0.04,
                width: MediaQuery.of(context).size.width * 0.08,
              ),
            /*   if (widget.seat.seatName != null)
              Positioned(
                top: 3,
                child: Text(
                  // '${seat.seatName!}\n(${seat.rowPos}, ${seat.colPos})',
                  '${widget.seat.seatName!}',
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),*/
          ],
        ),
      ),
    );
  }
}
