// To parse this JSON data, do
//
//     final orbitAllBusList = orbitAllBusListFromJson(jsonString);

import 'dart:convert';

OrbitAllBusList orbitAllBusListFromJson(String str) =>
    OrbitAllBusList.fromJson(json.decode(str));

String orbitAllBusListToJson(OrbitAllBusList data) =>
    json.encode(data.toJson());

class OrbitAllBusList {
  int? status;
  DateTime? datetime;
  List<TripType>? data;

  OrbitAllBusList({
    this.status,
    this.datetime,
    this.data,
  });

  factory OrbitAllBusList.fromJson(Map<String, dynamic> json) =>
      OrbitAllBusList(
        status: json["status"],
        datetime: DateTime.parse(json["datetime"]),
        data: json["data"] != null && json["data"] is List
            ? List<TripType>.from(json["data"].map((x) => TripType.fromJson(x)))
            : [], // Default to an empty list if "data" is not a List
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "datetime": datetime!.toIso8601String(),
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
      };
}

class TripType {
  String? tripCode;
  String? scheduleCode;
  String? tripStageCode;
  DateTime? travelDate;
  String? displayName;
  List<StageFare>? stageFare;
  List<int>? fareList;
  int? availableSeatCount;
  String? travelTime;
  Bus? bus;
  Station? fromStation;
  Station? toStation;
  Operator? tripStatus;
  Operator? datumOperator;
  List<Amenity>? amenities;
  List<dynamic>? activities;
  CancellationTerm? cancellationTerm;

  String? serviceNumber;
  int? acBusTax;
  Tax? tax;

  TripType({
    this.tripCode,
    this.scheduleCode,
    this.tripStageCode,
    this.travelDate,
    this.displayName,
    this.stageFare,
    this.fareList,
    this.availableSeatCount,
    this.travelTime,
    this.bus,
    this.fromStation,
    this.toStation,
    this.tripStatus,
    this.datumOperator,
    this.amenities,
    this.activities,
    this.cancellationTerm,
    this.serviceNumber,
    this.acBusTax,
    this.tax,
  });

  factory TripType.fromJson(Map<String, dynamic> json) => TripType(
        tripCode: json["tripCode"] ?? '',
        scheduleCode: json["scheduleCode"] ?? '',
        tripStageCode: json["tripStageCode"] ?? '',
        travelDate: json["travelDate"] != null
            ? DateTime.parse(json["travelDate"])
            : null,
        displayName: json["displayName"] ?? '',
        stageFare: json["stageFare"] != null
            ? List<StageFare>.from(
                json["stageFare"].map((x) => StageFare.fromJson(x)))
            : [],
        fareList: json["fareList"] != null
            ? List<int>.from(json["fareList"].map((x) => x))
            : [],
        availableSeatCount: json["availableSeatCount"] ?? 0,
        travelTime: json["travelTime"] ?? '',
        bus: json["bus"] != null ? Bus.fromJson(json["bus"]) : null,
        fromStation: json["fromStation"] != null
            ? Station.fromJson(json["fromStation"])
            : null,
        toStation: json["toStation"] != null
            ? Station.fromJson(json["toStation"])
            : null,
        tripStatus: json["tripStatus"] != null
            ? Operator.fromJson(json["tripStatus"])
            : null,
        datumOperator: json["operator"] != null
            ? Operator.fromJson(json["operator"])
            : null,
        amenities: json["amenities"] != null
            ? List<Amenity>.from(
                json["amenities"].map((x) => Amenity.fromJson(x)))
            : [],
        activities: json["activities"] != null
            ? List<dynamic>.from(json["activities"].map((x) => x))
            : [],
        cancellationTerm: json["cancellationTerm"] != null
            ? CancellationTerm.fromJson(json["cancellationTerm"])
            : null,
        serviceNumber: json["serviceNumber"] ?? '',
        acBusTax: json["acBusTax"] ?? 0,
        tax: json["tax"] != null ? Tax.fromJson(json["tax"]) : null,
      );

  Map<String, dynamic> toJson() => {
        "tripCode": tripCode ?? '',
        "scheduleCode": scheduleCode ?? '',
        "tripStageCode": tripStageCode ?? '',
        "travelDate": travelDate != null
            ? "${travelDate!.year.toString().padLeft(4, '0')}-${travelDate!.month.toString().padLeft(2, '0')}-${travelDate!.day.toString().padLeft(2, '0')}"
            : '',
        "displayName": displayName ?? '',
        "stageFare":
            List<dynamic>.from(stageFare?.map((x) => x.toJson()) ?? []),
        "fareList": List<dynamic>.from(fareList?.map((x) => x) ?? []),
        "availableSeatCount": availableSeatCount ?? 0,
        "travelTime": travelTime ?? '',
        "bus": bus?.toJson() ?? {},
        "fromStation": fromStation?.toJson() ?? {},
        "toStation": toStation?.toJson() ?? {},
        "tripStatus": tripStatus?.toJson() ?? {},
        "operator": datumOperator?.toJson() ?? {},
        "amenities":
            List<dynamic>.from(amenities?.map((x) => x.toJson()) ?? []),
        "activities": List<dynamic>.from(activities ?? []),
        "cancellationTerm": cancellationTerm?.toJson() ?? {},
        "serviceNumber": serviceNumber ?? '',
        "acBusTax": acBusTax ?? 0,
        "tax": tax?.toJson() ?? {},
      };
}

class Amenity {
  String? code;
  String? name;
  int? activeFlag;

  Amenity({
    this.code,
    this.name,
    this.activeFlag,
  });

  factory Amenity.fromJson(Map<String, dynamic> json) => Amenity(
        code: json["code"] ?? '',
        name: json["name"] ?? '',
        activeFlag: json["activeFlag"] ?? 0,
      );

  Map<String, dynamic> toJson() => {
        "code": code ?? '',
        "name": name ?? '',
        "activeFlag": activeFlag ?? 0,
      };
}

class Bus {
  String? busType;
  String? categoryCode;
  String? displayName;
  String? name;
  int? totalSeatCount;

  Bus({
    this.busType,
    this.categoryCode,
    this.displayName,
    this.name,
    this.totalSeatCount,
  });

  factory Bus.fromJson(Map<String, dynamic> json) => Bus(
        busType: json["busType"],
        categoryCode: json["categoryCode"],
        displayName: json["displayName"],
        name: json["name"],
        totalSeatCount: json["totalSeatCount"],
      );

  Map<String, dynamic> toJson() => {
        "busType": busType,
        "categoryCode": categoryCode,
        "displayName": displayName,
        "name": name,
        "totalSeatCount": totalSeatCount,
      };
}

class CancellationTerm {
  String? code;
  DateTime? datetime;
  int? activeFlag;
  List<PolicyList>? policyList;

  CancellationTerm({
    this.code,
    this.datetime,
    this.activeFlag,
    this.policyList,
  });

  factory CancellationTerm.fromJson(Map<String, dynamic> json) =>
      CancellationTerm(
        code: json["code"],
        datetime: DateTime.parse(json["datetime"]),
        activeFlag: json["activeFlag"],
        policyList: List<PolicyList>.from(
            json["policyList"].map((x) => PolicyList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "datetime": datetime!.toIso8601String(),
        "activeFlag": activeFlag,
        "policyList": List<dynamic>.from(policyList!.map((x) => x.toJson())),
      };
}

class PolicyList {
  String? code;
  int? fromValue;
  int? toValue;
  int? deductionAmount;
  String? policyPattern;
  int? percentageFlag;

  PolicyList({
    this.code,
    this.fromValue,
    this.toValue,
    this.deductionAmount,
    this.policyPattern,
    this.percentageFlag,
  });

  factory PolicyList.fromJson(Map<String, dynamic> json) => PolicyList(
        code: json["code"],
        fromValue: json["fromValue"],
        toValue: json["toValue"],
        deductionAmount: json["deductionAmount"],
        policyPattern: json["policyPattern"],
        percentageFlag: json["percentageFlag"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "fromValue": fromValue,
        "toValue": toValue,
        "deductionAmount": deductionAmount,
        "policyPattern": policyPattern,
        "percentageFlag": percentageFlag,
      };
}

class Operator {
  String? code;
  String? name;

  Operator({
    this.code,
    this.name,
  });

  factory Operator.fromJson(Map<String, dynamic> json) => Operator(
        code: json["code"],
        name: json["name"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "name": name,
      };
}

class Station {
  String? name;
  String? code;
  DateTime? dateTime;
  List<StationPoint>? stationPoint;

  Station({
    this.name,
    this.code,
    this.dateTime,
    this.stationPoint,
  });

  factory Station.fromJson(Map<String, dynamic> json) => Station(
        name: json["name"],
        code: json["code"],
        dateTime: DateTime.parse(json["dateTime"]),
        stationPoint: List<StationPoint>.from(
            json["stationPoint"].map((x) => StationPoint.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "code": code,
        "dateTime": dateTime!.toIso8601String(),
        "stationPoint":
            List<dynamic>.from(stationPoint!.map((x) => x.toJson())),
      };
}

class StationPoint {
  String? code;
  String? name;
  String? latitude;
  String? longitude;
  String? address;
  String? landmark;
  String? number;
  DateTime? dateTime;
  int? additionalFare;
  List<Amenity>? amenities;

  StationPoint({
    this.code,
    this.name,
    this.latitude,
    this.longitude,
    this.address,
    this.landmark,
    this.number,
    this.dateTime,
    this.additionalFare,
    this.amenities,
  });

  factory StationPoint.fromJson(Map<String, dynamic> json) => StationPoint(
        code: json["code"],
        name: json["name"],
        latitude: json["latitude"],
        longitude: json["longitude"],
        address: json["address"],
        landmark: json["landmark"],
        number: json["number"],
        dateTime: DateTime.parse(json["dateTime"]),
        additionalFare: json["additionalFare"],
        amenities: List<Amenity>.from(
            json["amenities"].map((x) => Amenity.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "name": name,
        "latitude": latitude,
        "longitude": longitude,
        "address": address,
        "landmark": landmark,
        "number": number,
        "dateTime": dateTime!.toIso8601String(),
        "additionalFare": additionalFare,
        "amenities": List<dynamic>.from(amenities!.map((x) => x.toJson())),
      };
}

class StageFare {
  int? fare;
  String? seatType;
  String? seatName;
  int? availableSeatCount;

  StageFare({
    this.fare,
    this.seatType,
    this.seatName,
    this.availableSeatCount,
  });

  factory StageFare.fromJson(Map<String, dynamic> json) => StageFare(
        fare: json["fare"],
        seatType: json["seatType"],
        seatName: json["seatName"],
        availableSeatCount: json["availableSeatCount"],
      );

  Map<String, dynamic> toJson() => {
        "fare": fare,
        "seatType": seatType,
        "seatName": seatName,
        "availableSeatCount": availableSeatCount,
      };
}

class Tax {
  double? cgstValue;
  double? sgstValue;
  int? ugstValue;
  int? igstValue;
  String? tradeName;
  String? gstin;

  Tax({
    this.cgstValue,
    this.sgstValue,
    this.ugstValue,
    this.igstValue,
    this.tradeName,
    this.gstin,
  });

  factory Tax.fromJson(Map<String, dynamic> json) => Tax(
    cgstValue: json["cgstValue"] != null ? json["cgstValue"].toDouble() : null,
    sgstValue: json["sgstValue"] != null ? json["sgstValue"].toDouble() : null,
    ugstValue: json["ugstValue"] ?? null,
    igstValue: json["igstValue"] ?? null,
    tradeName: json["tradeName"] ?? '',
    gstin: json["gstin"] ?? '',
      );

  Map<String, dynamic> toJson() => {
        "cgstValue": cgstValue,
        "sgstValue": sgstValue,
        "ugstValue": ugstValue,
        "igstValue": igstValue,
        "tradeName": tradeName,
        "gstin": gstin,
      };
}
