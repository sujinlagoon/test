import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/bus_list/controller.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/orbit_filter_screen/orbit_filter_screen.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/sizes.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';

import '../../both/bothCitiesController.dart';
import '../reuse_widget/custom_chip.dart';
import '../seaatayout_/orbit_seatLayout_controller/orbit_seat_layout_controller.dart';
import '../seaatayout_/orbit_seatLayout_view.dart';
import '../select_source/controller/O_source_destination_controller.dart';
import 'controller/orbit_allBusView_controller.dart';

class OrbitAllBusViewList extends StatelessWidget {
  OrbitAllBusViewList({super.key});

   OSourceDestinationController controller = Get.put(OSourceDestinationController());
  OrbitAllBusListController busListController = Get.put(OrbitAllBusListController());
  OrbitSeatLayOutController layoutController = Get.put(OrbitSeatLayOutController());
  BothCitiesController bothCitiesController = Get.put(BothCitiesController());

  @override
  Widget build(BuildContext context) {
    final List<String> selectedBusTypes = Get.arguments ?? [];
    busListController.selectedBusTypes = selectedBusTypes;
    busListController.filterBusList();
    return WillPopScope(
      onWillPop: () async {
        bothCitiesController.clearLocation();
        Navigator.pop(context);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
              padding: EdgeInsets.zero,
              onPressed: () {
                //  Get.delete<OSourceDestinationController>();
                controller.clearAll();
                bothCitiesController.clearLocation();
                Get.back();
              },
              icon: Icon(Icons.arrow_back_ios_new_outlined)),
          actions: [
            Padding(
              padding: EdgeInsets.only(right: 13.w),
              child: GetBuilder<OrbitAllBusListController>(
                builder: (v) {
                  return Text(
                    v.orbitAllBusList.length == 1
                        ? "${v.filteredBusList.length}Bus"
                        : "${v.filteredBusList.length} Buses",

                  );
                }
              ),
            )
          ],
          // / titleSpacing: 0.0,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    '${controller.fromLocation} - ${controller.toLocation}',
                    style: TextStyle(fontSize: 14.sp),
                  ),
                  SizedBox(
                    width: MediaQuery.sizeOf(context).width * 0.01,
                  ),
                  /*  InkWell(
                    onTap: () {},
                    child: Icon(
                      Icons.edit_outlined,
                      size: 14.sp,
                    ),
                  )*/
                ],
              ),
              SizedBox(
                height: MediaQuery.sizeOf(context).height * 0.01,
              ),
              Text(
                "${DateFormat('EEE, dd MMM').format(controller.oSelectedDate!)}",
                style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.normal),
              )
            ],
          ),
        ),
        body: Column(
          children: [
            SizedBox(
              height: 10.h,
            ),
            GetBuilder<OrbitAllBusListController>(builder: (context) {
              return Row(children: [
                InkWell(
                  onTap: () {
                    Get.to(() => OrbitFilterScreen());
                  },
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        Image.asset(
                          "assets/filter.png",
                          height: 12.h,
                          width: 17.w,
                        ),
                        SizedBox(
                          width: 5.w,
                        ),
                        Text("Filter")
                      ],
                    ),
                  ),
                ),
                GetBuilder<OrbitAllBusListController>(builder: (v) {
                  return Expanded(
                    child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Wrap(
                          children: v.chipLabels.map((label) {
                            return CustomChip(
                              label: label,
                              isSelected: v.selectedBusTypes.contains(label),
                              onTap: () {
                                v.toggleBusTypeSelection(label);
                              },
                              selectedColor: Colors.blue,
                              unselectedColor: Colors.grey[300]!,
                              selectedTextStyle: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                              unselectedTextStyle:
                                  const TextStyle(color: Colors.black),
                            );
                          }).toList(),
                        )),
                  );
                })
              ]);
            }),
            GetBuilder<OrbitAllBusListController>(builder: (v) {
              if (v.isLoading) {
                return Center(child: CircularProgressIndicator());
              }

              return Expanded(
                  child: v.filteredBusList.isEmpty
                      ? /*Center(
                          child: Text(
                            "No buses available in this route",
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                        )*/

                      Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.30,
                              width: MediaQuery.of(context).size.width,
                              child: Lottie.asset(
                                  "assets/lottie/Animation - 1739179385129.json"),
                            ),
                            kHeight10,
                            Text(
                              "No buses Found in this route",
                              style: TextStyle(
                                  fontSize: 20.sp,
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold),
                            ),
                          ],
                        )
                      : ListView.builder(
                          itemCount: v.filteredBusList.length,
                          itemBuilder: (context, index) {
                            var data = v.filteredBusList[index];
                            v.busName = data.bus!.name;
                            v.busType = data.bus!.busType;
                            return Padding(
                              padding: EdgeInsets.all(8.r),
                              child: InkWell(
                                onTap: () async {
                                  bool isSuccess = await layoutController.orbitSeatLayoutApi(
                                    tripCode: data.tripCode,
                                    fromCode: controller.fromLocationCode,
                                    toCode: controller.toLocationCode,
                                    selectedDate: controller.oSelectedDate,
                                  );

                                  if (isSuccess) {
                                    Get.to(() => OrbitSeatLayoutView(
                                          busname: data.bus!.name,
                                          busType: data.bus!.busType,
                                          selectDate: controller.oSelectedDate,
                                          fromLocationCode:
                                              data.fromStation!.code,
                                          toLocationCode: data.toStation!.code,
                                          tripCode: data.tripCode,
                                          toLocation: controller.toLocation,
                                          fromLocation: controller.fromLocation,
                                        ));
                                  } else {
                                    // Optionally show an error message or handle the failed scenario
                                    Get.snackbar(
                                      "",
                                      "${layoutController.errorDesc}",
                                      snackPosition: SnackPosition.BOTTOM,
                                      backgroundColor: Colors.redAccent,
                                      colorText: Colors.white,
                                    );
                                  }

                                },
                                child: OrBitBusCard(
                                  companyName: data.bus!.name!,
                                  rating: 2,
                                  busType: data.bus!.busType!,
                                  departureTime: data.fromStation!.dateTime!
                                      .toIso8601String(),
                                  arrivalTime:
                                      data.toStation!.dateTime!.toIso8601String(),
                                  duration: '',
                                  price: data.fareList,
                                  seatsLeft: data.availableSeatCount!,
                                  onDetailsPressed: () async {
                                    bool isSuccess =
                                        await layoutController.orbitSeatLayoutApi(
                                      tripCode: data.tripCode,
                                      fromCode: controller.fromLocationCode,
                                      toCode: controller.toLocationCode,
                                      selectedDate: controller.oSelectedDate,
                                    );

                                    if (isSuccess) {
                                      Get.to(() => OrbitSeatLayoutView(
                                            busname: data.bus!.name,
                                            busType: data.bus!.busType,
                                            selectDate: controller.oSelectedDate,
                                            fromLocationCode:
                                                data.fromStation!.code,
                                            toLocationCode: data.toStation!.code,
                                            tripCode: data.tripCode,
                                            toLocation: controller.fromLocation,
                                            fromLocation: controller.toLocation,
                                          ));
                                    } else {
                                      // Optionally show an error message or handle the failed scenario
                                      Get.snackbar(
                                        "",
                                        "${layoutController.errorDesc}",
                                        snackPosition: SnackPosition.BOTTOM,
                                        backgroundColor: Colors.redAccent,
                                        colorText: Colors.white,
                                      );
                                    }
                                  },
                                ),
                              ),
                            );
                          }) /*:Center(
                  child: Text(
                    "No buses available in this route",
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ),*/
                  );
            })
          ],
        ),
      ),
    );
  }
}

class OrBitBusCard extends StatelessWidget {
  final String companyName;
  final double rating;
  final String busType;
  final String departureTime;
  final String arrivalTime;

  final String duration;
  final dynamic price;
  final int seatsLeft;
  final VoidCallback onDetailsPressed;

  const OrBitBusCard({
    Key? key,
    required this.companyName,
    required this.rating,
    required this.busType,
    required this.departureTime,
    required this.arrivalTime,
    required this.duration,
    required this.price,
    required this.seatsLeft,
    required this.onDetailsPressed,
  }) : super(key: key);

  String formatTime(String time) {
    try {
      DateTime dateTime = DateTime.parse(time);
      return DateFormat('h:mm a').format(dateTime);
    } catch (e) {
      return time;
    }
  }

  String calculateDuration(String departure, String arrival) {
    try {
      DateTime depTime = DateTime.parse(departure);
      DateTime arrTime = DateTime.parse(arrival);
      Duration duration = arrTime.difference(depTime);

      // Convert duration to hours and minutes
      int hours = duration.inHours;
      int minutes = duration.inMinutes.remainder(60);

      return '${hours}h ${minutes}m';
    } catch (e) {
      return "Invalid time";
    }
  }

  @override
  Widget build(BuildContext context) {
    final duration = calculateDuration(departureTime, arrivalTime);
    return Container(
        decoration: BoxDecoration(
            border: Border.all(color: Colors.black, width: 0.2),
            borderRadius: BorderRadius.circular(6)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Company Name and Rating Section
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    companyName,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(1),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.star, color: Colors.white, size: 16),
                        const SizedBox(width: 4),
                        Text(
                          rating.toString(),
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              // Bus Type Section
              Text(
                busType,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 10.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text:
                              '(${formatTime(departureTime)} - ${formatTime(arrivalTime)})  ',
                          style: TextStyle(
                            fontSize: 13.sp,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TextSpan(
                          text: '($duration)',
                          style: TextStyle(
                            fontSize: 13.sp,
                            color: Colors.grey,
                            fontWeight: FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    price == null
                        ? 'Price not available'
                        : price is List && price.isNotEmpty
                            ? '₹ ${price.first}' // Display only the first value
                            : '₹ $price',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '$seatsLeft Seats Left',
                    style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                      color: seatsLeft > 5 ? Colors.green : Colors.red,
                    ),
                  ),
                  TextButton(
                    onPressed: onDetailsPressed,
                    style: TextButton.styleFrom(
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'Bus Details',
                      style: TextStyle(
                        color: Colors.blue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ));
  }
}
