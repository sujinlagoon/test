import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../modal/orbit_allBusListView-modal.dart';
import '../orbit_allBusListView_.dart';

class OrbitAllBusListController extends GetxController {
  List<TripType> orbitAllBusList = [];
  List<StationPoint> fromStation = [];
  List<StationPoint> toStation = [];
  RangeValues selectedPriceRange = RangeValues(0, 0);

  List<String> chipLabels = [
    "All",
    "A/C",
    "Non A/C",
    "Sleeper",
    "Semi Sleeper"
  ];
  String selectedChip = "All";
  DateTime? fromTime;
  DateTime? toTime;
  String? busName;
  String? busType;
  bool isDroppingTabActive = false;
  bool isExpanded = false;
  String? tripCode;
  bool isLoading = false;
  TabController? tabController;

  List<String> selectedBusTypes = [];

  getOrbitAllBusListApi(
      {String? fomCode, String? toCode, DateTime? selectedDate}) async {
    try {
      isLoading = true;
      update();

      String formattedDate = DateFormat('yyyy-MM-dd').format(selectedDate!);
      var url =
          'http://staging.busticketagent.com/orbitservices/api/1.0/json/orbit/devapiuser/85838253YLGF049ZMF731A10YH814/search/$fomCode/$toCode/$formattedDate';
      var res = await http.get(Uri.parse(url));
      print("API Response Status Code: ${res.statusCode}");

      if (res.statusCode == 200) {
        var data = orbitAllBusListFromJson(res.body);
        print("---------------------r-${data.toJson()}");
        if (data.data != null && data.data!.isNotEmpty) {
          orbitAllBusList = data.data!;
          fromStation = orbitAllBusList.first.fromStation?.stationPoint ?? [];
          toStation = orbitAllBusList.first.toStation?.stationPoint ?? [];
          print(fromStation);
          print(toStation);
        } else {
          orbitAllBusList = [];
        }
        filterBusList();
        update();
        Get.to(() => OrbitAllBusViewList());
        /*  if (orbitAllBusList.isEmpty) {

          print("No buses available.");
        } else {
          Get.to(() => OrbitAllBusViewList());
          print("Bus List: $orbitAllBusList");
        }*/
      } else {
        print("Failed to fetch data. Status code: ${res.statusCode}");
      }
    } catch (e) {
      debugPrint(e.toString());
    }

    isLoading = false;
    update();
  }

  int? fromSelectedIndex;
  String? fromSelectedId;

  int? toSelectedIndex;
  String? toSelectedId;

  void updateFromStationPoint(int? selectedIndex) {
    fromSelectedIndex = selectedIndex;
    fromSelectedId = fromStation[selectedIndex!].code;
    fromTime = fromStation[selectedIndex].dateTime;
    update();
    if (tabController!.index != 1) {
      tabController!.animateTo(1);
    }
    update();
    print("Selected Boarding Point ID: $fromSelectedId");
  }

  void updateToStationPoint(int? selectedIndex) {
    toSelectedIndex = selectedIndex;
    toSelectedId = toStation[selectedIndex!].code;
    toTime = toStation[selectedIndex].dateTime;
    update();
    print("Selected Dropping Point ID: $toSelectedId");
  }

  List<TripType> filteredBusList = [];

  filterBusList() {
    // Start with all buses
    filteredBusList = orbitAllBusList;

    // Filter based on selected bus types
    if (selectedBusTypes.contains("A/C")) {
      filteredBusList = filteredBusList
          .where((bus) => bus.bus!.busType!.contains("A/C"))
          .toList();
    }

    if (selectedBusTypes.contains("Semi Sleeper")) {
      filteredBusList = filteredBusList
          .where((bus) => bus.bus!.busType!.contains("Semi Sleeper"))
          .toList();
    }

    // Check if "Non A/C" is selected
    if (selectedBusTypes.contains("Non A/C")) {
      filteredBusList = filteredBusList
          .where((bus) => bus.bus!.busType!.contains("Non A/C"))
          .toList();
    }

    // Check if "A/C" buses are selected
    if (selectedBusTypes.contains("A/C")) {
      filteredBusList = filteredBusList
          .where((bus) => bus.bus!.busType!.contains("A/C"))
          .toList();
    }

    // Additional filtering logic for other bus types like "Seater", "Sleeper"
    if (selectedBusTypes.isNotEmpty && !selectedBusTypes.contains("All")) {
      filteredBusList = filteredBusList
          .where((bus) => selectedBusTypes
              .every((type) => bus.bus!.busType!.contains(type)))
          .toList();
    }

    // Filter by available seats
    filteredBusList = filteredBusList.where((bus) {
      // Ensure there are available seats (greater than 0)
      return bus.stageFare!.any((fare) => fare.availableSeatCount! > 0);
    }).toList();
    // Update the UI only if the filtered list is not empty

sortBusList();


    findMinMax();

    if (filteredBusList.isNotEmpty) {
     // update();
    }
  }

  void toggleBusTypeSelection(String busType) {
    if (busType == "All") {
      selectedBusTypes.clear();
      selectedBusTypes.add("All");
    } else {
      selectedBusTypes.remove("All");
      if (selectedBusTypes.contains(busType)) {
        selectedBusTypes.remove(busType);
      } else {
        selectedBusTypes.add(busType);
      }
      if (selectedBusTypes.isEmpty) {
        selectedBusTypes.add("All");
      }
    }

    Future.delayed(Duration(milliseconds: 100), () {
      filterBusList();
    });

    update();
  }

  String selectedSortingOption = "Low to High";

  void sortBusList() {
    if (selectedSortingOption == "Low to High") {
      filteredBusList.sort((a, b) {
        return a.stageFare!.first.fare!.compareTo(b.stageFare!.first.fare!);
      });
    } else if (selectedSortingOption == "High to Low") {
      filteredBusList.sort((a, b) {
        return b.stageFare!.first.fare!.compareTo(a.stageFare!.first.fare!);
      });
    }

  }

  int minFare = 0;
  int maxFare = 0;
  void findMinMax() {
    if (filteredBusList.isNotEmpty) {
      minFare = filteredBusList[0].fareList?.reduce((a, b) => a < b ? a : b) ?? 0;
      maxFare = filteredBusList[0].fareList?.reduce((a, b) => a > b ? a : b) ?? 0;

      for (var bus in filteredBusList) {
        if (bus.fareList != null && bus.fareList!.isNotEmpty) {
          minFare = bus.fareList!.reduce((a, b) => a < b ? a : b) < minFare
              ? bus.fareList!.reduce((a, b) => a < b ? a : b)
              : minFare;
          maxFare = bus.fareList!.reduce((a, b) => a > b ? a : b) > maxFare
              ? bus.fareList!.reduce((a, b) => a > b ? a : b)
              : maxFare;
        }
      }

      selectedPriceRange = RangeValues(minFare.toDouble(), maxFare.toDouble());
      //update();
    }
  }
  void setPriceRange(double min, double max) {
    selectedPriceRange = RangeValues(min, max);
    filteredBusList = orbitAllBusList.where((bus) {
      double busFare = bus.stageFare!.first.fare!.toDouble();
      return busFare >= min && busFare <= max;
    }).toList();


    update();
  }
/*  findMinMax() {
    minFare = filteredBusList[0].fareList?.reduce((a, b) => a < b ? a : b) ?? 0;
    maxFare = filteredBusList[0].fareList?.reduce((a, b) => a > b ? a : b) ?? 0;
    for (var bus in filteredBusList) {
      if (bus.fareList != null && bus.fareList!.isNotEmpty) {
        minFare = bus.fareList!.reduce((a, b) => a < b ? a : b) < minFare ? bus.fareList!.reduce((a, b) => a < b ? a : b) : minFare;
        maxFare = bus.fareList!.reduce((a, b) => a > b ? a : b) > maxFare ? bus.fareList!.reduce((a, b) => a > b ? a : b) : maxFare;
      }
    }
    update();
  }*/
 /* void setPriceRange(double min, double max) {
    minFare = min.toInt();
    maxFare = max.toInt();
    filterBusList();

  }*/

/*void toggleBusTypeSelection(String busType) {
    if (selectedBusTypes.contains(busType)) {
      selectedBusTypes.remove(busType);
    } else {
      selectedBusTypes.add(busType);
    }
    Future.delayed(Duration(milliseconds: 100), () {
      filterBusList();
    });
    update();
  }*/
}
