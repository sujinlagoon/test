import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/sizes.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../orbit_allBuslistView/controller/orbit_allBusView_controller.dart';

class OrbitFilterScreen extends StatelessWidget {
  OrbitFilterScreen({super.key});

  OrbitAllBusListController busListController =
      Get.put(OrbitAllBusListController());
  final Map<String, String> busTypeImages = {
    "A/C": "assets/filter/ac.png",
    "Non A/C": "assets/filter/non_ac.png",
    "Semi Sleeper": "assets/filter/armchair (1).png",
    "Sleeper": "assets/filter/sleeper.png",
  };

  @override
  Widget build(BuildContext context) {
    print(busListController.minFare);
    print(busListController.maxFare);

    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
          backgroundColor: Colors.blue,
          onPressed: () {
            Get.back(result: busListController.selectedBusTypes);
          },
          label: Center(
            child: Text(
              "Apply Filters",
              style: TextStyle(color: Colors.black, fontSize: 12.sp),
            ),
          )),
      appBar: AppBar(
        title: Text(
          "Filter Screen",
          style: TextStyle(color: Colors.white),
        ),
        leading: IconButton(
            onPressed: () {
              Get.back(result: busListController.selectedBusTypes);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            )),
        backgroundColor: Colors.blue,
      ),
      body: GetBuilder<OrbitAllBusListController>(builder: (v) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          child: Column(
            children: [
              kHeight5,
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Select Preferred Bus Type",
                    style: TextStyle(color: Colors.black, fontSize: 17.sp),
                  ),
                ),
              ),
              kHeight10,
              Container(
                height: 90.h,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: Colors.white,
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: v.chipLabels
                          .where((type) => type != "All")
                          .map((type) {
                        return GetBuilder<OrbitAllBusListController>(
                          builder: (context) {
                            return InkWell(
                              onTap: () {
                                v.toggleBusTypeSelection(type);
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(4.0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      height: 60.h,
                                      width: 65.w,
                                      decoration: BoxDecoration(
                                        border: Border.all(color: Colors.blue),
                                        color: v.selectedBusTypes.contains(type)
                                            ? Colors.blue
                                            : Colors.white,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Container(
                                        height: type == "Semi Sleeper"
                                            ? 45.h
                                            : 30.h,
                                        width: type == "Semi Sleeper"
                                            ? 55.w
                                            : 30.w,
                                        child: Image.asset(
                                          busTypeImages[type] ??
                                              'assets/images/default_bus.png',
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                    ),
                                    kHeight5,
                                    Text(
                                      type,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.bold,
                                        color: v.selectedBusTypes.contains(type)
                                            ? Colors.black
                                            : Colors.black,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),
              kHeight15,
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Select Preferred Price Range",
                    style: TextStyle(color: Colors.black, fontSize: 17.sp),
                  ),
                ),
              ),
              kHeight15,
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    sortingButton(
                      context,
                      "Low to High",
                      v.selectedSortingOption == "Low to High",
                      () {
                        v.selectedSortingOption = "Low to High";
                        v.sortBusList();
                        v.update();
                      },
                    ),
                    sortingButton(
                      context,
                      "High to Low",
                      v.selectedSortingOption == "High to Low",
                      () {
                        v.selectedSortingOption = "High to Low";
                        v.sortBusList();
                        v.update();
                      },
                    ),
                  ],
                ),
              ),
              kHeight20,
              // Price Range Slider
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Select Price Range",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    kHeight10,
                    RangeSlider(
                      min: busListController.minFare.toDouble(),
                      max: busListController.maxFare.toDouble(),
                      divisions: 100,
                      labels: RangeLabels(
                        '\$${busListController.selectedPriceRange.start.toStringAsFixed(0)}',
                        '\$${busListController.selectedPriceRange.end.toStringAsFixed(0)}',
                      ),
                      values: busListController.selectedPriceRange,
                      onChanged: (RangeValues values) {
                        busListController.setPriceRange(values.start, values.end);
                      },
                    ),

                  ],
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}

Widget sortingButton(
  BuildContext context,
  String label,
  bool isSelected,
  VoidCallback onTap,
) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 20.w),
      decoration: BoxDecoration(
        color: isSelected ? Colors.blue : Colors.white,
        border: Border.all(color: Colors.blue),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.blue,
          fontSize: 14.sp,
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
  );
}

Widget customType(
  BuildContext context, {
  // String? imageUrl,
  String? typeName,
}) {
  return Container(
    height: 45.h,
    width: 40.w,
    decoration: BoxDecoration(border: Border.all(color: Colors.blue)),
    child: Column(
      children: [
        //    Image.asset(imageUrl ?? ''),
        kHeight5,
        Text(
          typeName ?? '',
          style: TextStyle(fontSize: 10.sp, color: Colors.black),
        )
      ],
    ),
  );
}
