import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:fluttertickect365/presentation/utils/AppConstants.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import '../../../SharedPref/sharedPref.dart';

class OrbitReviewBookingController extends GetxController {
  bool isPanelOpen = false;
  TextEditingController contactCT = TextEditingController();
  TextEditingController emailCT = TextEditingController();
  var selectedOffer = '';
  bool isLoading = false;
  String ?bookingCode;
  Future<bool> confirmBooking(String blockKey) async {
    try {
      isLoading = true;
      update();
      String url =
          'https://ticketapp365.akprojects.co/api/orbit/bus/OrbitConfirmTicket';
      String? token = await sharedPrefer().getToken();

      if (token == null) {
        print("Error: Token is null.");
        isLoading = false;
        update();
        return false;
      }

      var request = http.MultipartRequest('POST', Uri.parse(url));

      request.headers.addAll({
        'Authorization': 'Bearer $token',
        'Content-Type': 'multipart/form-data',
      });

      request.fields['blockKey'] = blockKey;
      print("Request Fields: ${request.fields}");

      http.StreamedResponse response = await request.send();

      if (response.statusCode == 200) {
        String responseBody = await response.stream.bytesToString();
        print("Response: $responseBody");
        var data = jsonDecode(responseBody);
         bookingCode = data["data"]["data"]["code"];
         print(bookingCode);
         isLoading = false;
        update();

        if (data["status"] == true) {
          print("Booking Confirmed Successfully!");
          return true;
        } else {
          print("Failed to confirm booking: ${data["message"]}");
          return false;
        }
      } else {
        print("Error: ${response.statusCode}");
        isLoading = false;
        update();
        return false;
      }
    } catch (e) {
      print("Exception: $e");
      isLoading = false;
      update();
      return false;
    }
  }
}
