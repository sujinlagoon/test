import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/OrbitReviewBooking/orbit_review_controller/orbit_review_booking_controller.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/orbit_addPassenger_details/modal.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/customBottomSheet.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/seaatayout_/orbit_seatLayout_controller/orbit_seat_layout_controller.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';

import '../../../presentation/cab_homepage_screen/BusTabPage.dart';
import '../../../presentation/cab_homepage_screen/apiModel/HomePage.dart';
import '../../../presentation/cab_homepage_screen/cab_homepage_screen.dart';
import '../../Screens/ReviewBooking/reviewBooking_view.dart';
import '../../Screens/TicketDetails/TicketDetails_view.dart';
import '../../Screens/utils/textField_custom.dart';
import '../../customBus_details.dart';
import '../../customButton.dart';
import '../orbit_addPassenger_details/orbit_passenger_cntroller/orbit_addPassenger_controller.dart';
import '../orbit_allBuslistView/controller/orbit_allBusView_controller.dart';
import '../orbit_ticket_details_view/ticket_details_view.dart';

class OrbitReviewBookingView extends StatefulWidget {
  List<String>? selectedSeats;
  List<String>? selectSeatCode;
  double? fare;
  DateTime selectedDate;
  String? fromLocation;
  String? toLocation;
  List<OrbitPassenger>? selectedPassengers;
  List<int> ages;
  String? busName;
  String? boardingPoint;
  String? droppingPoint;
  List<String>? names;
  List<String>? sex;

  OrbitReviewBookingView(
      {super.key,
      this.selectedSeats,
      this.fromLocation,
      this.selectedPassengers,
      this.toLocation,
      this.selectSeatCode,
      this.fare,
      required this.selectedDate,
      required this.ages,
      this.droppingPoint,
      this.boardingPoint,
      this.names,
      this.sex,
      required this.busName});

  @override
  State<OrbitReviewBookingView> createState() => _OrbitReviewBookingViewState();
}

class _OrbitReviewBookingViewState extends State<OrbitReviewBookingView> {
  OrbitAddPassengerController controller =
      Get.put(OrbitAddPassengerController());
  OrbitReviewBookingController vv = Get.put(OrbitReviewBookingController());
  OrbitAllBusListController busListController =
      Get.put(OrbitAllBusListController());
  OrbitSeatLayOutController lay = Get.put(OrbitSeatLayOutController());

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: ()async{
        bool shouldPop = await _showConfirmationDialog(context);
        return shouldPop;      },
      child: Scaffold(
        bottomSheet: GetBuilder<OrbitReviewBookingController>(
          builder: (v) {
            return CustomBottomSheet(
                isLoading: v.isLoading,
                seatNames: widget.selectedSeats ?? [],
                totalFare: widget.fare ?? 0.0,
                onNext: () async {
                  bool isSuccess = await vv.confirmBooking(controller.ticketCode!);
                  if (isSuccess) {
                    showDialog(
                      context: context,
                      barrierDismissible: false,
                      builder: (context) {
                        return WillPopScope(
                          onWillPop: () async {
                            return false;
                          },
                          child: AlertDialog(
                            content: Container(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Lottie.asset("assets/lottie/8fw2wa1zjV.json"),
                                  SizedBox(height: 10),
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: 16),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("Booking Successful",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold)),
                                        SizedBox(height: 8),
                                        Text(
                                          "Congratulations! Your ticket is confirmed.",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(fontSize: 16),
                                        ),
                                        SizedBox(
                                          height: MediaQuery.of(context).size.height *
                                              0.01,
                                        ),
                                        InkWell(
                                          onTap: () {
                                            Get.to(() => OrbitTicketDetailsView(
                                                  toLocation: widget.toLocation,
                                                  fromLocation: widget.fromLocation,
                                                  selectedDate: widget.selectedDate,
                                                  ages: widget.ages,
                                                  busRate: widget.fare,
                                                  busName: widget.busName,
                                                  boardingPoint: widget.boardingPoint,
                                                  droppingPoint: widget.droppingPoint,
                                                  //  fromTime: widget.fromTime,
                                                  names: widget.names,
                                                  sex: widget.sex,

                                                  ///  toTime: widget.toTime,
                                                  selectedIndexes:
                                                      widget.selectedPassengers,
                                                  selectedSeatNames:
                                                      widget.selectedSeats,
                                                ));
                                          },
                                          child: Container(
                                            height:
                                                MediaQuery.of(context).size.height *
                                                    0.04,
                                            width: Get.width * 0.30,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(12.r),
                                              gradient: LinearGradient(
                                                colors: [
                                                  Color(0xFF4181FF),
                                                  Color(0xFF274E99)
                                                ],
                                                begin: Alignment.centerLeft,
                                                end: Alignment.centerRight,
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                "View E-Tickets",
                                                style: TextStyle(color: Colors.black),
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          height: MediaQuery.of(context).size.height *
                                              0.02,
                                        ),
                                        InkWell(
                                          onTap: () {},
                                          child: CustomButton(
                                            text: "Back to Home",
                                            onTap: () {
                                              Get.offAll(CabHomepageScreen(),
                                                  transition: Transition.fade);
                                            },
                                          ),
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Something went wrong. Please try again.'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                });
          }
        ),
        backgroundColor: Colors.white,
        appBar: AppBar(
          elevation: 0,
          title: Text("Review Booking"),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  //  customBusDetails(context),
                  GetBuilder<OrbitSeatLayOutController>(builder: (v) {
                    print("${v.fromTime!.toIso8601String()}");
                    return SizedBox();
                    // return CustomBusDetails(
                    //   toLocation: widget.toLocation,
                    //   fromLocation: widget.fromLocation,
                    //   fromTime: v.fromTime!.toIso8601String(),
                    //   toTime: v.toTime!.toIso8601String(),
                    //   busName: v.busName,
                    // );
                  }),

                  const SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    child: GetBuilder<OrbitAddPassengerController>(builder: (v) {
                      return ListView.builder(
                        shrinkWrap: true,
                        itemCount: widget.selectedPassengers!.length,
                        // Use the selected indexes count
                        itemBuilder: (context, index) {
                          final passenger = v.passengers[index];
                          print("orbitAge${passenger.age}");
                          return Padding(
                              padding: const EdgeInsets.all(3.0),
                              child: PassengerDetails(
                                context,
                                passengerName: passenger.name,
                                age: passenger.age,
                                seatNo: widget.selectedSeats![index],
                                index: index,
                              ));
                        },
                      );
                    }),
                  ),
                  /*     const SizedBox(
                    height: 10,
                  ),
                  Container(
                    padding: const EdgeInsets.all(13),
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 0.2),
                        borderRadius: BorderRadius.circular(12)),
                    child: Column(
                      children: [
                        const Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              "Enter Contact Details to get Ticket",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                            )),
                        const SizedBox(
                          height: 15,
                        ),
                        customTextField(context,
                            textInputType: TextInputType.number,
                            controller: vv.contactCT,
                            maxLength: 10,
                            labelText: "Mobile Number",
                            labelStyle: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(
                          height: 15,
                        ),
                        customTextField(context,
                            textInputType: TextInputType.emailAddress,
                            controller: vv.emailCT,
                            labelStyle: TextStyle(
                                color: Colors.black, fontWeight: FontWeight.bold),
                            labelText: "Email ID"),
                      ],
                    ),
                  ),*/
                /*  const SizedBox(
                    height: 15,
                  ),
                  GetBuilder<OrbitReviewBookingController>(builder: (v) {
                    return Container(
                      padding: EdgeInsets.all(13),
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey, width: 0.2),
                          borderRadius: BorderRadius.circular(12)),
                      child: Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 35.w),
                            child: Align(
                              child: Text(
                                "Offers",
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                              alignment: Alignment.topLeft,
                            ),
                          ),
                          SizedBox(
                            height: 3.h,
                          ),
                          OfferCard(
                            groupValue: v.selectedOffer,
                            onChanged: (value) {
                              v.selectedOffer = value!;
                              v.update();
                            },
                            title: 'TRANZKINGBUS',
                            description:
                                'Avail Rs. 100 instant discount on bus ticket booking.',
                          ),
                          const SizedBox(height: 16),
                          OfferCard(
                            groupValue: v.selectedOffer,
                            onChanged: (value) {
                              v.selectedOffer = value!;
                              v.update();
                            },
                            title: 'BOTBUS',
                            description:
                                'Avail Rs. 100 instant discount on bus ticket booking.',
                          ),
                          const SizedBox(height: 16),
                        ],
                      ),
                    );
                  }),*/
                  const SizedBox(
                    height: 10,
                  ),
                  GetBuilder<OrbitReviewBookingController>(builder: (v) {
                    return ExpansionPanelList(
                      animationDuration: Duration(milliseconds: 500),
                      expansionCallback: (int index, bool isExpanded) {
                        v.isPanelOpen = isExpanded;
                        print(v.isPanelOpen);
                        v.update();
                      },
                      children: [
                        ExpansionPanel(
                          headerBuilder: (BuildContext context, bool isExpanded) {
                            return Container(
                              decoration:
                                  const BoxDecoration(color: Colors.white),
                              padding: const EdgeInsets.symmetric(
                                  vertical: 16, horizontal: 8),
                              // Optional padding
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                // Aligns to the left
                                crossAxisAlignment: CrossAxisAlignment.center,
                                // Centers vertically
                                children: [
                                  Text(
                                    "Cancellation Policy",
                                    style: TextStyle(
                                        fontSize: 16.sp,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            );
                          },
                          body: const Column(
                            children: [
                              Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Text(
                                    "Our cancellation policy ensures fairness and transparency for all customers. Cancellations made more than 24 hours before the scheduled departure are eligible for a full refund, while those made within 12-24 hours will incur a 50% cancellation fee. Unfortunately, cancellations made less than 12 hours before departure or no-shows are non-refundable. Refunds will be processed within 5-7 business days. In case of service disruptions due to unforeseen circumstances, a full refund will be provided. For assistance, please reach out to our support team."),
                              )
                            ],
                          ),
                          backgroundColor: Colors.white,
                          isExpanded: v.isPanelOpen,
                        ),
                      ],
                    );
                  }),
                  SizedBox(
                    height: 100,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void showEditPassengerDialog(
    BuildContext context, {
    required int index,
    required String passengerName,
    required int age,
  }) {
    TextEditingController nameController =
        TextEditingController(text: passengerName);
    TextEditingController ageController =
        TextEditingController(text: age.toString());

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Edit Passenger Details"),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Name TextField
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: "Name"),
              ),
              // Age TextField
              TextField(
                controller: ageController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: "Age"),
              ),
            ],
          ),
          actions: [
            // Cancel Button
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text("Cancel"),
            ),
            // Save Button
            GetBuilder<OrbitAddPassengerController>(builder: (v) {
              return TextButton(
                onPressed: () {
                  String updatedName = nameController.text;
                  int updatedAge = int.tryParse(ageController.text) ?? age;
                  v.updatePassengerDetails(index, updatedName, updatedAge);
                  print(updatedAge);
                  v.update();
                  Navigator.of(context).pop();
                },
                child: Text("Save"),
              );
            }),
          ],
        );
      },
    );
  }

  Widget PassengerDetails(
    BuildContext context, {
    String? passengerName,
    int? age,
    String? seatNo,
    int? index,
  }) {
    return Container(
        padding: EdgeInsets.all(8),
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.2),
            borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Passenger Details",
                  style: TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold),
                ),
                GetBuilder<OrbitAddPassengerController>(builder: (v) {
                  return InkWell(
                      onTap: () {
                        print(passengerName);
                        showEditPassengerDialog(
                          context,
                          index: index!,
                          passengerName: passengerName!,
                          age: age!,
                        );
                      },
                      child: Text(
                        "Edit",
                        style: TextStyle(color: Colors.blue, fontSize: 16),
                      ));
                }),
              ],
            ),
            const SizedBox(
              height: 12,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Mr. ${passengerName}',
                  style: const TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold),
                ),
                Text(
                  '$age yrs | seat $seatNo',
                  style: const TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ],
            )
          ],
        ));
  }

  Future<bool> _showConfirmationDialog(BuildContext context) async {
    return await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Are you sure?"),
          content: Text(
            "You are about to cancel the seat. Your seat is already blocked. If you go back, you cannot book the seat again for the next 10 minutes.",
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false);

                Fluttertoast.showToast(
                  msg: "Your seat is blocked for the next 10 minutes!",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.TOP,
                  backgroundColor: Colors.red,
                  textColor: Colors.white,
                  fontSize: 16.0,
                );
              },
              child: Text("Stay Here"),
            ),
            TextButton(
              onPressed: () {
              Get.off(()=>AppointmentView());
              },
              child: Text("Cancel Seat"),
            ),
          ],
        );
      },
    ) ??
        false;
  }
}
