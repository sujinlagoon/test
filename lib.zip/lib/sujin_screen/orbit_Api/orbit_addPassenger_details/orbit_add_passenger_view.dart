import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/Screens/utils/textField_custom.dart';
import 'package:fluttertickect365/sujin_screen/both/bothCitiesController.dart';
import 'package:fluttertickect365/sujin_screen/customButton.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/customBottomSheet.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/sizes.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/seaatayout_/orbit_seatLayout_controller/orbit_seat_layout_controller.dart';
import 'package:get/get.dart';
import '../../Profile/profile__controller.dart';
import '../../Screens/Address/address_view.dart';
import '../OrbitReviewBooking/orbit_review_booking_View.dart';
import '../orbit_allBuslistView/controller/orbit_allBusView_controller.dart';
import '../select_source/controller/O_source_destination_controller.dart';
import 'modal.dart';
import 'orbit_passenger_cntroller/orbit_addPassenger_controller.dart';

class OrbitAddPassengerView extends StatefulWidget {
  List<String>? selectedSeats;
  double? fare;
  String? fromLocation;
  String? toLocation;
  List<String>? selectedSeatCode;
  String? tripCode;
  List<double>? seatFareList = [];
  String? fromLocationCode;
  String? toLocationCode;
  DateTime? selectDate;
  String? busType;
  String? busname;
  String? boardingPoint;
  String? droppingPoint;

//
  String? fromLocationCodeCommon;
  String? toLocationCodeCommon;
  String? fromLocationNameCommon;
  String? toLocationNameCommon;

  OrbitAddPassengerView({
    super.key,
    this.fromLocation,
    this.toLocation,
    this.selectedSeats,
    this.selectedSeatCode,
    this.tripCode,
    this.seatFareList,
    this.selectDate,
    this.toLocationCode,
    this.fromLocationCode,
    this.busType,
    this.busname,
    this.fare,
    this.boardingPoint,
    this.droppingPoint,
    //
    this.fromLocationCodeCommon,
    this.toLocationCodeCommon,
    this.toLocationNameCommon,
    this.fromLocationNameCommon,
  });

  @override
  State<OrbitAddPassengerView> createState() => _OrbitAddPassengerViewState();
}

class _OrbitAddPassengerViewState extends State<OrbitAddPassengerView> {
  OrbitAddPassengerController _controller =
      Get.put(OrbitAddPassengerController());
  ProfileController controller = Get.find<ProfileController>();
  BothCitiesController bothCitiesController = Get.put(BothCitiesController());
  OSourceDestinationController v = Get.put(OSourceDestinationController());
  OrbitSeatLayOutController zz = Get.put(OrbitSeatLayOutController());

  int? setIndex;
  OrbitPassenger? orbit;

  @override
  void initState() {
    // TODO: implement initState
    _controller.emailCT.text = controller.profile?.data.userMail ?? "";
    _controller.phoneNumberCT.text = controller.profile?.data.userPhone ?? "";
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print(widget.boardingPoint);
    print(widget.droppingPoint);
    return Scaffold(
      bottomSheet: GetBuilder<OrbitAddPassengerController>(builder: (vv) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 90.h,
              width: double.infinity,
              decoration: BoxDecoration(
                border:
                    Border(top: BorderSide(color: Colors.black, width: 0.6)),
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
              ),
              child: GetBuilder<ProfileController>(builder: (v) {
                return Column(
                  children: [
                    kHeight5,
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Booking Details will be sent to",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 15.sp,
                                fontWeight: FontWeight.w700),
                            textAlign: TextAlign.center,
                          ),
                          IconButton(
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                            onPressed: () {
                              showModalBottomSheet(
                                context: context,
                                isScrollControlled: true,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.vertical(
                                      top: Radius.circular(16)),
                                ),
                                builder: (context) {
                                  return Padding(
                                    padding: EdgeInsets.only(
                                      bottom: MediaQuery.of(context)
                                          .viewInsets
                                          .bottom, // Adjust for keyboard
                                    ),
                                    child: GetBuilder<ProfileController>(
                                        builder: (v) {
                                      return SingleChildScrollView(
                                        child: Container(
                                          padding: EdgeInsets.all(16.sp),
                                          height: MediaQuery.of(context)
                                                  .size
                                                  .height *
                                              0.35, // Adjust height
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Text(
                                                  "Contact Information",
                                                  style: TextStyle(
                                                      fontSize: 18.sp,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Colors.black),
                                                ),
                                              ),
                                              Align(
                                                alignment: Alignment.topLeft,
                                                child: Text(
                                                  "Your Ticke information will be sent here.",
                                                  style: TextStyle(
                                                      fontSize: 10.sp,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Colors.black),
                                                ),
                                              ),
                                              SizedBox(height: 16),
                                              TextField(
                                                controller: _controller.emailCT,
                                                decoration: InputDecoration(
                                                  //     labelText: "Email",
                                                  label: Text("E-mail"),
                                                  hintStyle: TextStyle(
                                                      color: Colors.black,
                                                      fontWeight:
                                                          FontWeight.normal),
                                                  border: OutlineInputBorder(),
                                                ),
                                              ),
                                              SizedBox(height: 16),
                                              TextField(
                                                controller:
                                                    _controller.phoneNumberCT,
                                                decoration: InputDecoration(
                                                  label: Text("Phone"),
                                                  hintStyle: TextStyle(
                                                      color: Colors.black,
                                                      fontWeight:
                                                          FontWeight.normal),
                                                  border: OutlineInputBorder(),
                                                ),
                                              ),
                                              SizedBox(height: 16),
                                              InkWell(
                                                onTap: () {
                                                  // Update API data with new values
                                                  controller.profile?.data
                                                          .userMail =
                                                      _controller.emailCT.text;
                                                  controller.profile?.data
                                                          .userPhone =
                                                      _controller
                                                          .phoneNumberCT.text;

                                                  // Notify UI to update
                                                  controller.update();

                                                  // Close Bottom Sheet
                                                  Navigator.pop(context);
                                                },
                                                child: Container(
                                                  height: 45.h,
                                                  width: MediaQuery.of(context)
                                                          .size
                                                          .width *
                                                      0.90,
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12.r),
                                                      color: Colors.blue),
                                                  child: Center(
                                                    child: Text(
                                                      "Confirm",
                                                      style: TextStyle(
                                                          color: Colors.white),
                                                    ),
                                                  ),
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      );
                                    }),
                                  );
                                },
                              );
                            },
                            style: const ButtonStyle(
                              tapTargetSize: MaterialTapTargetSize
                                  .shrinkWrap, // the '2023' part
                            ),
                            icon: Icon(Icons.edit_outlined, color: Colors.blue),
                          )
                        ],
                      ),
                    ),
                    kHeight5,
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Row(
                        children: [
                          Icon(
                            Icons.alternate_email_outlined,
                            color: Colors.black,
                          ),
                          kWidth15,
                          Text(v.profile!.data.userMail ?? "",
                              style: TextStyle(
                                color: Colors.black,
                              )),
                        ],
                      ),
                    ),
                    kHeight5,
                    kHeight5,
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Row(
                        children: [
                          Icon(
                            Icons.phone,
                            color: Colors.black,
                          ),
                          kWidth15,
                          Text(v.profile!.data.userPhone ?? "",
                              style: TextStyle(
                                color: Colors.black,
                              )),
                        ],
                      ),
                    )
                  ],
                );
              }),
            ),
            CustomBottomSheet(
              seatNames: widget.selectedSeats ?? [],
              totalFare: widget.fare ?? 0.0,
              onNext: () async {
                _controller.selectedSeatsCount =
                    widget.selectedSeats?.length ?? 0;
                int selectedPassengersCount =
                    _controller.checkboxValues.where((value) => value).length;
                if (_controller.emailCT.text.trim().isEmpty ||
                    _controller.phoneNumberCT.text.trim().isEmpty) {
                  Get.snackbar(
                    "Please Check",
                    "Email or PhoneNumber.",
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: Colors.red.withOpacity(0.8),
                    colorText: Colors.white,
                  );
                  return;
                }
                if (_controller.selectedSeatsCount == 0) {
                  // No seats selected
                  Get.snackbar(
                    "Validation Error",
                    "Please select at least one seat.",
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: Colors.red.withOpacity(0.8),
                    colorText: Colors.white,
                  );
                } else if (selectedPassengersCount <
                    _controller.selectedSeatsCount!.toInt()) {
                  Get.snackbar(
                    "Validation Error",
                    "You have selected ${_controller.selectedSeatsCount} seat(s) but only $selectedPassengersCount passenger(s). Please select more passengers.",
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: Colors.red.withOpacity(0.8),
                    colorText: Colors.white,
                  );
                } else if (selectedPassengersCount >
                    _controller.selectedSeatsCount!.toInt()) {
                  Get.snackbar(
                    "Validation Error",
                    "You have selected ${_controller.selectedSeatsCount} seat(s) but $selectedPassengersCount passenger(s). Please select fewer passengers.",
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: Colors.red.withOpacity(0.8),
                    colorText: Colors.white,
                  );
                } else {
                  List<OrbitPassenger> selectedPassengers = [];
                  for (int i = 0; i < _controller.checkboxValues.length; i++) {
                    if (_controller.checkboxValues[i]) {
                      selectedPassengers.add(_controller.passengers[i]);
                    }
                  }

                  /*      Get.to(
                    OrbitReviewBookingView(
                      selectSeatCode: widget.selectSeatCode,
                      selectedSeats: widget.selectedSeats,
                      selectedPassengers: selectedPassengers,
                      fare: widget.fare,
                      fromLocation: widget.fromLocation,
                      toLocation: widget.toLocation,
                    ),
                  );*/
                  bool success = await _controller.orbitBlockSeat(
                    busName: widget.busname,
                    busType: widget.busType,
                    boardingCode: controller.profile!.busapiname == "common"
                        ? widget.fromLocationCodeCommon
                        : v.fromLocationCode,
                    droppingCode: controller.profile!.busapiname == "common"
                        ? widget.toLocationCodeCommon
                        : v.toLocationCode,
                    travelDate: v.oSelectedDate,
                    fromCode: zz.fromSelectedId,
                    toCode: zz.toSelectedId,
                    tripCode: widget.tripCode,
                    seatNames: widget.selectedSeats,
                    seatCode: widget.selectedSeatCode,
                    seatFares: widget.seatFareList,
                    agentTransactionPNR: 'GRM103DE',
                    passengerEmail: _controller.emailCT.text,
                    passengerMobile: _controller.phoneNumberCT.text,
                  );
                  if (success) {
                    Get.to(
                      OrbitReviewBookingView(
                        droppingPoint: widget.droppingPoint,
                        boardingPoint: widget.boardingPoint,
                        selectedDate: v.oSelectedDate!,
                        sex: selectedPassengers.map((p) => p.sex).toList(),
                        ages: selectedPassengers.map((p) => p.age).toList(),
                        names: selectedPassengers.map((p) => p.name).toList(),
                        busName: widget.busname,
                        selectSeatCode: widget.selectedSeatCode,
                        selectedSeats: widget.selectedSeats,
                        selectedPassengers: selectedPassengers,
                        fare: widget.fare,
                        fromLocation: widget.fromLocation,
                        toLocation: widget.toLocation,
                      ),
                    );
                  } else {
                    Get.snackbar(
                      "Error",
                      "Failed to block the seats. Please try again.",
                      snackPosition: SnackPosition.BOTTOM,
                      backgroundColor: Colors.redAccent,
                      colorText: Colors.white,
                    );
                  }
                }
              },
              isLoading: vv.isLoading,
            ),
          ],
        );
      }),
      appBar: AppBar(
        bottom: PreferredSize(
            preferredSize: const Size.fromHeight(4.0),
            child: Container(
              color: Colors.grey[200],
              height: MediaQuery.sizeOf(context).height * 0.001,
            )),
        leading: IconButton(
            padding: EdgeInsets.zero,
            onPressed: () {
              Get.back();
            },
            icon: Icon(Icons.arrow_back_ios_new_outlined)),
        // / titleSpacing: 0.0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text(
              'Add Passengers',
              style: TextStyle(fontSize: 14.sp),
            ),
            kHeight5,
            Text(
              '${widget.fromLocation} > ${widget.toLocation}',
              style: TextStyle(fontSize: 10.sp, color: Colors.grey),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          /*  kHeight10,
          controller.profile!.busapiname == "orbit" ||
                  bothCitiesController.ProviderType == "orbit"
              ? Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                          child: customTextField(context,
                              labelText: 'Email',
                              hint: "Email",
                              controller: _controller.emailCT)),
                      kWidth5,
                      Expanded(
                          child: customTextField(
                        context,
                        controller: _controller.phoneNumberCT,
                        hint: "Mobile",
                        labelText: 'Mobile',
                      ))
                    ],
                  ),
                )
              : SizedBox(),*/
          kHeight10,
          GetBuilder<OrbitAddPassengerController>(builder: (v) {
            return ListView.builder(
                shrinkWrap: true,
                itemCount: _controller.passengers.length,
                itemBuilder: (context, index) {
                  var data = _controller.passengers[index];
                  /*setIndex = index;
                  orbit = data;*/
                  return CustomInfoWidget(
                    name: data.name,
                    age: data.age.toString(),
                    sex: data.sex,
                    onChanged: (bool? value) {
                      if (v.checkboxValues.isNotEmpty) {
                        v.checkboxValues[index] = value ?? false;
                        print("checkboc${v.checkboxValues[index]}");
                        v.update();
                      }
                    },
                    value: v.checkboxValues.isNotEmpty
                        ? v.checkboxValues[index]
                        : false,
                    onEdit: () {
                      _showPassengerDialog(context,
                          index: index, passenger: data);
                      print('Edit $index');
                      v.update();
                    },
                    onDelete: () {
                      v.removePassenger(index);
                      v.savePassengersToSharedPrefs();
                      v.update();
                    },
                  );
                });
          }),
          kHeight20,
          Padding(
            padding: EdgeInsets.symmetric(
                horizontal: MediaQuery.sizeOf(context).width * 0.10),
            child: InkWell(
              onTap: () {
                if (_controller.passengers.length <
                    (widget.selectedSeats?.length ?? 0)) {
                  _showPassengerDialog(
                    context,
                  );
                } else {
                  Get.snackbar(
                    "Limit Exceeded",
                    "You have already added passengers for all selected seats.",
                    snackPosition: SnackPosition.BOTTOM,
                    backgroundColor: Colors.red.withOpacity(0.8),
                    colorText: Colors.white,
                  );
                }
              },
              child: Container(
                height: 43.h,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.blue),
                    borderRadius: BorderRadius.circular(12.r)),
                child: Center(
                  child: Text(
                    "Add New Passengers",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showPassengerDialog(BuildContext context,
      {int? index, OrbitPassenger? passenger}) {
    _controller.nameCT.text = passenger?.name ?? '';
    _controller.ageCT.text = passenger?.age.toString() ?? '';
    _controller.selectedGender = passenger?.sex ?? 'Male';

    showDialog(
      context: context,
      builder: (context) {
        var height = MediaQuery.of(context).size.height;
        var width = MediaQuery.of(context).size.width;
        return GetBuilder<OrbitAddPassengerController>(builder: (v) {
          String seatName = index != null && widget.selectedSeats != null
              ? widget.selectedSeats![index] // Get the selected seat name
              : 'N/A';

          String seatCode = index != null && widget.selectedSeatCode != null
              ? widget.selectedSeatCode![index] // Get the seat code
              : 'N/A';

          return AlertDialog(
            //    title: Text(index == null ? "Add Passenger" : "Edit Passenger"),
            content: Container(
              height: height * 0.45,
              width: width,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      index == null
                          ? "Add Passenger (Seat Code: ${widget.selectedSeatCode?[_controller.passengers.length] ?? 'N/A'}, Seat Number: ${widget.selectedSeats?[_controller.passengers.length] ?? 'N/A'})"
                          : "Edit Passenger (Seat Code: ${widget.selectedSeatCode?[index] ?? 'N/A'}, Seat Number: ${widget.selectedSeats?[index] ?? 'N/A'})",
//index == null ? "Add Passenger" : "Edit Passenger",
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        color: Colors.black,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  kHeight15,
                  Expanded(
                    child: Row(
                      children: [
                        Radio<String>(
                          value: "Male",
                          groupValue: _controller.selectedGender,
                          onChanged: (value) {
                            _controller.updateGender(value!);
                          },
                        ),
                        Text(
                          'Male',
                          style: TextStyle(
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              color: Colors.black),
                        ),
                        Radio<String>(
                          value: "Female",
                          groupValue: _controller.selectedGender,
                          onChanged: (value) {
                            _controller.updateGender(value!);
                          },
                        ),
                        Text(
                          'FeMale',
                          style: TextStyle(
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              color: Colors.black),
                        ),
                      ],
                    ),
                  ),
                  kHeight15,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 0.0),
                    child: TextFormField(
                      controller: _controller.nameCT,
                      cursorColor: Color(0xFF4181FF),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp('[a-zA-Z ]')),
                      ],
                      keyboardType: TextInputType.text,
                      style: TextStyle(
                        fontFamily: 'Poppins Medium',
                        fontSize: 15.0,
                        color: Colors.black,
                      ),
                      decoration: InputDecoration(
                        label: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Name',
                              style: TextStyle(
                                fontSize: 20,
                                fontFamily: 'Poppins Medium',
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        hintText: 'Enter your name',
                        hintStyle: TextStyle(
                          fontFamily: 'Poppins-Regular',
                          fontSize: 15.0,
                          color: Color(0xFFA5A5A5),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        filled: true,
                        fillColor: Colors.white,
                        contentPadding:
                            EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: Color(0xFFDDDDDD),
                            // Ensure this color is visible
                            width: 2,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: Color(0xFF9FC0FF),
                            width: 2,
                          ),
                        ),
                      ),
                    ),
                  ),
                  kHeight20,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 0.0),
                    child: TextFormField(
                      maxLength: 2,
                      controller: _controller.ageCT,
                      cursorColor: Color(0xFF4181FF),
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                        fontFamily: 'Poppins Medium',
                        fontSize: 15.0,
                        color: Colors.black,
                      ),
                      decoration: InputDecoration(
                        label: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Age',
                              style: TextStyle(
                                fontSize: 20,
                                fontFamily: 'Poppins Medium',
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        hintText: 'Enter your Age',
                        hintStyle: TextStyle(
                          fontFamily: 'Poppins-Regular',
                          fontSize: 15.0,
                          color: Color(0xFFA5A5A5),
                        ),
                        counterText: '',
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        filled: true,
                        fillColor: Colors.white,
                        contentPadding:
                            EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: Color(0xFFDDDDDD),
                            // Ensure this color is visible
                            width: 2,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: Color(0xFF9FC0FF),
                            width: 2,
                          ),
                        ),
                      ),
                    ),
                  ),
                  kHeight10,
                  Center(
                    child: CustomButton(
                      onTap: () {
                        if (_controller.nameCT.text.isEmpty ||
                            _controller.ageCT.text.isEmpty) {
                          Get.snackbar(
                            "Validation Error",
                            "Please fill in all fields.",
                            snackPosition: SnackPosition.BOTTOM,
                          );
                          return;
                        }

                        final passenger = OrbitPassenger(
                          name: _controller.nameCT.text,
                          age: int.parse(_controller.ageCT.text),
                          sex: _controller.selectedGender,
                          seatCode: seatCode,
                          seatName: seatName,
                        );

                        if (index == null) {
                          _controller.addPassengers(passenger);
                        } else {
                          _controller.passengers[index] = passenger;
                          _controller.savePassengersToSharedPrefs();
                          _controller.update();
                        }

                        Get.back();
                      },
                      width: MediaQuery.sizeOf(context).width * 0.30,
                      text: index == null ? "Add" : "Update",
                    ),
                  )
                ],
              ),
            ),
          );
        });
      },
    );
  }
}
