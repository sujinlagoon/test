class OrbitPassenger {
  String name;
  String sex;
  int age;
  String? seatCode;
  String? seatName;

  OrbitPassenger(
      {required this.name,
      required this.sex,
      required this.age,
      this.seatCode,
      this.seatName});

  // Convert object to JSON
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'sex': sex,
      'age': age,
      'seatCode': seatCode,
      'seatName': seatName
    };
  }

  // Create object from JSON
  factory OrbitPassenger.fromJson(Map<String, dynamic> json) {
    return OrbitPassenger(
      name: json['name'],
      sex: json['sex'],
      age: json['age'],
      seatCode: json['seatCode'],
      seatName: json['seatName'],
    );
  }
}
