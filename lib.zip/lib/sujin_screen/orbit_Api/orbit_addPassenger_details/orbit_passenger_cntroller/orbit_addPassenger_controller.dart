import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertickect365/presentation/utils/AppConstants.dart';
import 'package:fluttertickect365/sujin_screen/Profile/profile__controller.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../SharedPref/sharedPref.dart';
import '../modal.dart';

class OrbitAddPassengerController extends GetxController {
  List<OrbitPassenger> passengers = [];
  TextEditingController nameCT = TextEditingController();
  TextEditingController ageCT = TextEditingController();
  TextEditingController phoneNumberCT =
      TextEditingController();
  TextEditingController emailCT =
      TextEditingController();
  String selectedGender = 'Male';
  List<bool> checkboxValues = [];
  int? selectedSeatsCount;
  bool isLoading = false;
  List<String> selectedSeatNameApi = [];
  List<String> selectedSeatCodeApi = [];
  String? ticketCode;

  @override
  void onInit() {
    super.onInit();
    loadPassengersFromSharedPrefs();

      // Initialize controllers with API data



  }

  String convertPassengerGender(String sex) {
    if (sex.toLowerCase() == 'male') {
      return 'M';
    } else if (sex.toLowerCase() == 'female') {
      return 'F';
    } else {
      return '';
    }
  }

  Future<bool> orbitBlockSeat({
    String? boardingCode,
    String? droppingCode,
    DateTime? travelDate,
    String? fromCode,
    String? toCode,
    String? tripCode,
    List<String>? seatNames,
    List<String>? seatCode,
    List<double>? seatFares,
    String? agentTransactionPNR,
    String? passengerEmail,
    String? passengerMobile,
    String? busName,
    String? busType,
  }) async {
  /*  try {*/
    isLoading = true;
    update();
    int j = 0;
    String formattedDate = DateFormat('yyyy-MM-dd').format(travelDate!);
    // Prepare ticket details as a JSON string
    List<Map<String, dynamic>> ticketDetails = [];
    for (int i = 0; i < checkboxValues.length; i++) {
      print(i);
      print(checkboxValues.toString());
      if (checkboxValues[i]) {
        OrbitPassenger passenger = passengers[i];
        for (j = j; j < seatCode!.length; j++) {
          j = j;
          ticketDetails.add({
            "seatCode": seatCode![j],
            "seatName": seatNames![j],
            "passengerGendar": convertPassengerGender(passenger.sex),
            "passengerName": passenger.name,
            "passengerAge": passenger.age.toString(),
            "seatFare": seatFares![j],
          });

          print(ticketDetails.toString());
        }

        /*      if (i < seatCode!.length) {
            ticketDetails.add({
              "seatCode": seatCode![i],
              "seatName": seatNames![i],
              "passengerGendar": convertPassengerGender(passenger.sex),
              "passengerName": passenger.name,
              "passengerAge": passenger.age.toString(),
              "seatFare": seatFares![i],
            });
          } else {
            // Handle the error case if the seatCode and passenger lists don't match
            print("Error: Mismatch between seat and passenger data.");
            return false;
          }*/
      }
    }

    if (ticketDetails.length != seatNames!.length) {
      print("Error: Mismatch between selected seats and passenger details.");
      Get.snackbar(
        "Error",
        "The number of passengers does not match the number of selected seats.",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
      return false;
    }

    // Convert ticket details to JSON string
    String ticketDetailsJson = jsonEncode(ticketDetails);

    var url = Uri.parse('https://ticketapp365.akprojects.co/api/orbit/bus/OrbitBlockTicket');
    String? token = await sharedPrefer().getToken();

    if (token == null) {
      print("Error: Token is null.");
      return false;
    }

    var request = http.MultipartRequest('POST', url);
    request.headers.addAll({
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    });

    request.fields.addAll({
      'busType': busName!,
      'busdisplayName': busType!,
      'boardingPoint': fromCode!,
      'droppingPoint': toCode!,
      'travelDate': formattedDate,
      'fromStation': boardingCode!,
      'toStation': droppingCode!,
      'tripCode': tripCode!,
      'passengerEmail': passengerEmail!,
      'passengerMobile': passengerMobile!,
      'agentTransactionPNR': agentTransactionPNR!,
      'ticketDetails': ticketDetailsJson,
    });

    print("Request Fields: ${request.fields}");
    print("Request URL: ${request.url}");
    print("Request Headers: ${request.headers}");
    ;

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      String responseBody = await response.stream.bytesToString();
      print("Response: $responseBody");
      var data = jsonDecode(responseBody);
      print("decoded Data$data");
      if (data["status"] == true) {
        ticketCode = data["response"]["data"]["ticketCode"];
        print("ticketCode $ticketCode");
        return true;
      } else {
        Get.snackbar(
          "Error",
          "Failed to block seats: ${data["message"]}",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.redAccent,
          colorText: Colors.white,
        );
        return false;
      }
      /*     ticketCode = data["data"]["ticketCode"];
        print("ticketCode$ticketCode");*/

      //return true;
    } else {
      print("Response Status Code: ${response.statusCode}");
      print("Response Reason: ${response.reasonPhrase}");
      return false;
    }
    /*} catch (e) {
      print("Error during API call: $e");
      return false;
    } finally {
      isLoading = false;
      update();
    }*/
  }

  Future<void> loadPassengersFromSharedPrefs() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? encodedPassengers = prefs.getStringList('passengers');

    if (encodedPassengers != null) {
      passengers = encodedPassengers
          .map((encodedPassenger) =>
              OrbitPassenger.fromJson(jsonDecode(encodedPassenger)))
          .toList();
      checkboxValues = List<bool>.generate(passengers.length, (index) => false);
      update();
    }
  }

  void addPassengers(OrbitPassenger passenger) async {
    passengers.add(passenger);
    checkboxValues.add(false);
    await savePassengersToSharedPrefs();
    update();
  }

  void removePassenger(int index) async {
    passengers.removeAt(index);
    checkboxValues.removeAt(index);
    await savePassengersToSharedPrefs();
    update();
  }

  void updateGender(String gender) {
    selectedGender = gender;
    update();
  }

  Future<void> savePassengersToSharedPrefs() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> encodedPassengers =
        passengers.map((passenger) => jsonEncode(passenger.toJson())).toList();
    await prefs.setStringList('passengers', encodedPassengers);
  }

  Future<void> updatePassengerDetails(
      int index, String updatedName, int updatedAge) async {
    passengers[index].name = updatedName;
    passengers[index].age = updatedAge;
    update();
    await savePassengersToSharedPrefs();
    loadPassengersFromSharedPrefs();
    update();
  }

}
