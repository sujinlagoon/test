import 'dart:io';
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/Screens/ReviewBooking/ReviewBooking_Controller/review_booking_controller.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/OrbitReviewBooking/orbit_review_controller/orbit_review_booking_controller.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/orbit_addPassenger_details/modal.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:screenshot/screenshot.dart';
import 'package:share_plus/share_plus.dart';

import '../../Screens/TicketDetails/TicketDetails_view.dart';

class OrbitTicketDetailsView extends StatefulWidget {
  String? fromTime;
  String? toTime;
  double? busRate;
  String? fromLocation;
  String? toLocation;
  DateTime? selectedDate;
  String? busName;
  List<String>? names;
  List<int>? ages;
  List<String>? sex;
  String? droppingPoint;
  String? boardingPoint;
  List<OrbitPassenger>? selectedIndexes;
  List<String>? selectedSeatNames;


  OrbitTicketDetailsView(
      {super.key,
      this.toLocation,
      this.fromLocation,
      this.selectedDate,
      this.ages,
      this.busName,
      this.fromTime,
      this.names,
      this.busRate,
      this.sex,
      this.boardingPoint,
      this.droppingPoint,
      this.selectedIndexes,
      this.selectedSeatNames,
      this.toTime});

  @override
  State<OrbitTicketDetailsView> createState() => _OrbitTicketDetailsViewState();
}

class _OrbitTicketDetailsViewState extends State<OrbitTicketDetailsView> {
  final ScreenshotController screenshotController = ScreenshotController();
  OrbitReviewBookingController controller =
      Get.put(OrbitReviewBookingController());

  void _takeScreenshotAndShare() async {
    try {
      final Uint8List? screenshot = await screenshotController.capture();
      if (screenshot != null) {
        final directory = await getTemporaryDirectory();
        final filePath = '${directory.path}/ticket_screenshot.png';

        // Save the screenshot to a file
        final File file = File(filePath);
        await file.writeAsBytes(screenshot);

        // Convert the file path to XFile
        final xFile = XFile(file.path);

        // Share the screenshot using XFile
        await Share.shareXFiles([xFile], text: 'Here is my ticket details!');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to capture screenshot')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    print("selectedIndex${widget.selectedIndexes}");
    print("selectedseeatname${widget.selectedSeatNames}");
    return Screenshot(
      controller: screenshotController,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
              onPressed: () {
                Get.back();
              },
              icon: Icon(Icons.arrow_back_ios)),
          title: Text(
            "Ticket Details",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          actions: [
            IconButton(
                onPressed: _takeScreenshotAndShare, icon: Icon(Icons.share))
          ],
        ),
        body: SafeArea(
            child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              TripCard(
                toTime: widget.toTime,
                fromTime: widget.fromTime,
                status: "Completed",
                startCity: widget.fromLocation!,
                startPlace: widget.boardingPoint!,
                startDateTime: DateFormat('h:mm a, dd MMMM').format(widget.selectedDate!),
                endCity: widget.toLocation!,
                endPlace: widget.droppingPoint!,
                endDateTime:
                    DateFormat('h:mm a, dd MMMM').format(widget.selectedDate!),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  children: [
                    Text(
                      widget.busName!,
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                    Text("AC Volvo Sleeper Multi-Axle"),
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Passenger Details",
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    ListView.builder(
                        itemCount: widget.selectedIndexes!.length,
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          print("length of tickeyt user ${widget.selectedIndexes!.length}");
                          OrbitPassenger actualIndex = widget.selectedIndexes![index];
                          print("actualInde$actualIndex");

                          return Column(
                            children: [
                              const SizedBox(
                                height: 12,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Mr ${[actualIndex.name]}',
                                    style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    '${[actualIndex.age]} Yrs | Seat ${widget.selectedSeatNames![index]}',
                                    style: TextStyle(
                                        color: Colors.grey, fontSize: 12.sp),
                                  ),
                                ],
                              )
                            ],
                          );
                        })
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              GetBuilder<OrbitReviewBookingController>(builder: (v) {
                return TicketInfoCard(
                  ticketNumber: v.bookingCode ?? '',
                  pnrNumber: "TRANZR56R",
                  fare: ('\u{20B9}${widget.busRate}'),
                );
              }),
            ],
          ),
        )),
      ),
    );
  }
}
