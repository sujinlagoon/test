import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../../Common_modal/cities_modal.dart';

class OSourceDestinationController extends GetxController {
  List<CitiesData> ocitiesData = [];
  List<CitiesData> filteredCities = [];
  String? fromLocation;
  String? toLocation;
  String? fromLocationCode;
  String? toLocationCode;
  TextEditingController searchController = TextEditingController();
  bool isLoading = false;
  DateTime? oSelectedDate = DateTime.now();
  Timer? debounce;

  getAllStation() async {
    try {
      isLoading = true;
      update();
      var res = await http.get(Uri.parse(
          'http://staging.busticketagent.com/orbitservices/api/1.0/json/orbit/devapiuser/85838253YLGF049ZMF731A10YH814/station'));
      if (res.statusCode == 200) {
        var data = orbitCitiesFromJson(res.body);
        ocitiesData = data.data ?? [];
        filteredCities = ocitiesData;
      } else {
        debugPrint("Failed to fetch data. Status code: ${res.statusCode}");
      }
    } catch (e) {
      debugPrint("Error fetching data: $e");
    } finally {
      isLoading = false;
      update();
    }
  }
  void onSearchChanged(String query) {
    if (debounce?.isActive ?? false) {
      debounce?.cancel();
    }
    debounce = Timer(const Duration(milliseconds: 500), () {
      filterCities(query);
    });
  }
  void clearAll() {
    fromLocation = null;
    toLocation = null;
    update();
  }
  // Modify the filterCities method to start with the query
  void filterCities(String query) {
    String trimUnwantedSpaces = query.trim();
    if (trimUnwantedSpaces.isEmpty) {
      filteredCities = ocitiesData;
    } else {
      // Filter cities that start with the query string, case-insensitive
      filteredCities = ocitiesData.where((city) => city.name!.toLowerCase().startsWith(trimUnwantedSpaces.toLowerCase())
          /*||
          city.state!.name!.toLowerCase().startsWith(trimUnwantedSpaces.toLowerCase())*/)
          .toList();
    }
    update();
  }

/*  void filterCities(String query) {

    String trimUnwantedSpaces = query.trim();
    if (trimUnwantedSpaces.isEmpty) {
      filteredCities = ocitiesData;
    } else {
      filteredCities = ocitiesData
          .where((city) =>
              city.name!.toLowerCase().contains(trimUnwantedSpaces.toLowerCase()) ||
              city.state!.name!.toLowerCase().contains(trimUnwantedSpaces.toLowerCase()))
          .toList();
    }
    update();
  }*/

  void setFromLocation(String location, String code) {
    fromLocationCode = code;
    fromLocation = location;
    update();
  }

  void setToLocation(String location, String code) {
    toLocationCode = code;
    toLocation = location;
    update();
  }

  @override
  void onInit() {
    getAllStation();
    searchController.addListener(() {
      onSearchChanged(searchController.text);
      //filterCities(searchController.text);
    });
    super.onInit();
  }
}
