class ApiUrl {
  String orbitCities =
      'http://staging.busticketagent.com/orbitservices/api/1.0/json/orbit/devapiuser/85838253YLGF049ZMF731A10YH814/station';
}
