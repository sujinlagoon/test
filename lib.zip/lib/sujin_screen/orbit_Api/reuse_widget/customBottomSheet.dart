import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/customButton.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class CustomBottomSheet extends StatelessWidget {
  final List<String> seatNames;
  final double totalFare;
  final VoidCallback onNext;
  final bool? isLoading;

  const CustomBottomSheet({
    Key? key,
    required this.seatNames,
    required this.totalFare,
    required this.onNext,
    this.isLoading = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.sizeOf(context).height * 0.10,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          top: BorderSide(color: Colors.grey.withOpacity(0.6), width: 1),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Left Section: Seat Names and Total Fare
          Padding(
            padding: const EdgeInsets.only(left: 18.0, top: 7),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Seat Names
                Text(
                  "Seat No: ${seatNames.join(', ')}",
                  // Combine list into a single string
                  style: TextStyle(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                ),
                const SizedBox(height: 5),
                // Total Fare
                Text(
                  "Total Fare",
                  style: TextStyle(
                      color: Colors.blue,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  "\u{20B9}$totalFare",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          // Right Section: Next Button
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: isLoading!
                ? CircularProgressIndicator()
                : CustomButton(
                    height: Get.width * 0.10,
                    width: Get.width * 0.30,
                    text: "Next",
                    onTap: onNext,
                  ),
          )
        ],
      ),
    );
  }
}
