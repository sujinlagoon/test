import 'package:flutter/material.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/customBottomSheet.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../orbit_addPassenger_details/orbit_add_passenger_view.dart';
import '../orbit_allBuslistView/controller/orbit_allBusView_controller.dart';
import '../seaatayout_/orbit_seatLayout_controller/orbit_seat_layout_controller.dart';

class OrbitPickupAndDropping extends StatefulWidget {
  List<String>? selectedSeats;
  double? fare;
  String? fromLocation;
  String? toLocation;
  List<String>? selectedSeatCode;
  String? tripCode;
  List<double>? seatFareList = [];
  String? fromLocationCode;
  String? toLocationCode;
  DateTime? selectDate;
  String? busName;
  String? busType;

//
  String? fromLocationCodeCommon;
  String? toLocationCodeCommon;
  String? fromLocationNameCommon;
  String? toLocationNameCommon;

  OrbitPickupAndDropping(
      {Key? key,
      this.selectedSeats,
      this.fare,
      this.toLocation,
      this.tripCode,
      this.selectedSeatCode,
      this.fromLocationCode,
      this.toLocationCode,
      this.seatFareList,
      this.selectDate,
      this.busType,
      this.busName,
      //
      this.fromLocationCodeCommon,
      this.toLocationCodeCommon,
      this.toLocationNameCommon,
      this.fromLocationNameCommon,
      this.fromLocation})
      : super(key: key);

  @override
  _OrbitPickupAndDroppingState createState() => _OrbitPickupAndDroppingState();
}

class _OrbitPickupAndDroppingState extends State<OrbitPickupAndDropping>
    with SingleTickerProviderStateMixin {
  //late TabController _tabController;
  bool isLoading = true;

  // OrbitAllBusListController controller = Get.put(OrbitAllBusListController());
  OrbitSeatLayOutController orbitSeatLayOutController =
      Get.put(OrbitSeatLayOutController());

  @override
  void initState() {
    orbitSeatLayOutController.tabController =
        TabController(length: 2, vsync: this);
    orbitSeatLayOutController.tabController!.addListener(() {
      setState(() {
        orbitSeatLayOutController.isDroppingTabActive =
            orbitSeatLayOutController.tabController!.index == 1;
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    orbitSeatLayOutController.tabController!.dispose();
    super.dispose();
  }

  String? boardingPoint;
  String? droppingPoint;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet: orbitSeatLayOutController.isDroppingTabActive
          ? GetBuilder<OrbitSeatLayOutController>(builder: (v) {
              return CustomBottomSheet(
                  seatNames: widget.selectedSeats ?? [],
                  totalFare: widget.fare ?? 0.0,
                  onNext: () {
                    if (v.fromSelectedId == null) {
                      Fluttertoast.showToast(
                        msg: "Please select Boarding Point",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                      );
                      return;
                    } else if (v.toSelectedId == null) {
                      Fluttertoast.showToast(
                        msg: "Please select Dropping Point",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                      );
                      return;
                    } else {
                      Get.to(() => OrbitAddPassengerView(
                            boardingPoint: boardingPoint,
                            droppingPoint: droppingPoint,
                            busType: widget.busName,
                            busname: widget.busType,
                            tripCode: widget.tripCode,
                            selectedSeatCode: widget.selectedSeatCode,
                            toLocation: widget.toLocation,
                            fromLocation: widget.fromLocation,
                            fare: widget.fare,
                            seatFareList: widget.seatFareList,
                            selectedSeats: widget.selectedSeats,
                            selectDate: widget.selectDate,
                            fromLocationCode: widget.fromLocationCode,
                            toLocationCode: widget.toLocationCode,

                            //

                            toLocationNameCommon: widget.toLocationNameCommon,
                            toLocationCodeCommon: widget.toLocationCodeCommon,
                            fromLocationNameCommon: widget.fromLocationNameCommon,
                            fromLocationCodeCommon: widget.fromLocationCodeCommon,
                          ));
                    }
                  });
            })
          : null,
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        centerTitle: true,
        leading: GetBuilder<OrbitSeatLayOutController>(builder: (v) {
          return IconButton(
              onPressed: () {
                v.clearSection();
                v.update();
                Get.back();
              },
              icon: Icon(Icons.arrow_back_ios));
        }),
        title: Text(
          "Boarding And Dropping Points",
          style: TextStyle(fontSize: 16),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TabBar(
            controller: orbitSeatLayOutController.tabController,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.blue,
            dividerColor: Colors.transparent,
            tabs: [
              Tab(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedBuilder(
                      animation:
                          orbitSeatLayOutController.tabController!.animation!,
                      builder: (context, child) {
                        return Text(
                          "Boarding Points",
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: orbitSeatLayOutController
                                        .tabController!.index ==
                                    0
                                ? Colors.black
                                : Colors.grey,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              Tab(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(width: 8.0),
                    AnimatedBuilder(
                      animation:
                          orbitSeatLayOutController.tabController!.animation!,
                      builder: (context, child) {
                        return Text(
                          "Dropping Points",
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: orbitSeatLayOutController
                                        .tabController!.index ==
                                    1
                                ? Colors.black
                                : Colors.grey,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
          Expanded(
            child: GetBuilder<OrbitSeatLayOutController>(builder: (v) {
              //v.update();
              return TabBarView(
                controller: orbitSeatLayOutController.tabController,
                children: [
                  ListView.builder(
                    itemCount: v.fromStation.length,
                    itemBuilder: (context, index) {
                      var data = v.fromStation[index];
                      boardingPoint = data.name;
                      return boardingList(
                        context,
                        location: data.name,
                        address: data.address,
                        date: data.landmark,
                        groupValue: v.fromSelectedIndex,
                        value: index,
                        onChanged: (int? newValue) {
                          orbitSeatLayOutController
                              .updateFromStationPoint(newValue);
                          v.update();
                          orbitSeatLayOutController.tabController!.animateTo(1);
                          print(newValue);
                        },
                      );
                    },
                  ),
                  ListView.builder(
                    itemCount: v.toStation.length,
                    itemBuilder: (context, index) {
                      var data = v.toStation[index];
                      droppingPoint = data.name;
                      return boardingList(
                        context,
                        location: data.name,
                        address: data.address,
                        date: data.landmark,
                        groupValue: v.toSelectedIndex,
                        value: index,
                        onChanged: (int? newValue) {
                          orbitSeatLayOutController
                              .updateToStationPoint(newValue);
                          v.update();
                          print(newValue);
                        },
                      );
                    },
                  ),
                ],
              );
            }),
          ),
          SizedBox(height: MediaQuery.of(context).size.height * 0.10),
        ],
      ),
    );
  }
}

Widget boardingList(
  BuildContext context, {
  String? location,
  String? address,
  String? date,
  int? groupValue,
  ValueChanged<int?>? onChanged,
  int? value,
}) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
    child: GestureDetector(
      onTap: () {
        onChanged?.call(value);
      },
      child: Container(
        padding: EdgeInsets.all(3),
        // height: MediaQuery.sizeOf(context).height * 0.09,
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Color(0xFFA4BFF4),
            width: 1.5,
          ),
          borderRadius: BorderRadius.all(
            Radius.circular(10.0),
          ),
        ),
        child: Row(
          children: [
            Radio(
              value: value!,
              groupValue: groupValue,
              onChanged: onChanged, // Callback to handle value change
            ),
            SizedBox(width: 10),
            Padding(
              padding: EdgeInsets.only(
                  top: MediaQuery.sizeOf(context).height * 0.014),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.73,
                    child: Text(
                      location!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          color: Color(0xFF282828)),
                    ),
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: Get.width * 0.60),
                    // Define maximum width
                    child: Text(
                      address!,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          fontSize: 13,
                          color: Color(0xFF282828)),
                    ),
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  Text(
                    date!,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                        color: Color(0xFF282828)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
