// To parse this JSON data, do
//
//     final orbitCities = orbitCitiesFromJson(jsonString);

import 'dart:convert';

OrbitCities orbitCitiesFromJson(String str) =>
    OrbitCities.fromJson(json.decode(str));

String orbitCitiesToJson(OrbitCities data) => json.encode(data.toJson());

class OrbitCities {
  int? status;
  DateTime? datetime;
  List<CitiesData>? data;

  OrbitCities({
    this.status,
    this.datetime,
    this.data,
  });

  factory OrbitCities.fromJson(Map<String, dynamic> json) => OrbitCities(
        status: json["status"] ?? 0,
        datetime:
            json["datetime"] != null ? DateTime.parse(json["datetime"]) : null,
        data: json["data"] != null
            ? List<CitiesData>.from(json["data"].map((x) => CitiesData.fromJson(x)))
            : [],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "datetime": datetime?.toIso8601String(),
        "data": data != null
            ? List<dynamic>.from(data!.map((x) => x.toJson()))
            : [],
      };
}

class CitiesData {
  String? name;
  String? code;
  State? state;

  CitiesData({
    this.name,
    this.code,
    this.state,
  });

  factory CitiesData.fromJson(Map<String, dynamic> json) => CitiesData(
        name: json["name"] ?? '',
        code: json["code"] ?? '',
        state: json["state"] != null ? State.fromJson(json["state"]) : null,
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "code": code,
        "state": state?.toJson(),
      };
}

class State {
  String? code;
  String? name;
  int? activeFlag;

  State({
    this.code,
    this.name,
    this.activeFlag,
  });

  factory State.fromJson(Map<String, dynamic> json) => State(
        code: json["code"] ?? '',
        name: json["name"] ?? '',
        activeFlag: json["activeFlag"] ?? 0,
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "name": name,
        "activeFlag": activeFlag,
      };
}
