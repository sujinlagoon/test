import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/Screens/utils/appBar_reuse.dart';
import 'package:fluttertickect365/sujin_screen/both/bothCitiesController.dart';
import 'package:get/get.dart';
import '../Screens/Filter_screen/filter_view.dart';
import '../Screens/controller/seatavailabilty-controller.dart';
import '../Screens/shimmer/BusCard_shimmer.dart';
import '../Screens/shimmer/choicechipp_shimmer.dart';
import 'controller.dart';
import 'seat_slection_view.dart';

class BusLists extends StatefulWidget {
  String? fromLocation;
  String? toLocation;
  String? fromLocationCode;
  String? toLocationCode;
  DateTime? selectedDate;

  BusLists({
    super.key,
    this.fromLocation,
    this.toLocation,
    this.selectedDate,
    this.toLocationCode,
    this.fromLocationCode,
  });

  @override
  State<BusLists> createState() => _BusListsState();
}

class _BusListsState extends State<BusLists> {
  BusListController vv = Get.put(BusListController());

  SeatAvailabilityController seatAvailabilityController =
      Get.put(SeatAvailabilityController());
  BothCitiesController bothCitiesController = Get.put(BothCitiesController());
  int? totalBus;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) {
      vv.availabilitySeatGet(
          selectDate: widget.selectedDate,
          from: widget.fromLocationCode,
          to: widget.toLocationCode);
    });
  }

  @override
  Widget build(BuildContext context) {
    print("${widget.selectedDate}");
    return Scaffold(
      appBar: CustomAppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            bothCitiesController.clearLocation();
            Get.back();
          },
        ),
        place: "${widget.fromLocation}",
        to: "${widget.toLocation}",
        date: widget.selectedDate,
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 10.w),
            child: GetBuilder<BusListController>(builder: (context) {
              return Text("${vv.availableTrips.length} Buses");
            }),
          )
        ],
      ),
      body: WillPopScope(
        onWillPop: () async {
          bothCitiesController.clearLocation();
          Navigator.pop(context);
          return false;
        },
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: GetBuilder<BusListController>(builder: (v) {
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Wrap(
                      spacing: 8.0,
                      children: [
                        v.isLoading
                            ? ShimmerChoiceChip()
                            : InkWell(
                                onTap: () async {
                                  var selectedBusTypes =
                                      await Get.to(() => FilterView(
                                            selectedDate: widget.selectedDate,
                                            fromLocation: widget.fromLocation,
                                            toLocation: widget.toLocation,
                                            selectedBusTypes:
                                                vv.selectedBusTypes,
                                          ));
                                  if (selectedBusTypes != null) {
                                    vv.selectedBusTypes = selectedBusTypes;
                                    vv.update();
                                  }
                                },
                                child: Padding(
                                  padding:
                                      EdgeInsets.only(top: Get.height * 0.01),
                                  child: Container(
                                    padding: EdgeInsets.all(1.r),
                                    height: Get.height * 0.04,
                                    width: Get.width * 0.17,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(7),
                                        border: Border.all(
                                            color: Colors.grey, width: 0.2)),
                                    child: Row(
                                      children: [
                                        Image.asset(
                                          "assets/filter.png",
                                          height: 12.h,
                                          width: 17.w,
                                        ),
                                        SizedBox(
                                          width: 5.w,
                                        ),
                                        Text("Filter")
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                        v.isLoading
                            ? ShimmerChoiceChip()
                            : ChoiceChip(
                                label: const Text('All'),
                                selected: vv.selectedFilter == 'All',
                                onSelected: (selected) {
                                  if (selected) vv.filterTrips('All');
                                  print(selected);
                                },
                                backgroundColor: Colors.white,
                                selectedColor: Colors.blue,
                                showCheckmark: false,
                              ),
                        v.isLoading
                            ? ShimmerChoiceChip()
                            : ChoiceChip(
                                label: const Text('AC'),
                                selected: vv.selectedFilter == 'AC',
                                onSelected: (selected) {
                                  if (selected) vv.filterTrips('AC');
                                  print(selected);
                                },
                                backgroundColor: Colors.white,
                                selectedColor: Colors.blue,
                                showCheckmark: false,
                              ),
                        v.isLoading
                            ? ShimmerChoiceChip()
                            : ChoiceChip(
                                label: const Text('Non-AC'),
                                selected: vv.selectedFilter == 'Non-AC',
                                onSelected: (selected) {
                                  if (selected) vv.filterTrips('Non-AC');
                                  print(selected);
                                },
                                backgroundColor: Colors.white,
                                selectedColor: Colors.blue,
                                showCheckmark: false,
                              ),
                        v.isLoading
                            ? ShimmerChoiceChip()
                            : ChoiceChip(
                                label: const Text('Sleeper'),
                                selected: vv.selectedFilter == 'Sleeper',
                                onSelected: (selected) {
                                  if (selected) vv.filterTrips('Sleeper');
                                  print(selected);
                                },
                                backgroundColor: Colors.white,
                                showCheckmark: false,
                                selectedColor: Colors.blue,
                              ),
                        v.isLoading
                            ? ShimmerChoiceChip()
                            : ChoiceChip(
                                label: const Text('Seater'),
                                selected: vv.selectedFilter == 'Seater',
                                onSelected: (selected) {
                                  if (selected) vv.filterTrips('Seater');
                                  print(selected);
                                },
                                backgroundColor: Colors.white,
                                selectedColor: Colors.blue,
                                showCheckmark: false,
                              ),
                      ],
                    ),
                  );
                }),
              ),
              Expanded(
                child: GetBuilder<BusListController>(builder: (v) {
                  if (v.isLoading) {
                    return ListView.builder(
                        itemCount: 6,
                        itemBuilder: (context, index) {
                          return BusCardShimmer();
                        });
                  }

                  if (v.filteredTrips.isEmpty) {
                    return const Center(child: Text('No trips available'));
                  }
                  return ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    itemCount: vv.filteredTrips.length,
                    itemBuilder: (context, index) {
                      print(v.filteredTrips.length);
                      var data = vv.filteredTrips[index];
                      return InkWell(
                          onTap: () {
                            /* Get.to(() => SeatLayOut(
                                  index: data.id,
                                ));*/
                          },
                          child: /*busListAll(
                          context,
                          busName: data.travels,
                          fromtime: data.departureTime,
                          toTime: data.arrivalTime,
                          prize: data.fares.toString(),
                        ),*/
                              Padding(
                            padding: const EdgeInsets.all(4.0),
                            child: InkWell(
                              highlightColor: Colors.transparent,
                              onTap: () {

                                Get.to(() => SeatLayOut(
                                  fromLocationCode: widget.fromLocationCode,
                                  toLocationCode: widget.toLocationCode,

                                      fromTime: data.departureTime,
                                      toTime: data.arrivalTime,
                                      index: data.id,
                                      fromLocation: widget.fromLocation,
                                      toLocation: widget.toLocation,
                                      busName: data.travels,
                                      selectedDate: widget.selectedDate,
                                    ));
                              },
                              child: BusCard(
                                  companyName: data.travels ?? '',
                                  rating: 2.5,
                                  busType: data.busType ?? '',
                                  departureTime: data.departureTime ?? '',
                                  arrivalTime: data.arrivalTime ?? "",
                                  duration: data.duration ?? '',
                                  price: data.fares,
                                  seatsLeft: int.parse(data.availableSeats!),
                                  onDetailsPressed: () {
                                    Get.to(() => SeatLayOut(
                                          fromTime: data.departureTime,
                                          toTime: data.arrivalTime,
                                          index: data.id,
                                          fromLocation: widget.fromLocation,
                                          toLocation: widget.toLocation,
                                          fromLocationCode: widget.fromLocationCode,
                                          toLocationCode: widget.toLocationCode,
                                          busName: data.travels,
                                          selectedDate: widget.selectedDate,
                                        ));
                                  }),
                            ),
                          ));
                    },
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/*Widget busListAll(BuildContext context,
    {String? busName, String? fromtime, String? toTime, String? prize}) {
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: Container(
      height: MediaQuery.of(context).size.height * 0.10,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.black,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            busName ?? 'No name',
            style: const TextStyle(color: Colors.black, fontSize: 16),
          ),
          Text(fromtime ?? 'No departure time'),
          Text(toTime ?? 'No arrival time'),
          Text(prize ?? 'No fare'),
        ],
      ),
    ),
  );
}*/

class BusCard extends StatelessWidget {
  final String companyName;
  final double rating;
  final String busType;
  final String departureTime;
  final String arrivalTime;
  final String duration;
  final dynamic price;
  final int seatsLeft;
  final VoidCallback onDetailsPressed;

  const BusCard({
    Key? key,
    required this.companyName,
    required this.rating,
    required this.busType,
    required this.departureTime,
    required this.arrivalTime,
    required this.duration,
    required this.price,
    required this.seatsLeft,
    required this.onDetailsPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border: Border.all(color: Colors.black, width: 0.2),
          borderRadius: BorderRadius.circular(6)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                companyName,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  children: [
                    Icon(Icons.star, color: Colors.green, size: 16),
                    const SizedBox(width: 4),
                    Text(
                      rating.toString(),
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.green[700],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Bus Type Section
          Text(
            busType,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 16),

          // Time and Duration Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Left Section: Time and Duration
              Expanded(
                child: Row(
                  children: [
                    Text(
                      '${SeatAvailabilityController().convertMinutesToTimeFormat(int.parse(departureTime))} - ${SeatAvailabilityController().convertMinutesToTimeFormat(int.parse(departureTime))}',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(
                      width: 4,
                    ),
                    Text(
                      "($duration)",
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),

              // Right Section: Price
              Text(
                price == null
                    ? 'Price not available'
                    : price is List && price.isNotEmpty
                        ? '₹ ${price.first}' // Display only the first value
                        : '₹ $price',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),

          // Price and Seats Left Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '$seatsLeft Seats Left',
                style: TextStyle(
                  fontSize: 14,
                  color: seatsLeft > 5 ? Colors.green : Colors.red,
                ),
              ),
              TextButton(
                onPressed: onDetailsPressed,
                child: Text(
                  'Bus Details',
                  style: TextStyle(
                    color: Colors.blue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
