import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:oauth1/oauth1.dart' as oauth1;

import 'modal_bus_list.dart';

class BusListController extends GetxController {
  bool isLoading = true;
  final String consumerKey = 'MCycaVxF6XVV0ImKgqFPBAncx0prPp';
  final String consumerSecret = '5f0lpy9heMvXNQ069lQPNMomysX6rt';

  List<BusList> allBusList = [];
  List<AvailableTrip> availableTrips = [];
  List<AvailableTrip> filteredTrips = [];
  List<AvailableTrip> selectedTrips = [];
  String selectedFilter = 'All';
  List<bool> isExpandedList = [false, false, false];

  availabilitySeatGet({DateTime? selectDate,String?from,String?to}) async {

    final clientCredentials =
        oauth1.ClientCredentials(consumerKey, consumerSecret);
    final authClient = oauth1.Client(
        oauth1.SignatureMethods.hmacSha1, clientCredentials, null);
    isLoading = true;
    update();

    final url = Uri.parse(
        'http://api.seatseller.travel/availabletrips?source=$from&destination=$to&doj=$selectDate');
    print(url);
    final response = await authClient.get(url);
    if (response.statusCode == 200) {
      var data = busListFromJson(response.body);
      availableTrips = data!.availableTrips ?? [];
      filteredTrips = availableTrips;
      update();
      isLoading = false;
      update();
    } else {
      isLoading = false;
      update();
      print('Fully not fetch');
    }
  }

/*  void filterTrips(String type) {
    selectedFilter = type;
    if (type == 'All') {
      filteredTrips = availableTrips;
    } else if (type == 'AC') {
      filteredTrips = availableTrips.where((trip) => trip.ac == 'true').toList();
    } else if (type == 'Non-AC') {
      filteredTrips = availableTrips.where((trip) => trip.nonAc == 'true').toList();
    } else if (type == 'Sleeper') {
      filteredTrips = availableTrips.where((trip) => trip.sleeper == 'true').toList();
    } else if (type == 'Seater') {
      filteredTrips = availableTrips.where((trip) => trip.seater == 'true').toList();
    }
    update();
  }*/
  // Filter trips based on selected filter
  void filterTrips(String filter) {
    selectedFilter = filter;
    filteredTrips = availableTrips;

    if (filter == 'AC') {
      filteredTrips =
          availableTrips.where((trip) => trip.ac == 'true').toList();
    } else if (filter == 'Non-AC') {
      filteredTrips =
          availableTrips.where((trip) => trip.nonAc == 'true').toList();
    } else if (filter == 'Sleeper') {
      filteredTrips =
          availableTrips.where((trip) => trip.sleeper == 'true').toList();
    } else if (filter == 'Seater') {
      filteredTrips =
          availableTrips.where((trip) => trip.seater == 'true').toList();
    } else if (filter == 'All') {
      filteredTrips = availableTrips; // Show all trips if "All" is selected
    }
    update();
  }

  void resetBusTypesSelection() {
    // Reset all bus types' selection state to false
    filteredTrips.forEach((trip) {
      trip.isSelected = false;
    });
    update();
  }

  List<String> selectedBusTypes = [];

  void addToSelectedBusTypes(String busType) {
    if (!selectedBusTypes.contains(busType)) {
      selectedBusTypes.add(busType);
    }
    update();
  }

  void removeFromSelectedBusTypes(String busType) {
    selectedBusTypes.remove(busType);
    update();
  }

  @override
  void onInit() {
    filteredTrips = availableTrips;
    super.onInit();
  }
}
