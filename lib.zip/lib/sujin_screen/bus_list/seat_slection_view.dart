import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertickect365/sujin_screen/customButton.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shimmer/shimmer.dart';
import '../Screens/boarding_droping/boarding_dropping.dart';
import '../Screens/controller/seatavailabilty-controller.dart';
import '../Screens/utils/appBar_reuse.dart';

class SeatLayOut extends StatefulWidget {
  final String? index;
  String? fromTime;
  String? toTime;
  String? busName;
  String? fromLocation;
  String? toLocation;
  String? fromLocationCode;
  String? toLocationCode;
  DateTime? selectedDate;

  SeatLayOut(
      {super.key,
      this.index,
      this.fromTime,
      this.toTime,
      this.busName,
      this.toLocation,
      this.selectedDate,
      this.fromLocationCode,
      this.toLocationCode,
      this.fromLocation});

  @override
  State<SeatLayOut> createState() => _SeatLayOutState();
}

class _SeatLayOutState extends State<SeatLayOut> {
  SeatAvailabilityController seatAvailabilityController =
      Get.put(SeatAvailabilityController());

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchSeatData();
  }

  Future<void> fetchSeatData() async {
    if (widget.index != null) {
      seatAvailabilityController.resetSelection();
      await seatAvailabilityController.availabilitySeatGet(
          id: int.parse(widget.index!));
      setState(() {
        isLoading = false;
      });
    } else {
      print("Bus ID is null");
    }
  }

  @override
  Widget build(BuildContext context) {
    print("from${widget.fromLocationCode}");
    print("to${widget.toLocationCode}");
    return Scaffold(
      bottomSheet: GetBuilder<SeatAvailabilityController>(builder: (v) {
        return Container(
          height: Get.height * 0.09,
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border(
              top: BorderSide(color: Colors.grey.withOpacity(0.6), width: 1),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 18.0, top: 7),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          //   'Seat No : ${seatAvailabilityController.selectedSeatNames.map((seat) => seatAvailabilityController.getPrefixedSeatName(seat)).join(', ')}',
                          'Seat No : ${seatAvailabilityController.selectedSeatNames.map((seat) => seat.toString().replaceAll(RegExp(r'[\(\)]'), '')).join(', ')}',

                          style: TextStyle(
                              color: Colors.black, fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                    Text(
                      "Total Fare",
                      style: TextStyle(color: Colors.blue),
                    ),
                    GetBuilder<SeatAvailabilityController>(builder: (v) {
                      print(
                        "Seat No:  ${seatAvailabilityController.selectedSeatNames.map((seat) => seatAvailabilityController.getPrefixedSeatName(seat)).join(', ')}",
                      );
                      return Text(
                        " \u{20B9}${v.calculateTotalFare()}",
                        style: TextStyle(
                            color: Colors.black, fontWeight: FontWeight.bold),
                      );
                    }),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 8.0),
                child: CustomButton(
                  width: Get.width * 0.30,
                  text: "Next",
                  onTap: () {
                    if (seatAvailabilityController.selectedSeatNames.isEmpty) {
                      Fluttertoast.showToast(
                        msg: "Please select at least one seat.",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.CENTER,
                        backgroundColor: Colors.black,
                        textColor: Colors.white,
                        fontSize: 16.sp,
                      );
                      return;
                    }
                    double totalFare =
                        seatAvailabilityController.calculateTotalFare();
                    List<double> selectedBusRates = seatAvailabilityController
                        .availSeat
                        .where((seat) => seatAvailabilityController
                            .selectedSeatNames
                            .contains(seat.name))
                        .map((seat) {
                      if (seat.fare != null && seat.fare!.isNotEmpty) {
                        return double.tryParse(seat.fare!) ?? 0.0;
                      }
                      return 0.0;
                    }).toList();

                    print("pass rate${seatAvailabilityController.busRate}");
                    print("Selected Bus Rates: $selectedBusRates");
                    Get.to(() => SelectboardingDropping(
                          busRates: selectedBusRates,
                          toTime: widget.toTime,
                          fromTime: widget.fromTime,
                          busIndex: widget.index,
                          selectedSeatNames:
                              seatAvailabilityController.selectedSeatNames,
                          busRate: totalFare,
                          busName: widget.busName,
                          toLocation: widget.toLocation,
                          fromLocation: widget.fromLocation,
                          toLocationCode: widget.toLocationCode,
                          fromLocationCode: widget.fromLocationCode,
                          selectedDate: widget.selectedDate,
                        ));
                  },
                ),
              ),
            ],
          ),
        );
      }),
      backgroundColor: Colors.white,
      appBar: AppBar(
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(1.0),
          child: Container(
            color: Colors.grey.withOpacity(0.3),
            height: 1.0,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Select Seats",
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        )),
                    SizedBox(
                      height: Get.height * 0.01,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            overflow: TextOverflow.ellipsis,
                            '${widget.fromLocation} - ${widget.toLocation}' ??
                                'Nagercoil - Chennai',
                            style: TextStyle(
                                color: Colors.grey,
                                fontWeight: FontWeight.normal,
                                fontSize: 14.sp),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 4),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            /*    Positioned(
              left: 0,
              top: MediaQuery.of(context).size.height * 0.60,
              child: Container(
                height: MediaQuery.of(context).size.height * 0.09,
                width: MediaQuery.of(context).size.width * 0.09,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.blue),
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(5.r), // Top-right corner radius
                    bottomRight:
                        Radius.circular(5.r), // Bottom-right corner radius
                  ),
                ),
                child: Center(
                  child: Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.01,
                      ),
                      Icon(
                        Icons.info_outline_rounded,
                        color: Colors.grey,
                      ),
                      Text("Seat \nInfo")
                    ],
                  ),
                ),
              ),
            ),*/
            GetBuilder<SeatAvailabilityController>(
              builder: (controller) {
                if (controller.isLoading) {
                  return Center(
                      child: Center(
                    child: Shimmer.fromColors(
                      baseColor: Colors.grey[300]!,
                      highlightColor: Colors.grey[100]!,
                      child: ListView.builder(
                        itemCount: 10, // Number of items for shimmer
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Container(
                              height: 50.0,
                              color: Colors.white,
                            ),
                          );
                        },
                      ),
                    ),
                  ));
                }

                if (controller.availSeat.isEmpty) {
                  return Center(child: Text("No seats available"));
                }

                bool doubleBerth = controller.upperDeckSeats.isNotEmpty &&
                    controller.lowerDeckSeats.isNotEmpty;

                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.sizeOf(context).height * 0.06,
                      ),
                      doubleBerth
                          ? Row(
                              children: [
                                // Lower Deck
                                Expanded(
                                  //flex: 1,
                                  child: buildSeatLayout(
                                      title: "Lower Deck",
                                      seatData: controller.lowerDeckSeats,
                                      isShow: true),
                                ),
                                const SizedBox(width: 2),
                                // Upper Deck
                                Expanded(
                                  // flex: 1,
                                  child: buildSeatLayout(
                                      title: "Upper Deck",
                                      seatData: controller.upperDeckSeats,
                                      isShow: false),
                                ),
                              ],
                            )
                          : buildSeaterLayout(),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget buildSeatLayout({
    required String title,
    required List<dynamic> seatData,
    bool isShow = false,
  }) {
    // Group seats by rows and track the maximum number of columns
    Map<int, List<dynamic>> groupedSeats = {};
    int maxColumns = 0;
    int maxRow = 0;

    for (var seat in seatData) {
      int rowNumber = int.parse(seat.row!);
      int columnNumber = int.parse(seat.column!);

      groupedSeats[rowNumber] ??= [];
      maxColumns = max(maxColumns, columnNumber);
      maxRow = max(maxRow, rowNumber);
      groupedSeats[rowNumber]!.add(seat);
    }

    // Ensure all rows from 0 to maxRow are present, including empty rows
    for (int row = 0; row <= maxRow; row++) {
      groupedSeats[row] ??= [];
      // Fill the row with null to ensure the same number of columns
      List<dynamic> normalizedRow = List.filled(maxColumns + 1, null);
      for (var seat in groupedSeats[row]!) {
        int columnIndex = int.parse(seat.column!);
        normalizedRow[columnIndex] = seat;
      }
      groupedSeats[row] = normalizedRow;
    }

    return Container(
      height: MediaQuery.sizeOf(context).height * 0.58,
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.grey.withOpacity(0.2),
        ),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Column(
        children: [
          SizedBox(height: MediaQuery.of(context).size.height * 0.01),
          Container(
            // color: Colors.red,
            height: MediaQuery.of(context).size.height * 0.02,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(title),
                isShow
                    ? SizedBox(
                        height: 22.h,
                        width: 15.w,
                        child: Image.asset("assets/car_handle.png"))
                    : SizedBox()
              ],
            ),
          ),
          SizedBox(height: MediaQuery.of(context).size.height * 0.01),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(maxRow + 1, (rowNumber) {
                      // If the row is missing, it will be an empty row of SizedBox
                      List<dynamic> rowSeats = groupedSeats[rowNumber] ?? [];
                      return Column(
                        // mainAxisAlignment: MainAxisAlignment.center,
                        children: rowSeats.map((seat) {
                          return seat != null
                              ? Padding(
                                  padding: EdgeInsets.symmetric(vertical: 2.0),
                                  child: buildSeat(
                                    seatNumber: seat.name,
                                    index: seatData.indexOf(seat),
                                    deckType: seat.zIndex,
                                  ),
                                )
                              : Container(
                                  padding: EdgeInsets.zero,
                                  height:
                                      MediaQuery.sizeOf(context).height * 0.075,
                                  width:
                                      MediaQuery.of(context).size.width * 0.07,
                                  //color: Colors.green,
                                  decoration: BoxDecoration(
                                      //color: Colors.red,
                                      ),
                                  /* child: Center(
                                    child: Icon(
                                      Icons.dangerous,
                                      color: Colors.red,
                                    ),
                                  ),*/
                                );
                        }).toList(),
                      );
                    }),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSeaterLayout() {
    return GetBuilder<SeatAvailabilityController>(
      builder: (controller) {
        // Group seats by rows and track the maximum number of columns
        Map<int, List<dynamic>> groupedSeats = {};
        int maxColumns = 0;
        int maxRow = 0;

        for (var seat in controller.availSeat) {
          int rowNumber = int.parse(seat.row!);
          int columnNumber = int.parse(seat.column!);

          // Update max columns and rows based on seat data
          maxColumns = max(maxColumns, columnNumber);
          maxRow = max(maxRow, rowNumber);

          groupedSeats[rowNumber] ??= [];
          groupedSeats[rowNumber]!.add(seat);
        }

        // Ensure all rows from 0 to maxRow are present, including empty rows
        for (int row = 0; row <= maxRow; row++) {
          groupedSeats[row] ??= [];

          // Create a row with null entries to fill up to maxColumns
          List<dynamic> normalizedRow = List.filled(maxColumns + 1, null);

          // Fill the row with seats (making sure they're placed in the correct index)
          for (var seat in groupedSeats[row]!) {
            int columnIndex = int.parse(seat.column!); // columnIndex is 0-based
            if (columnIndex >= 0 && columnIndex <= maxColumns) {
              normalizedRow[columnIndex] = seat;
            }
          }

          groupedSeats[row] = normalizedRow;
        }

        return Column(
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.only(top: 32.0),
                child: Container(
                  padding: EdgeInsets.all(5),
                  height: MediaQuery.sizeOf(context).height * 0.58,
                  width: MediaQuery.sizeOf(context).width * 0.62,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: Colors.grey, width: 0.3),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(maxRow + 1, (rowNumber) {
                            List<dynamic> rowSeats =
                                groupedSeats[rowNumber] ?? [];

                            return SingleChildScrollView(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: rowSeats.map((seat) {
                                  return seat != null
                                      ? Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: Get.width * 0.01,
                                              vertical: Get.height * 0.004),
                                          child: buildSeat(
                                            seatNumber: seat.name,
                                            index: controller.availSeat
                                                .indexOf(seat),
                                            deckType: seat.zIndex,
                                          ),
                                        )
                                      : Container(
                                          height: MediaQuery.sizeOf(context)
                                                  .height *
                                              0.07,
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              0.07,
                                          decoration: BoxDecoration(
                                              //   color: Colors.red,
                                              ),
                                        );
                                }).toList(),
                              ),
                            );
                          }),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget buildSeat({
    String? seatNumber,
    int? index,
    String? deckType,
  }) {
    return GetBuilder<SeatAvailabilityController>(
      builder: (controller) {
        var seat = controller.availSeat[index!];
        String assetPath = 'assets/default_seat.png';
        int seatLength = int.tryParse(seat.length!) ?? 0;
        int seatWidth = int.tryParse(seat.width!) ?? 0;

        if (seatLength == 1 && seatWidth == 1) {
          assetPath = 'assets/seats_img/seat.svg';
        } else if (seatLength == 2 && seatWidth == 1) {
          assetPath = 'assets/seats_img/sleeper.svg';
        } else if (seatLength == 1 && seatWidth == 2) {
          assetPath = 'assets/seats_img/sleeper.svg';
        }
        bool isAvailable = seat.available == 'true';

        bool isSelected = deckType == "0"
            ? controller.lowerDeckSelectedSeats[seat.name] ?? false
            : controller.upperDeckSelectedSeats[seat.name] ?? false;

        Color seatColor;
        if (seat.ladiesSeat == "true") {
          print("Ladies Seat Detected: ${seat.ladiesSeat}");
          seatColor = Colors.pink;
        } else if (seat.malesSeat == "true") {
          seatColor = Colors.blue;
        } else if (seat.available == 'true') {
          seatColor = Colors.green;
        } else if (seat.available == "false") {
          seatColor = Colors.grey;
        } else {
          seatColor = Colors.black;
        }

        if (isSelected) {
          seatColor = Colors.red;
        }

        return InkWell(
            highlightColor: Colors.transparent,
            overlayColor: MaterialStateProperty.all(Colors.transparent),
            onTap: isAvailable
                ? () {
                    controller.toggleSeatSelection(seat.name!, deckType ?? '');
                  }
                : () {
                    // Show a toast message when the seat is unavailable
                    Fluttertoast.showToast(
                      msg: "This seat is already booked!",
                      toastLength: Toast.LENGTH_SHORT,
                      gravity: ToastGravity.CENTER,
                      backgroundColor: Colors.black,
                      textColor: Colors.white,
                      fontSize: 16.0,
                    );
                  },
            child: Center(
              child: Stack(
                children: [
                  Container(
                    height: MediaQuery.sizeOf(context).height * 0.07,
                    //color: Colors.blue,
                    child: SvgPicture.asset(
                      assetPath,
                      color: seatColor,
                      fit: BoxFit.contain,
                      height: assetPath == 'assets/seats_img/sleeper.svg'
                          ? MediaQuery.sizeOf(context).height * 0.070
                          : MediaQuery.sizeOf(context).height * 0.044,
                      width: MediaQuery.of(context).size.width * 0.08,
                    ),
                  ),
                  /* if (seatNumber != null)
                    Positioned(
                      top: 3,
                      child: Text(
                        // '${seat.seatName!}\n(${seat.rowPos}, ${seat.colPos})',
                        '${seatNumber}',
                        style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),*/
                ],
              ),
            ));
      },
    );
  }
}
