import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../Screens/controller/seatavailabilty-controller.dart';

class BusBookingScreen extends StatefulWidget {
  String? index;

  BusBookingScreen({super.key, this.index});

  @override
  State<BusBookingScreen> createState() => _BusBookingScreenState();
}

class _BusBookingScreenState extends State<BusBookingScreen> {
  @override
  void initState() {
    super.initState();
    if (widget.index != null) {
      vv.availabilitySeatGet(id: int.parse(widget.index!));
    }
  }

  SeatAvailabilityController vv = Get.put(SeatAvailabilityController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Bus Booking")),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Expanded(
                child: GetBuilder<SeatAvailabilityController>(
              init: SeatAvailabilityController(),
              builder: (vv) {
                if (vv.availSeat.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                } else {
                  return GridView.builder(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 5,
                        crossAxisSpacing: 8.0,
                        mainAxisSpacing: 8.0,
                      ),
                      itemCount: vv.availSeat.length,
                      itemBuilder: (context, index) {
                        var seat = vv.lowerDeckSeats[index];
                        bool isAvailable = seat.available == "true";
                        int length = int.parse(seat.length!);
                        int width = int.parse(seat.width!);
                        bool isDoubleBerth = seat.doubleBirth == "true"; // Check for double berth

                        return SeatWidget(
                          seatName: seat.name!,
                          isAvailable: isAvailable,
                          length: length,
                          width: width,
                          seatWidth: 50,
                          seatHeight: 80,
                          isDoubleBerth: isDoubleBerth,
                        );
                      });
                }
              },
            )),
          ],
        ),
      ),
    );
  }
}

class SeatWidget extends StatelessWidget {
  final String seatName;
  final bool isAvailable;
  final int length;
  final int width;
  final double seatWidth;
  final double seatHeight;
  final bool isDoubleBerth;

  const SeatWidget({
    required this.seatName,
    required this.isAvailable,
    required this.length,
    required this.width,
    required this.seatWidth,
    required this.seatHeight,
    required this.isDoubleBerth, // New parameter
  });

  @override
  Widget build(BuildContext context) {
    String seatImage = isDoubleBerth
        ? "assets/double_berth.png"
        : "assets/single_berth.png"; // Use different images

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Image.asset(
            seatImage,
            fit: BoxFit.cover,
            width: seatWidth * (isDoubleBerth ? 2 : 1),
            // Double width for double berths
            height: seatHeight,
          ),
          if (!isAvailable)
            Container(
              color: Colors.black.withOpacity(0.5),
              child: Center(
                child: Text(
                  "Unavailable",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          Center(
            child: Text(
              seatName,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
