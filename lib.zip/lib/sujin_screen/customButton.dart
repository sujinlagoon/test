import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class CustomButton extends StatelessWidget {
  CustomButton(
      {super.key,
      this.child,
      this.isLoading = false,
      this.text,
      this.onTap,
      this.width,
      this.height});

  bool? isLoading;
  Widget? child;
  String? text;
  Function()? onTap;
  double? width;
  double? height;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.r),
        gradient: LinearGradient(
          colors: [Color(0xFF4181FF), Color(0xFF274E99)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: InkWell(
        onTap: () {
          Future.delayed(const Duration(milliseconds: 300), () {
            onTap == null ? () {} : onTap!();
          });
        },
        splashFactory: InkRipple.splashFactory,
        splashColor: Colors.white.withOpacity(0.6),
        borderRadius: BorderRadius.circular(30),
        child: Container(
          width: width ?? MediaQuery.of(context).size.width * 0.5,
          height: height ?? 40,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
          ),
          child: isLoading!
              ? SizedBox(
                  height: Get.height * 0.03,
                  width: Get.width * 0.06,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 0.4,
                  ),
                )
              : child ??
                  Text(
                    text!,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, color: Colors.white),
                  ),
        ),
      ),
    );
  }
}
