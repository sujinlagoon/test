import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';

class sharedPrefer {
  saveToken(String token) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
    log("otp with login$token");
  }

  Future<String?> getToken() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');
  //  log(token!);
    return token;
  }

  saveBlockKey(String blockKey) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('block_Key', blockKey);
    debugPrint('BlockKey saved: $blockKey');
    log(blockKey);
  }

  Future<String?> getBlockKey() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('block_Key');
    debugPrint('BlockKey retrieved: $token');
    log(token!);
    return token;
  }

  saveBookingKey(String bookingKey) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('book_Key', bookingKey);
    debugPrint('Booking_key saved: $bookingKey');
  }

  Future<String?> getBookingKey() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('book_Key');
    debugPrint('BookingKey retrieved: $token');
    log(token!);
    return token;
  }

  Future<void> clearAll() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
