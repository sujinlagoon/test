import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:fluttertickect365/presentation/utils/AppConstants.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../../SharedPref/sharedPref.dart';
import '../../modals/booking_view_modal.dart';

class CancelController extends GetxController {
  bool isLoading = false;
  int? bookingId;

  cancelBooking({List<String>? tinNumbers, List<String>? seatNumbers,List<String>?providerType}) async {
    try {
      String? token = await sharedPrefer().getToken();
      isLoading = true;
      update();
      var url = Uri.parse("https://ticketapp365.akprojects.co/api/orbit/bus/OrbitcancelTicket");

      var request = http.MultipartRequest("POST", url);
      request.headers.addAll({
        'Authorization': 'Bearer $token',
        'Content-Type': 'multipart/form-data',
      });
      request.fields['tin'] = tinNumbers!.join(",");
      request.fields['seatsToCancel'] = seatNumbers!.join(",");
      request.fields['ProviderType'] = providerType!.join(",");
      /*request.fields['tin'] = tin!;
      request.fields['seatsToCancel'] = seatNo!;*/
      print("Request: $request");
      print("Fields: ${request.fields}");
      var response = await request.send();
      if (response.statusCode == 200) {
        // Response: {status: true, message: success!, data: {status: 1, datetime: 2025-02-07 16:09:20, data: {code: OTP27BVE5, totalRefundAmount: 1189.65, cancellationCharge: 0, activeFlag: 0}}}
        var responseBody = await response.stream.bytesToString();
        var jsonResponse = jsonDecode(responseBody);

        print("Response: $jsonResponse");

        if (jsonResponse['status'] == true) {
          selectedIndexes.clear();
          Get.snackbar("Success", "Tickets cancelled successfully!",
              backgroundColor: Colors.green);
          await viewBookingApi(bookingId: bookingId);
        }
      } else {
        var errorBody = await response.stream.bytesToString();
        print("Error Response: $errorBody");
        print("Something went wrong");
      }
    } catch (e) {
      print("Error: $e");
    }
    isLoading = false;
    update();
  }

  List<ViewPassenger> viewPassengerList = [];
  bool isLoadingView = false;

  viewBookingApi({int? bookingId}) async {
    try {
      isLoadingView = true;
      update();

      String? token = await sharedPrefer().getToken();

      if (token == null) {
        print("Authorization token is missing.");
        isLoadingView = false;
        update();
        return;
      }


      var headers = {
        'Authorization': 'Bearer $token',
      };
      var requestBody = {
        "BookingID": bookingId.toString(),
      };
//https://api.ticketapp365.com/api/bus/ViewBooking
      var res = await http.post(
        Uri.parse("https://ticketapp365.akprojects.co/api/bus/ViewBooking"),
        body: requestBody,
        headers: headers,
      );



      print("Request Body: ${requestBody}");

      if (res.statusCode == 200) {
        var data = viewBookingModalFromJson(res.body);
        selectedIndexes.clear();
        update();
        viewPassengerList = data.data!.passengers!;
        update();
      } else {
        print("Error: Something went wrong with the response");
      }
    } catch (e) {
      print("Error: $e");
      Get.snackbar("Error", "Failed to fetch booking details.",
          backgroundColor: Colors.red);
    } finally {
      isLoadingView = false;
      update();
    }
  }

  List<int> selectedIndexes = [];

  void toggleSelection(int index) {
    if (selectedIndexes.contains(index)) {
      selectedIndexes.remove(index);
    } else {
      selectedIndexes.add(index);
    }
    update();
  }
}
