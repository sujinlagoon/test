// To parse this JSON data, do
//
//     final viewBookingModal = viewBookingModalFromJson(jsonString);

import 'dart:convert';

ViewBookingModal viewBookingModalFromJson(String str) => ViewBookingModal.fromJson(json.decode(str));

String viewBookingModalToJson(ViewBookingModal data) => json.encode(data.toJson());

class ViewBookingModal {
  bool? status;
  String? message;
  Data? data;

  ViewBookingModal({
    this.status,
    this.message,
    this.data,
  });

  factory ViewBookingModal.fromJson(Map<String, dynamic> json) => ViewBookingModal(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
  };
}

class Data {
  List<ViewPassenger>? passengers;

  Data({
    this.passengers,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    passengers: json["passengers"] == null ? [] : List<ViewPassenger>.from(json["passengers"]!.map((x) => ViewPassenger.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "passengers": passengers == null ? [] : List<dynamic>.from(passengers!.map((x) => x.toJson())),
  };
}

class ViewPassenger {
  int? buspassengerId;
  int? buspassengerBlockId;
  int? buspassengerBookingId;
  String? buspassengerSeatName;
  String? buspassengerSeatCode;
  String? buspassengerName;
  String? buspassengerFare;
  int? buspassengerStatus;
  dynamic buspassengerLadiesSeat;
  dynamic buspassengerAddress;
  dynamic buspassengerAge;
  String? buspassengerEmail;
  String? buspassengerGender;
  dynamic buspassengerIdNumber;
  dynamic buspassengerIdType;
  String? buspassengerMobile;
  dynamic buspassengerPrimary;
  dynamic buspassengerTitle;
  dynamic buspassengerGstName;
  dynamic buspassengerGstid;
  dynamic buspassengerGstAddress;
  dynamic buspassengerGstEmail;
  DateTime? buspassengerCreatedAt;
  int? bbookingId;
  int? bbookingUserId;
  String? bbookingBusName;
  String? bbookingBusType;
  dynamic bbookingDepartTime;
  String? bbookingStatus;
  String? bbookingBlockKey;
  String? bbookingTin;
  String? bbookingAvailableTripId;
  String? bbookingBPointId;
  String? bbookingDPointId;
  String? bbookingDestination;
  String? bbookingSource;
  DateTime? bbookingCreatedAt;
  String? bbookingPickupLocation;
  String? bbookingDropLocation;
  dynamic bbookingPickupTime;
  dynamic bbookingDropTime;
  DateTime? bbookingDate;
  String? bBookingProviderType;
  String? bbookingFrom;
  String? bbookingTo;

  ViewPassenger({
    this.buspassengerId,
    this.buspassengerBlockId,
    this.buspassengerBookingId,
    this.buspassengerSeatName,
    this.buspassengerSeatCode,
    this.buspassengerName,
    this.buspassengerFare,
    this.buspassengerStatus,
    this.buspassengerLadiesSeat,
    this.buspassengerAddress,
    this.buspassengerAge,
    this.buspassengerEmail,
    this.buspassengerGender,
    this.buspassengerIdNumber,
    this.buspassengerIdType,
    this.buspassengerMobile,
    this.buspassengerPrimary,
    this.buspassengerTitle,
    this.buspassengerGstName,
    this.buspassengerGstid,
    this.buspassengerGstAddress,
    this.buspassengerGstEmail,
    this.buspassengerCreatedAt,
    this.bbookingId,
    this.bbookingUserId,
    this.bbookingBusName,
    this.bbookingBusType,
    this.bbookingDepartTime,
    this.bbookingStatus,
    this.bbookingBlockKey,
    this.bbookingTin,
    this.bbookingAvailableTripId,
    this.bbookingBPointId,
    this.bbookingDPointId,
    this.bbookingDestination,
    this.bbookingSource,
    this.bbookingCreatedAt,
    this.bbookingPickupLocation,
    this.bbookingDropLocation,
    this.bbookingPickupTime,
    this.bbookingDropTime,
    this.bbookingDate,
    this.bBookingProviderType,
    this.bbookingFrom,
    this.bbookingTo,
  });

  factory ViewPassenger.fromJson(Map<String, dynamic> json) => ViewPassenger(
    buspassengerId: json["BuspassengerID"],
    buspassengerBlockId: json["BuspassengerBlockID"],
    buspassengerBookingId: json["BuspassengerBookingID"],
    buspassengerSeatName: json["BuspassengerSeatName"],
    buspassengerSeatCode: json["BuspassengerSeatCode"] ?? "",

    buspassengerName: json["BuspassengerName"],
    buspassengerFare: json["BuspassengerFare"],
    buspassengerStatus: json["BuspassengerStatus"],
    buspassengerLadiesSeat: json["BuspassengerLadiesSeat"],
    buspassengerAddress: json["BuspassengerAddress"],
    buspassengerAge: json["BuspassengerAge"],
    buspassengerEmail: json["BuspassengerEmail"],
    buspassengerGender: json["BuspassengerGender"],
    buspassengerIdNumber: json["BuspassengerIDNumber"],
    buspassengerIdType: json["BuspassengerIDType"],
    buspassengerMobile: json["BuspassengerMobile"],
    buspassengerPrimary: json["BuspassengerPrimary"],
    buspassengerTitle: json["BuspassengerTitle"],
    buspassengerGstName: json["BuspassengerGSTName"],
    buspassengerGstid: json["BuspassengerGSTID"],
    buspassengerGstAddress: json["BuspassengerGSTAddress"],
    buspassengerGstEmail: json["BuspassengerGSTEmail"],
    buspassengerCreatedAt: json["BuspassengerCreatedAt"] == null ? null : DateTime.parse(json["BuspassengerCreatedAt"]),
    bbookingId: json["BbookingID"],
    bbookingUserId: json["BbookingUserID"],
    bbookingBusName: json["BbookingBusName"],
    bbookingBusType: json["BbookingBusType"],
    bbookingDepartTime: json["BbookingDepartTime"],
    bbookingStatus: json["BbookingStatus"],
    bbookingBlockKey: json["BbookingBlockKey"],
    bbookingTin: json["BbookingTIN"],
    bbookingAvailableTripId: json["BbookingAvailableTripId"],
    bbookingBPointId: json["BbookingBPointId"],
    bbookingDPointId: json["BbookingDPointId"],
    bbookingDestination: json["BbookingDestination"],
    bbookingSource: json["BbookingSource"],
    bbookingCreatedAt: json["BbookingCreatedAt"] == null ? null : DateTime.parse(json["BbookingCreatedAt"]),
    bbookingPickupLocation: json["BbookingPickupLocation"],
    bbookingDropLocation: json["BbookingDropLocation"],
    bbookingPickupTime: json["BbookingPickupTime"],
    bbookingDropTime: json["BbookingDropTime"],
    bbookingDate: json["BbookingDate"] == null ? null : DateTime.parse(json["BbookingDate"]),
    bBookingProviderType: json["BBookingProviderType"],
    bbookingFrom: json["BbookingFrom"],
    bbookingTo: json["BbookingTo"],
  );

  Map<String, dynamic> toJson() => {
    "BuspassengerID": buspassengerId,
    "BuspassengerBlockID": buspassengerBlockId,
    "BuspassengerBookingID": buspassengerBookingId,
    "BuspassengerSeatName": buspassengerSeatName,
    "BuspassengerSeatCode": buspassengerSeatCode,
    "BuspassengerName": buspassengerName,
    "BuspassengerFare": buspassengerFare,
    "BuspassengerStatus": buspassengerStatus,
    "BuspassengerLadiesSeat": buspassengerLadiesSeat,
    "BuspassengerAddress": buspassengerAddress,
    "BuspassengerAge": buspassengerAge,
    "BuspassengerEmail": buspassengerEmail,
    "BuspassengerGender": buspassengerGender,
    "BuspassengerIDNumber": buspassengerIdNumber,
    "BuspassengerIDType": buspassengerIdType,
    "BuspassengerMobile": buspassengerMobile,
    "BuspassengerPrimary": buspassengerPrimary,
    "BuspassengerTitle": buspassengerTitle,
    "BuspassengerGSTName": buspassengerGstName,
    "BuspassengerGSTID": buspassengerGstid,
    "BuspassengerGSTAddress": buspassengerGstAddress,
    "BuspassengerGSTEmail": buspassengerGstEmail,
    "BuspassengerCreatedAt": buspassengerCreatedAt?.toIso8601String(),
    "BbookingID": bbookingId,
    "BbookingUserID": bbookingUserId,
    "BbookingBusName": bbookingBusName,
    "BbookingBusType": bbookingBusType,
    "BbookingDepartTime": bbookingDepartTime,
    "BbookingStatus": bbookingStatus,
    "BbookingBlockKey": bbookingBlockKey,
    "BbookingTIN": bbookingTin,
    "BbookingAvailableTripId": bbookingAvailableTripId,
    "BbookingBPointId": bbookingBPointId,
    "BbookingDPointId": bbookingDPointId,
    "BbookingDestination": bbookingDestination,
    "BbookingSource": bbookingSource,
    "BbookingCreatedAt": bbookingCreatedAt?.toIso8601String(),
    "BbookingPickupLocation": bbookingPickupLocation,
    "BbookingDropLocation": bbookingDropLocation,
    "BbookingPickupTime": bbookingPickupTime,
    "BbookingDropTime": bbookingDropTime,
    "BbookingDate": bbookingDate?.year != null
        ? "${bbookingDate!.year.toString().padLeft(4, '0')}-${bbookingDate!.month.toString().padLeft(2, '0')}-${bbookingDate!.day.toString().padLeft(2, '0')}"
        : "Not Available",
    "BBookingProviderType": bBookingProviderType,
    "BbookingFrom": bbookingFrom,
    "BbookingTo": bbookingTo,
  };
}
