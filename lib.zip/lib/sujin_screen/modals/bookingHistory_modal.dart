import 'dart:convert';

BookingHistory bookingHistoryFromJson(String str) =>
    BookingHistory.fromJson(json.decode(str));

String bookingHistoryToJson(BookingHistory data) => json.encode(data.toJson());

class BookingHistory {
  bool? status;
  String? message;
  Data? data;

  BookingHistory({
    this.status,
    this.message,
    this.data,
  });

  factory BookingHistory.fromJson(Map<String, dynamic> json) => BookingHistory(
        status: json["status"] ?? false, // Default to false if null
        message: json["message"] ?? "", // Default to empty string if null
        data: json["data"] != null ? Data.fromJson(json["data"]) : null,
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "message": message,
        "data": data?.toJson(),
      };
}

class Data {
  List<Booking>? bookings;

  Data({
    this.bookings,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        bookings: json["bookings"] != null
            ? List<Booking>.from(
                json["bookings"].map((x) => Booking.fromJson(x)))
            : [], // Default to an empty list if bookings is null
      );

  Map<String, dynamic> toJson() => {
        "bookings": bookings != null
            ? List<dynamic>.from(bookings!.map((x) => x.toJson()))
            : [], // Default to an empty list if bookings is null
      };
}

class Booking {
  String? buspassengerSeatName;
  String? bbookingTin;
  int? bbookingId;
  String? bbookingBusName;
  String? bbookingBusType;
  String? bbookingPickupLocation;
  String? bbookingPickupTime;
  String? bbookingDropLocation;
  String? bbookingDropTime;
  String? bbookingStatus;
  String? buspassengerSeatCode;

  Booking({
    this.buspassengerSeatName,
    this.buspassengerSeatCode,
    this.bbookingId,
    this.bbookingTin,
    this.bbookingBusName,
    this.bbookingBusType,
    this.bbookingPickupLocation,
    this.bbookingPickupTime,
    this.bbookingDropLocation,
    this.bbookingDropTime,
    this.bbookingStatus,
  });

  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
        bbookingTin: json["BbookingTIN"],
        bbookingId: json["BbookingID"] ?? 0,
        // Default to 0 if null
        bbookingBusName: json["BbookingBusName"] ?? "",
        // Default to empty string if null
        bbookingBusType: json["BbookingBusType"] ?? "",
        buspassengerSeatName: json["BuspassengerSeatName"],
        buspassengerSeatCode: json["BuspassengerSeatCode"],
        // Default to empty string if null
        bbookingPickupLocation: json["BbookingPickupLocation"] ?? "",
        // Default to empty string if null
        bbookingPickupTime: json["BbookingPickupTime"] ?? "",
        // Default to empty string if null
        bbookingDropLocation: json["BbookingDropLocation"] ?? "",
        // Default to empty string if null
        bbookingDropTime: json["BbookingDropTime"] ?? "",
        // Default to empty string if null
        bbookingStatus:
            json["BbookingStatus"] ?? "", // Default to empty string if null
      );

  Map<String, dynamic> toJson() => {
        "BuspassengerSeatName": buspassengerSeatName,
        "BbookingTIN": bbookingTin,
        "BbookingID": bbookingId,
        "BbookingBusName": bbookingBusName,
        "BbookingBusType": bbookingBusType,
        "BbookingPickupLocation": bbookingPickupLocation,
        "BbookingPickupTime": bbookingPickupTime,
        "BbookingDropLocation": bbookingDropLocation,
        "BbookingDropTime": bbookingDropTime,
        "BbookingStatus": bbookingStatus,
        "BuspassengerSeatCode": buspassengerSeatCode,
      };
}
