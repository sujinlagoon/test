// To parse this JSON data, do
//
//     final bothCities = bothCitiesFromJson(jsonString);

import 'dart:convert';

BothCities bothCitiesFromJson(String str) => BothCities.fromJson(json.decode(str));

String bothCitiesToJson(BothCities data) => json.encode(data.toJson());

class BothCities {
  bool? status;
  String? message;
  BothData? data;

  BothCities({
    this.status,
    this.message,
    this.data,
  });

  factory BothCities.fromJson(Map<String, dynamic> json) => BothCities(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : BothData.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
  };
}

class BothData {
  List<BothPopularCity>? popularcities;
  List<BothCity>? cities;

  BothData({
    this.popularcities,
    this.cities,
  });

  factory BothData.fromJson(Map<String, dynamic> json) => BothData(
    popularcities: json["popularcities"] == null ? [] : List<BothPopularCity>.from(json["popularcities"]!.map((x) => BothPopularCity.fromJson(x))),
    cities: json["cities"] == null ? [] : List<BothCity>.from(json["cities"]!.map((x) => BothCity.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "popularcities": popularcities == null ? [] : List<dynamic>.from(popularcities!.map((x) => x.toJson())),
    "cities": cities == null ? [] : List<dynamic>.from(cities!.map((x) => x.toJson())),
  };
}

class BothCity {
  dynamic cityId;
  String? cityName;
  dynamic cityStateId;
  String? cityState;
  String? serviceProviderType;

  BothCity({
    this.cityId,
    this.cityName,
    this.cityStateId,
    this.cityState,
    this.serviceProviderType,
  });

  factory BothCity.fromJson(Map<String, dynamic> json) => BothCity(
    cityId: json["CityID"],
    cityName: json["CityName"],
    cityStateId: json["CityStateID"],
    cityState: json["CityState"],
    serviceProviderType: json["service_provider_type"],
  );

  Map<String, dynamic> toJson() => {
    "CityID": cityId,
    "CityName": cityName,
    "CityStateID": cityStateId,
    "CityState": cityState,
    "service_provider_type": serviceProviderType,
  };
}

class BothPopularCity {
  int? cityId;
  int? cityStateId;
  String? cityName;
  String? cityLocationType;
  String? cityLatitude;
  String? cityLongitude;
  String? cityState;

  BothPopularCity({
    this.cityId,
    this.cityStateId,
    this.cityName,
    this.cityLocationType,
    this.cityLatitude,
    this.cityLongitude,
    this.cityState,
  });

  factory BothPopularCity.fromJson(Map<String, dynamic> json) => BothPopularCity(
    cityId: json["CityID"],
    cityStateId: json["CityStateID"],
    cityName: json["CityName"],
    cityLocationType: json["CityLocationType"],
    cityLatitude: json["CityLatitude"],
    cityLongitude: json["CityLongitude"],
    cityState: json["CityState"],
  );

  Map<String, dynamic> toJson() => {
    "CityID": cityId,
    "CityStateID": cityStateId,
    "CityName": cityName,
    "CityLocationType": cityLocationType,
    "CityLatitude": cityLatitude,
    "CityLongitude": cityLongitude,
    "CityState": cityState,
  };
}
