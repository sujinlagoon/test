import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../bus_list/bus_List.dart';
import '../../bus_list/controller.dart';
import '../../customButton.dart';
import 'customexpansion/custom_rating.dart';
import 'customexpansion/filtercustom_expansion.dart';

class FilterView extends StatefulWidget {
  String? fromLocation;
  String? toLocation;
  DateTime? selectedDate;
  List<String>? selectedBusTypes;

  FilterView(
      {super.key,
      this.toLocation,
      this.fromLocation,
      this.selectedDate,
      this.selectedBusTypes});

  @override
  _FilterViewState createState() => _FilterViewState();
}

class _FilterViewState extends State<FilterView> {
  BusListController controller = Get.put(BusListController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.selectedBusTypes = widget.selectedBusTypes ?? [];
    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Filter By"),
        leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Icon(Icons.arrow_back_ios)),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: SingleChildScrollView(
            child: GetBuilder<BusListController>(builder: (v) {
              return Column(
                children: [
                  // First Panel - Bus Operator Rating
                  ExpansionPanelItem(
                    title: "Operator Rating",
                    isExpanded: v.isExpandedList[0],
                    onExpansionChanged: (bool expanded) {
                      v.isExpandedList[0] = expanded;
                      v.update();
                    },
                    childBody: Column(
                      children: [
                        CustomRating(
                          label: "5",
                          isChecked: true,
                          onChanged: (bool? value) {
                            // Update the selected rating filter
                          },
                        ),
                        CustomRating(
                          label: "4-3",
                          isChecked: true,
                          onChanged: (bool? value) {
                            // Update the selected rating filter
                          },
                        ),
                        CustomRating(
                          label: "1-2",
                          isChecked: true,
                          onChanged: (bool? value) {
                            // Update the selected rating filter
                          },
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 12),

                  // Second Panel - Bus Operators
                  ExpansionPanelItem(
                    title: "Bus Operators",
                    isExpanded: v.isExpandedList[1],
                    onExpansionChanged: (bool expanded) {
                      v.isExpandedList[1] = expanded;
                      v.update();
                    },
                    childBody: GetBuilder<BusListController>(builder: (v) {
                      return ListView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: v.availableTrips.length,
                        itemBuilder: (context, index) {
                          return CheckboxListTile(
                            title: Text(v.availableTrips[index].busType ?? 'Unknown'),
                            value: widget.selectedBusTypes!
                                .contains(v.availableTrips[index].busType),
                            onChanged: (bool? value) {
                              if (value == true) {
                                controller.addToSelectedBusTypes(
                                    v.filteredTrips[index].busType!);
                              } else {
                                controller.removeFromSelectedBusTypes(
                                    v.filteredTrips[index].busType!);
                              }
                              setState(() {}); // Update UI
                            },
                          );
                        },
                      );
                    }),
                  ),

                  SizedBox(height: 12),

                  SizedBox(height: 78),
                ],
              );
            }),
          ),
        ),
      ),
      bottomSheet: Container(
        height: MediaQuery.of(context).size.height * 0.10,
        width: MediaQuery.of(context).size.width,
        decoration: const BoxDecoration(
            border: Border(top: BorderSide(color: Colors.black, width: 0.2))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TextButton(
              onPressed: () {},
              child: Text("Clear All Selection"),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: GetBuilder<BusListController>(builder: (v) {
                return CustomButton(
                  width: MediaQuery.sizeOf(context).height * 0.12,
                  text: "Find",
                  onTap: () {
                    controller.filteredTrips = controller.availableTrips
                        .where((trip) =>
                            widget.selectedBusTypes!.contains(trip.busType))
                        .toList();
                    controller.update();
                    controller.filteredTrips.forEach((e) {
                      return print(e);
                    });
                    Get.back();
                    /* controller.filteredTrips = controller.filteredTrips
                        .where((trip) => trip.isSelected == true)
                        .toList();
                    controller.update();
                    controller.filteredTrips.forEach((e) {
                      return print(e);
                    });
                    Get.back();*/
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}
