import 'package:flutter/material.dart';

class ExpansionPanelItem extends StatelessWidget {
  final String title;
  final bool isExpanded;
  final Widget? childBody;
  final Function(bool) onExpansionChanged;

  ExpansionPanelItem({
    Key? key,
    required this.title,
    required this.isExpanded,
    this.childBody,
    required this.onExpansionChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ExpansionPanelList(
      elevation: 1,
      expandedHeaderPadding: EdgeInsets.zero,
      animationDuration: Duration(milliseconds: 500),
      expansionCallback: (int index, bool isExpanded) {
        onExpansionChanged(isExpanded);
      },
      children: [
        ExpansionPanel(
          canTapOnHeader: true,
          headerBuilder: (BuildContext context, bool isExpanded) {
            return Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: Text(
                title,
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            );
          },
          body: childBody != null
              ? SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: childBody,
            ),
          )
              : SizedBox.shrink(),
          isExpanded: isExpanded,
        ),
      ],
    );
  }
}
