import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:screenshot/screenshot.dart';
import 'package:share_plus/share_plus.dart';

import '../../CancelTicket/canel_controller/cancel_controller.dart';
import '../../controllers_/booking_history_controller.dart';
import '../../modals/bookingHistory_modal.dart';

class ParticularDetails extends StatefulWidget {
  final Booking bookingDetails;

  ParticularDetails({Key? key, required this.bookingDetails}) : super(key: key);

  @override
  State<ParticularDetails> createState() => _ParticularDetailsState();
}

class _ParticularDetailsState extends State<ParticularDetails> {
  BookingHistoryController controller = Get.put(BookingHistoryController());
  CancelController cancelController = Get.put(CancelController());
  final ScreenshotController _screenshotController = ScreenshotController();

  void _takeScreenshotAndShare() async {
    try {
      final Uint8List? screenshot = await _screenshotController.capture();
      if (screenshot != null) {
        final directory = await getTemporaryDirectory();
        final filePath = '${directory.path}/ticket_screenshot.png';

        // Save the screenshot to a file
        final File file = File(filePath);
        await file.writeAsBytes(screenshot);

        // Convert the file path to XFile
        final xFile = XFile(file.path);

        // Share the screenshot using XFile
        await Share.shareXFiles([xFile], text: 'Here is my ticket details!');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to capture screenshot')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    cancelController.bookingId = widget.bookingDetails.bbookingId;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print("---bb${cancelController.bookingId}");
    return Screenshot(
      controller: _screenshotController,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
              onPressed: () {
                Get.back();
              },
              icon: Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              )),
          actions: [
            IconButton(
                onPressed: _takeScreenshotAndShare,
                icon: Icon(
                  Icons.share,
                  color: Colors.white,
                ))
          ],
          backgroundColor: Colors.blueAccent,
          title: Text(
            'Ticket Details',
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: GetBuilder<BookingHistoryController>(builder: (v) {
            if (widget.bookingDetails == null) {
              return Center(child: Text("No booking details available"));
            }

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Booking ID and Bus Name
                Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Booking ID: ${widget.bookingDetails.bbookingId}',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8),
                        Row(
                          children: [
                            Icon(Icons.directions_bus,
                                color: Colors.blueAccent),
                            SizedBox(width: 8),
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.70,
                              child: Text(
                                overflow: TextOverflow.ellipsis,
                                'Bus Name: ${widget.bookingDetails.bbookingBusName}',
                                style: TextStyle(fontSize: 16),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(height: 20),

                // Bus Type
                Text(
                  'Bus Type: ${widget.bookingDetails.bbookingBusType}',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.black54,
                  ),
                ),
                SizedBox(height: 20),

                // Pickup and Drop Information
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildLocationCard(
                      icon: Icons.location_on,
                      label: 'Pickup',
                      location: widget.bookingDetails.bbookingPickupLocation!,
                      time: widget.bookingDetails.bbookingPickupTime!,
                    ),
                    _buildLocationCard(
                      icon: Icons.location_on,
                      label: 'Drop',
                      location: widget.bookingDetails.bbookingDropLocation!,
                      time: widget.bookingDetails.bbookingDropTime!,
                    ),
                  ],
                ),

                SizedBox(height: 20),

                // Booking Status
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: (widget.bookingDetails.bbookingStatus == "BOOKED" ||
                            widget.bookingDetails.bbookingStatus == "Booked")
                        ? Colors.green
                        : Colors.red,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        (widget.bookingDetails.bbookingStatus == "BOOKED" ||
                                widget.bookingDetails.bbookingStatus ==
                                    "Booked")
                            ? Icons.check_circle
                            : Icons.cancel,
                        color: Colors.white,
                      ),
                      SizedBox(width: 8),
                      Text(
                        'Status: ${widget.bookingDetails.bbookingStatus}',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                if (cancelController.selectedIndexes.isNotEmpty)
                  SizedBox(
                    height: 10.h,
                  ),
                GetBuilder<CancelController>(builder: (v) {
                  // v.selectedIndexes.clear();
                  if (v.selectedIndexes.isNotEmpty)
                    return Column(
                      children: [
                        SizedBox(height: 10.h),
                        InkWell(
                          onTap: () {
                            bool hasSeatSeller = v.selectedIndexes.any((index) =>
                            v.viewPassengerList[index].bBookingProviderType?.toLowerCase() == "seatseller");

                            print(hasSeatSeller);
                            List<String> selectedTins = v.selectedIndexes.map((index) => v.viewPassengerList[index].bbookingTin!).toList();
                            List<String> sele = v.selectedIndexes.map((index) => v.viewPassengerList[index].bBookingProviderType!).toList();

                            List<String> selectedSeats = v.selectedIndexes.map((index) => v.viewPassengerList[index].buspassengerSeatCode!).toList();
                            print("${selectedSeats}selectedSeats");
                            List<String> selectedSeatsPro = v.selectedIndexes.map((index) => v.viewPassengerList[index].buspassengerSeatName!).toList();


                            v.cancelBooking(
                              seatNumbers:hasSeatSeller ? selectedSeatsPro : selectedSeats,
                              tinNumbers: selectedTins,
                              providerType:sele ,
                            );
                          },
                          child: Align(
                            alignment: Alignment.topRight,
                            child: Container(
                              padding: EdgeInsets.all(5.r),
                              height: 30.h,
                              decoration: BoxDecoration(
                                color: Colors.red,
                                borderRadius: BorderRadius.circular(10.r),
                              ),
                              child: Center(
                                child: Text(
                                  v.selectedIndexes.length == 1
                                      ? "Cancel"
                                      : "Cancel All",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    );
                  return SizedBox.shrink();
                }),

                GetBuilder<CancelController>(builder: (v) {
                  List filteredPassengers = v.viewPassengerList
                      .where((ticket) => ticket.buspassengerStatus == 1)
                      .toList();

                  return v.isLoadingView
                      ? Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Center(
                            child: CircularProgressIndicator(),
                          ),
                        )
                      : ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: filteredPassengers.length,
                          padding: EdgeInsets.all(12),
                          itemBuilder: (context, index) {
                            var ticket = filteredPassengers[index];

                            String formattedDate = DateFormat('MMM dd, yyyy')
                                .format(ticket.buspassengerCreatedAt!);
                            String formattedTime = DateFormat('hh:mm a')
                                .format(ticket.buspassengerCreatedAt!);
                            return ticket.buspassengerStatus == 1
                                ? TicketCard(
                                    title: ticket.buspassengerName,
                                    date: formattedDate,
                                    price: ticket.buspassengerFare,
                                    seat: ticket.buspassengerSeatName,
                                    time: formattedTime,
                                    isSelected:
                                        v.selectedIndexes.contains(index),
                                    onChanged: (value) {
                                      print(value);
                                      v.toggleSelection(index);
                                    },
                                  )
                                : SizedBox();
                          },
                        );
                }),
                SizedBox(height: 1),
                // Booking Created At
              ],
            );
          }),
        ),
      ),
    );
  }

  // Helper method to create Pickup/Drop cards
  Widget _buildLocationCard({
    required IconData icon,
    required String label,
    required String location,
    required String time,
  }) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Icon(icon, color: Colors.blueAccent, size: 30),
            SizedBox(height: 8),
            Text(
              '$label Location',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              location,
              style: TextStyle(fontSize: 14),
            ),
            SizedBox(height: 8),
            Text(
              'Time: $time',
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}

class TicketCard extends StatelessWidget {
  String? title;
  String? price;
  String? date;
  String? time;
  String? seat;
  bool? isSelected;
  ValueChanged<bool?>? onChanged;

  TicketCard(
      {Key? key,
      this.title,
      this.date,
      this.time,
      this.price,
      this.seat,
      this.isSelected,
      this.onChanged})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Top Section with Checkbox
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Checkbox(
                    value: isSelected,
                    onChanged: onChanged,
                  ),
                  Icon(Icons.airplane_ticket, color: Colors.blue, size: 28),
                ],
              ),
              Text(
                title!,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text(
                price!,
                style: TextStyle(fontSize: 16, color: Colors.green),
              ),
            ],
          ),
          SizedBox(height: 8),

          // Middle Section (Dashed Divider)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              children: List.generate(
                150 ~/ 3,
                (index) => index.isEven
                    ? SizedBox(width: 3)
                    : Container(width: 3, height: 1, color: Colors.black54),
              ),
            ),
          ),

          // Bottom Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Date",
                      style: TextStyle(fontSize: 14, color: Colors.grey)),
                  Text(date!,
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Time",
                      style: TextStyle(fontSize: 14, color: Colors.grey)),
                  Text(time!,
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Seat",
                      style: TextStyle(fontSize: 14, color: Colors.grey)),
                  Text(seat!,
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
