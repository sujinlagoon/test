import 'dart:typed_data'; // This is the correct import for Uint8List
import 'dart:io'; // For file operations
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/Screens/controller/seatavailabilty-controller.dart';
import 'package:fluttertickect365/sujin_screen/Screens/utils/appBar_reuse.dart';
import 'package:fluttertickect365/sujin_screen/SharedPref/sharedPref.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:screenshot/screenshot.dart';
import 'package:share_plus/share_plus.dart';

class TicketdetailsView extends StatefulWidget {
  String? fromTime;
  String? toTime;
  double? busRate;
  String? fromLocation;
  String? toLocation;
  DateTime? selectedDate;
  String? busName;
  List<String>? names;
  List<int>? ages;
  List<String>? sex;
  String? droppingPoint;
  String? boardingPoint;
  List<int>? selectedIndexes;
  List<String>? selectedSeatNames;

  TicketdetailsView(
      {super.key,
      this.toLocation,
      this.fromLocation,
      this.selectedDate,
      this.ages,
      this.busName,
      this.fromTime,
      this.names,
      this.busRate,
      this.sex,
      this.boardingPoint,
      this.droppingPoint,
      this.selectedIndexes,
      this.selectedSeatNames,
      this.toTime});

  @override
  State<TicketdetailsView> createState() => _TicketdetailsViewState();
}

class _TicketdetailsViewState extends State<TicketdetailsView> {
  final ScreenshotController _screenshotController = ScreenshotController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getSharePrefBookId();
  }

  String? getBookId;

  getSharePrefBookId() async {
    String? bookingId = await sharedPrefer().getBookingKey();
    setState(() {
      getBookId = bookingId;
    });
  }

  void _takeScreenshotAndShare() async {
    try {
      final Uint8List? screenshot = await _screenshotController.capture();
      if (screenshot != null) {
        final directory = await getTemporaryDirectory();
        final filePath = '${directory.path}/ticket_screenshot.png';

        // Save the screenshot to a file
        final File file = File(filePath);
        await file.writeAsBytes(screenshot);

        // Convert the file path to XFile
        final xFile = XFile(file.path);

        // Share the screenshot using XFile
        await Share.shareXFiles([xFile], text: 'Here is my ticket details!');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to capture screenshot')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    print("selectedIndex${widget.selectedIndexes}");
    print("selectedseeatname${widget.selectedSeatNames}");
    return Screenshot(
      controller: _screenshotController,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
              onPressed: () {
                Get.back();
              },
              icon: Icon(Icons.arrow_back_ios)),
          title: Text(
            "Ticket Details",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          actions: [
            IconButton(
                onPressed: _takeScreenshotAndShare, icon: Icon(Icons.share))
          ],
        ),
        body: SafeArea(
            child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              TripCard(
                toTime: widget.toTime,
                fromTime: widget.fromTime,
                status: "Completed",
                startCity: widget.fromLocation!,
                startPlace: widget.boardingPoint!,
                startDateTime:
                    DateFormat('h:mm a, dd MMMM').format(widget.selectedDate!),
                endCity: widget.toLocation!,
                endPlace: widget.droppingPoint!,
                endDateTime:
                    DateFormat('h:mm a, dd MMMM').format(widget.selectedDate!),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  children: [
                    Text(
                      widget.busName!,
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                    Text("AC Volvo Sleeper Multi-Axle"),
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Passenger Details",
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    ListView.builder(
                        itemCount: widget.selectedIndexes!.length,
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          print(
                              "length of tickeyt user ${widget.selectedIndexes!.length}");
                          int actualIndex = widget.selectedIndexes![index];
                          print("actualInde$actualIndex");

                          return Column(
                            children: [
                              const SizedBox(
                                height: 12,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Mr ${widget.names![actualIndex]}',
                                    style: const TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    '${widget.ages![actualIndex]} Yrs | Seat ${widget.selectedSeatNames![index]}',
                                    style: TextStyle(
                                        color: Colors.grey, fontSize: 12.sp),
                                  ),
                                ],
                              )
                            ],
                          );
                        })
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              TicketInfoCard(
                ticketNumber: getBookId ?? 'Loading...',
                pnrNumber: "TRANZR56R",
                fare: ('\u{20B9}${widget.busRate}'),
              ),
            ],
          ),
        )),
      ),
    );
  }
}

class TripCard extends StatelessWidget {
  final String status;
  final String startCity;
  final String startPlace;
  final String startDateTime;
  final String endCity;
  final String endPlace;
  final String endDateTime;
  String? fromTime;
  String? toTime;

  TripCard(
      {Key? key,
      required this.status,
      required this.startCity,
      required this.startPlace,
      required this.startDateTime,
      required this.endCity,
      required this.endPlace,
      required this.endDateTime,
      this.fromTime,
      this.toTime})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black, width: 0.2),
        color: Colors.grey[200], // Background color
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Text(
            status,
            style: TextStyle(
              color: status == 'Completed' ? Colors.green : Colors.orange,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Expanded(
                  child: buildCityColumn(
                      startCity, startPlace, startDateTime, fromTime)),
              /* SizedBox(
                width: MediaQuery.of(context).size.width * 0.06,
              ),*/
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  // Right align content
                  children: [
                    buildCityColumn1(endCity, endPlace, endDateTime, toTime),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildCityColumn1(
      String city, String place, String date, String? time) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          city,
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 15.sp,
              color: Colors.black,
              overflow: TextOverflow.ellipsis),
        ),
        const SizedBox(height: 6),
        Text(
          place,
          style: TextStyle(
            fontSize: 13.sp,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          '$date ${time != null ? '| ' + SeatAvailabilityController().getPrefixedSeatName(time) : ''}',
          style: TextStyle(
            fontSize: 13.sp,
            color: Colors.black,
          ),
        ),
      ],
    );
  }

  Widget buildCityColumn(String city, String place, String date, String? time) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          city,
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 15.sp,
              color: Colors.black,
              overflow: TextOverflow.ellipsis),
        ),
        const SizedBox(height: 6),
        Text(
          place,
          style: TextStyle(
            fontSize: 13.sp,
            color: Colors.black,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          '$date ${time != null ? '| ' + SeatAvailabilityController().getPrefixedSeatName(time) : ''}',
          style: TextStyle(
            fontSize: 13.sp,
            color: Colors.black,
          ),
        ),
      ],
    );
  }
}

class TicketInfoCard extends StatelessWidget {
  final String ticketNumber;
  final String pnrNumber;
  final String fare;

  const TicketInfoCard({
    Key? key,
    required this.ticketNumber,
    required this.pnrNumber,
    required this.fare,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black, width: 0.2),
        // Border color and width
        borderRadius: BorderRadius.circular(8), // Rounded corners
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildRow("Ticket #", ticketNumber),
          const Divider(color: Colors.grey), // Dashed line separator
          _buildRow("PNR #", pnrNumber),
          const Divider(color: Colors.grey),
          _buildRow("FARE", fare, isBold: true),
        ],
      ),
    );
  }

  Widget _buildRow(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12.sp,
                color: Colors.black,
              ),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
