import 'package:get/get.dart';
import 'package:oauth1/oauth1.dart' as oauth1;

import '../modal/Availability_seats.dart';

class SeatAvailabilityController extends GetxController {
  SeatAvailabilty? seatAvailability;
  List<Seat> availSeat = [];
  List<Seat> lowerDeckSeats = [];
  List<Seat> upperDeckSeats = [];
  bool isDoubleBerth = false;
  int?totaBus;
  List<String> selectedSeatNames = [];
  Map<int, Map<int, Seat>> seat2DArray = {}; // 2D array for seats (row, column)
  Map<int, Map<int, Map<int, Seat>>> seat3DArray =
      {}; // 3D array for seats (zIndex, row, column)

  double? busRate = 0.0;
  bool isLoading = true;
  bool is3DLayout(List<Seat> seats) {
    return seats.any((seat) => seat.zIndex != null && seat.zIndex != "0");
  }

  final String consumerKey = 'MCycaVxF6XVV0ImKgqFPBAncx0prPp';
  final String consumerSecret = '5f0lpy9heMvXNQ069lQPNMomysX6rt';
  Future<bool> availabilitySeatGet({int? id}) async {
    try {
      isLoading = true;
      update();

      final clientCredentials = oauth1.ClientCredentials(consumerKey, consumerSecret);
      final authClient = oauth1.Client(oauth1.SignatureMethods.hmacSha1, clientCredentials, null);

      final url = Uri.parse('http://api.seatseller.travel/tripdetails?id=$id');
      final response = await authClient.get(url);
      print(url);

      if (response.statusCode == 200) {
        final data = seatAvailabiltyFromJson(response.body);

        if (data != null && data.seats.isNotEmpty) {
          availSeat = data.seats;
          try {
            busRate = double.parse(data.seats.first.fare!);
          } catch (e) {
            busRate = 0;
            print("Error parsing busRate: $e");
          }

          seat2DArray.clear();
          seat3DArray.clear();

          // Populate the seat arrays
          for (var seat in data.seats) {
            int zIndex = int.parse(seat.zIndex!);
            int row = int.parse(seat.row!);
            int column = int.parse(seat.column!);

            // 2D Array: Group seats by row and column
            seat2DArray[row] ??= {};
            seat2DArray[row]![column] = seat;

            // 3D Array: Group seats by zIndex, row, and column
            seat3DArray[zIndex] ??= {};
            seat3DArray[zIndex]![row] ??= {};
            seat3DArray[zIndex]![row]![column] = seat;
          }

          lowerDeckSeats = availSeat.where((seat) => seat.zIndex == "0").toList();
          upperDeckSeats = availSeat.where((seat) => seat.zIndex == "1").toList();
          isDoubleBerth = lowerDeckSeats.isNotEmpty && upperDeckSeats.isNotEmpty;
          isLoading = false;
          update();

          return true; // ✅ Ensure the function returns true if successful
        } else {
          print("Error: Unable to parse seat availability data.");
          isLoading = false;
          update();
          return false; // ✅ Return false if no seats are available
        }
      } else {
        print("Error: ${response.statusCode} - ${response.body}");
        isLoading = false;
        update();
        return false; // ✅ Return false if the API response fails
      }
    } catch (e) {
      print("Exception occurred: $e");
      isLoading = false;  // Set loading state to false in case of error
      update();
      return false; // ✅ Return false if an exception occurs
    }
  }
/*
 availabilitySeatGet({int? id}) async {
    try {
      isLoading = true;
      update();

      final clientCredentials =
          oauth1.ClientCredentials(consumerKey, consumerSecret);
      final authClient = oauth1.Client(
        oauth1.SignatureMethods.hmacSha1,
        clientCredentials,
        null,
      );

      final url = Uri.parse('http://api.seatseller.travel/tripdetails?id=$id');
      final response = await authClient.get(url);
       print(url);
      if (response.statusCode == 200) {
        final data = seatAvailabiltyFromJson(response.body);
        if (data != null && data.seats.isNotEmpty) {
          availSeat = data.seats;
          try {
            busRate = double.parse(data.seats.first.fare!);
          } catch (e) {
            busRate = 0;
            print("Error parsing busRate: $e");
          }
          seat2DArray.clear();
          seat3DArray.clear();

          // Populate the seat arrays
          for (var seat in data.seats) {
            int zIndex = int.parse(seat.zIndex!);
            int row = int.parse(seat.row!);
            int column = int.parse(seat.column!);


            print("Seat Details - zIndex: $zIndex, Row: $row, Column: $column");

            // 2D Array: Group seats by row and column
            seat2DArray[row] ??= {};
            seat2DArray[row]![column] = seat;

            // 3D Array: Group seats by zIndex, row, and column
            seat3DArray[zIndex] ??= {};
            seat3DArray[zIndex]![row] ??= {};
            seat3DArray[zIndex]![row]![column] = seat;
          }

          lowerDeckSeats =
              availSeat.where((seat) => seat.zIndex == "0").toList();
          upperDeckSeats =
              availSeat.where((seat) => seat.zIndex == "1").toList();
          isDoubleBerth =
              lowerDeckSeats.isNotEmpty && upperDeckSeats.isNotEmpty;
          isLoading = false;
          update();

        } else {
          print("Error: Unable to parse seat availability data.");
        }
      } else {
        print("Error: ${response.statusCode} - ${response.body}");
      }
    } catch (e) {
      print("Exception occurred: $e");
      isLoading = false;  // Set loading state to false in case of error
      update();
    }
  }
*/

  Map<String, bool> lowerDeckSelectedSeats = {};
  Map<String, bool> upperDeckSelectedSeats = {};

  void toggleSeatSelection(String seatId, String deck) {
    if (deck == "0") {
      if (lowerDeckSelectedSeats.containsKey(seatId)) {
        lowerDeckSelectedSeats[seatId] = !lowerDeckSelectedSeats[seatId]!;
      } else {
        lowerDeckSelectedSeats[seatId] = true;
      }
    } else if (deck == "1") {
      if (upperDeckSelectedSeats.containsKey(seatId)) {
        upperDeckSelectedSeats[seatId] = !upperDeckSelectedSeats[seatId]!;
      } else {
        upperDeckSelectedSeats[seatId] = true;
      }
    }
    updateSelectedSeatNames();
    update();
  }

  String getPrefixedSeatName(String seatName) {
    // Example logic for determining prefix
    if (seatName.startsWith('L')) {
      return seatName; // Already prefixed with L
    } else if (seatName.startsWith('U')) {
      return seatName; // Already prefixed with U
    } else {
      // Logic to determine if it's a lower or upper deck seat
      bool isLowerDeck = true; // Replace with actual condition
      return isLowerDeck ? 'L$seatName' : 'U$seatName';
    }
  }

  void updateSelectedSeatNames() {
    selectedSeatNames.clear();

    // Add selected lower deck seats with "L" prefix
    selectedSeatNames.addAll(lowerDeckSelectedSeats.entries
        .where((entry) => entry.value) // Only add selected seats
        .map((entry) => '${entry.key}'));

    // Add selected upper deck seats with "U" prefix
    selectedSeatNames.addAll(upperDeckSelectedSeats.entries
        .where((entry) => entry.value)
        .map((entry) => '${entry.key}'));
  }

  void resetSelection() {
    lowerDeckSelectedSeats.clear();
    upperDeckSelectedSeats.clear();
    selectedSeatNames.clear();
    update();
  }

  double calculateTotalFare() {
    int totalSelectedSeats = lowerDeckSelectedSeats.values
            .where((isSelected) => isSelected)
            .length +
        upperDeckSelectedSeats.values.where((isSelected) => isSelected).length;
    return totalSelectedSeats * (busRate ?? 0.0);
  }

  String convertMinutesToTimeFormat(int minutes) {
    int hours = minutes ~/ 60;
    int remainingMinutes = minutes % 60;

    // Format the time as HH:mm
    String formattedTime =
        '${hours.toString().padLeft(2, '0')}:${remainingMinutes.toString().padLeft(2, '0')}';

    return formattedTime;
  }
}
