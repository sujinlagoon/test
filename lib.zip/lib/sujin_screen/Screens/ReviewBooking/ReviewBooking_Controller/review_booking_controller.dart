import 'dart:convert';
import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:fluttertickect365/presentation/utils/AppConstants.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../../../SharedPref/sharedPref.dart';

class ReviewBookingController extends GetxController {
  TextEditingController contactCT = TextEditingController();
  TextEditingController emailCT = TextEditingController();
  var selectedOffer = '';
  bool isPanelOpen = false;

  bool isLoading = false;
  final String consumerKey = 'MCycaVxF6XVV0ImKgqFPBAncx0prPp';
  final String consumerSecret = '5f0lpy9heMvXNQ069lQPNMomysX6rt';

  // bookApi

  Future<bool> bookTicket({required String blockKey}) async {

    final url = Uri.parse('https://ticketapp365.akprojects.co/api/bus/bookTicket');
    debugPrint("API URL: $url");

    try {
      isLoading = true;
      update();

      String? getToken = await sharedPrefer().getToken();
      log("Bearer Token: $getToken");

      final bodyData = {
        'blockKey': blockKey,
      };
      print("book api body data: $bodyData");

      final response = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $getToken',
        },
        body: bodyData,
      );
      debugPrint(url.toString());
      debugPrint("Response Status Code: ${response.statusCode}");
      debugPrint("Response Body: ${response.body}");

      if (response.statusCode == 200) {
        print('Ticket booked successfully');
        var data = jsonDecode(response.body);
        var bookingId = data['data'];
        sharedPrefer().saveBookingKey(bookingId);
        debugPrint('--BookingId$bookingId');
        return true;
      } else {
        print('Failed to book ticket: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error during ticket booking: $e');
      return false;
    } finally {
      isLoading = false;
      update();
    }
  }
}
