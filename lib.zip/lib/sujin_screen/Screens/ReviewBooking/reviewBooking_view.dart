import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/Screens/controller/seatavailabilty-controller.dart';
import 'package:fluttertickect365/sujin_screen/Screens/utils/appBar_reuse.dart';
import 'package:fluttertickect365/sujin_screen/SharedPref/sharedPref.dart';
import 'package:fluttertickect365/sujin_screen/customButton.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';

import '../../../presentation/cab_homepage_screen/apiModel/HomePage.dart';
import '../../../presentation/cab_homepage_screen/cab_homepage_screen.dart';
import '../../customBus_details.dart';
import '../Address/address_controller/address_controller.dart';
import '../TicketDetails/TicketDetails_view.dart';
import '../utils/textField_custom.dart';
import 'ReviewBooking_Controller/review_booking_controller.dart';

class ReviewbookingView extends StatefulWidget {
  List<String> selectedSeatNames = [];
  double busRate;
  final List<String>? names;
  final List<int>? ages;
  final List<String>? sex;
  List<double>? busRates = [];
  String? fromTime;
  String? busName;
  String? fromLocation;
  String? toLocation;
  String? toTime;
  DateTime? selectDate;
  List<int>? selectedIndexes;
  String? droppingPoint;
  String? boardingPoint;

  ReviewbookingView(
      {super.key,
      required this.selectedSeatNames,
      required this.busRate,
      this.names,
      this.ages,
      this.busRates,
      this.fromTime,
      this.selectedIndexes,
      this.toTime,
      this.fromLocation,
      this.toLocation,
      this.selectDate,
      this.busName,
      this.droppingPoint,
      this.boardingPoint,
      this.sex});

  @override
  State<ReviewbookingView> createState() => _ReviewbookingViewState();
}

class _ReviewbookingViewState extends State<ReviewbookingView> {
  bool isLoading = false;
  ReviewBookingController vv = Get.put(ReviewBookingController());
  AddressController ac = Get.put(AddressController());

  @override
  Widget build(BuildContext context) {
    print("--------------------->${widget.selectedIndexes}");
    print("selected seat name${widget.selectedSeatNames}");
    return Scaffold(
      bottomSheet: Container(
        height: 75,
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(
            top: BorderSide(color: Colors.grey.withOpacity(0.6), width: 1),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 18.0, top: 7),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Seat No: ${widget.selectedSeatNames.join(',')}',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    "Total Fare",
                    style: TextStyle(color: Colors.blue),
                  ),
                  Text(
                    "\u{20B9}${widget.busRate}",
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(right: 8.0),
              child: GetBuilder<ReviewBookingController>(
                builder: (v) {
                  return CustomButton(
                    width: Get.width * 0.30,
                    text: "Proceed to Pay",
                    onTap: () async {

                      /*setState(() {
                        isLoading = true;
                      });*/
                      String? block_key = await sharedPrefer().getBlockKey();
                      bool isSuccess = await vv.bookTicket(blockKey: block_key!);
                      // Set loading state to true
                    /*  setState(() {
                        isLoading = true;
                      });*/
                      if (isSuccess) {
                        showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (context) {
                            return WillPopScope(
                              onWillPop: () async {
                                return false;
                              },
                              child: AlertDialog(
                                content: Container(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Lottie.asset("assets/lottie/8fw2wa1zjV.json"),
                                      SizedBox(height: 10),
                                      Container(
                                        padding:
                                            EdgeInsets.symmetric(horizontal: 16),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text("Booking Successful",
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold)),
                                            SizedBox(height: 8),
                                            Text(
                                              "Congratulations! Your ticket is confirmed.",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(fontSize: 16),
                                            ),
                                            SizedBox(
                                              height: MediaQuery.of(context)
                                                      .size
                                                      .height *
                                                  0.01,
                                            ),
                                            InkWell(
                                              onTap: () {
                                                Get.to(() => TicketdetailsView(
                                                      toLocation: widget.toLocation,
                                                      fromLocation: widget.fromLocation,
                                                      selectedDate: widget.selectDate,
                                                      ages: widget.ages,
                                                      busRate: widget.busRate,
                                                      busName: widget.busName,
                                                      fromTime: widget.fromTime,
                                                      names: widget.names,
                                                      sex: widget.sex,
                                                      toTime: widget.toTime,
                                                      selectedIndexes: widget.selectedIndexes,
                                                      selectedSeatNames: widget.selectedSeatNames,
                                                      boardingPoint: widget.boardingPoint,
                                                      droppingPoint: widget.droppingPoint,
                                                    ));
                                              },
                                              child: Container(
                                                height: MediaQuery.of(context)
                                                        .size
                                                        .height *
                                                    0.04,
                                                width: Get.width * 0.30,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(12.r),
                                                  gradient: LinearGradient(
                                                    colors: [
                                                      Color(0xFF4181FF),
                                                      Color(0xFF274E99)
                                                    ],
                                                    begin: Alignment.centerLeft,
                                                    end: Alignment.centerRight,
                                                  ),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    "View E-Tickets",
                                                    style: TextStyle(
                                                        color: Colors.black),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height: MediaQuery.of(context)
                                                      .size
                                                      .height *
                                                  0.02,
                                            ),
                                            InkWell(
                                              onTap: () {},
                                              child: CustomButton(
                                                text: "Back to Home",
                                                onTap: () {
                                                  Get.offAll(CabHomepageScreen(),
                                                      transition: Transition.fade);
                                                },
                                              ),
                                            )
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Please check Api.........'),
                            backgroundColor: Colors.red,
                          ),
                        );
                      }

                      //
                    },
                    isLoading: v.isLoading,
                  );
                }
              ),
            ),
          ],
        ),
      ),
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        title: Text("Review Booking"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                CustomBusDetails(
                    busName: widget.busName,
                    fromTime: widget.fromTime,
                    fromLocation: widget.fromLocation,
                    toLocation: widget.toLocation,
                    dateTime: widget.selectDate,
                    toTime: widget.toTime),
                const SizedBox(
                  height: 10,
                ),
                SizedBox(
                  child: GetBuilder<AddressController>(builder: (v) {
                    return ListView.builder(
                      shrinkWrap: true,
                      itemCount: widget.selectedIndexes!.length,
                      // Use the selected indexes count
                      itemBuilder: (context, index) {
                        print(
                            "Rebuilding GetBuilder with passengers: ${v.passengers}");
                        int actualIndex = widget.selectedIndexes![index];
                        final passenger = v.passengers[index];
                        return Padding(
                            padding: const EdgeInsets.all(3.0),
                            child: /*PassengerDetails(
                              context,
                              passengerName: widget.names![actualIndex],
                              age: widget.ages![actualIndex],
                              seatNo: widget.selectedSeatNames[index],
                              index: actualIndex
                            )*/
                                // index: actualIndex),
                                PassengerDetails(
                              context,
                              passengerName: passenger.name,
                              age: passenger.age,
                              seatNo: widget.selectedSeatNames[index],
                              index: index,
                            ));
                      },
                    );
                  }),
                ),
           /*     const SizedBox(
                  height: 10,
                ),
                Container(
                  padding: const EdgeInsets.all(13),
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey, width: 0.2),
                      borderRadius: BorderRadius.circular(12)),
                  child: Column(
                    children: [
                      const Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            "Enter Contact Details to get Ticket",
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold),
                          )),
                      const SizedBox(
                        height: 15,
                      ),
                      customTextField(context,
                          textInputType: TextInputType.number,
                          controller: vv.contactCT,
                          maxLength: 10,
                          labelText: "Mobile Number",
                          labelStyle: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(
                        height: 15,
                      ),
                      customTextField(context,
                          textInputType: TextInputType.emailAddress,
                          controller: vv.emailCT,
                          labelStyle: TextStyle(
                              color: Colors.black, fontWeight: FontWeight.bold),
                          labelText: "Email ID"),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                GetBuilder<ReviewBookingController>(builder: (v) {
                  return Container(
                    padding: EdgeInsets.all(13),
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey, width: 0.2),
                        borderRadius: BorderRadius.circular(12)),
                    child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 35.w),
                          child: Align(
                            child: Text(
                              "Offers",
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                            alignment: Alignment.topLeft,
                          ),
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        OfferCard(
                          groupValue: v.selectedOffer,
                          onChanged: (value) {
                            v.selectedOffer = value!;
                            v.update();
                          },
                          title: 'TRANZKINGBUS',
                          description:
                              'Avail Rs. 100 instant discount on bus ticket booking.',
                        ),
                        const SizedBox(height: 16),
                        OfferCard(
                          groupValue: v.selectedOffer,
                          onChanged: (value) {
                            v.selectedOffer = value!;
                            v.update();
                          },
                          title: 'BOTBUS',
                          description:
                              'Avail Rs. 100 instant discount on bus ticket booking.',
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  );
                }),*/
                const SizedBox(
                  height: 10,
                ),
                GetBuilder<ReviewBookingController>(builder: (v) {
                  return ExpansionPanelList(
                    animationDuration: Duration(milliseconds: 500),
                    expansionCallback: (int index, bool isExpanded) {
                      v.isPanelOpen = isExpanded;
                      print(v.isPanelOpen);
                      v.update();
                    },
                    children: [
                      ExpansionPanel(
                        headerBuilder: (BuildContext context, bool isExpanded) {
                          return Container(
                            decoration:
                                const BoxDecoration(color: Colors.white),
                            padding: const EdgeInsets.symmetric(
                                vertical: 16, horizontal: 8),
                            // Optional padding
                            child:  Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              // Aligns to the left
                              crossAxisAlignment: CrossAxisAlignment.center,
                              // Centers vertically
                              children: [
                                Text(
                                  "Cancellation Policy",
                                  style: TextStyle(
                                      fontSize: 16.sp,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          );
                        },
                        body: const Column(
                          children: [
                            Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Text(
                                  "Our cancellation policy ensures fairness and transparency for all customers. Cancellations made more than 24 hours before the scheduled departure are eligible for a full refund, while those made within 12-24 hours will incur a 50% cancellation fee. Unfortunately, cancellations made less than 12 hours before departure or no-shows are non-refundable. Refunds will be processed within 5-7 business days. In case of service disruptions due to unforeseen circumstances, a full refund will be provided. For assistance, please reach out to our support team."),
                            )
                          ],
                        ),
                        backgroundColor: Colors.white,
                        isExpanded: v.isPanelOpen,
                      ),
                    ],
                  );
                }),
                SizedBox(
                  height: 100,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void showEditPassengerDialog(
    BuildContext context, {
    required int index,
    required String passengerName,
    required int age,
  }) {
    TextEditingController nameController =
        TextEditingController(text: passengerName);
    TextEditingController ageController =
        TextEditingController(text: age.toString());

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Edit Passenger Details"),
          content: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Name TextField
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: "Name"),
              ),
              // Age TextField
              TextField(
                controller: ageController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: "Age"),
              ),
            ],
          ),
          actions: [
            // Cancel Button
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text("Cancel"),
            ),
            // Save Button
            GetBuilder<AddressController>(builder: (v) {
              return TextButton(
                onPressed: () {
                  String updatedName = nameController.text;
                  int updatedAge = int.tryParse(ageController.text) ?? age;
                  v.updatePassengerDetails(index, updatedName, updatedAge);
                  print(updatedAge);
                  v.update();
                  Navigator.of(context).pop();
                },
                child: Text("Save"),
              );
            }),
          ],
        );
      },
    );
  }

  Widget PassengerDetails(
    BuildContext context, {
    String? passengerName,
    int? age,
    String? seatNo,
    int? index,
  }) {
    return Container(
        padding: EdgeInsets.all(8),
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.2),
            borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Passenger Details",
                  style: TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold),
                ),
                GetBuilder<AddressController>(builder: (v) {
                  return InkWell(
                      onTap: () {
                        print(passengerName);
                        showEditPassengerDialog(
                          context,
                          index: index!,
                          passengerName: passengerName!,
                          age: age!,
                        );
                      },
                      child: Text(
                        "Edit",
                        style: TextStyle(color: Colors.blue, fontSize: 16),
                      ));
                }),
              ],
            ),
            const SizedBox(
              height: 12,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Mr. ${passengerName}',
                  style: const TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold),
                ),
                Text(
                  '$age yrs | seat $seatNo',
                  style: const TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ],
            )
          ],
        ));
  }
}

/*Widget customBusDetails(
  BuildContext context, {
  String? BusName,
  String? fromLocation,
  String? toLocation,
  String? fromTime,
  String? toTime,
  DateTime? dateTime,
}) {
  return Container(
    padding: EdgeInsets.all(8),
    width: MediaQuery.of(context).size.width,
    decoration: BoxDecoration(
        border: Border.all(color: Colors.grey, width: 0.2),
        borderRadius: BorderRadius.circular(12)),
    child: Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              BusName ?? '',
              style: TextStyle(
                  fontSize: 18.sp,
                  color: Colors.black,
                  fontWeight: FontWeight.bold),
            ),
            Text(
              "Details",
              style: TextStyle(fontSize: 14.sp, color: Colors.blue),
            ),
          ],
        ),
        SizedBox(
          height: 13.h,
        ),
        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        fromLocation ?? '',
                        style: TextStyle(color: Colors.black),
                      ),
                      const Text(
                        "Detailed Address",
                        style: TextStyle(color: Colors.black),
                      ),
                      Text(
                          "${SeatAvailabilityController().convertMinutesToTimeFormat(int.parse(fromTime!))} | ${DateFormat('EEE, dd MMM').format(dateTime!)}"),
                    ],
                  ),
                ),
                const SizedBox(width: 10), // Adding space between columns
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        toLocation ?? '',
                        style: TextStyle(color: Colors.black),
                        overflow: TextOverflow.ellipsis,
                      ),
                      const Text(
                        "Detailed Address",
                        style: TextStyle(color: Colors.black),
                      ),
                      Text(
                          "${SeatAvailabilityController().convertMinutesToTimeFormat(int.parse(toTime!))} | ${DateFormat('EEE, dd MMM').format(dateTime!)}"),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
          ],
        ),
      ],
    ),
  );
}*/




class OfferCard extends StatelessWidget {
  final String title;
  final String description;
  final String groupValue;
  final ValueChanged<String?> onChanged;

  const OfferCard({
    Key? key,
    required this.title,
    required this.description,
    required this.groupValue,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          // /  border: Border.all(color: Colors.grey, width: 0.2),
          borderRadius: BorderRadius.circular(12)),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Radio(
            value: title,
            groupValue: groupValue,
            onChanged: onChanged,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.blue,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                      color: Colors.black, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                GestureDetector(
                  onTap: () {},
                  child: const Text(
                    'T&C',
                    style: TextStyle(
                      color: Colors.black,
                      /*decoration: TextDecoration.underline,*/
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
