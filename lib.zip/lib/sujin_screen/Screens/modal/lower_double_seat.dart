import 'package:flutter/material.dart';

class SleeperWithSeatNewUI extends StatefulWidget {
  SleeperWithSeatNewUI({super.key});

  @override
  State<SleeperWithSeatNewUI> createState() => _SleeperWithSeatNewUIState();
}

class _SleeperWithSeatNewUIState extends State<SleeperWithSeatNewUI> {
  // Separate lists for lower and upper desk seat selections
  final List<int> selectedLowerSeats = [];
  final List<int> selectedUpperSeats = [];

  // Toggle selection for lower desk seats
  void toggleLowerSeatSelection(int seatIndex) {
    setState(() {
      if (selectedLowerSeats.contains(seatIndex)) {
        selectedLowerSeats.remove(seatIndex);
      } else {
        selectedLowerSeats.add(seatIndex);
      }
    });
  }

  // Toggle selection for upper desk seats
  void toggleUpperSeatSelection(int seatIndex) {
    setState(() {
      if (selectedUpperSeats.contains(seatIndex)) {
        selectedUpperSeats.remove(seatIndex);
      } else {
        selectedUpperSeats.add(seatIndex);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet: Container(
        color: Colors.white,
        height: 100,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text("Selected Seats:"),
                Text(
                  [
                    ...selectedLowerSeats,
                    ...selectedUpperSeats,
                  ].join(", "),
                ),
                Text(
                    "Total Fare: \$${(selectedLowerSeats.length + selectedUpperSeats.length) * 50}"),
              ],
            ),
            Container(
              color: Colors.blue,
              height: 45,
              width: 100,
            ),
          ],
        ),
      ),
      appBar: AppBar(
        leading: Icon(Icons.arrow_back_ios),
        automaticallyImplyLeading: false,
        title: const Text("Select Seats"),
      ),
      body: Row(
        children: [
          // Lower Desk Section
          Expanded(
            flex: 1,
            child: Padding(
              padding: EdgeInsets.only(
                left: MediaQuery.of(context).size.width * 0.03,
                bottom: MediaQuery.of(context).size.height * 0.13,
                top: MediaQuery.of(context).size.height * 0.01,
              ),
              child: Container(
                height: MediaQuery.sizeOf(context).height * 0.7,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Text("Lower Desk"),
                        Image.asset(
                          "assets/car_handle.png",
                          height: 22,
                        ),
                      ],
                    ),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.01),
                    Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: GridView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: 5,
                            gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 1,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 9,
                              mainAxisExtent: 87,
                            ),
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  toggleLowerSeatSelection(index + 1);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(4.0),
                                  child: Container(
                                    height: 50,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      border: Border.all(
                                        color: selectedLowerSeats
                                            .contains(index + 1)
                                            ? Colors.green
                                            : Colors.grey,
                                        width: 1,
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        "${index + 1}",
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 2),
                        const VerticalDivider(color: Colors.black),
                        Expanded(
                          flex: 7,
                          child: GridView.builder(
                            shrinkWrap: true,
                            physics: const AlwaysScrollableScrollPhysics(),
                            itemCount: 20,
                            gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                            ),
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                  onTap: () {
                                    toggleLowerSeatSelection(index + 6);
                                  },
                                  child: buildSeat(index + 6));
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          // Upper Desk Section
          Expanded(
            flex: 1,
            child: Padding(
              padding: EdgeInsets.only(
                right: MediaQuery.of(context).size.width * 0.03,
                bottom: MediaQuery.of(context).size.height * 0.13,
                top: MediaQuery.of(context).size.height * 0.01,
              ),
              child: Container(
                height: MediaQuery.sizeOf(context).height * 0.7,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                ),
                child: Column(
                  children: [
                    Text("Upper Desk"),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.02),
                    Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: GridView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: 5,
                            gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 1,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 9,
                              mainAxisExtent: 87,
                            ),
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  toggleUpperSeatSelection(index + 1 + 5); // Shifted by 5
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(4.0),
                                  child: Container(
                                    height: 50,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      border: Border.all(
                                        color: selectedUpperSeats
                                            .contains(index + 1 + 5)
                                            ? Colors.green
                                            : Colors.grey,
                                        width: 1,
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        "${index + 1 + 5}", // Shifted by 5
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 2),
                        Expanded(
                          flex: 7,
                          child: GridView.builder(
                            shrinkWrap: true,
                            physics: const AlwaysScrollableScrollPhysics(),
                            itemCount: 10,
                            gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 10,
                              mainAxisExtent: 86,
                            ),
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  toggleUpperSeatSelection(index + 6 + 5); // Shifted by 5
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(4.0),
                                  child: Container(
                                    height: 50,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      border: Border.all(
                                        color: selectedUpperSeats
                                            .contains(index + 6 + 5)
                                            ? Colors.green
                                            : Colors.grey,
                                        width: 1,
                                      ),
                                    ),
                                    child: Center(
                                      child: Text(
                                        "${index + 6 + 5}", // Shifted by 5
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSeat(int seatIndex,
      {String imagePath = "assets/armchair (1).png"}) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Image.asset(
          imagePath,
          height: 32,
          color: selectedLowerSeats.contains(seatIndex) || selectedUpperSeats.contains(seatIndex)
              ? Colors.green
              : Colors.grey,
          colorBlendMode: BlendMode.modulate, // Tint image
        ),
        Positioned(
          top: 11,
          child: Text(
            "$seatIndex",
            style: const TextStyle(
              fontSize: 12,
              color: Colors.black,
            ),
          ),
        ),
      ],
    );
  }
}
