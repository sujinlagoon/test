// To parse this JSON data, do
//
//     final seatAvailabilty = seatAvailabiltyFromJson(jsonString);

import 'dart:convert';

SeatAvailabilty seatAvailabiltyFromJson(String str) => SeatAvailabilty.fromJson(json.decode(str));

String seatAvailabiltyToJson(SeatAvailabilty data) => json.encode(data.toJson());

class SeatAvailabilty {
  String availableSeats;
  String availableSingleSeat;
  dynamic boardingTimes;
  String callFareBreakUpApi;
  dynamic droppingTimes;
  List<FareDetail> fareDetails;
  String forcedSeats;
  String isAggregator;
  String maxSeatsPerTicket;
  String noSeatLayoutEnabled;
  String primo;
  List<Seat> seats;
  String vaccinatedBus;
  String vaccinatedStaff;

  SeatAvailabilty({
    required this.availableSeats,
    required this.availableSingleSeat,
    required this.boardingTimes,
    required this.callFareBreakUpApi,
    required this.droppingTimes,
    required this.fareDetails,
    required this.forcedSeats,
    required this.isAggregator,
    required this.maxSeatsPerTicket,
    required this.noSeatLayoutEnabled,
    required this.primo,
    required this.seats,
    required this.vaccinatedBus,
    required this.vaccinatedStaff,
  });

  factory SeatAvailabilty.fromJson(Map<String, dynamic> json) {
    return SeatAvailabilty(
      availableSeats: json["availableSeats"],
      availableSingleSeat: json["availableSingleSeat"],
      boardingTimes: _parseTimes(json["boardingTimes"]),
      callFareBreakUpApi: json["callFareBreakUpAPI"],
      droppingTimes: _parseTimes(json["droppingTimes"]),
      fareDetails: json["fareDetails"] is List
          ? List<FareDetail>.from((json["fareDetails"] as List).map((x) => FareDetail.fromJson(x)))
          : [],
      forcedSeats: json["forcedSeats"],
      isAggregator: json["isAggregator"],
      maxSeatsPerTicket: json["maxSeatsPerTicket"],
      noSeatLayoutEnabled: json["noSeatLayoutEnabled"],
      primo: json["primo"],
      seats: List<Seat>.from(json["seats"].map((x) => Seat.fromJson(x))),
      vaccinatedBus: json["vaccinatedBus"],
      vaccinatedStaff: json["vaccinatedStaff"],
    );
  }

  Map<String, dynamic> toJson() => {
    "availableSeats": availableSeats,
    "availableSingleSeat": availableSingleSeat,
    "boardingTimes": _timesToJson(boardingTimes),
    "callFareBreakUpAPI": callFareBreakUpApi,
    "droppingTimes": _timesToJson(droppingTimes),
    "fareDetails": List<dynamic>.from(fareDetails.map((x) => x.toJson())),
    "forcedSeats": forcedSeats,
    "isAggregator": isAggregator,
    "maxSeatsPerTicket": maxSeatsPerTicket,
    "noSeatLayoutEnabled": noSeatLayoutEnabled,
    "primo": primo,
    "seats": List<dynamic>.from(seats.map((x) => x.toJson())),
    "vaccinatedBus": vaccinatedBus,
    "vaccinatedStaff": vaccinatedStaff,
  };

  // Method to parse both list and single object for boardingTimes and droppingTimes
  static dynamic _parseTimes(dynamic timesJson) {
    if (timesJson is List) {
      return List<IngTimes>.from(timesJson.map((x) => IngTimes.fromJson(x)));
    } else {
      return IngTimes.fromJson(timesJson);
    }
  }

  // Method to handle times in JSON serialization
  static dynamic _timesToJson(dynamic times) {
    if (times is List) {
      return List<dynamic>.from(times.map((x) => x.toJson()));
    } else {
      return times.toJson();
    }
  }
}


class IngTimes {
  String address;
  String bpId;
  String bpName;
  String city;
  String cityId;
  String contactNumber;
  String landmark;
  String location;
  String locationId;
  String prime;
  String time;

  IngTimes({
    required this.address,
    required this.bpId,
    required this.bpName,
    required this.city,
    required this.cityId,
    required this.contactNumber,
    required this.landmark,
    required this.location,
    required this.locationId,
    required this.prime,
    required this.time,
  });

  factory IngTimes.fromJson(Map<String, dynamic> json) => IngTimes(
    address: json["address"],
    bpId: json["bpId"],
    bpName: json["bpName"],
    city: json["city"],
    cityId: json["cityId"],
    contactNumber: json["contactNumber"],
    landmark: json["landmark"],
    location: json["location"],
    locationId: json["locationId"],
    prime: json["prime"],
    time: json["time"],
  );

  Map<String, dynamic> toJson() => {
    "address": address,
    "bpId": bpId,
    "bpName": bpName,
    "city": city,
    "cityId": cityId,
    "contactNumber": contactNumber,
    "landmark": landmark,
    "location": location,
    "locationId": locationId,
    "prime": prime,
    "time": time,
  };
}

class FareDetail {
  String bankTrexAmt;
  String baseFare;
  String bookingFee;
  String childFare;
  String gst;
  String levyFare;
  String markupFareAbsolute;
  String markupFarePercentage;
  String opFare;
  String opGroupFare;
  String operatorServiceChargeAbsolute;
  String operatorServiceChargePercentage;
  String serviceCharge;
  String serviceTaxAbsolute;
  String serviceTaxPercentage;
  String srtFee;
  String tollFee;
  String totalFare;

  FareDetail({
    required this.bankTrexAmt,
    required this.baseFare,
    required this.bookingFee,
    required this.childFare,
    required this.gst,
    required this.levyFare,
    required this.markupFareAbsolute,
    required this.markupFarePercentage,
    required this.opFare,
    required this.opGroupFare,
    required this.operatorServiceChargeAbsolute,
    required this.operatorServiceChargePercentage,
    required this.serviceCharge,
    required this.serviceTaxAbsolute,
    required this.serviceTaxPercentage,
    required this.srtFee,
    required this.tollFee,
    required this.totalFare,
  });

  factory FareDetail.fromJson(Map<String, dynamic> json) => FareDetail(
    bankTrexAmt: json["bankTrexAmt"],
    baseFare: json["baseFare"],
    bookingFee: json["bookingFee"],
    childFare: json["childFare"],
    gst: json["gst"],
    levyFare: json["levyFare"],
    markupFareAbsolute: json["markupFareAbsolute"],
    markupFarePercentage: json["markupFarePercentage"],
    opFare: json["opFare"],
    opGroupFare: json["opGroupFare"],
    operatorServiceChargeAbsolute: json["operatorServiceChargeAbsolute"],
    operatorServiceChargePercentage: json["operatorServiceChargePercentage"],
    serviceCharge: json["serviceCharge"],
    serviceTaxAbsolute: json["serviceTaxAbsolute"],
    serviceTaxPercentage: json["serviceTaxPercentage"],
    srtFee: json["srtFee"],
    tollFee: json["tollFee"],
    totalFare: json["totalFare"],
  );

  Map<String, dynamic> toJson() => {
    "bankTrexAmt": bankTrexAmt,
    "baseFare": baseFare,
    "bookingFee": bookingFee,
    "childFare": childFare,
    "gst": gst,
    "levyFare": levyFare,
    "markupFareAbsolute": markupFareAbsolute,
    "markupFarePercentage": markupFarePercentage,
    "opFare": opFare,
    "opGroupFare": opGroupFare,
    "operatorServiceChargeAbsolute": operatorServiceChargeAbsolute,
    "operatorServiceChargePercentage": operatorServiceChargePercentage,
    "serviceCharge": serviceCharge,
    "serviceTaxAbsolute": serviceTaxAbsolute,
    "serviceTaxPercentage": serviceTaxPercentage,
    "srtFee": srtFee,
    "tollFee": tollFee,
    "totalFare": totalFare,
  };
}

class Seat {
  String ?available;
  String ?baseFare;
  String ?column;
  String ?doubleBirth;
  String ?fare;
  String ?ladiesSeat;
  String ?length;
  String ?malesSeat;
  String ?markupFareAbsolute;
  String ?markupFarePercentage;
  String ?name;
  String ?operatorServiceChargeAbsolute;
  String ?operatorServiceChargePercent;
  String ?reservedForSocialDistancing;
  String ?row;
  String ?serviceTaxAbsolute;
  String ?serviceTaxPercentage;
  String ?width;
  String ?zIndex;

  Seat({
     this.available,
     this.baseFare,
     this.column,
     this.doubleBirth,
     this.fare,
     this.ladiesSeat,
     this.length,
     this.malesSeat,
     this.markupFareAbsolute,
     this.markupFarePercentage,
     this.name,
     this.operatorServiceChargeAbsolute,
     this.operatorServiceChargePercent,
     this.reservedForSocialDistancing,
     this.row,
     this.serviceTaxAbsolute,
     this.serviceTaxPercentage,
     this.width,
     this.zIndex,
  });

  factory Seat.fromJson(Map<String, dynamic> json) => Seat(
    available: json["available"],
    baseFare: json["baseFare"],
    column: json["column"],
    doubleBirth: json["doubleBirth"],
    fare: json["fare"],
    ladiesSeat: json["ladiesSeat"],
    length: json["length"],
    malesSeat: json["malesSeat"],
    markupFareAbsolute: json["markupFareAbsolute"],
    markupFarePercentage: json["markupFarePercentage"],
    name: json["name"],
    operatorServiceChargeAbsolute: json["operatorServiceChargeAbsolute"],
    operatorServiceChargePercent: json["operatorServiceChargePercent"],
    reservedForSocialDistancing: json["reservedForSocialDistancing"],
    row: json["row"],
    serviceTaxAbsolute: json["serviceTaxAbsolute"],
    serviceTaxPercentage: json["serviceTaxPercentage"],
    width: json["width"],
    zIndex: json["zIndex"],
  );

  Map<String, dynamic> toJson() => {
    "available": available,
    "baseFare": baseFare,
    "column": column,
    "doubleBirth": doubleBirth,
    "fare": fare,
    "ladiesSeat": ladiesSeat,
    "length": length,
    "malesSeat": malesSeat,
    "markupFareAbsolute": markupFareAbsolute,
    "markupFarePercentage": markupFarePercentage,
    "name": name,
    "operatorServiceChargeAbsolute": operatorServiceChargeAbsolute,
    "operatorServiceChargePercent": operatorServiceChargePercent,
    "reservedForSocialDistancing": reservedForSocialDistancing,
    "row": row,
    "serviceTaxAbsolute": serviceTaxAbsolute,
    "serviceTaxPercentage": serviceTaxPercentage,
    "width": width,
    "zIndex": zIndex,
  };

}
