import 'package:flutter/material.dart';
import 'package:fluttertickect365/sujin_screen/Screens/utils/appBar_reuse.dart';

class BusSeatLayout extends StatefulWidget {
  const BusSeatLayout({super.key});

  @override
  State<BusSeatLayout> createState() => _BusSeatLayoutState();
}

class _BusSeatLayoutState extends State<BusSeatLayout> {
  final List<int> _selectedSeats = [];
  final List<int> _selectedAdditionalSeats = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Text('70 Buses'),
          ),
        ],
      ),
      body: Column(
        children: [
          // Avoid giving unbounded height by using a ListView or CustomScrollView
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(
                  horizontal: MediaQuery.of(context).size.width / 7,
                  vertical: MediaQuery.of(context).size.height / 12),
              child: Stack(
                children: [
                  Container(
                    padding: const EdgeInsets.only(top: 50),
                    decoration:
                        BoxDecoration(border: Border.all(color: Colors.black)),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // Left side (20 seats)
                            Flexible(
                              child: GridView.builder(
                                padding: const EdgeInsets.all(8.0),
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: 20,
                                shrinkWrap: true,
                                gridDelegate:
                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2, // 2 seats per row
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10,
                                  childAspectRatio: 1.2,
                                ),
                                itemBuilder: (context, index) {
                                  final seatNumber = index + 1;
                                  return buildSeat(seatNumber);
                                },
                              ),
                            ),
                            const SizedBox(width: 30), // Aisle space
                            // Right side (20 seats)
                            Flexible(
                              child: GridView.builder(
                                padding: const EdgeInsets.all(8.0),
                                physics: const NeverScrollableScrollPhysics(),
                                itemCount: 20,
                                shrinkWrap: true,
                                gridDelegate:
                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2, // 2 seats per row
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10,
                                  childAspectRatio: 1.2,
                                ),
                                itemBuilder: (context, index) {
                                  final seatNumber = index + 21;
                                  return buildSeat(seatNumber);
                                },
                              ),
                            ),
                          ],
                        ),
                        // Handle the additional 5 seats (at the bottom)
                        Flexible(
                          child: GridView.builder(
                            padding: const EdgeInsets.all(8.0),
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: 5,
                            shrinkWrap: true,
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 5,
                              crossAxisSpacing: 10,
                              mainAxisSpacing: 10,
                              mainAxisExtent: 35,
                              childAspectRatio: 0.1,
                            ),
                            itemBuilder: (context, index) {
                              final seatNumber = index + 41;
                              return buildAdditionalSeat(seatNumber);
                            },
                          ),
                        )
                      ],
                    ),
                  ),
                  // Flutter logo positioned at the top-right
                  const Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: EdgeInsets.all(8.0), // Add some spacing
                      child: FlutterLogo(size: 30), // Adjust size as needed
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildSeat(int seatNumber) {
    final isSelected = _selectedSeats.contains(seatNumber);
    return GestureDetector(
      onTap: () {
        setState(() {
          if (isSelected) {
            _selectedSeats.remove(seatNumber);
          } else {
            _selectedSeats.add(seatNumber);
          }
        });
      },
      child: Container(
        height: 30,
        decoration: BoxDecoration(
          color: isSelected ? Colors.green : Colors.grey[300],
          border: Border.all(color: Colors.black),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: Text(
            '$seatNumber',
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 10,
            ),
          ),
        ),
      ),
    );
  }

  // Build additional seat widget (for the 5 seats)
  Widget buildAdditionalSeat(int seatNumber) {
    final isSelected = _selectedAdditionalSeats.contains(seatNumber);
    return GestureDetector(
      onTap: () {
        setState(() {
          if (isSelected) {
            _selectedAdditionalSeats.remove(seatNumber);
          } else {
            _selectedAdditionalSeats.add(seatNumber);
          }
        });
      },
      child: Container(
        height: 30,
        decoration: BoxDecoration(
          color: isSelected ? Colors.green : Colors.grey[300],
          border: Border.all(color: Colors.black),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: Text(
            '$seatNumber',
            style: TextStyle(
              color: isSelected ? Colors.white : Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 10,
            ),
          ),
        ),
      ),
    );
  }
}
