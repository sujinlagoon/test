/*
class SeatDummy {
  final String row;
  final int seatNumber;
  bool isSelected;

  SeatDummy({
    required this.row,
    required this.seatNumber,
    this.isSelected = false,
  });
}
*/
