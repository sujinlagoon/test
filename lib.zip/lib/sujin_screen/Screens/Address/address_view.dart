import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/customButton.dart';
import 'package:get/get.dart';
import 'package:fluttertickect365/sujin_screen/Screens/utils/appBar_reuse.dart';
import '../../../presentation/cab_homepage_screen/apiModel/sharedPref.dart';
import '../../Profile/profile__controller.dart';
import '../../orbit_Api/reuse_widget/sizes.dart';
import '../ReviewBooking/reviewBooking_view.dart';
import 'address_controller/address_controller.dart';
import 'address_modal/adress_modal.dart';

class AddressView extends StatefulWidget {
  List<String> selectedSeatNames = [];
  double busRate;
  List<double>? busRates = [];
  String? fromTime;
  String? toTime;
  String? busName;
  String? fromLocation;
  String? toLocation;
  String? busIndex;
  DateTime? selectedDate;
  String? selectBoardingPoint;
  String? selectDroppingPoint;
  String? boardingPointId;
  String? droppingPointId;
  String? fromLocationCode;
  String? toLocationCode;

  AddressView(
      {super.key,
      required this.busRate,
      required this.selectedSeatNames,
      this.selectedDate,
      this.fromTime,
      this.busRates,
      this.busName,
      this.fromLocation,
      this.toLocation,
      this.busIndex,
      this.boardingPointId,
      this.droppingPointId,
      this.selectBoardingPoint,
      this.selectDroppingPoint,
      this.fromLocationCode,
      this.toLocationCode,
      this.toTime});

  @override
  State<AddressView> createState() => _AddressViewState();
}

class _AddressViewState extends State<AddressView> {
  @override
  void initState() {
    super.initState();
    vv.selectedSeatNames = widget.selectedSeatNames;
    vv.eachSeatFare = widget.busRates!;
    vv.emailCT.text = controller.profile?.data.userMail ?? "";
    vv.phoneNumberCT.text = controller.profile?.data.userPhone ?? "";
    super.initState();
  }

  ProfileController controller = Get.find<ProfileController>();
  AddressController vv = Get.put(AddressController());

  @override
  Widget build(BuildContext context) {
    print("----------${widget.selectedSeatNames}");
    print("----------${widget.busRates}");
    return Scaffold(
      bottomSheet: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 90.h,
            width: double.infinity,
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: Colors.black, width: 0.6)),
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: GetBuilder<ProfileController>(builder: (v) {
              return Column(
                children: [
                  kHeight5,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Booking Details will be sent to",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15.sp,
                              fontWeight: FontWeight.w700),
                          textAlign: TextAlign.center,
                        ),
                        IconButton(
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                          onPressed: () {
                            showModalBottomSheet(
                              context: context,
                              isScrollControlled: true,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(16)),
                              ),
                              builder: (context) {
                                return Padding(
                                  padding: EdgeInsets.only(
                                    bottom: MediaQuery.of(context)
                                        .viewInsets
                                        .bottom, // Adjust for keyboard
                                  ),
                                  child: GetBuilder<ProfileController>(
                                      builder: (v) {
                                    return SingleChildScrollView(
                                      child: Container(
                                        padding: EdgeInsets.all(16.sp),
                                        height:
                                            MediaQuery.of(context).size.height *
                                                0.35, // Adjust height
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Text(
                                                "Contact Information",
                                                style: TextStyle(
                                                    fontSize: 18.sp,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.topLeft,
                                              child: Text(
                                                "Your Ticke information will be sent here.",
                                                style: TextStyle(
                                                    fontSize: 10.sp,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.black),
                                              ),
                                            ),
                                            SizedBox(height: 16),
                                            TextField(
                                              controller: vv.emailCT,
                                              decoration: InputDecoration(
                                                //     labelText: "Email",
                                                label: Text("E-mail"),
                                                hintStyle: TextStyle(
                                                    color: Colors.black,
                                                    fontWeight:
                                                        FontWeight.normal),
                                                border: OutlineInputBorder(),
                                              ),
                                            ),
                                            SizedBox(height: 16),
                                            TextField(
                                              controller: vv.phoneNumberCT,
                                              decoration: InputDecoration(
                                                label: Text("Phone"),
                                                hintStyle: TextStyle(
                                                    color: Colors.black,
                                                    fontWeight:
                                                        FontWeight.normal),
                                                border: OutlineInputBorder(),
                                              ),
                                            ),
                                            SizedBox(height: 16),
                                            InkWell(
                                              onTap: () {
                                                // Update API data with new values
                                                controller.profile?.data
                                                    .userMail = vv.emailCT.text;
                                                controller.profile?.data
                                                        .userPhone =
                                                    vv.phoneNumberCT.text;

                                                // Notify UI to update
                                                controller.update();

                                                // Close Bottom Sheet
                                                Navigator.pop(context);
                                              },
                                              child: Container(
                                                height: 45.h,
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.90,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            12.r),
                                                    color: Colors.blue),
                                                child: Center(
                                                  child: Text(
                                                    "Confirm",
                                                    style: TextStyle(
                                                        color: Colors.white),
                                                  ),
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  }),
                                );
                              },
                            );
                          },
                          style: const ButtonStyle(
                            tapTargetSize: MaterialTapTargetSize
                                .shrinkWrap, // the '2023' part
                          ),
                          icon: Icon(Icons.edit_outlined, color: Colors.blue),
                        )
                      ],
                    ),
                  ),
                  kHeight5,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(
                      children: [
                        Icon(
                          Icons.alternate_email_outlined,
                          color: Colors.black,
                        ),
                        kWidth15,
                        Text(v.profile!.data.userMail ?? "",
                            style: TextStyle(
                              color: Colors.black,
                            )),
                      ],
                    ),
                  ),
                  kHeight5,
                  kHeight5,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(
                      children: [
                        Icon(
                          Icons.phone,
                          color: Colors.black,
                        ),
                        kWidth15,
                        Text(v.profile!.data.userPhone ?? "",
                            style: TextStyle(
                              color: Colors.black,
                            )),
                      ],
                    ),
                  )
                ],
              );
            }),
          ),
          Container(
            height: 70.h,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(
                top: BorderSide(color: Colors.grey.withOpacity(0.6), width: 1),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 18.0, top: 7),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Seat No: ${widget.selectedSeatNames.join(',')}",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                      Text("Total Fare"),
                      Text(
                        "\u{20B9}${widget.busRate}",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                    ],
                  ),
                ),
                GetBuilder<AddressController>(builder: (v) {
                  return Padding(
                    padding: EdgeInsets.only(right: 8.0),
                    child: CustomButton(
                      isLoading: v.isLoading,
                      text: "Proceed to Pay",
                      width: Get.width * 0.30,
                      onTap: () async {
                        List<int> selectedIndexes = [];
                        for (int i = 0; i < vv.checkboxValues.length; i++) {
                          if (vv.checkboxValues[i]) {
                            selectedIndexes.add(i);
                            print("check box select ${selectedIndexes}");
                          }
                        }

                        if (selectedIndexes.length != widget.selectedSeatNames.length) {
                          Get.snackbar(
                            "Invalid Selection",
                            "You need to select ${widget.selectedSeatNames.length} passengers for the selected seats.",
                            snackPosition: SnackPosition.BOTTOM,
                            backgroundColor: Colors.redAccent,
                            colorText: Colors.white,
                            duration: Duration(seconds: 3),
                          );
                          return;
                        }

                        List<String> names = v.passengers.isNotEmpty
                            ? v.passengers.map((e) => e.name).toList()
                            : [];
                        List<int> ages = v.passengers.isNotEmpty
                            ? v.passengers.map((e) => e.age).toList()
                            : [];
                        List<String> sexes = v.passengers.isNotEmpty
                            ? v.passengers.map((e) => e.sex).toList()
                            : [];
                        vv.loadData(widget.fromLocationCode!, widget.toLocationCode!);
                        // Call the blockSeat method and check if it was successful
                        bool success = await v.blockSeat(
                          availableTripId: int.parse(widget.busIndex!),
                          boardingPointId: int.parse(widget.boardingPointId!),
                          droppingPointId: int.parse(widget.droppingPointId!),
                          seatNames: vv.selectedSeatNames,
                          seatFares: widget.busRates!,
                        );

                        if (success) {
                          // Only navigate to the next screen if the seat blocking was successful

                          Get.to(() => ReviewbookingView(
                                busRate: widget.busRate,
                                busRates: widget.busRates,
                                selectedIndexes: selectedIndexes,
                                selectedSeatNames: widget.selectedSeatNames,
                                fromTime: widget.fromTime,
                                toTime: widget.toTime,
                                ages: ages,
                                selectDate: widget.selectedDate,
                                names: names,
                                sex: sexes,
                                fromLocation: widget.fromLocation,
                                toLocation: widget.toLocation,
                                busName: widget.busName,
                                droppingPoint: widget.selectDroppingPoint,
                                boardingPoint: widget.selectBoardingPoint,
                              ));
                        } else {
                          // If the blockSeat API fails, show an error message
                          Get.snackbar(
                            "Error",
                            "Please Check your Api..........",
                            snackPosition: SnackPosition.BOTTOM,
                            backgroundColor: Colors.redAccent,
                            colorText: Colors.white,
                            duration: Duration(seconds: 3),
                          );
                        }
                      },
                    ),
                  );
                }),
              ],
            ),
          ),
        ],
      ),
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Padding(
          padding: const EdgeInsets.only(top: 8.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Add Passengers",
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        )),
                    SizedBox(
                      height: Get.height * 0.01,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            overflow: TextOverflow.ellipsis,
                            '${widget.fromLocation} - ${widget.toLocation}' ??
                                'Nagercoil - Chennai',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.normal,
                              fontSize: 12.sp,
                            ),
                          ),
                        ),
                      ],
                    ),
                    /* SizedBox(height: 4),*/
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child:
                Icon(Icons.new_releases_outlined, color: Colors.blue, size: 22),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              GetBuilder<AddressController>(builder: (v) {
                return Column(
                  children: [
                    ListView.builder(
                      physics: NeverScrollableScrollPhysics(), // Disable scrolling inside ListView
                      shrinkWrap: true, // Allow it to take only the space needed
                      itemCount: v.passengers.length,
                      itemBuilder: (BuildContext context, int index) {
                        var data = v.passengers[index];
                        return CustomInfoWidget(
                          name: data.name,
                          sex: data.sex,
                          age: data.age.toString(),
                          onChanged: (bool? value) {
                            if (v.checkboxValues.isNotEmpty) {
                              v.checkboxValues[index] = value ?? false;
                              v.update();
                            }
                          },
                          value: v.checkboxValues.isNotEmpty
                              ? v.checkboxValues[index]
                              : false,
                          onEdit: () {
                            showPassengerDialog(context,
                                index: index, passenger: data);
                          },
                          onDelete: () {
                            v.removePassenger(index);
                            v.savePassengers();
                          },
                        );
                      },
                    ),
                    // Add Passenger Button Right After the List
                    SizedBox(height: 10.h),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: InkWell(
                        onTap: () {
                          showPassengerDialog(context);
                        },
                        child: Container(
                          height: 43.h,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.blue),
                              borderRadius: BorderRadius.circular(12.r)),
                          child: Center(
                            child: Text(
                              "Add New Passengers",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: MediaQuery.of(context).size.height*0.20.h),
                  ],
                );
              }),
            //  SizedBox(height: 60.h),
            ],
          ),
        ),
      ),

    );
  }

  void showPassengerDialog(BuildContext context,
      {int? index, Passenger? passenger}) {
    vv.nameCT.text = passenger?.name ?? '';
    vv.ageCT.text = passenger?.age.toString() ?? '';
    vv.selectedGender = passenger?.sex ?? 'Male';
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return GetBuilder<AddressController>(builder: (v) {
          return AlertDialog(
            contentPadding: EdgeInsets.all(10.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
            content: Builder(builder: (context) {
              var height = MediaQuery.of(context).size.height;
              var width = MediaQuery.of(context).size.width;
              return Container(
                height: height * 0.50,
                width: width,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          'Add Passenger ${vv.counter + 1}',
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w600,
                            color: Colors.black,
                            fontSize: 18,
                          ),
                        ),
                        Spacer(),
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).pop(); // Close the dialog
                          },
                          child: Icon(Icons.cancel_outlined),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    GetBuilder<AddressController>(builder: (v) {
                      return Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Radio<String>(
                                  value: 'Male',
                                  groupValue: v.selectedGender,
                                  onChanged: (value) {
                                    v.updateGender(value!);
                                  },
                                ),
                                Text(
                                  'Male',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Radio<String>(
                                  value: 'Female',
                                  groupValue: v.selectedGender,
                                  onChanged: (value) {
                                    v.updateGender(value!);
                                  },
                                ),
                                Text(
                                  'Female',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }),
                    SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 0.0),
                      child: TextFormField(
                        controller: vv.nameCT,
                        cursorColor: Color(0xFF4181FF),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp('[a-zA-Z ]')),
                        ],
                        keyboardType: TextInputType.text,
                        style: TextStyle(
                          fontFamily: 'Poppins Medium',
                          fontSize: 15.0,
                          color: Colors.black,
                        ),
                        decoration: InputDecoration(
                          label: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'Name',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontFamily: 'Poppins Medium',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                          hintText: 'Enter your name',
                          hintStyle: TextStyle(
                            fontFamily: 'Poppins-Regular',
                            fontSize: 15.0,
                            color: Color(0xFFA5A5A5),
                          ),
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 20, horizontal: 16),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: Color(0xFFDDDDDD),
                              // Ensure this color is visible
                              width: 2,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: Color(0xFF9FC0FF),
                              width: 2,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 30),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 0.0),
                      child: TextFormField(
                        maxLength: 2,
                        controller: vv.ageCT,
                        cursorColor: Color(0xFF4181FF),
                        keyboardType: TextInputType.number,
                        style: TextStyle(
                          fontFamily: 'Poppins Medium',
                          fontSize: 15.0,
                          color: Colors.black,
                        ),
                        decoration: InputDecoration(
                          label: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                'Age',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontFamily: 'Poppins Medium',
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                          hintText: 'Enter your Age',
                          hintStyle: TextStyle(
                            fontFamily: 'Poppins-Regular',
                            fontSize: 15.0,
                            color: Color(0xFFA5A5A5),
                          ),
                          floatingLabelBehavior: FloatingLabelBehavior.always,
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 20, horizontal: 16),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: Color(0xFFDDDDDD),
                              // Ensure this color is visible
                              width: 2,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(
                              color: Color(0xFF9FC0FF),
                              width: 2,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 15.h),
                    Center(
                      child: Container(
                        height: 38.h,
                        width: MediaQuery.of(context).size.width * 0.20,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color(0xFF4181FF),
                              Color(0xFF274E99),
                            ],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        child: ElevatedButton(
                          onPressed: () {
                            if (v.nameCT.text.isEmpty) {
                              Get.snackbar(
                                "Validation Error",
                                "Name cannot be empty.",
                                snackPosition: SnackPosition.BOTTOM,
                                backgroundColor: Colors.redAccent,
                                colorText: Colors.white,
                                duration: Duration(seconds: 2),
                              );
                              return; // Exit if validation fails
                            }

                            if (v.ageCT.text.isEmpty) {
                              Get.snackbar(
                                "Validation Error",
                                "Age cannot be empty.",
                                snackPosition: SnackPosition.BOTTOM,
                                backgroundColor: Colors.redAccent,
                                colorText: Colors.white,
                                duration: Duration(seconds: 2),
                              );
                              return;
                            }

                            if (index != null) {
                              // Update existing passenger
                              v.passengers[index] = Passenger(
                                name: v.nameCT.text,
                                sex: v.selectedGender!,
                                age: int.parse(v.ageCT.text),
                              );
                            } else {
                              // Add new passenger
                              v.addPassengers(Passenger(
                                name: v.nameCT.text,
                                sex: v.selectedGender!,
                                age: int.parse(v.ageCT.text),
                              ));
                            }

                            v.savePassengers();
                            /* v.addPassengers(Passenger(
                              name: v.nameCT.text,
                              sex: v.selectedGender!,
                              age: int.parse(v.ageCT.text),
                            ));*/
                            v.nameCT.clear();
                            v.ageCT.clear();
                            v.selectedGender = null;

                            Navigator.of(context).pop();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            padding: EdgeInsets.symmetric(vertical: 12.0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(
                                  12.0), // Match with the container
                            ),
                          ),
                          child: Text(
                            index == null ? 'Add' : 'Update',
                            style: TextStyle(
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
          );
        });
      },
    );
  }
}

class CustomInfoWidget extends StatelessWidget {
  final String? name;
  final String? sex;
  final String? age;
  final bool? value;
  final ValueChanged<bool?>? onChanged;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  CustomInfoWidget({
    Key? key,
    this.name,
    this.sex,
    this.age,
    this.value,
    this.onChanged,
    this.onEdit,
    this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        //  height: MediaQuery.of(context).size.height * 0.09,
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.all(12.r),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black, width: 0.3),
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: Row(
                children: [
                  Checkbox(
                    value: value ?? false,
                    onChanged: onChanged,
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        name ?? 'Name',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Text(
                            sex ?? 'Unknown',
                            style: const TextStyle(fontSize: 14),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            age ?? 'N/A',
                            style: const TextStyle(fontSize: 14),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 1,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit_outlined, color: Colors.black),
                    onPressed: onEdit,
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline_outlined,
                        color: Colors.black),
                    onPressed: onDelete,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
