import 'dart:convert';
/*import 'dart:nativewrappers/_internal/vm/lib/math_patch.dart'hide log;*/
import 'package:flutter/material.dart';
import 'package:fluttertickect365/presentation/utils/AppConstants.dart';
import 'package:fluttertickect365/sujin_screen/SharedPref/sharedPref.dart';
import 'package:oauth1/oauth1.dart' as oauth1;
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:developer';
import '../../../../presentation/cab_homepage_screen/apiModel/sharedPref.dart';
import '../address_modal/adress_modal.dart';
import 'package:http/http.dart' as http;

class AddressController extends GetxController {
  List<bool> checkboxValues = [];
  String? selectedGender;
  int? fromLocationId;
  int? toLocationId;
  List<String> selectedSeatNames = [];
  List<Passenger> passengers = [];
  List<double> eachSeatFare = [];
  int counter = 0;
  TextEditingController nameCT = TextEditingController();
  TextEditingController ageCT = TextEditingController();


  void updateSelectedSeats(List<String> seatNames) {
    selectedSeatNames = seatNames;
    update();
  }

  TextEditingController emailCT = TextEditingController();
  TextEditingController phoneNumberCT = TextEditingController();

  addPassengers(Passenger passenger) {
    passengers.add(passenger);
    checkboxValues.add(false);
    counter++;
    savePassengers();
    update();
  }

  removePassenger(int index) {
    passengers.removeAt(index);
    update();
  }

  void updateGender(String gender) {
    selectedGender = gender;
    print("Gender updated to: $selectedGender");
    update();
  }

  Future<void> loadPassengers() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? passengersJson = prefs.getString('passengers');
    if (passengersJson != null) {
      List<dynamic> passengerList = jsonDecode(passengersJson);
      passengers =
          passengerList.map((data) => Passenger.fromJson(data)).toList();
      checkboxValues = List.generate(passengers.length, (index) => false);
    }
    update();
  }

  // Save passengers to SharedPreferences
  Future<void> savePassengers() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String passengersJson =
        jsonEncode(passengers.map((e) => e.toJson()).toList());

    prefs.setString('passengers', passengersJson);
    update();
  }

  // Future<void> loadSharedPreferences() async {
  //   fromLocationId = await sharedPref.getCityID();
  //   toLocationId = await sharedPref.getDepartureCityID();
  // }

  void loadData(String fromCode,String toCode) async {
    fromLocationId = int.tryParse(fromCode);
    toLocationId = int.tryParse(toCode);
    update();
  }

  bool isLoading = false;
  final String consumerKey = 'MCycaVxF6XVV0ImKgqFPBAncx0prPp';
  final String consumerSecret = '5f0lpy9heMvXNQ069lQPNMomysX6rt';

  Future<bool> blockSeat({
    required int availableTripId,
    required int boardingPointId,
    required int droppingPointId,
    required List<String> seatNames,
    required List<double> seatFares,
  }) async {
    final clientCredentials =
        oauth1.ClientCredentials(consumerKey, consumerSecret);
    final authClient = oauth1.Client(
        oauth1.SignatureMethods.hmacSha1, clientCredentials, null);

    List<Map<String, dynamic>> passengerDetails = [];
    for (int i = 0; i < checkboxValues.length; i++) {
      if (checkboxValues[i]) {
        String seatName = seatNames[passengerDetails.length];
        String seatNumber = seatName;
        double fareForSeat = seatFares[passengerDetails.length];

        passengerDetails.add({
          "seatName": seatNumber,
          "fare": fareForSeat,
          "ladiesSeat": false,
          "address": "",
          "age": passengers[i].age,
          "email": emailCT.text,
          "gender": passengers[i].sex,
          "idNumber": "",
          "idType": "",
          "mobile": phoneNumberCT.text,
          "name": passengers[i].name,
          "primary": passengerDetails.isEmpty,
          "title": "",
          "registrationName": "",
          "gstId": "",
          "gstaddress": "",
          "gstemailId": ""
        });
      }
    }
    if (passengerDetails.length != seatNames.length) {
      print(
          "Error: The number of selected passengers does not match the number of selected seats.");
      Get.snackbar(
        "Error",
        "Please ensure that the number of selected passengers matches the number of selected seats.",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.redAccent,
        colorText: Colors.white,
      );
      return false; // Abort the process
    }

    final url = Uri.parse('https://ticketapp365.akprojects.co/api/bus/blockTicket');
    final requestBody = {
      'availableTripId': availableTripId,
      'boardingPointId': boardingPointId,
      'droppingPointId': droppingPointId,
      'destination': toLocationId,
      'source': fromLocationId,
      'passengers': passengerDetails,
    };
    print(url);
    print(jsonEncode(requestBody));

    try {
      isLoading = true;
      update();

      String? getToken = await sharedPrefer().getToken();
      if (getToken == null) {
        print("Error: Token is null.");
        return false;
      }
      var headers = {
        'Authorization': 'Bearer $getToken',
      };

      var request = http.MultipartRequest('POST', url)
        ..headers.addAll(headers)
        ..fields['availableTripId'] = availableTripId.toString()
        ..fields['boardingPointId'] = boardingPointId.toString()
        ..fields['droppingPointId'] = droppingPointId.toString()
        ..fields['destination'] = toLocationId.toString()
        ..fields['source'] = fromLocationId.toString();

      passengerDetails.asMap().forEach((index, passenger) {
        passenger.forEach((key, value) {
          request.fields['passengers[$index][$key]'] = value.toString();
        });
      });

      final response = await request.send();

      if (response.statusCode == 200) {
        final responseString = await response.stream.bytesToString();
        final responseJson = jsonDecode(responseString);
        print("responseJson${responseJson}");
        final data = responseJson['data'];
        await sharedPrefer().saveBlockKey(data);
        print('Seat blocked successfully');
        return true;
      } else {
        print('Failed to block seat: ${response.reasonPhrase}');
        return false;
      }
    } catch (e) {
      print('Error during seat blocking: $e');
      return false;
    } finally {
      isLoading = false;
      update();
    }
  }

  Future<void> updatePassengerDetails(
      int index, String updatedName, int updatedAge) async {
    passengers[index].name = updatedName;
    passengers[index].age = updatedAge;
    update(); // Notify listeners
    await savePassengers();
    loadPassengers();
    update(); // Notify listeners
  }

  @override
  void onInit() {

    loadPassengers();
    super.onInit();
  }
}
