class Passenger {
  String name;
  String sex;
  int age;

  Passenger({required this.name, required this.sex, required this.age});

  Map<String, dynamic> toJson() => {
        'name': name,
        'sex': sex,
        'age': age,
      };

  factory Passenger.fromJson(Map<String, dynamic> json) {
    return Passenger(
      name: json['name'],
      sex: json['sex'],
      age: json['age'],
    );
  }
}
