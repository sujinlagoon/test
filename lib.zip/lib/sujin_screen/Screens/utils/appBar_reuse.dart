import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? place;
  final String? to;
  final DateTime? date;
  final String? busesInfo;
  IconData? iconsda;
  Widget? leading;
  final Color backgroundColor;
  final List<Widget>? actions;

  CustomAppBar(
      {this.place,
      this.to,
      this.date,
      this.busesInfo,
      this.backgroundColor = Colors.white,
      this.actions,
      this.iconsda,
      this.leading});

  @override
  Widget build(BuildContext context) {
    return AppBar(
        backgroundColor: backgroundColor,
        elevation: 0,
        leading: leading != null
            ? leading
            : IconButton(
                icon: Icon(Icons.arrow_back_ios, color: Colors.black),
                onPressed: () {
                  Get.back();
                },
              ),
        title: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          overflow: TextOverflow.ellipsis,
                          '${place} - ${to}' ?? 'Nagercoil - Chennai',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      SizedBox(width: 4),
                      Icon(iconsda, color: Colors.black, size: 16),
                    ],
                  ),
                  SizedBox(height: 4),
                  Text(
                    DateFormat('EEE, dd MMM').format(date!),
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
        actions: actions);
  }

  @override
  Size get preferredSize => Size.fromHeight(56.0); // Default AppBar height
}
