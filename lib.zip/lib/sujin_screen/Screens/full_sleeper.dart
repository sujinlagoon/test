import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fluttertickect365/sujin_screen/Screens/utils/appBar_reuse.dart';
import 'controller/seatavailabilty-controller.dart';

class FullSleeper extends StatefulWidget {
  FullSleeper({super.key});

  @override
  State<FullSleeper> createState() => _FullSleeperState();
}

class _FullSleeperState extends State<FullSleeper> {
  SeatAvailabilityController vv = Get.put(SeatAvailabilityController());

  Set<int> selectedLowerSeats = {};
  Set<int> selectedUpperSeats = {};

  String getSelectedSeatsText() {
    List<String> lowerSeats = selectedLowerSeats
        .map((index) => "L${index + 1}")
        .toList(); // For Lower Desk
    List<String> upperSeats = selectedUpperSeats
        .map((index) => "U${index + 1}")
        .toList(); // For Upper Desk

    return "Seat no : ${lowerSeats.join(", ")}${lowerSeats.isNotEmpty && upperSeats.isNotEmpty ? "," : ""}${upperSeats.join(", ")}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      bottomSheet: Container(
        height: 75,
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(
            top: BorderSide(color: Colors.grey.withOpacity(0.6), width: 1),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 18.0, top: 7),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(getSelectedSeatsText()),
                  Text("Total Fare"),
                  Text("\u{20B9}500"),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(right: 8.0),
              child: Container(
                height: 45,
                width: 100,
                decoration: BoxDecoration(
                    color: Colors.blue,
                    borderRadius: BorderRadius.circular(12)),
                child: Center(
                  child: Text(
                    "Next",
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      appBar: CustomAppBar(),
      body: Padding(
        padding: const EdgeInsets.only(top: 10.0),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  flex: 1, // Lower Desk
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width * 0.03,
                      // bottom: MediaQuery.of(context).size.height * 0.03,
                      top: MediaQuery.of(context).size.height * 0.01,
                    ),
                    child: Container(
                      height: MediaQuery.sizeOf(context).height * 0.60,
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.grey.withOpacity(0.2),
                          ),
                          borderRadius: BorderRadius.circular(5)),
                      child: Column(
                        children: [
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 0.01,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              const Text("Lower Desk"),
                              Image.asset(
                                "assets/car_handle.png",
                                height: 15,
                              )
                            ],
                          ),
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 0.01,
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: GridView.builder(
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    itemCount: 5,
                                    shrinkWrap: true,
                                    gridDelegate:
                                        const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 1,
                                      childAspectRatio: 2.0,
                                      crossAxisSpacing: 10,
                                      mainAxisSpacing: 10,
                                      mainAxisExtent: 78, // Height of each item
                                    ),
                                    itemBuilder: (context, index) {
                                      return GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            if (selectedLowerSeats.contains(index)) {
                                              selectedLowerSeats.remove(index);
                                            } else {
                                              selectedLowerSeats.add(index);
                                            }
                                          });
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: Container(
                                            height: 50,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                              border: Border.all(
                                                color: selectedLowerSeats
                                                        .contains(index)
                                                    ? Colors.green
                                                    : Colors.grey,
                                                width: 1,
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                "${index + 1}",
                                                style: const TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 12),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                const SizedBox(width: 15),
                                Expanded(
                                  flex: 7,
                                  child: GridView.builder(
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    itemCount: 10,
                                    shrinkWrap: true,
                                    gridDelegate:
                                        const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      childAspectRatio: 1.0,
                                      crossAxisSpacing: 10,
                                      mainAxisSpacing: 10,
                                      mainAxisExtent: 78,
                                    ),
                                    itemBuilder: (context, index) {
                                      return GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            if (selectedLowerSeats
                                                .contains(index + 5)) {
                                              selectedLowerSeats
                                                  .remove(index + 5);
                                            } else {
                                              selectedLowerSeats.add(index + 5);
                                            }
                                          });
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: Container(
                                            height: 50,
                                            width: 10,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                              border: Border.all(
                                                color: selectedLowerSeats
                                                        .contains(index + 5)
                                                    ? Colors.green
                                                    : Colors.grey,
                                                width: 1,
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                "${index + 6}",
                                                style: TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 12),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                // Upper Desk
                Expanded(
                  flex: 1,
                  child: Padding(
                    padding: EdgeInsets.only(
                      right: MediaQuery.of(context).size.width * 0.03,
                      // bottom: MediaQuery.of(context).size.height * 0.17,
                      top: MediaQuery.of(context).size.height * 0.01,
                    ),
                    child: Container(
                      height: MediaQuery.sizeOf(context).height * 0.60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(
                          color: Colors.grey.withOpacity(0.2),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4.0),
                        child: Column(
                          children: [
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.01,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: const [
                                Text("Upper Desk"),
                              ],
                            ),
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.01,
                            ),
                            Row(
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: GridView.builder(
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    itemCount: 5,
                                    shrinkWrap: true,
                                    gridDelegate:
                                        const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 1,
                                      childAspectRatio: 2.0,
                                      crossAxisSpacing: 10,
                                      mainAxisSpacing: 10,
                                      mainAxisExtent: 78, // Height of each item
                                    ),
                                    itemBuilder: (context, index) {
                                      return GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            if (selectedUpperSeats
                                                .contains(index)) {
                                              selectedUpperSeats.remove(index);
                                            } else {
                                              selectedUpperSeats.add(index);
                                            }
                                          });
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: Container(
                                            height: 50,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                              border: Border.all(
                                                color: selectedUpperSeats
                                                        .contains(index)
                                                    ? Colors.green
                                                    : Colors.grey,
                                                width: 1,
                                              ),
                                            ),
                                            child: Center(
                                              child: Text(
                                                "${index + 1}",
                                                style: const TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 12),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                const SizedBox(width: 2),
                                const VerticalDivider(color: Colors.black),
                                Expanded(
                                    flex: 7,
                                    child: GridView.builder(
                                        shrinkWrap: true,
                                        physics:
                                            const AlwaysScrollableScrollPhysics(),
                                        itemCount: 10,
                                        gridDelegate:
                                            const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 2,
                                          childAspectRatio: 1.0,
                                          crossAxisSpacing: 10,
                                          mainAxisSpacing: 10,
                                          mainAxisExtent: 78,
                                        ),
                                        itemBuilder: (context, index) {
                                          return GestureDetector(
                                            onTap: () {
                                              setState(() {
                                                if (selectedUpperSeats
                                                    .contains(index + 5)) {
                                                  selectedUpperSeats
                                                      .remove(index + 5);
                                                } else {
                                                  selectedUpperSeats
                                                      .add(index + 5);
                                                }
                                              });
                                            },
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(4.0),
                                              child: Container(
                                                height: 50,
                                                width: 10,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(5),
                                                  border: Border.all(
                                                    color: selectedUpperSeats
                                                            .contains(index + 5)
                                                        ? Colors.green
                                                        : Colors.grey,
                                                    width: 1,
                                                  ),
                                                  /*  color: selectedUpperSeats
                                                            .contains(index + 5)
                                                        ? Colors.green
                                                        : Colors.white,*/
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    "${index + 6}",
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 12),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          );
                                        }))
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 15,
            ),
            Align(
              alignment: Alignment.topLeft,
              child: InkWell(
                onTap: () {
                  showDialog(
                      context: context,
                      builder: (context) {
                        return Dialog(
                          elevation: 1,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          child: Container(
                            width: 300,
                            height: MediaQuery.of(context).size.height * 0.55,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15.0),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(
                                  height: 15,
                                ),
                                seatInfo(
                                    borderColor: Colors.black,
                                    fillColor: Colors.blue.withOpacity(0.4),
                                    colorPurpus: 'Selected'),
                                const SizedBox(
                                  height: 15,
                                ),
                                seatInfo(
                                    borderColor: Colors.green,
                                    colorPurpus: 'Available'),
                                const SizedBox(
                                  height: 5,
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                seatInfo(
                                    borderColor: Colors.pinkAccent,
                                    colorPurpus: 'Available for female'),
                                const SizedBox(
                                  height: 5,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                seatInfo(
                                    borderColor: Colors.pinkAccent,
                                    fillColor: Colors.grey.withOpacity(0.3),
                                    colorPurpus: 'Already booked for female'),
                                const SizedBox(
                                  height: 5,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                seatInfo(
                                    borderColor: Colors.blue,
                                    colorPurpus: 'Available for male'),
                                const SizedBox(
                                  height: 5,
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                seatInfo(
                                    borderColor: Colors.blue,
                                    fillColor: Colors.grey.withOpacity(0.3),
                                    colorPurpus: 'Already booked for male'),
                                const SizedBox(
                                  height: 5,
                                ),
                              ],
                            ),
                          ),
                        );
                      });
                },
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.10,
                  width: MediaQuery.of(context).size.width * 0.15,
                  padding: EdgeInsets.all(5),
                  decoration:
                      BoxDecoration(border: Border.all(color: Colors.blue)),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Icon(
                        CupertinoIcons.exclamationmark_circle,
                        color: Colors.black,
                      ),
                      Text(
                        "Seat Info",
                        style: TextStyle(color: Colors.black),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget seatInfo({
    Color? borderColor,
    Color? fillColor,
    String? colorPurpus,
  }) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.07,
      width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
          //border: Border.all(color: Colors.black),
          ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: 30, // Set a fixed height
            width: 30, // Set a fixed width
            decoration: BoxDecoration(
              color: fillColor,
              border: Border.all(color: borderColor ?? Colors.black),
              borderRadius: BorderRadius.circular(5), // Rounded corners
            ),
          ),
          const SizedBox(width: 10), // Space between the seat box and text
          Expanded(
            child: Text(
              colorPurpus ?? '',
              style: const TextStyle(color: Colors.black),
              overflow: TextOverflow.ellipsis, // Handles long text gracefully
            ),
          ),
        ],
      ),
    );
  }
}

class RedBusSeatUI extends StatefulWidget {
  const RedBusSeatUI({Key? key}) : super(key: key);

  @override
  _RedBusSeatUIState createState() => _RedBusSeatUIState();
}

class _RedBusSeatUIState extends State<RedBusSeatUI> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Zing Bus"),
        backgroundColor: Color(0xffd44d57),
      ),
      body: Container(
        child: Stack(
          children: [
            Positioned(
                top: 100,
                left: 100,
                child: Card(
                  elevation: 10,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Container(
                    margin: EdgeInsets.all(12),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            SizedBox(
                              width: 150,
                            ),
                            Icon(Icons.circle)
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            _Full_gents_seatLayout(),
                            _Full_gents_seatLayout(),
                            SizedBox(
                              width: 40,
                            ),
                            _Vacant_seatLayout(),
                            _Full_gents_seatLayout()
                          ],
                        ),
                        Row(
                          children: [
                            _Full_ladies_seatLayout(),
                            _Vacant_seatLayout(),
                            SizedBox(
                              width: 40,
                            ),
                            _Full_gents_seatLayout(),
                            _Full_gents_seatLayout()
                          ],
                        ),
                        Row(
                          children: [
                            _Full_ladies_seatLayout(),
                            _Vacant_seatLayout(),
                            SizedBox(
                              width: 40,
                            ),
                            _Full_gents_seatLayout(),
                            _Full_gents_seatLayout()
                          ],
                        ),
                        Row(
                          children: [
                            _Vacant_seatLayout(),
                            _Vacant_seatLayout(),
                            SizedBox(
                              width: 40,
                            ),
                            _Full_gents_seatLayout(),
                            _Vacant_seatLayout()
                          ],
                        ),
                        Row(
                          children: [
                            _Vacant_seatLayout(),
                            _Vacant_seatLayout(),
                            SizedBox(
                              width: 40,
                            ),
                            _Selected_Seat(),
                            _Full_gents_seatLayout()
                          ],
                        ),
                        Row(
                          children: [
                            _Full_ladies_seatLayout(),
                            _Vacant_seatLayout(),
                            SizedBox(
                              width: 40,
                            ),
                            _Full_gents_seatLayout(),
                            _Full_gents_seatLayout()
                          ],
                        ),
                        Row(
                          children: [
                            _Full_ladies_seatLayout(),
                            _Vacant_seatLayout(),
                            SizedBox(
                              width: 40,
                            ),
                            _Full_ladies_seatLayout(),
                            _Full_ladies_seatLayout()
                          ],
                        ),
                        Row(
                          children: [
                            _Vacant_seatLayout(),
                            _Vacant_seatLayout(),
                            SizedBox(
                              width: 40,
                            ),
                            _Full_gents_seatLayout(),
                            _Vacant_seatLayout()
                          ],
                        ),
                        Row(
                          children: [
                            _Vacant_seatLayout(),
                            _Vacant_seatLayout(),
                            _Vacant_seatLayout(),
                            _Vacant_seatLayout(),
                            _Vacant_seatLayout()
                          ],
                        )
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }

  Widget _Vacant_seatLayout() {
    return Container(
      width: 40,
      height: 40,
      child: Stack(
        children: [
          Positioned(
            top: 5,
            bottom: 5,
            left: 5,
            right: 5,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.white),
              ),
            ),
          ),
          Positioned(
            top: 29,
            bottom: 5,
            left: 5,
            right: 5,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.white),
              ),
            ),
          ),
          Positioned(
            top: 15,
            bottom: 5,
            left: 4,
            right: 30,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.white),
              ),
            ),
          ),
          Positioned(
            top: 15,
            bottom: 5,
            left: 30,
            right: 4,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.white),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _Full_gents_seatLayout() {
    return Container(
      width: 40,
      height: 40,
      child: Stack(
        children: [
          Positioned(
            top: 5,
            bottom: 5,
            left: 5,
            right: 5,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.grey.shade300),
              ),
            ),
          ),
          Positioned(
            top: 29,
            bottom: 5,
            left: 5,
            right: 5,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.blueAccent),
              ),
            ),
          ),
          Positioned(
            top: 15,
            bottom: 5,
            left: 4,
            right: 30,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.blueAccent),
              ),
            ),
          ),
          Positioned(
            top: 15,
            bottom: 5,
            left: 30,
            right: 4,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.blueAccent),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _Full_ladies_seatLayout() {
    return Container(
      width: 40,
      height: 40,
      child: Stack(
        children: [
          Positioned(
            top: 5,
            bottom: 5,
            left: 5,
            right: 5,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.grey.shade300),
              ),
            ),
          ),
          Positioned(
            top: 29,
            bottom: 5,
            left: 5,
            right: 5,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.cyan),
              ),
            ),
          ),
          Positioned(
            top: 15,
            bottom: 5,
            left: 4,
            right: 30,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.cyan),
              ),
            ),
          ),
          Positioned(
            top: 15,
            bottom: 5,
            left: 30,
            right: 4,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.cyan),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _Selected_Seat() {
    return Container(
      width: 40,
      height: 40,
      child: Stack(
        children: [
          Positioned(
            top: 5,
            bottom: 5,
            left: 5,
            right: 5,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.lightGreenAccent),
              ),
            ),
          ),
          Positioned(
            top: 29,
            bottom: 5,
            left: 5,
            right: 5,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.lightGreenAccent),
              ),
            ),
          ),
          Positioned(
            top: 15,
            bottom: 5,
            left: 4,
            right: 30,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.lightGreenAccent),
              ),
            ),
          ),
          Positioned(
            top: 15,
            bottom: 5,
            left: 30,
            right: 4,
            child: SizedBox(
              child: DecoratedBox(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.lightGreenAccent),
              ),
            ),
          )
        ],
      ),
    );
  }
}
