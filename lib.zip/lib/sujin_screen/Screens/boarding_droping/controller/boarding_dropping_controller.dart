import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:oauth1/oauth1.dart' as oauth1;

import '../modal.dart';

class BoardingDroppingController extends GetxController {
  final String consumerKey = 'MCycaVxF6XVV0ImKgqFPBAncx0prPp';
  final String consumerSecret = '5f0lpy9heMvXNQ069lQPNMomysX6rt';

  BoardingPoints? allPoints;
  List<IngPoint> boardingPoints = [];
  List<IngPoint> droppingPoints = [];
  int? boardingSelectedValue;
  int? droppingSelectedValue;
  bool isDroppingTabActive = false;
  TabController? tabController;
  int? boardingSelectedIndex; // To store the selected boarding index
  String? boardingSelectedId; // To store the selected boarding point ID

  int? droppingSelectedIndex; // To store the selected dropping index
  String? droppingSelectedId; // To store the selected dropping point ID
  Future<void> boardingDroppingApi({int? id}) async {
    try {
      final clientCredentials =
          oauth1.ClientCredentials(consumerKey, consumerSecret);
      final authClient = oauth1.Client(
        oauth1.SignatureMethods.hmacSha1,
        clientCredentials,
        null,
      );

      final url = Uri.parse('http://api.seatseller.travel/bpdpDetails?id=$id');
      final response = await authClient.get(url);

      if (response.statusCode == 200) {
        var data = boardingPointsFromJson(response.body);
        droppingPoints = data.droppingPoints!;
        boardingPoints = data.boardingPoints!;
        update();
      }
    } catch (e) {
      print("Exception occurred: $e");
    }
  }

  void updateBoardingPoint(int? selectedIndex) {
    boardingSelectedIndex = selectedIndex;
    boardingSelectedId = boardingPoints[selectedIndex!].id; // Store the ID
    update(); // Notify listeners
    if (tabController!.index != 1) {
      tabController!.animateTo(1);
    }
    update();
    print("Selected Boarding Point ID: $boardingSelectedId");
  }

  void updateDroppingPoint(int? selectedIndex) {
    droppingSelectedIndex = selectedIndex;
    droppingSelectedId = droppingPoints[selectedIndex!].id; // Store the ID
    update(); // Notify listeners
    print("Selected Dropping Point ID: $droppingSelectedId");
  }

  @override
  void onInit() {
    // boardingDroppingApi();
    super.onInit();
  }
}
