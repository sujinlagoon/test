import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/Screens/controller/seatavailabilty-controller.dart';
import 'package:fluttertickect365/sujin_screen/customButton.dart';
import 'package:get/get.dart';
import '../Address/address_view.dart';
import '../utils/appBar_reuse.dart';
import 'controller/boarding_dropping_controller.dart';

class SelectboardingDropping extends StatefulWidget {
  List<String> selectedSeatNames = [];
  double busRate;
  List<double>? busRates = [];
  String? fromTime;
  String? toTime;
  String? busIndex;
  String? busName;
  String? fromLocation;
  String? toLocation;
  String? toLocationCode;
  String? fromLocationCode;
  DateTime? selectedDate;

  /*String? boardingPointId;
  String? droppingPointId;*/

  SelectboardingDropping({
    Key? key,
    required this.selectedSeatNames,
    required this.busRate,
    this.toTime,
    this.busRates,
    this.fromLocation,
    this.toLocation,
    this.busName,
    this.busIndex,
    this.toLocationCode,
    this.fromLocationCode,
    this.selectedDate,
    this.fromTime,
/*    this.boardingPointId,
    this.droppingPointId,*/
  }) : super(key: key);

  @override
  _SelectboardingDroppingState createState() => _SelectboardingDroppingState();
}

class _SelectboardingDroppingState extends State<SelectboardingDropping>
    with SingleTickerProviderStateMixin {
 // late TabController _tabController;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchSeatData();
    controller.tabController = TabController(length: 2, vsync: this);

    // Listen to tab changes
    controller.tabController!.addListener(() {
      setState(() {
        controller.isDroppingTabActive = controller.tabController!.index == 1;
      });
    });

  }

  @override
  void dispose() {
    controller.tabController!.dispose();
    super.dispose();
  }

  BoardingDroppingController controller = Get.put(BoardingDroppingController());

  Future<void> fetchSeatData() async {
    if (widget.busIndex != null) {
      await controller.boardingDroppingApi(id: int.parse(widget.busIndex!));
      setState(() {
        isLoading = false;
      });
    } else {
      print("Bus ID is null");
    }
  }

  @override
  Widget build(BuildContext context) {
    print(widget.selectedSeatNames);
    print(widget.busRates);
    return Scaffold(
      bottomSheet: controller.isDroppingTabActive
          ? Container(
              height: Get.height * 0.09,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  top:
                      BorderSide(color: Colors.grey.withOpacity(0.6), width: 1),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 18.0, top: 7),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Seat No: ${widget.selectedSeatNames.map((seat) => SeatAvailabilityController().getPrefixedSeatName(seat)).join(', ')},',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, color: Colors.black),
                        ),
                        Text(
                          'Total fare',
                          style: TextStyle(color: Colors.blue),
                        ),
                        Text(
                          '\u{20B9}${widget.busRate}',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, color: Colors.black),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: CustomButton(
                      width: Get.width * 0.30,
                      text: "Next",
                      onTap: () {
                        if (controller.boardingSelectedId == null) {
                          Get.snackbar(
                            "Warning!",
                            "Please check the Boarding Points",
                            snackPosition: SnackPosition.BOTTOM,
                            backgroundColor: Colors.redAccent,
                            colorText: Colors.white,
                            duration: Duration(seconds: 3),
                          );
                        } else if (controller.droppingSelectedId == null) {
                          Get.snackbar(
                            "Warning!",
                            "Please check the Boarding Points",
                            snackPosition: SnackPosition.BOTTOM,
                            backgroundColor: Colors.redAccent,
                            colorText: Colors.white,
                            duration: Duration(seconds: 3),
                          );
                        } else {
                          Get.to(() => AddressView(
                                busRates: widget.busRates,
                                toTime: widget.toTime,
                                busIndex: widget.busIndex,
                                fromTime: widget.fromTime,
                                busRate: widget.busRate,
                                selectedSeatNames: widget.selectedSeatNames,
                                busName: widget.busName,
                                fromLocation: widget.fromLocation,
                                toLocation: widget.toLocation,
                            fromLocationCode: widget.fromLocationCode,
                            toLocationCode: widget.toLocationCode,
                                selectedDate: widget.selectedDate,
                                boardingPointId: controller.boardingSelectedId,
                                droppingPointId: controller.droppingSelectedId,
                                selectBoardingPoint: controller
                                    .boardingPoints[
                                        controller.boardingSelectedIndex!]
                                    .locationName,
                                selectDroppingPoint: controller
                                    .droppingPoints[
                                        controller.droppingSelectedIndex!]
                                    .locationName,
                              ));
                        }
                      },
                    ),
                  ),
                ],
              ),
            )
          : null,
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        centerTitle: true,
        leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Icon(Icons.arrow_back_ios)),
        title: Text(
          "Boarding And Dropping Points",
          style: TextStyle(fontSize: 16),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TabBar(
            controller: controller.tabController,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.blue,
            dividerColor: Colors.transparent,
            tabs: [
              Tab(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: controller.tabController!.animation!,
                      builder: (context, child) {
                        return Text(
                          "Boarding Points",
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: controller.tabController!.index == 0
                                ? Colors.black
                                : Colors.grey,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              Tab(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(width: 8.0),
                    AnimatedBuilder(
                      animation: controller.tabController!.animation!,
                      builder: (context, child) {
                        return Text(
                          "Dropping Points",
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: controller.tabController!.index == 1
                                ? Colors.black
                                : Colors.grey,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
          Expanded(
            child: GetBuilder<BoardingDroppingController>(builder: (v) {
              return TabBarView(
                controller: controller.tabController,
                children: [
                  ListView.builder(
                    itemCount: v.boardingPoints.length,
                    itemBuilder: (context, index) {
                      var data = v.boardingPoints[index];
                      return boardingList(
                        context,
                        location: data.locationName,
                        address: data.address,
                        date: data.landmark,
                        groupValue: v.boardingSelectedIndex,
                        value: index,
                        onChanged: (int? newValue) {
                          controller.updateBoardingPoint(newValue);
                          v.update();
                          print(newValue);
                        },
                      );
                    },
                  ),
                  ListView.builder(
                    itemCount: v.droppingPoints.length,
                    itemBuilder: (context, index) {
                      var data = v.droppingPoints[index];
                      return boardingList(
                        context,
                        location: data.locationName,
                        address: data.address,
                        date: data.landmark,
                        groupValue: v.droppingSelectedIndex,
                        value: index,
                        onChanged: (int? newValue) {
                          controller.updateDroppingPoint(newValue);
                          v.update();
                          print(newValue);
                        },
                      );
                    },
                  ),
                ],
              );
            }),
          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}

Widget boardingList(
  BuildContext context, {
  String? location,
  String? address,
  String? date,
  int? groupValue,
  ValueChanged<int?>? onChanged,
  int? value,
}) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
    child: GestureDetector(
      onTap: () {
        onChanged?.call(value);
      },
      child: Container(
        padding: EdgeInsets.all(3),
        // height: MediaQuery.sizeOf(context).height * 0.09,
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(
            color: Color(0xFFA4BFF4),
            width: 1.5,
          ),
          borderRadius: BorderRadius.all(
            Radius.circular(10.0),
          ),
        ),
        child: Row(
          children: [
            Radio(
              value: value!,
              groupValue: groupValue,
              onChanged: onChanged, // Callback to handle value change
            ),
            SizedBox(width: 10),
            Padding(
              padding: EdgeInsets.only(
                  top: MediaQuery.sizeOf(context).height * 0.014),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    location!,
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 16,
                        color: Color(0xFF282828)),
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: Get.width * 0.60),
                    // Define maximum width
                    child: Text(
                      address!,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          fontSize: 13,
                          color: Color(0xFF282828)),
                    ),
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  Text(
                    date!,
                    style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                        color: Color(0xFF282828)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
