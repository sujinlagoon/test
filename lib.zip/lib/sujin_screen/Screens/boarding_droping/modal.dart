import 'dart:convert';

BoardingPoints boardingPointsFromJson(String str) =>
    BoardingPoints.fromJson(json.decode(str));

String boardingPointsToJson(BoardingPoints data) => json.encode(data.toJson());

class BoardingPoints {
  List<IngPoint>? boardingPoints;
  List<IngPoint>? droppingPoints;

  BoardingPoints({
    this.boardingPoints,
    this.droppingPoints,
  });

  factory BoardingPoints.fromJson(Map<String, dynamic> json) => BoardingPoints(
        boardingPoints: json["boardingPoints"] is List
            ? List<IngPoint>.from(
                json["boardingPoints"].map((x) => IngPoint.fromJson(x)))
            : [IngPoint.fromJson(json["boardingPoints"])],
        droppingPoints: json["droppingPoints"] is List
            ? List<IngPoint>.from(
                json["droppingPoints"].map((x) => IngPoint.fromJson(x)))
            : [IngPoint.fromJson(json["droppingPoints"])],
      );

  Map<String, dynamic> toJson() => {
        "boardingPoints":
            List<dynamic>.from(boardingPoints!.map((x) => x.toJson())),
        "droppingPoints":
            List<dynamic>.from(droppingPoints!.map((x) => x.toJson())),
      };
}

class IngPoint {
  String? address;
  String? contactnumber;
  String? id;
  String? landmark;
  String? locationName;
  String? name;
  String? rbMasterId;

  IngPoint({
    this.address,
    this.contactnumber,
    this.id,
    this.landmark,
    this.locationName,
    this.name,
    this.rbMasterId,
  });

  factory IngPoint.fromJson(Map<String, dynamic> json) => IngPoint(
        address: json["address"],
        contactnumber: json["contactnumber"],
        id: json["id"],
        landmark: json["landmark"],
        locationName: json["locationName"],
        name: json["name"],
        rbMasterId: json["rbMasterId"],
      );

  Map<String, dynamic> toJson() => {
        "address": address,
        "contactnumber": contactnumber,
        "id": id,
        "landmark": landmark,
        "locationName": locationName,
        "name": name,
        "rbMasterId": rbMasterId,
      };
}
