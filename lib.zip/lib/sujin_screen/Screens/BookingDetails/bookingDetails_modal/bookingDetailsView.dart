import 'package:flutter/material.dart';

class Bookingdetailsview extends StatefulWidget {
  const Bookingdetailsview({super.key});

  @override
  State<Bookingdetailsview> createState() => _BookingdetailsviewState();
}

class _BookingdetailsviewState extends State<Bookingdetailsview> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.builder(itemBuilder: (BuildContext context, index) {
        return TripCard();
      }),
    );
  }
}

class TripCard extends StatelessWidget {
  final String? travelAgencyName;
  final bool? isActive;
  final String? fromLocation;
  final String? fromAddress;
  final String? fromTime;
  final String? toLocation;
  final String? toAddress;
  final String? toTime;

  const TripCard({
    Key? key,
    this.travelAgencyName,
    this.isActive,
    this.fromLocation,
    this.fromAddress,
    this.fromTime,
    this.toLocation,
    this.toAddress,
    this.toTime,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                travelAgencyName!,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              Text(
                isActive! ? "Active Now" : "Inactive",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: isActive! ? Colors.blue : Colors.grey,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // From and To Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _LocationColumn(
                location: fromLocation!,
                address: fromAddress!,
                time: fromTime!,
              ),
              _LocationColumn(
                location: toLocation!,
                address: toAddress!,
                time: toTime!,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _LocationColumn extends StatelessWidget {
  final String location;
  final String address;
  final String time;

  const _LocationColumn({
    Key? key,
    required this.location,
    required this.address,
    required this.time,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          location,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          address,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          time,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}
