import 'package:fluttertickect365/sujin_screen/SharedPref/sharedPref.dart';
import 'package:get/get.dart';
import 'package:oauth1/oauth1.dart' as oauth1;

import 'bookingDetails_modal/booking_details_modal.dart';

class BookingDetailsController extends GetxController {
  final String consumerKey = 'MCycaVxF6XVV0ImKgqFPBAncx0prPp';
  final String consumerSecret = '5f0lpy9heMvXNQ069lQPNMomysX6rt';

  void checkBookedTicket(String blockKey) async {
    final clientCredentials =
        oauth1.ClientCredentials(consumerKey, consumerSecret);
    final authClient = oauth1.Client(
        oauth1.SignatureMethods.hmacSha1, clientCredentials, null);
    String? blockKey = await sharedPrefer().getBlockKey();
    print(blockKey);
    bool isLoading = true;
    update();

    final url = Uri.parse(
        'http://api.seatseller.travel/checkBookedTicket?blockKey=$blockKey');

    final response = await authClient.get(url);

    if (response.statusCode == 200) {
      var data = bookingDetailsFromJson(response.body);

      update();
      isLoading = false;
      update();
    } else {
      isLoading = false;
      update();
      print('Failed to fetch booked ticket data');
    }
  }
}
