/*
import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';

import 'bus_list/bus_List.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
          useMaterial3: true,
        ),
        home:  BusLists());
  }
}



class SeatLayouts extends StatelessWidget {
  final List<Map<String, dynamic>> seats = [
    {"name": "1", "row": "0", "column": "1", "available": "false"},
    {"name": "2", "row": "0", "column": "2", "available": "true"},
    {"name": "3", "row": "0", "column": "3", "available": "true"},
    {"name": "4", "row": "0", "column": "4", "available": "true"},
    {"name": "5", "row": "0", "column": "5", "available": "true"},
    {"name": "6", "row": "2", "column": "1", "available": "true"},
    {"name": "7", "row": "2", "column": "2", "available": "true"},
    {"name": "8", "row": "2", "column": "3", "available": "true"},
    {"name": "9", "row": "2", "column": "4", "available": "true"},
    {"name": "19", "row": "2", "column": "5", "available": "true"},
  ];

  @override
  Widget build(BuildContext context) {
    // Determine the number of rows and columns dynamically
    const int totalColumns = 5; // Assuming there are 5 columns
    const int totalRows = 3; // Assuming 3 rows: 0, 1 (missing), and 2

    // Generate a 2D grid of seats, including placeholders for missing seats
    List<List<Map<String, dynamic>?>> grid = List.generate(
      totalRows,
          (_) => List.generate(totalColumns, (_) => null),
    );

    for (var seat in seats) {
      int row = int.parse(seat["row"]);
      int column = int.parse(seat["column"]) - 1; // Column is 1-based, convert to 0-based
      grid[row][column] = seat;
    }

    // Flatten the 2D grid for the GridView
    List<Map<String, dynamic>?> flattenedGrid = grid.expand((row) => row).toList();

    return Scaffold(
      appBar: AppBar(title: Text("Seat Layout")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: totalColumns, // Number of columns
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: 1, // Keep cells square
          ),
          itemCount: flattenedGrid.length,
          itemBuilder: (context, index) {
            final seat = flattenedGrid[index];

            if (seat == null) {
              // Placeholder for missing seats
              return Container(
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  border: Border.all(color: Colors.black),
                ),
                child: Center(
                  child: Text(
                    "Empty",
                    style: TextStyle(color: Colors.black),
                  ),
                ),
              );
            }

            // Render actual seats
            return Container(
              decoration: BoxDecoration(
                color: seat["available"] == "true" ? Colors.green : Colors.red,
                border: Border.all(color: Colors.black),
              ),
              child: Center(
                child: Text(
                  seat["name"], // Seat number
                  style: TextStyle(color: Colors.white),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}*/
