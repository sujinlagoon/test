// To parse this JSON data, do
//
//     final profile = profileFromJson(jsonString);

import 'dart:convert';

Profile profileFromJson(String str) => Profile.fromJson(json.decode(str));

String profileToJson(Profile data) => json.encode(data.toJson());

class Profile {
  bool status;
  String message;
  Data data;
  String busapiname;

  Profile({
    required this.status,
    required this.message,
    required this.data,
    required this.busapiname /*= "orbit"*/,
  });


  factory Profile.fromJson(Map<String, dynamic> json) => Profile(
    status: json["status"],
    message: json["message"],
    data: Data.fromJson(json["data"],
    ),
    busapiname:"common"/*json["busapiname"]*/,
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data.toJson(),
    "busapiname": busapiname,
  };
}

class Data {
  int userId;
  int userMainId;
  String userName;
  String userRefId;
  String userPhone;
  String userMail;
  dynamic userEmailPrimaryId;
  int userPhoneVerify;
  int userEmailIsVerified;
  DateTime userDob;
  String userGender;
  dynamic userProfImg;
  String userFbToken;
  int userIsRegistered;
  DateTime userCreatedAt;
  dynamic userCreatedBy;
  DateTime userUpdatedAt;
  dynamic userUpdatedBy;
  int userIsActive;
  int userIsDelete;

  Data({
    required this.userId,
    required this.userMainId,
    required this.userName,
    required this.userRefId,
    required this.userPhone,
    required this.userMail,
    required this.userEmailPrimaryId,
    required this.userPhoneVerify,
    required this.userEmailIsVerified,
    required this.userDob,
    required this.userGender,
    required this.userProfImg,
    required this.userFbToken,
    required this.userIsRegistered,
    required this.userCreatedAt,
    required this.userCreatedBy,
    required this.userUpdatedAt,
    required this.userUpdatedBy,
    required this.userIsActive,
    required this.userIsDelete,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    userId: json["UserID"],
    userMainId: json["UserMainID"],
    userName: json["UserName"],
    userRefId: json["UserRefID"],
    userPhone: json["UserPhone"],
    userMail: json["UserMail"],
    userEmailPrimaryId: json["UserEmailPrimaryID"],
    userPhoneVerify: json["UserPhoneVerify"],
    userEmailIsVerified: json["UserEmailIsVerified"],
    userDob: DateTime.parse(json["UserDob"]),
    userGender: json["UserGender"],
    userProfImg: json["UserProfImg"],
    userFbToken: json["UserFBToken"],
    userIsRegistered: json["UserIsRegistered"],
    userCreatedAt: DateTime.parse(json["UserCreatedAt"]),
    userCreatedBy: json["UserCreatedBy"],
    userUpdatedAt: DateTime.parse(json["UserUpdatedAt"]),
    userUpdatedBy: json["UserUpdatedBy"],
    userIsActive: json["UserIsActive"],
    userIsDelete: json["UserIsDelete"],
  );

  Map<String, dynamic> toJson() => {
    "UserID": userId,
    "UserMainID": userMainId,
    "UserName": userName,
    "UserRefID": userRefId,
    "UserPhone": userPhone,
    "UserMail": userMail,
    "UserEmailPrimaryID": userEmailPrimaryId,
    "UserPhoneVerify": userPhoneVerify,
    "UserEmailIsVerified": userEmailIsVerified,
    "UserDob": "${userDob.year.toString().padLeft(4, '0')}-${userDob.month.toString().padLeft(2, '0')}-${userDob.day.toString().padLeft(2, '0')}",
    "UserGender": userGender,
    "UserProfImg": userProfImg,
    "UserFBToken": userFbToken,
    "UserIsRegistered": userIsRegistered,
    "UserCreatedAt": userCreatedAt.toIso8601String(),
    "UserCreatedBy": userCreatedBy,
    "UserUpdatedAt": userUpdatedAt.toIso8601String(),
    "UserUpdatedBy": userUpdatedBy,
    "UserIsActive": userIsActive,
    "UserIsDelete": userIsDelete,
  };
}
