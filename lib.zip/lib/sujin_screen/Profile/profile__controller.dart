import 'dart:developer';

import 'package:fluttertickect365/sujin_screen/Profile/profile_modal/profile_modal.dart';
import 'package:fluttertickect365/sujin_screen/SharedPref/sharedPref.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class ProfileController extends GetxController {
  Profile? profile;
  bool isLoading = false;

  Future<void> getProfile() async {
    try {
      isLoading = true;
      update();
      String? getToken = await sharedPrefer().getToken();
      if (getToken == null || getToken.isEmpty) {
        log("Error: No token found, user might not be logged in.");
        return;
      }
      log("---------------token${getToken}");
      var headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $getToken',
      };

      String url = 'https://ticketapp365.akprojects.co/api/user/view_profile';
      log("API Request: $url");

      var response = await http.post(Uri.parse(url), headers: headers);

      if (response.statusCode == 200) {
        var data = profileFromJson(response.body);
        profile = data;
        update();
      } else {
        log("API Error: ${response.body}");
      }
    } catch (e, stackTrace) {
      log("Exception in getProfile: $e", stackTrace: stackTrace);
    }
    isLoading = false;
    update();
  }

  @override
  void onInit() {
    getProfile();
    super.onInit();
  }
}
