import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/sujin_screen/Profile/profile__controller.dart';
import 'package:fluttertickect365/sujin_screen/both/bothCitiesController.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/sizes.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';

import 'Screens/controller/seatavailabilty-controller.dart';

class CustomBusDetails extends StatelessWidget {
  final String? busName;
  final String? fromLocation;
  final String? toLocation;
  final String? fromTime;
  final String? toTime;
  final DateTime? dateTime;

  CustomBusDetails({
    Key? key,
    this.busName,
    this.fromLocation,
    this.toLocation,
    this.fromTime,
    this.toTime,
    this.dateTime,
  }) : super(key: key);

  ProfileController controller = Get.find<ProfileController>();
  BothCitiesController bothCitiesController = Get.put(BothCitiesController());

  @override
  Widget build(BuildContext context) {
    print("fromTime${fromTime}");
    return Container(
      padding: EdgeInsets.all(8),
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey, width: 0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: GetBuilder<ProfileController>(builder: (v) {

        print("fromTime${fromTime}");
        return Column(
          children: [
            // Bus Name and Details
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  busName ?? '',
                  style: TextStyle(
                    fontSize: 18.sp,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  "Details",
                  style: TextStyle(fontSize: 14.sp, color: Colors.blue),
                ),
              ],
            ),
            SizedBox(
              height: 13.h,
            ),
            // Locations and Times
            Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // From Location
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          fromLocation ?? '',
                          style: TextStyle(color: Colors.black),
                        ),
                        const Text(
                          "Detailed Address",
                          style: TextStyle(color: Colors.black),
                        ),

                        Text(
                          v.profile!.busapiname == "seatseller" || bothCitiesController.ProviderType == "seatseller" ||   v.profile!.busapiname == "common"
                              ? "${SeatAvailabilityController().convertMinutesToTimeFormat(int.parse(fromTime!))} | ${DateFormat('EEE, dd MMM').format(dateTime!)}"
                              : "${DateFormat('h:mm a, d MMMM').format(DateTime.parse(fromTime!))}",
                          style: TextStyle(color: Colors.black),
                        ),
                      ],
                    ),

                    // To Location
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          toLocation ?? '',
                          style: TextStyle(color: Colors.black),
                          overflow: TextOverflow.ellipsis,
                        ),
                        const Text(
                          "Detailed Address",
                          style: TextStyle(color: Colors.black),
                        ),
                        Text(
                          v.profile!.busapiname == "seatseller" || bothCitiesController.ProviderType == "seatseller" ||   v.profile!.busapiname == "common"
                              ? "${SeatAvailabilityController().convertMinutesToTimeFormat(int.parse(toTime!))} | ${DateFormat('EEE, dd MMM').format(dateTime!)}"
                              : "${DateFormat('h:mm a, d MMMM').format(DateTime.parse(toTime!))}",
                          style: TextStyle(color: Colors.black),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 20),
              ],
            ),
          ],
        );
      }),
    );
  }
}
