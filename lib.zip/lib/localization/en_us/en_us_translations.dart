final Map<String, String> enUs = {
// Splash Screen Four Screen
  "lbl_get_started": "Get Started",
  "lbl_ticketapp365": "Ticketapp365",
  "lbl_welcome_to": "Welcome to",
  "msg_discover_and_book":
      "Discover and book bus tickets, flights, \ncabs, and hotels all in one place.",
  "msg_welcome_to_ticketapp365": "Welcome to Ticketapp365",
// Splash Screen Five Screen
  "lbl_next": "Next",
  "msg_all_in_one_travel": "All-in-One Travel Planner",
  "msg_manage_all_your":
      "Manage all your bookings and travel \nplans in one place, with easy access to \nyour itineraries.",
// Splash Screen Six Screen
  "lbl_ready_to_go": "Ready to Go?",
  "lbl_start_exploring": "Start Exploring",
  "msg_start_exploring":
      "Start exploring now and plan your \nnext adventure with Ticketapp365",
// Login Screen
  "lbl_content_policy": "Content Policy",
  "lbl_get_otp": "Get OTP",
  "lbl_or": "OR",
  "lbl_privacy_policy": "Privacy Policy",
  "msg_by_continuing_you":
      "By continuing, you agree to our\nTerms of service Privacy Policy Content Policy",
  "msg_by_continuing_you2": "By continuing, you agree to our\n",
  "msg_continue_with_google": "Continue with google",
  "msg_enter_your_phone": "Enter your phone number",
  "msg_login_to_your_account": "Login to your Account",
  "msg_terms_of_service": "Terms of service",

  // OTP Screen
  "lbl_91_9487_6": "+91-9487*****6",
  "OTP_Verification": "OTP Verification",
  "lbl_continue": "Continue",
  "msg_didn_t_get_the_otp": "Didn't get the OTP? Resend SMS in 30s",
  "msg_otp_verification": "OTP Verification",
  "msg_we_have_sent_a_verification":
      "We have sent a verification code to\n+91-9487*****6",
  "msg_we_have_sent_a_verification2": "We have sent a verification code to\n",

// Frame 1716775434 Screen
  "lbl_active_now": "Active Now",
  "lbl_bookings": "Bookings",
  "lbl_bus": "Bus",
  "lbl_cancelled": "Cancelled",
  "lbl_chennai": "Chennai",
  "lbl_completed": "Completed",
  "lbl_home": "Home",
  "lbl_my_booking": "My Booking",
  "lbl_nagercoil": "Nagercoil",
  "lbl_profile": "Profile",
  "msg_6_40_pm_27_june": "6:40 PM, 27 June",
  "msg_detailed_address": "Detailed address",
  "msg_tranzking_travels": "Tranzking Travels",

// Common String
  "lbl_skip": "Skip",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",

  // CAB - Homepage Screen
  "lbl_buses": "Buses",
  "lbl_cabs": "Cabs",
  "lbl_flights": "Flights",
  "lbl_hotels": "hotels",
  "lbl hello smith": "Hello Smith,",
  "lbl hotels": "Hotels",
  "lbl_offers": "Offers",
  "lbl_place_to_place": "PLACE\nTO\nPLACE",
  "lbl_popular_routes": "Popular Routes",
  "lbl_select_location": "Select Location",
  "lbl_viewall": "viewall",
  "msg_coimbatore_to_nagercoil": "Coimbatore\nTO\nNagercoil",
  "msg_let_s_holiday_together": "Let's Holiday Together!",
// Set Location Three Screen
  "lbl_from": "From",
// Set Location Four Screen
  "msg_current_location": "Current Location",

  // Booking \ no active Screen
  "msg_you_don_t_have_an": "You don't have an active bus booking at this time",
  "msg_you_have_no_active": "You have no active bus booking",
// Account Screen
  "lbl_91_76784 25635": "+91 76784 25635",
  "lbl account": "Account",
  "lbl_address": "Address",
  "lbl_andrew_smith": "Andrew Smith",
  "lbl_logout": "Logout",
  "lbl notification": "Notification",

// Search location > not found Screen
  "lbl 0 found": "0 found",
  "lbl abhbhh": "aBHBHH",
  "lbl not found": "Not Found",
  "msg_results_for_abhbhh": "Results for ",
  "msg_sorry_the_keyword":
      "Sorry, the keyword you entered cannot be\nfound, please check again or search with \nanother keyword.",
// Common String
  "lbl 1 5 km": "1.5 km",
  "lbl 2 5 km": "2.5 km",
  "lbl active now": "Active Now",
  "lbl_bookings": "Bookings",
  "lbl bus": "Bus",
  "lbl cancelled": "Cancelled",
  "lbl chennai": "Chennai",
  "lbl clear all": "Clear all",
  "lbl completed": "Completed",
  "lbl destination": "Destination",
  "lbl home": "Home",
  "lbl_my_booking": "My Booking",
  "lbl nagercoil": "Nagercoil",
  "lbl_profile": "Profile",
  "lbl recent": "Recent",
  "lbl_saved_places": "Saved Places",
  "lbl search location": "Search Location",
  "lbl_select_address": "Select Address",
  "lbl_skip": "Skip",
  "msg_43n_augusta_st": "43N, Augusta St. Lorain, OH 44656",
  "msg_50_bucks_nagercoil": "50 Bucks, Nagercoil",
  "msg_6_40_pm_27_june": "6:40 PM, 27 june",
  "msg_detailed_address": "Detailed address",
  "msg_pothys_nagercoil": "Pothys, Nagercoil",
  "msg_tranzking_travels": "Tranzking Travels",
// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
  "lbl_hello_smith": "hello adith",
  "lbl_hello_guest": "hello sir",
};
