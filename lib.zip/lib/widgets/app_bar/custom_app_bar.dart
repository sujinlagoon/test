import 'package:flutter/material.dart';
import '../../core/app_export.dart';

enum Style { bgoutline }

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  CustomAppBar({
    Key? key,
    this.height,
    this.shape,
    this.styleType,
    this.leadingWidth,
    this.leading,
    this.title,
    this.centerTitle,
    this.actions,
  }) : super(key: key);

  final double? height;
  final ShapeBorder? shape;
  final Style? styleType;
  final double? leadingWidth;
  final Widget? leading;
  final Widget? title;
  final bool? centerTitle;
  final List<Widget>? actions;

  @override
  Widget build(BuildContext context) {
    return AppBar(

      elevation: 0,
      shape: shape,
      toolbarHeight: height ?? 40,
      automaticallyImplyLeading: false,
      backgroundColor: Colors.transparent,
      flexibleSpace: _getStyle(),
      leadingWidth: leadingWidth ?? 0,
      leading: leading,
      title: title,
      titleSpacing: 0,
      centerTitle: centerTitle ?? false,
      actions: actions,
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(height ?? 40);

  Widget? _getStyle() {
    switch (styleType) {
      case Style.bgoutline:
        return Container(
          height: 40,
          width: double.infinity, // or use a specific width if needed
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: appTheme.gray30001,
                width: 1,
              ),
            ),
          ),
        );
      default:
        return null;
    }
  }
}
