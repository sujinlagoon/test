import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../theme/custom_text_style.dart';
import 'base_button.dart';

class CustomOutlinedButton extends BaseButton {
  CustomOutlinedButton({
    Key? key,
    this.decoration,
    this.leftIcon,
    this.rightIcon,
    this.label,
    VoidCallback? onPressed,
    ButtonStyle? buttonStyle,
    TextStyle? buttonTextStyle,
    bool? isDisabled,
    Alignment? alignment,
    double? height,
    double? width,
    EdgeInsets? margin,
    required String text,
  }) : super(
          key: key, // Include the key in the superclass constructor
          text: text,
          onPressed: onPressed,
          buttonStyle: buttonStyle,
          isDisabled: isDisabled,
          buttonTextStyle: buttonTextStyle,
          height: height,
          alignment: alignment,
          width: width,
          margin: margin,
        );

  final BoxDecoration? decoration;
  final Widget? leftIcon;
  final Widget? rightIcon;
  final Widget? label;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: alignment ?? Alignment.center,
      child: buildOutlinedButtonWidget(context),
    );
  }

  Widget buildOutlinedButtonWidget(BuildContext context) {
    return Container(
      height: height ?? 40,
      width: width ??
          double.infinity, // Use double.infinity instead of double.maxFinite
      margin: margin,
      decoration: decoration,
      child: OutlinedButton(
        style: buttonStyle,
        onPressed:
            isDisabled == true ? null : onPressed, // Use isDisabled directly
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (leftIcon != null) leftIcon!, // Use null-aware operator
            Text(
              text,
              style: buttonTextStyle ?? CustomTextStyles.titleMediumGray90001,
            ),
            if (rightIcon != null) rightIcon!, // Use null-aware operator
          ],
        ),
      ),
    );
  }
}
