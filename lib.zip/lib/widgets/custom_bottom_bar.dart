import 'package:flutter/material.dart';
import '../core/app_export.dart';
import '../core/utils/image_constant.dart';
import '../theme/custom_text_style.dart'; // Your custom app export file

enum BottomBarEnum { Home, Bookings, Profile }

// ignore_for_file: must_be_immutable
class CustomBottomBar extends StatefulWidget {
  CustomBottomBar({this.onChanged,this.selectedIndex});

  // Callback for when a bottom bar item is selected.
  Function(BottomBarEnum)? onChanged;
  int?selectedIndex;

  @override
  CustomBottomBarState createState() => CustomBottomBarState();
}

// ignore_for_file: must_be_immutable
class CustomBottomBarState extends State<CustomBottomBar> {
 // int selectedIndex = 0;

  // List of bottom bar items with their respective icons, titles, and enum type.
  List<BottomMenuModel> bottomMenuList = [
    BottomMenuModel(
      icon: ImageConstant.imgNavHome, // Icon for inactive state
      activeIcon: ImageConstant.imgNavHomeSelected, // Icon for active state
      title: "lbl_home".tr, // Title (localized)
      type: BottomBarEnum.Home, // Enum to identify the tab
    ),
    BottomMenuModel(
      icon: ImageConstant.imgNavBookings,
      activeIcon: ImageConstant.imgNavBookingsSelected, // Icon for active state
      title: "lbl_bookings".tr,
      type: BottomBarEnum.Bookings,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgNavProfile,
      activeIcon: ImageConstant.imgNavProfileSelected, // Icon for active state
      title: "lbl_profile".tr,
      type: BottomBarEnum.Profile,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF), // White background color
        border: Border(
          top: BorderSide(
            color: Color(0XFFB3B3B3), // Border color for top
            width: 1,
          ),
        ),
      ),
      child: BottomNavigationBar(
        backgroundColor: Colors.transparent,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        selectedFontSize: 0,
        elevation: 0,
        currentIndex: widget.selectedIndex!,
        type: BottomNavigationBarType.fixed,
        items: List.generate(bottomMenuList.length, (index) {
          return BottomNavigationBarItem(
            icon: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CustomImageView(
                  imagePath: bottomMenuList[index].icon,
                  height: 20, // Icon height (responsive)
                  width: 20, // Icon width (responsive)
                  color: Color(0XFF3F3F3F), // Inactive icon color
                ),
                SizedBox(height: 4),
                Text(
                  bottomMenuList[index].title ?? "",
                  style: CustomTextStyles.bodySmallGray80001.copyWith(
                    color: Color(0XFF3F3F3F), // Inactive text color
                  ),
                ),
              ],
            ),
            activeIcon: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CustomImageView(
                  imagePath: bottomMenuList[index]
                      .activeIcon, // This will now use the updated active icon
                  height: 20, // Active icon height
                  width: 22, // Active icon width (slightly larger)
                  color: Color(0XFF4081FF), // Active icon color
                ),
                SizedBox(height: 4),
                Text(
                  bottomMenuList[index].title ?? "",
                  style: CustomTextStyles.bodySmallBlueA200.copyWith(
                    color: Color(0XFF4081FF), // Active text color
                  ),
                ),
              ],
            ),
            label: "",
          );
        }),
        onTap: (index) {
        /*  setState(() {
            widget.selectedIndex = index; // Update selected index
          });*/
          widget.onChanged?.call(bottomMenuList[index].type); // Trigger callback when tab changes
        },
      ),
    );
  }
}

// Model class representing each item in the bottom bar
class BottomMenuModel {
  BottomMenuModel({
    required this.icon,
    required this.activeIcon,
    this.title,
    required this.type,
  });

  String icon;
  String activeIcon;
  String? title;
  BottomBarEnum type;
}

// DefaultWidget class to be replaced with the respective widget
class DefaultWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color(0xffffffff),
      padding: EdgeInsets.all(10),
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Please replace the respective Widget here',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
