/*
import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
// For checking internet connectivity
abstract class NetworkInfoI {
  Future<bool> isConnected();
  Future<ConnectivityResult> get connectivityResult;
  Stream<ConnectivityResult> get onConnectivityChanged;
}

class NetworkInfo implements NetworkInfoI {
  final Connectivity _connectivity;

  // Singleton instance
  static final NetworkInfo _networkInfo = NetworkInfo._internal(Connectivity());

  factory NetworkInfo() {
    return _networkInfo;
  }

  NetworkInfo._internal(this._connectivity);


  @override
  Future<bool> isConnected() async {
    final result = await connectivityResult;
    return result != ConnectivityResult.none;
  }

  // To check type of internet connectivity
  @override
  Future<ConnectivityResult> get connectivityResult async {
    // Fetch the current connectivity result
    return await _connectivity.checkConnectivity();
  }

  @override
  Stream<ConnectivityResult> get onConnectivityChanged =>
      _connectivity.onConnectivityChanged;
}

abstract class Failure {}

// General failures
class ServerFailure extends Failure {}

class CacheFailure extends Failure {}

class NetworkFailure extends Failure {}

class ServerException implements Exception {}

class CacheException implements Exception {}

class NetworkException implements Exception {}

// Can be used for throwing [NoInternetException]
class NoInternetException implements Exception {
  final String _message;

  NoInternetException([String message = 'No Internet Connection'])
      : _message = message {
    if (globalMessengerKey.currentState != null) {
      globalMessengerKey.currentState!
          .showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  String toString() {
    return _message;
  }
}
*/
