// ignore for file: must be immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';
  // Splash Screen Four images
  //static String img585138319372530 = '$imagePath/img_58513831_9372530.svg';//old
  static String img585138319372530 = '$imagePath/img58513831_9372530.svg';
  // Splash Screen Five images
  static String imgGroup = '$imagePath/img_group.svg';
  // Splash Screen Six images
  static String imgBus1 = '$imagePath/img_bus_1.png';
  static String imgAirplanel = '$imagePath/img_airplane_1.png';
  static String imgHotelSign1 = '$imagePath/img_hotel_sign_1.png';
  static String imgCar11 = '$imagePath/img_car_1_1.png';
  // Login images
  static String imgFrame1716775383 = '$imagePath/img_frame_1716775383.png';
  static String imgFirrphonecall = '$imagePath/img_firrphonecall.svg';
  static String imgFi300221 = '$imagePath/img_fi300221.png';
  // OTP images
  static String imgEdit = '$imagePath/img_edit.svg';
  // Frame 1716775434 images
  static String imgArrowdownGray90001 =
      '$imagePath/img_arrowdown_gray_900_01.svg';
  static String imgNavHome = '$imagePath/img_nav_home.svg';
  static String imgNavHomeSelected = '$imagePath/img_nav_home_selected.svg';
  static String imgNavBookings = '$imagePath/img_nav_bookings.svg';
  static String imgNavBookingsSelected =
      '$imagePath/img_nav_booking_selected.svg';
  static String imgNavProfile = '$imagePath/img_nav_profile.svg';
  static String imgNavProfileSelected =
      '$imagePath/img_nav_profile_selected.svg';

  // Common images

  static String imgTicketapp36501 = '$imagePath/img_ticketapp365_01.png';

  static String imgArrowDown = '$imagePath/icon_back_button.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';

  //cab home image

  static String image5 = '$imagePath/image_5.png';
  //static String imgTourBus1 = '$imagePath/img_tour_bus_1.svg';
  static String imgTourBus1 = '$imagePath/bus1.svg';
  static String greyairplane = '$imagePath/img_grey_airoplane.svg';
  static String greytaxi = '$imagePath/img_grey_taxi.svg';
  static String greyhotel = '$imagePath/img_grey_hotel.svg';
  static String icon_notification = '$imagePath/icon_notification.svg';
  //static String icon_notification = '$imagePath/icon_notification.png';
  static String img_home_car = '$imagePath/img_home_car.svg';

  static String accUser = '$imagePath/acc_user.svg';
  static String acclocation = '$imagePath/acc_location.svg';
  static String accnotification = '$imagePath/acc_notification.svg';
  static String acclogout = '$imagePath/acc_logout.svg';
  static String popupLogout = '$imagePath/popup_logout.svg';
  static String bluedot = '$imagePath/bluedot.svg';
  static String bluelocation = '$imagePath/blue_location.svg';
  static String liteblueedit = '$imagePath/liteblue_edit.svg';
  static String toycar = '$imagePath/toy_car.svg';
  static String greylocation = '$imagePath/grey_location.svg';
  static String greytime = '$imagePath/grey_time.svg';
  static String greywallet = '$imagePath/grey_wallet.svg';
  static String carsearch = '$imagePath/car_search.png';
  static String searchcar = '$imagePath/search_car.svg';
  static String locationplus = '$imagePath/location_plus.svg';
  static String whitecancel = '$imagePath/white_cancel.svg';
  static String whitecomment = '$imagePath/white_comment.svg';
  static String whitephone = '$imagePath/white_phone.svg';
  static String chatsent = '$imagePath/chat_sent.svg';
  static String whitedot = '$imagePath/white_dot.svg';
  static String saveicon = '$imagePath/saveicon.svg';
  static String discount = '$imagePath/discount.svg';

  static String arrow_left = '$imagePath/arrow_left.png';
  static String edit_num = '$imagePath/edit_num.png';
}
