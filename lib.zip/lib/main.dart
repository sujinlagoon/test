import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/presentation/cab_homepage_screen/cab_homepage_screen.dart';
import 'package:fluttertickect365/presentation/login_screen/login_screen.dart';
import 'package:fluttertickect365/presentation/onboardingscreen/OnboardingScreen.dart';
import 'package:fluttertickect365/presentation/onboardingscreen/OnboardingScreentwo.dart';
import 'package:fluttertickect365/presentation/utils/NotificationService.dart';
import 'package:fluttertickect365/sujin_screen/Profile/profile__controller.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/bindings_interface.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/app_export.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

var globalMessengerKey = GlobalKey<ScaffoldMessengerState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // Wait for preferences to initialize
  await PrefUtils().init();
  final loginStatus = await getloginstatus(); // Check login status
  await Firebase.initializeApp();
  // Initialize NotificationService
  NotificationService.initialize();
  // Initialize Firebase Messaging and handle foreground messages
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    print("firebae message$message");
    if (message.notification != null) {
      NotificationService.showNotification(
        title: message.notification?.title ?? 'New Notification',
        body: message.notification?.body ?? 'You have a new message!',
        imageUrl: message.data['image'], // Handle image data from message
      );
    }
  });

  // Handle background messages
  FirebaseMessaging.onBackgroundMessage(backgroundMessageHandler);

  runApp(
    ScreenUtilInit(
        designSize: const Size(360, 690),
        minTextAdapt: true,
        builder: (context, child) => MyApp(loginStatus: loginStatus)),
  );

  // Pass the login status to MyApp
}

Future<String?> getloginstatus() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs
      .getString('login'); // Get the login status from SharedPreferences
}

// Background message handler for when the app is in the background or terminated
Future<void> backgroundMessageHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  if (message.notification != null) {
    NotificationService.showNotification(
      title: message.notification?.title ?? 'Background Notification',
      body: message.notification?.body ?? 'You have a new background message!',
      imageUrl: message.data['image'], // Handle image data from message
    );
  }
}

class MyApp extends StatelessWidget {
  final String? loginStatus;

  MyApp({this.loginStatus});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      initialBinding:InitialBindings(),
      theme: theme,
      title: 'Ticket 365',
      navigatorKey: NavigatorService.navigatorKey,
      debugShowCheckedModeBanner: false,
      localizationsDelegates: [
        AppLocalizationDelegate(),
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate
      ],
      supportedLocales: [
        Locale('en'),
      ],
      // Remove initialRoute and handle navigation manually
      home: _getInitialScreen(),
    );
  }

  Widget _getInitialScreen() {
    // Check the login status and navigate accordingly
    if (loginStatus == 'yes') {
      // Navigate to home screen
      return CabHomepageScreen();
    } else if (loginStatus == 'login') {
      // Navigate to login screen
      return LoginScreen();
    } else {
      // Navigate to splash screen
      //  return SplashScreenFourScreen();
      return OnboardingScreen();
    }
  }
}

/*
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/app_export.dart';

var globalMessengerKey = GlobalKey<ScaffoldMessengerState>();

void main() async {
  WidgetsFlutterBinding
      .ensureInitialized(); // Ensures Flutter engine is initialized
  await Firebase.initializeApp(); // Initialize Firebase
  Future.wait([
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.portraitUp]) // Set the preferred orientation
  ]).then((value) {
    PrefUtils()
        .init(); // Initialize preferences (adjust based on your actual class)
    runApp(MyApp()); // Run the app
  });
}

Future<String?> getloginstatus() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('login');
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Sizer(
      builder: (context, orientation, deviceType) {
        return BlocProvider(
          create: (context) => ThemeBloc(
            themeType: PrefUtils().getThemeData(),
          ),
          child: BlocBuilder<ThemeBloc, ThemeState>(
            builder: (context, state) {
              return MaterialApp(
                theme: theme,
                //   title: 'adith_s_application1',
                title: 'Ticket 365',
                navigatorKey: NavigatorService.navigatorKey,
                debugShowCheckedModeBanner: false,
                localizationsDelegates: [
                  AppLocalizationDelegate(),
                  GlobalMaterialLocalizations.delegate,
                  GlobalWidgetsLocalizations.delegate,
                  GlobalCupertinoLocalizations.delegate
                ],
                supportedLocales: [
                  Locale('en'),
                ],

                // initialRoute: AppRoutes.loginScreen,

                initialRoute: AppRoutes.splashScreenFourScreen,
                routes: AppRoutes.routes,
              );
            },
          ),
        );
      },
    );
  }
}
*/
class InitialBindings extends Bindings {
  @override
  void dependencies() {
    // Initialize ProfileController
    Get.put(ProfileController());
  }
}