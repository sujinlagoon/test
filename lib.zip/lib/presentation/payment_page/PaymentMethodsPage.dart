import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;

class PaymentMethodsPage extends StatefulWidget {
  @override
  _PaymentMethodsPageState createState() => _PaymentMethodsPageState();
}

class _PaymentMethodsPageState extends State<PaymentMethodsPage> {
  int _selectedPaymentMethod = -1;
  final TextEditingController _promoCodeController = TextEditingController();
  String couponCode = "";

  //bool isLoading = true;
  bool isLoading = false; // Track API loading state

  List<dynamic> paymentList = []; // List to hold car data

  String Fare = "";
  String coupon_value = "";
  String total_price = "";

  @override
  void initState() {
    super.initState();
    fetchCarData();

  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }
  Future<String?> getBookingID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('bookingid');
  }



  Future<void> fetchCarData() async {
    String? token = await getToken();
    String? bookid = await getBookingID();

    print ("1.....");
    if (token == null) {
      showError("Authentication token not found");
      return;
    }
    if (bookid == null) {
      showError("Authentication bookingid not found");
      return;
    }
    print ("2.....");

    final url = Uri.parse('${AppConstants.MAIN_URL}get_payment_methods');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
    print ("3.....");

    final body = jsonEncode({
      "booking_id": bookid,
      //"BookingID": "88",
    });
    print ("4.....");
    setState(() {
      isLoading = true; // Start loading
    });

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(color: Color(0xFF4181FF)),
        );
      },
    );


    try {
      final response = await http.post(url, headers: headers, body: body);
      print ("5.....");

      if (response.statusCode == 200) {
        print ("6.....");

        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            print("in...");

            isLoading = false;
            print("isLoading...");

            // Safely parse and handle 'Fare'
            double doublefare = data['faredata']['Fare'];
            print("doublefare...");

            // Safely parse 'coupon_value' from String to double
            String couponValueString = data['faredata']['coupon_value'];
            double doublecoupen = double.tryParse(couponValueString) ?? 0.0;
            print("doublecoupen...");

            int doubletotal_price = data['faredata']['total_price'];
            print("doubletotal_price...");

            // Convert Fare to String with desired format
            Fare = doublefare.toStringAsFixed(2);
            coupon_value = doublecoupen.toStringAsFixed(2);
            total_price = doubletotal_price.toString();
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }finally {
      setState(() {
        isLoading = false; // End loading
      });


      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
      }
    }
  }
  Future<void> coupenApi() async {
    String? token = await getToken();
    String? bookid = await getBookingID();

    print ("1.....");
    if (token == null) {
      showError("Authentication token not found");
      return;
    }
    if (bookid == null) {
      showError("Authentication bookingid not found");
      return;
    }
    print ("2.....");

    final url = Uri.parse('${AppConstants.MAIN_URL}promo_code');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
    print ("3.....");

    final body = jsonEncode({
      //"booking_id": bookid,
      "coupon_code ": couponCode,
      "amount  ": total_price,
    });
    print ("4.....");
    setState(() {
      isLoading = true; // Start loading
    });

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(color: Color(0xFF4181FF)),
        );
      },
    );


    try {
      final response = await http.post(url, headers: headers, body: body);
      print ("5.....");

      if (response.statusCode == 200) {
        print ("6.....");

        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            print("in...");

            isLoading = false;
            print("isLoading...");

            // Safely parse and handle 'Fare'
            double doublefare = data['faredata']['Fare'];
            print("doublefare...");

            // Safely parse 'coupon_value' from String to double
            String couponValueString = data['faredata']['coupon_value'];
            double doublecoupen = double.tryParse(couponValueString) ?? 0.0;
            print("doublecoupen...");

            int doubletotal_price = data['faredata']['total_price'];
            print("doubletotal_price...");

            // Convert Fare to String with desired format
            Fare = doublefare.toStringAsFixed(2);
            coupon_value = doublecoupen.toStringAsFixed(2);
            total_price = doubletotal_price.toString();
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }finally {
      setState(() {
        isLoading = false; // End loading
      });


      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
      }
    }
  }


  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Payment Methods",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        leading: Icon(Icons.arrow_back),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Select the payment method you want to use",
                    style: TextStyle(color: Color(0xFF676767)),
                  ),
                  SizedBox(height: 16),
                  // Payment options


// Pay upon Arrival
                  Container(
                    margin: EdgeInsets.only(bottom: 8.0),  // Reduced bottom margin
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xFFBEBEBE), width: 1),  // Reduced border thickness
                      borderRadius: BorderRadius.circular(8),  // Optional: rounded corners for the border
                    ),
                    child: _buildPaymentOption("Pay upon Arrival", 3),
                  ),

                  SizedBox(height: 250),
                //  Spacer(),
                  // Promo Code Section
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Promo Code",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 8),
                        Row(
                          children: [

                          /*  Expanded(
                              child: TextField(
                                decoration: InputDecoration(
                                  hintText: "Enter Promo Code",
                                  hintStyle: TextStyle(color: Colors.white, fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14),  // Set hint text color to white
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide.none,
                                  ),
                                  filled: true,
                                  fillColor: Color(0xFFD6D6D6),
                                  contentPadding: EdgeInsets.symmetric(vertical: 1, horizontal: 10), // Reduced vertical padding
                                ),
                              ),
                            ),

                            SizedBox(width: 8),
                            // Submit Button with Gradient
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                gradient: LinearGradient(
                                  colors: [Color(0xFF4181FF), Color(0xFF274E99)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                              ),
                              child: ElevatedButton(
                                onPressed: () {},
                                style: ElevatedButton.styleFrom(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 24, vertical: 14),
                                  backgroundColor: Colors.transparent, // Make button background transparent
                                  shadowColor: Colors.transparent, // Remove shadow
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: Text(
                                  "Submit",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),*/

                            Expanded(
                              child: TextField(
                                controller: _promoCodeController, // Add a controller
                                decoration: InputDecoration(
                                  hintText: "Enter Promo Code",
                                  hintStyle: TextStyle(
                                      color: Colors.white,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide.none,
                                  ),
                                  filled: true,
                                  fillColor: Color(0xFFD6D6D6),
                                  contentPadding: EdgeInsets.symmetric(vertical: 1, horizontal: 10),
                                ),
                              ),
                            ),

                            SizedBox(width: 8),
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                gradient: LinearGradient(
                                  colors: [Color(0xFF4181FF), Color(0xFF274E99)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                              ),
                              child: ElevatedButton(
                                onPressed: () {
                                  couponCode = _promoCodeController.text;

                                  // Show a toast with the entered promo code
                               /*   Fluttertoast.showToast(
                                      msg: "Entered Promo Code: $enteredPromoCode",
                                      toastLength: Toast.LENGTH_SHORT,
                                      gravity: ToastGravity.BOTTOM,
                                      timeInSecForIosWeb: 1,
                                      backgroundColor: Colors.black,
                                      textColor: Colors.white,
                                      fontSize: 16.0
                                  );*/
                                  print(couponCode);
                                },
                                style: ElevatedButton.styleFrom(
                                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                                  backgroundColor: Colors.transparent,
                                  shadowColor: Colors.transparent,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: Text(
                                  "Submit",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  // Fare Section
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 16), // Horizontal padding
                    child: _buildFareRow("Fare", Fare),
                  ),

                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 16), // Horizontal padding
                    child: _buildFareRow("Coupon Applied", coupon_value),
                  ),

                  SizedBox(height: 16),
                  /* Divider(thickness: 1),
                  _buildFareRow("Total Fare", "₹150", isBold: true),*/
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16), // Add vertical and horizontal padding
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xFFBEBEBE)),  // Grey border around the Total Fare
                      borderRadius: BorderRadius.circular(8),  // Optional: rounded corners
                    ),
                    child: _buildFareRow("Total Fare", total_price, isBold: true),
                  ),
                ],
              ),
            ),
          ),
          // Fixed Continue Button at the Bottom
          buildUpdateButton(),


        ],
      ),
    );
  }

  Widget buildUpdateButton() {
    return Container(
      margin: EdgeInsets.all(16.0),
      child: CustomElevatedButton(
        text: "Continue",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Handle continue button action
        },
      ),
    );
  }

  Widget _buildPaymentOption(String title, int index) {
    String svgAssetPath = '';

    // Set different SVG image paths based on the index
    switch (index) {
      case 0: // Razorpay
        svgAssetPath = 'assets/images/razorpay.svg';  // Set path for Razorpay SVG
        break;
      case 1: // Paytm
        svgAssetPath = 'assets/images/paytm.svg';  // Set path for Paytm SVG
        break;
      case 2: // GPay
        svgAssetPath = 'assets/images/gpay.svg';  // Set path for GPay SVG
        break;
      case 3: // Pay upon Arrival
        svgAssetPath = 'assets/images/pay_upon_arrival.svg';  // Set path for Pay upon Arrival SVG
        break;
      default:
        svgAssetPath = '';  // Default case if needed
    }

    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Color(0xFFBEBEBE)), // Grey border around the payment option
        borderRadius: BorderRadius.circular(8), // Optional: rounded corners for the border
      ),
      child: ListTile(
        leading: SizedBox(
          width: 32,  // Set fixed width for all icons (static size)
          height: 32, // Set fixed height for all icons (static size)
          child: SvgPicture.asset(
            svgAssetPath,  // Load the SVG image from the asset
            fit: BoxFit.contain,  // Ensure the SVG fits correctly inside the set size
          ),
        ),
        title: Text(title, style: TextStyle(fontSize: 16)),
        trailing: Radio<int>(
          value: index,
          groupValue: _selectedPaymentMethod,
          onChanged: (int? value) {
            setState(() {
              _selectedPaymentMethod = value!;
            });
          },
        ),
      ),
    );
  }  Widget _buildFareRow(String label, String amount, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 16,
              color:Color(0xFF676767),
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            amount,
            style: TextStyle(
              fontSize: 16,
              color: Color(0xFF4181FF),
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}

/*// Razorpay
                  Container(
                    margin: EdgeInsets.only(bottom: 8.0),  // Reduced bottom margin
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xFFBEBEBE), width: 1),  // Reduced border thickness
                      borderRadius: BorderRadius.circular(8),  // Optional: rounded corners for the border
                    ),
                    child: _buildPaymentOption("Razorpay", 0),
                  ),

// Paytm
                  Container(
                    margin: EdgeInsets.only(bottom: 8.0),  // Reduced bottom margin
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xFFBEBEBE), width: 1),  // Reduced border thickness
                      borderRadius: BorderRadius.circular(8),  // Optional: rounded corners for the border
                    ),
                    child: _buildPaymentOption("Paytm", 1),
                  ),

// GPay
                  Container(
                    margin: EdgeInsets.only(bottom: 8.0),  // Reduced bottom margin
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xFFBEBEBE), width: 1),  // Reduced border thickness
                      borderRadius: BorderRadius.circular(8),  // Optional: rounded corners for the border
                    ),
                    child: _buildPaymentOption("GPay", 2),
                  ),*/

/*
import 'package:flutter/material.dart';

import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';

class PaymentMethodsPage extends StatefulWidget {
  @override
  _PaymentMethodsPageState createState() => _PaymentMethodsPageState();
}

class _PaymentMethodsPageState extends State<PaymentMethodsPage> {
  int _selectedPaymentMethod = -1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Payment Methods",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        leading: Icon(Icons.arrow_back),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Select the payment method you want to use",
                    style: TextStyle(color: Colors.grey),
                  ),
                  SizedBox(height: 16),
                  // Payment options
                  _buildPaymentOption("Razorpay", 0),
                  _buildPaymentOption("Paytm", 1),
                  _buildPaymentOption("GPay", 2),
                  _buildPaymentOption("Pay upon Arrival", 3),
                  SizedBox(height: 16),
                  // Promo Code Section
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Promo Code",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                decoration: InputDecoration(
                                  hintText: "Enter Promo Code",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide.none,
                                  ),
                                  filled: true,
                                  fillColor: Colors.grey[300],
                                ),
                              ),
                            ),
                            SizedBox(width: 8),
                            ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 24, vertical: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: Text("Submit"),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  // Fare Section
                  _buildFareRow("Fare", "₹200"),
                  _buildFareRow("Coupon Applied", "-₹50"),
                  Divider(thickness: 1),
                  _buildFareRow("Total Fare", "₹150", isBold: true),
                ],
              ),
            ),
          ),
          // Fixed Continue Button at the Bottom

          buildUpdateButton()
        ],
      ),
    );

  }
  Widget buildUpdateButton() {
    return Container(
      margin: EdgeInsets.all(16.0),
      child: CustomElevatedButton(
        text: "Continue",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Handle continue button action
        },
      ),
    );
  }


  Widget _buildPaymentOption(String title, int index) {
    return ListTile(
      leading: Icon(Icons.payment),
      title: Text(title, style: TextStyle(fontSize: 16)),
      trailing: Radio<int>(
        value: index,
        groupValue: _selectedPaymentMethod,
        onChanged: (int? value) {
          setState(() {
            _selectedPaymentMethod = value!;
          });
        },
      ),
    );
  }

  Widget _buildFareRow(String label, String amount, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 16,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            amount,
            style: TextStyle(
              fontSize: 16,
              color: Colors.blue,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
*/




/*
import 'package:flutter/material.dart';

class PaymentMethodsPage extends StatefulWidget {
  @override
  _PaymentMethodsPageState createState() => _PaymentMethodsPageState();
}

class _PaymentMethodsPageState extends State<PaymentMethodsPage> {
  int _selectedPaymentMethod = -1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Payment Methods",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        leading: Icon(Icons.arrow_back),
      ),
      body: SingleChildScrollView(
        // Wrapping the body with SingleChildScrollView
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Select the payment method you want to use",
              style: TextStyle(color: Colors.grey),
            ),
            SizedBox(height: 16),
            // Payment options
            _buildPaymentOption("Razorpay", 0),
            _buildPaymentOption("Paytm", 1),
            _buildPaymentOption("GPay", 2),
            _buildPaymentOption("Pay upon Arrival", 3),
            SizedBox(height: 16),
            // Promo Code Section
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Promo Code",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          decoration: InputDecoration(
                            hintText: "Enter Promo Code",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide.none,
                            ),
                            filled: true,
                            fillColor: Colors.grey[300],
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: Text("Submit"),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),
            // Fare Section
            _buildFareRow("Fare", "₹200"),
            _buildFareRow("Coupon Applied", "-₹50"),
            Divider(thickness: 1),
            _buildFareRow("Total Fare", "₹150", isBold: true),
            SizedBox(height: 16), // Added space for better appearance
            // Continue Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.blue,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  "Continue",
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentOption(String title, int index) {
    return ListTile(
      leading: Icon(Icons.payment),
      title: Text(title, style: TextStyle(fontSize: 16)),
      trailing: Radio<int>(
        value: index,
        groupValue: _selectedPaymentMethod,
        onChanged: (int? value) {
          setState(() {
            _selectedPaymentMethod = value!;
          });
        },
      ),
    );
  }

  Widget _buildFareRow(String label, String amount, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 16,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            amount,
            style: TextStyle(
              fontSize: 16,
              color: Colors.blue,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
*/
