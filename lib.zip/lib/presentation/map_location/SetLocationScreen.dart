import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../car/SelectCarScreen.dart';
import '../car/TripDetailsPage.dart';
import '../utils/AppConstants.dart';
import 'MapScreen.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:google_api_headers/google_api_headers.dart';
import 'package:flutter_google_places/flutter_google_places.dart';

class SetLocationScreen extends StatefulWidget {
  @override
  _SetLocationScreenState createState() => _SetLocationScreenState();
}

class _SetLocationScreenState extends State<SetLocationScreen> {
  GoogleMapController? mapController;
  String? destinationAddress; // To store the resolved address
  String? currentAddress; // To store the resolved address
  Set<Marker> _markers = {}; // Declare a set of markers

  LatLng _initialPosition = LatLng(8.188957, 77.423601);
  bool isLoading = true;
  List<dynamic> recentPlaces = [];
  List<dynamic> savedPlaces = [];
  Set<int> savedPlaceIds = {};

  String listClick = "";

  static const kGoogleApiKey = 'AIzaSyBP5GUxTHqath5-maur0OZIUOf81dgZlTM';
  final homeScaffoldKey = GlobalKey<ScaffoldState>();

  //final Mode _mode = Mode.overlay;

  @override
  void initState() {
    super.initState();
    // fetchRecentPlaces();

    _getCurrentLocation();
    // BackButtonInterceptor.add(myInterceptor);
    //fetchsavedPlaces();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  //map click
  Future<void> _onMapTapped(LatLng position) async {
    try {
      setState(() {
        isLoading = true;
      });

      // Reverse geocode to get the address
      List<Placemark> placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty) {
        Placemark place = placemarks.first;
        String address =
            "${place.name}, ${place.locality}, ${place.administrativeArea}, ${place.country}";

        setState(() {
          destinationAddress = address; // Set the address
          isLoading = false;

          // Clear the previous marker and add a new one at the tapped position
          _markers.clear(); // Clear all existing markers
          _markers.add(Marker(
            markerId: MarkerId(position.toString()), // Unique ID for the marker
            position: position, // Position of the marker
            infoWindow: InfoWindow(
                title: 'Selected Location',
                snippet: address), // Show address on tap
            icon:
                BitmapDescriptor.defaultMarker, // You can change the icon here
          ));
        });

        /*  ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Selected Address: $address')),
        );*/
        listClick = "";
      } else {
        throw Exception("No address found at the selected location.");
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to fetch address: $e")),
      );
    }
  }

  //location

  Future<LatLng> getCurrentLatLng() async {
    // Check if location services are enabled
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception("Location services are disabled.");
    }

    // Request location permissions
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception("Location permissions are denied.");
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception("Location permissions are permanently denied.");
    }

    // Get the current position
    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    return LatLng(position.latitude, position.longitude);
  }

  Future<void> _getCurrentLocation() async {
    setState(() {
      isLoading = true;
    });

    try {
      // Check if location services (GPS) are enabled
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        // If GPS is off, show the dialog to enable it
        _showGpsDialog();
        return;
      }

      // Check if location permission is granted
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        // If permission is denied, show the dialog to request permission
        _showPermissionDialog();
        return;
      }

      if (permission == LocationPermission.deniedForever) {
        // If permission is permanently denied, show the dialog to ask for permission again
        _showPermissionDialog();
        return;
      }

      // If permissions are granted, get the current location
      LatLng currentLatLng = await getCurrentLatLng();
      setState(() {
        _initialPosition = currentLatLng;
        isLoading = false;
      });

      // Reverse geocoding to get the address from the coordinates
      List<Placemark> placemarks = await placemarkFromCoordinates(
        currentLatLng.latitude,
        currentLatLng.longitude,
      );

      if (placemarks.isNotEmpty) {
        Placemark place = placemarks.first;
        currentAddress =
            "${place.name}, ${place.locality}, ${place.administrativeArea}, ${place.country}";

        // Optionally, you can display the address or store it in SharedPreferences
        print("Current Address: $currentAddress");

        // If you want to store it in SharedPreferences, you can do so:
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('current_address', currentAddress!);
      } else {
        showError("No address found at the current location.");
      }

      // Move the map camera to the current location
      mapController?.animateCamera(
        CameraUpdate.newLatLng(currentLatLng),
      );

      // Call the API after fetching the location
      fetchRecentPlaces();
      fetchsavedPlaces();
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      showError("Failed to get current location: $e");
    }
  }

  void _showGpsDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Enable GPS"),
          content: Text("Please enable your GPS to continue."),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
                // Open location settings for the user to enable GPS
                await Geolocator.openLocationSettings();
                // After the user returns from settings, try again
                _getCurrentLocation();
              },
              child: Text("Go to Settings"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                showError("GPS is required for this functionality.");
              },
              child: Text("Cancel"),
            ),
          ],
        );
      },
    );
  }

  void _showPermissionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Location Permission"),
          content: Text("Please grant location permission to continue."),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();

                // Request permission again
                LocationPermission permission =
                    await Geolocator.requestPermission();

                // Check the permission status after requesting
                if (permission == LocationPermission.denied) {
                  // If permission is still denied, show dialog again
                  _showPermissionDialog();
                } else if (permission == LocationPermission.deniedForever) {
                  // If permission is denied forever, ask user to enable manually
                  _showPermissionDeniedForeverDialog();
                } else {
                  // If permission is granted, proceed to get the location
                  _getCurrentLocation();
                }
              },
              child: Text("Grant Permission"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                showError("Location permission is required.");
              },
              child: Text("Cancel"),
            ),
          ],
        );
      },
    );
  }

  void _showPermissionDeniedForeverDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Permission Denied Forever"),
          content: Text(
              "You have permanently denied location permission. Please enable it from settings to continue."),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
                // Open app settings to allow the user to grant permission manually
                await Geolocator.openAppSettings();
              },
              child: Text("Open Settings"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                showError("Location permission is required.");
              },
              child: Text("Cancel"),
            ),
          ],
        );
      },
    );
  }

  Future<void> savePlace(String latitude, String longitude, String title,
      String address, int placeId) async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}save_location');

    print('api called');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "latitude": latitude,
      "longitude": longitude,
      "title": title,
      "address": address,
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        print('200 called');

        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          print('true called');
          print(data['message'] ?? "Failed to save location");

          setState(() {
            savedPlaceIds.add(placeId); // Mark this place as saved
          });
        } else {
          showError(data['message'] ?? "Failed to save location");
        }
      } else {
        showError('Failed to save data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  Future<void> fetchsavedPlaces() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}saved_locations_list');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "pageNo": "1",
      "fromlatitude": _initialPosition.latitude.toString(),
      "fromlongitude": _initialPosition.longitude.toString(),
    });

    print("savedlocation in...");
    print("svfromlatitude..." + _initialPosition.latitude.toString());
    print("svfromlongitude..." + _initialPosition.longitude.toString());
    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        print("savedlocation 200...");

        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            print("savedlocation true...");

            savedPlaces = data['data']['All_Locations'] ?? [];
            isLoading = false;

            //    print(savedPlaces);
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  Future<void> fetchRecentPlaces() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}recent_places');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "pageNo": "1",
      "fromlatitude": _initialPosition.latitude.toString(),
      "fromlongitude": _initialPosition.longitude.toString(),
    });

    print("savedlocation in...");
    print("fromlatitude..." + _initialPosition.latitude.toString());
    print("fromlongitude..." + _initialPosition.longitude.toString());

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            recentPlaces = data['data'] ?? [];
            print('Recent Places Response: $recentPlaces');
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  //search map
  //search destination
  Future<void> _handlePressButton() async {
    Prediction? p = await PlacesAutocomplete.show(
      context: context,
      apiKey: kGoogleApiKey,
      // onError: onError,
      // mode: _mode,
      language: 'en',
      strictbounds: false,
      types: [""],
      decoration: InputDecoration(
        hintText: 'Search',
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(color: Colors.white),
        ),
      ),
      components: [
        Component(Component.country, "in"), // Restrict to India
      ],
    );

    if (p != null) {
      displayPrediction(p, homeScaffoldKey.currentState);
    }
  }

  Future<void> displayPrediction(
      Prediction p, ScaffoldState? currentState) async {
    GoogleMapsPlaces places = GoogleMapsPlaces(
      apiKey: kGoogleApiKey,
      apiHeaders: await const GoogleApiHeaders()
          .getHeaders(), // Make sure this header is valid
    );

    // Fetch place details using the place ID
    PlacesDetailsResponse detail = await places.getDetailsByPlaceId(p.placeId!);

    // Extract latitude and longitude
    final lat = detail.result.geometry!.location.lat;
    final lng = detail.result.geometry!.location.lng;

    // Extract the full address
    final address = detail.result.formattedAddress;

    // Print the details
    print("lat = $lat");
    print("lng = $lng");
    print("Address = $address");
    setState(() {
      destinationAddress = address; // Set the address
      isLoading = false;
      listClick = "";
      // Clear the previous marker and add a new one at the tapped position
      _markers.clear(); // Clear all existing markers
      _markers.add(Marker(
        markerId: const MarkerId("0"), // Unique ID for the marker
        position: LatLng(lat, lng), // Position of the marker
        infoWindow: InfoWindow(
            title: 'Selected Location',
            snippet: address), // Show address on tap
        icon: BitmapDescriptor.defaultMarker, // You can change the icon here
      ));
    });

    // Animate the map to the new location
    mapController
        ?.animateCamera(CameraUpdate.newLatLngZoom(LatLng(lat, lng), 14.0));
  }

  //search from (source location)
  Future<void> _handlePressButtonsourselocation() async {
    Prediction? p = await PlacesAutocomplete.show(
      context: context,
      apiKey: kGoogleApiKey,
      // onError: onError,
      // mode: _mode,
      language: 'en',
      strictbounds: false,
      types: [""],
      decoration: InputDecoration(
        hintText: 'Search',
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(color: Colors.white),
        ),
      ),
      components: [
        Component(Component.country, "in"), // Restrict to India
      ],
    );

    if (p != null) {
      displayPredictionsourselocation(p, homeScaffoldKey.currentState);
    }
  }

  Future<void> displayPredictionsourselocation(
      Prediction p, ScaffoldState? currentState) async {
    GoogleMapsPlaces places = GoogleMapsPlaces(
      apiKey: kGoogleApiKey,
      apiHeaders: await const GoogleApiHeaders()
          .getHeaders(), // Make sure this header is valid
    );

    // Fetch place details using the place ID
    PlacesDetailsResponse detail = await places.getDetailsByPlaceId(p.placeId!);

    // Extract latitude and longitude
    final lat = detail.result.geometry!.location.lat;
    final lng = detail.result.geometry!.location.lng;

    // Extract the full address
    final address = detail.result.formattedAddress;
    _initialPosition = LatLng(lat, lng);

    // Print the details
    print("lat sourse= $lat");
    print("lng sourse= $lng");
    print("Address sourse= $address");
    setState(() {
      currentAddress = address; // Set the address
    });

    // Clear existing markers and add a new one

    /*mapController
        ?.animateCamera(CameraUpdate.newLatLngZoom(LatLng(lat, lng), 14.0));*/
  }

/*
  void onError(PlacesAutocompleteResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      elevation: 0,
      behavior: SnackBarBehavior.floating,
      backgroundColor: Colors.transparent,
      content: AwesomeSnackbarContent(
        title: 'Message',
        message: response.errorMessage!,
        contentType: ContentType.failure,
      ),
    ));
*/

  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text('Set Location'),
      ),
      body: Stack(
        children: [
          GoogleMap(
            myLocationEnabled: true,
            initialCameraPosition: CameraPosition(
              target: _initialPosition,
              zoom: 14,
            ),
            onMapCreated: (controller) {
              mapController = controller;
            },
            onTap: _onMapTapped,
            // Handle map taps
            markers: _markers, // Show the markers on the map
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Expanded(
                child: Container(
                  height: 45.h,
                  // margin: const EdgeInsets.all(8.0),
                  child: InkWell(
                    onTap: _handlePressButtonsourselocation,
                    borderRadius: BorderRadius.circular(7),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white, // Button background color
                       // borderRadius: BorderRadius.circular(7),
                      ),
                      alignment: Alignment.center,
                      child: Center(
                        child:  Text(
                          "Search Start Location",
                          style: TextStyle(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.black, // Text color
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // Destination Button
              Expanded(
                child: Container(
                  height: 45.h,
                  //margin: const EdgeInsets.all(8.0),
                  child: InkWell(
                    onTap: _handlePressButton,
                    borderRadius: BorderRadius.circular(7),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white, // Button background color
                        //borderRadius: BorderRadius.circular(7),
                      ),
                      alignment: Alignment.center,
                      child:  Text(
                        "Search Destination",
                        style: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.black, // Text color
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          DraggableScrollableSheet(
            initialChildSize: 0.4,
            minChildSize: 0.4,
            maxChildSize: 0.8,
            builder: (context, scrollController) {
              return Container(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                child: SingleChildScrollView(
                  controller: scrollController,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 40,
                          height: 4,
                          color: Colors.grey[400],
                        ),
                      ),
                      SizedBox(height: 16),
                      Center(
                        child: Text(
                          'Select Address',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                      LocationSelectionRow(
                        //label: 'Current Location',
                        label: currentAddress ?? "current Location",
                        icon: Icons.my_location,
                        iconColor: Colors.blue,
                        backgroundColor: Colors.blue[50]!,
                        onTap: () {
                          print("Current Location tapped"); // Debugging log
                          WidgetsBinding.instance.addPostFrameCallback((_) {
                            /*   Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => MapScreen()),
                            );*/
                            _getCurrentLocation();
                          });
                        },
                      ),
                      LocationSelectionRow(
                        // label: 'Destination',
                        label: destinationAddress ??
                            "Tap on the map to select a location",
                        icon: Icons.add,
                        iconColor: Colors.grey,
                        backgroundColor: Colors.grey[300]!,
                        onTap: () {
                          // Define what happens when the Destination row is tapped
                          print("Destination tapped");
                        },
                      ),
                      SizedBox(height: 16),
                      Text(
                        'Recent Places',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                      if (isLoading)
                        Center(child: CircularProgressIndicator())
                      else if (recentPlaces.isEmpty)
                        Center(child: Text("No recent places found."))
                      else
                        Column(
                          children: recentPlaces.asMap().entries.map((entry) {
                            final index = entry.key;
                            final place = entry.value;
                            return PlaceListItem(
                              placeName:
                                  place['BookingToName'] ?? 'Unknown Place',
                              address: place['BookingToAddress'] ??
                                  'No address available',
                              distance: '${place['distance']} km',
                              isSaved: savedPlaceIds.contains(index),
                              onSave: () {
                                savePlace(
                                  place['BookingToLatitude'].toString(),
                                  place['BookingToLongitude'].toString(),
                                  place['BookingToName'] ?? 'Unknown Place',
                                  place['BookingToAddress'] ??
                                      'No address available',
                                  index,
                                );
                              },
                              onTap: () async {
                                // Handle the click event to get the place details
                                final latitude = place['BookingToLatitude']
                                        is double
                                    ? place[
                                        'BookingToLatitude'] // If it's already a double, use it directly
                                    : double.tryParse(place['BookingToLatitude']
                                            .toString()) ??
                                        0.0; // Convert to double if it's not, default to 0.0 if parsing fails

                                final longitude = place['BookingToLongitude']
                                        is double
                                    ? place[
                                        'BookingToLongitude'] // If it's already a double, use it directly
                                    : double.tryParse(
                                            place['BookingToLongitude']
                                                .toString()) ??
                                        0.0; // Convert to double if it's not, default to 0.0 if parsing fails

                                final BookingToAddress =
                                    place['BookingToName'] +
                                        ", " +
                                        (place['BookingToAddress'] ??
                                            'No Address');
                                final placeName =
                                    place['BookingToName'] ?? 'Unknown Place';

                                // Print the clicked place details
                                print(
                                    'Clicked Place: $placeName, Latitude: $latitude, Longitude: $longitude');

                                // Get SharedPreferences instance
                                final prefs =
                                    await SharedPreferences.getInstance();

                                // Save values to SharedPreferences
                                await prefs.setDouble(
                                    'destination_lat', latitude);
                                await prefs.setDouble(
                                    'destination_lng', longitude);
                                await prefs.setString(
                                    'destination_address', BookingToAddress);

                                //     destinationAddress = BookingToAddress;
                                setState(() {
                                  destinationAddress = BookingToAddress;
                                });
                                listClick = "clicked";
                                print("success...");

                                // Perform any additional actions, such as navigation or updating UI
                              },
                            );
                          }).toList(),
                        ),
                      ListTile(
                        leading: Icon(
                          FontAwesomeIcons.bookmark,
                          color: Colors.blue,
                        ),
                        title: Text(
                          'Saved Places',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        trailing: Icon(Icons.arrow_forward_ios, size: 16),
                        onTap: () {
                          showSavedPlacesBottomSheet(context);
                          fetchsavedPlaces();
                        },
                      ),
                      Padding(
                        // New button
                        padding: const EdgeInsets.symmetric(horizontal: 15.0),
                        child: SizedBox(
                          width: double.infinity,
                          height:
                              50, // Adjust the height to fit your preference
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFF4181FF), Color(0xFF274E99)],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(15.0),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 10,
                                  offset: Offset(0, 5),
                                ),
                              ],
                            ),
                            child: ElevatedButton(
                              onPressed: () async {
                                if (currentAddress == null ||
                                    currentAddress!.isEmpty) {
                                  // Show error if locations are not valid
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text(
                                            "Please select current locations")),
                                  );
                                  return; // Exit early if locations are invalid
                                }

                                if (_initialPosition == null ||
                                    destinationAddress == null ||
                                    destinationAddress!.isEmpty ||
                                    _markers.isEmpty) {
                                  // Show error if locations are not valid

                                  if (listClick == "clicked" &&
                                      destinationAddress != null) {
                                    // Save current location and destination location to SharedPreferences
                                    final prefs =
                                        await SharedPreferences.getInstance();

                                    // Save current location
                                    await prefs.setDouble('current_lat',
                                        _initialPosition.latitude);
                                    await prefs.setDouble('current_lng',
                                        _initialPosition.longitude);
                                    await prefs.setString('current_address',
                                        currentAddress ?? "Unknown");
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => MapScreen()),
                                    );
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                          content: Text(
                                              "Please select both current and destination locations")),
                                    );
                                  }

                                  return; // Exit early if locations are invalid
                                }

                                // Save current location and destination location to SharedPreferences
                                final prefs =
                                    await SharedPreferences.getInstance();

                                // Save current location
                                await prefs.setDouble(
                                    'current_lat', _initialPosition.latitude);
                                await prefs.setDouble(
                                    'current_lng', _initialPosition.longitude);
                                await prefs.setString('current_address',
                                    currentAddress ?? "Unknown");

                                // Save destination location if available
                                if (_markers.isNotEmpty && listClick.isEmpty) {
                                  final marker = _markers.first;
                                  await prefs.setDouble('destination_lat',
                                      marker.position.latitude);
                                  await prefs.setDouble('destination_lng',
                                      marker.position.longitude);
                                  await prefs.setString('destination_address',
                                      marker.infoWindow.snippet ?? "Unknown");
                                }

                                // Optionally, navigate to the next screen

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => MapScreen()),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                shadowColor: Colors.transparent,
                                padding: EdgeInsets.symmetric(
                                    vertical: 10.0), // Vertical padding
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                              ),
                              child: Text(
                                'Continue',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontFamily: 'Poppins-SemiBold',
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  //SavedPlacesBottomSheet:
  void showSavedPlacesBottomSheet(BuildContext context) {
    if (savedPlaces.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("No saved places available")),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
      ),
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      // Set background to transparent
      builder: (BuildContext context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.5, // Start at half screen height
          minChildSize: 0.3, // Minimum size when collapsed
          maxChildSize: 0.9, // Maximum size when expanded
          builder: (BuildContext context, ScrollController scrollController) {
            return Container(
              decoration: BoxDecoration(
                color: Colors.white, // Content background color
                borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16.0, vertical: 10.0),
                child: Column(
                  children: [
                    // Top draggable indicator
                    Container(
                      width: 50,
                      height: 5,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Saved Places',
                      style: TextStyle(
                        fontSize: 18,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: 20),
                    Expanded(
                      child: ListView.builder(
                        controller:
                            scrollController, // Attach scroll controller
                        itemCount: savedPlaces.length,
                        itemBuilder: (context, index) {
                          final place = savedPlaces[index];
                          return ListTile(
                            leading:
                                Icon(Icons.bookmark, color: Color(0xFF4181FF)),
                            title: Text(
                              place['SLTitle'] ?? "No Title",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Text(
                              place['SLAddress'] ?? "No Address",
                              style: TextStyle(color: Colors.grey[600]),
                            ),
                            trailing: Text(
                              "${place['distance']} km",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            contentPadding: EdgeInsets.symmetric(vertical: 8.0),
                            onTap: () {
                              // Perform actions like navigation or setting location
                              print("Tapped on: ${place['SLTitle']}");
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class LocationSelectionRow extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color iconColor;
  final Color backgroundColor;
  final VoidCallback onTap;

  LocationSelectionRow({
    required this.label,
    required this.icon,
    required this.iconColor,
    required this.backgroundColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Column(
            children: [
              Icon(icon, color: iconColor),
              SizedBox(height: 8),
              Container(
                width: 2,
                height: 32,
                color: Colors.grey[300],
              ),
              SizedBox(height: 8),
            ],
          ),
          SizedBox(width: 10),
          Expanded(
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: backgroundColor,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: iconColor),
              ),
              child: Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceBetween, // Pushes icon to the right
                children: [
                  // Wrap Text in Flexible to handle long labels
                  Flexible(
                    child: Text(
                      label,
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black54,
                      ),
                      overflow: TextOverflow.ellipsis, // Prevents overflow
                      maxLines: 1, // Restricts to a single line
                    ),
                  ),
                  SizedBox(width: 8), // Add space between text and icon
                  Icon(icon,
                      color: iconColor), // Icon at the rightmost position
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PlaceListItem extends StatelessWidget {
  final String placeName;
  final String address;
  final String distance;
  final bool isSaved;
  final VoidCallback onSave;
  final VoidCallback? onTap; // Add an onTap parameter

  // Modify the constructor to accept the onTap callback
  PlaceListItem({
    required this.placeName,
    required this.address,
    required this.distance,
    required this.isSaved,
    required this.onSave,
    this.onTap, // Make it optional
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      // Wrap the ListTile with GestureDetector to detect taps
      onTap: onTap, // Trigger onTap callback when the item is tapped
      child: ListTile(
        leading: Icon(FontAwesomeIcons.clock, color: Colors.grey),
        title: Text(
          placeName,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          address,
          style: TextStyle(
            fontSize: 13,
            color: Color(0xFFBDBDBD),
            fontWeight: FontWeight.w500,
          ),
        ),
        trailing: IconButton(
          icon: Icon(
            FontAwesomeIcons.bookmark,
            color: isSaved ? Colors.blue : Colors.black,
          ),
          onPressed: onSave,
        ),
      ),
    );
  }
}
