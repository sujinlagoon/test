import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertickect365/core/app_export.dart';
import 'package:fluttertickect365/presentation/map_location/SetLocationScreen.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../car/SelectCarScreen.dart';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  late GoogleMapController mapController;
  Set<Polyline> _polylines = {}; // Set to store polyline routes
  Set<Marker> _markers = {}; // Set to store markers for start and end points
  String distanceText = "";
  String durationText = "";

  String? carname;
  String? vtId;
  String? carprice;
  String? current_address;
  String? destination_address;
  String? fromename;
  String? fromaddress;
  String? toname;
  String? toaddress;
  String? bookingID;
  late double currentLat;
  late double currentLatcar;
  late double currentLng;
  late double currentLngcar;
  late double destinationLat;
  late double destinationLng;

  BitmapDescriptor? movingMarkerIcon;
  late Timer _timer;

  final CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(8.189653, 77.401716), // Coordinates for the initial position
    zoom: 12.0,
  );

  @override
  void initState() {
    super.initState();
    _loadSharedPreferences();

    //_loadCustomMarker();
    // _startMovingMarker();
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  // Load SharedPreferences asynchronously
  Future<void> _loadSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentLat = prefs.getDouble('current_lat') ?? 0.0;
      currentLng = prefs.getDouble('current_lng') ?? 0.0;
      destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
      destinationLng = prefs.getDouble('destination_lng') ?? 0.0;
      carname = prefs.getString('carname');
      vtId = prefs.getString('vtId');
      carprice = prefs.getString('carprice');
      current_address = prefs.getString('current_address');
      destination_address = prefs.getString('destination_address');

      Map<String, String> addressParts = splitAddress(current_address!);
      Map<String, String> addressPartsto = splitAddressto(destination_address!);
      fromename = addressParts["mainAddress"];
      fromaddress = addressParts["secondaryAddress"];

      toname = addressPartsto["mainAddress"];
      toaddress = addressPartsto["secondaryAddress"];

      // Fetch the route and draw the polyline
      _getDirections();
    });
  }

  void _loadCustomMarker() async {
    movingMarkerIcon = await BitmapDescriptor.fromAssetImage(
      ImageConfiguration(size: Size(48, 48)),
      'assets/images/car_icon.png', // Path to your custom icon
    );
    setState(() {});

    print("in.....");
  }

  void _startMovingMarker() {
    print("in2.....");

    const updateInterval = Duration(seconds: 1);
    double stepLat = (destinationLat - currentLat) / 100;
    double stepLng = (destinationLng - currentLng) / 100;

    _timer = Timer.periodic(updateInterval, (timer) {
      setState(() {
        currentLat += stepLat;
        currentLng += stepLng;

        // Stop timer when destination is reached
        if ((currentLat - destinationLat).abs() < 0.0001 &&
            (currentLng - destinationLng).abs() < 0.0001) {
          _timer.cancel();
        }

        // Update the marker position
        _markers.removeWhere((m) => m.markerId == MarkerId("moving"));
        _markers.add(
          Marker(
            markerId: MarkerId("moving"),
            position: LatLng(currentLat, currentLng),
            icon: movingMarkerIcon ?? BitmapDescriptor.defaultMarker,
            infoWindow: InfoWindow(title: "Moving Vehicle"),
          ),
        );
      });
      print("good.....");
    });
  }

  Map<String, String> splitAddress(String fullAddress) {
    List<String> addressParts = fullAddress.split(', ');
    String mainAddress =
        addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
    String secondaryAddress =
        addressParts.length > 1 ? addressParts.sublist(1).join(', ') : "";
    return {
      "mainAddress": mainAddress,
      "secondaryAddress": secondaryAddress,
    };
  }

  Map<String, String> splitAddressto(String fullAddress) {
    List<String> addressParts = fullAddress.split(', ');
    String mainAddress =
        addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
    String secondaryAddress =
        addressParts.length > 1 ? addressParts.sublist(1).join(', ') : "";
    return {
      "mainAddress": mainAddress,
      "secondaryAddress": secondaryAddress,
    };
  }

//covert date time formate":
  String convertDurationToHHMMSS(String duration) {
    // Initialize hours, minutes, and seconds
    int hours = 0;
    int minutes = 0;
    int seconds = 0;

    // Parse the input string
    if (duration.contains("hour") || duration.contains("hours")) {
      RegExp hoursRegex = RegExp(r'(\d+)\s*hour');
      Match? match = hoursRegex.firstMatch(duration);
      if (match != null) {
        hours = int.parse(match.group(1)!);
      }
    }

    if (duration.contains("min")) {
      RegExp minutesRegex = RegExp(r'(\d+)\s*min');
      Match? match = minutesRegex.firstMatch(duration);
      if (match != null) {
        minutes = int.parse(match.group(1)!);
      }
    }

    // Calculate total seconds
    seconds = (hours * 3600) + (minutes * 60);

    // Format to HH:MM:SS
    final formattedDuration = Duration(seconds: seconds);
    String hh = formattedDuration.inHours.toString().padLeft(2, '0');
    String mm = (formattedDuration.inMinutes % 60).toString().padLeft(2, '0');
    String ss = (formattedDuration.inSeconds % 60).toString().padLeft(2, '0');

    return "$hh:$mm:$ss";
  }

  String extractDistanceAsString(String distance) {
    // Use a regular expression to find the numeric part of the distance string
    RegExp regex = RegExp(r'[\d.]+');
    Match? match = regex.firstMatch(distance);

    // If a match is found, return it as a string; otherwise, return "0.0"
    return match != null ? match.group(0)! : "0.0";
  }

  //sharepref
  Future<void> saveDistanceAndDuration(String distance, String duration) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('saved_distance', distance);
    await prefs.setString('saved_duration', duration);
    print('Distance and duration saved successfully.');
  }

  Future<void> savetimeText(String durationText) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('timeText', durationText);
    print('Duration Text saved: $durationText');
  }

//polyen line:
  Future<void> _getDirections() async {
    String url =
        "https://maps.googleapis.com/maps/api/directions/json?origin=$currentLat,$currentLng&destination=$destinationLat,$destinationLng&key=AIzaSyBP5GUxTHqath5-maur0OZIUOf81dgZlTM";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      List<LatLng> polylineCoordinates = [];

      if (data['routes'].isNotEmpty) {
        var route = data['routes'][0]['legs'][0];

        // Get distance and duration
        String distance = route['distance']['text']; // e.g., '4.5 km'
        String duration = route['duration']['text']; // e.g., '10 mins'

        // Set the distance and duration in the UI
        setState(() {
          // Update the UI with distance and duration

          String dis = extractDistanceAsString(distance);
          String due = convertDurationToHHMMSS(duration);
          saveDistanceAndDuration(
              dis, due); //to set the value in api call for search_Driver

          distanceText = distance;
          durationText = duration;
          savetimeText(
              durationText); //to set the value in time of SelectCarScreen page

          print("distanceText = " + distanceText);
          print("durationText = " + durationText);

          var steps = route['steps'];
          for (var step in steps) {
            String encodedPolyline = step['polyline']['points'];
            polylineCoordinates.addAll(_decodePolyline(encodedPolyline));
          }

          // Add polyline and markers as usual
          _polylines.add(
            Polyline(
              polylineId: PolylineId("route"),
              color: Color(0xFF4181FF),
              width: 5,
              points: polylineCoordinates,
            ),
          );

          // Add markers for start and destination points
          _markers.add(
            Marker(
              markerId: MarkerId("start"),
              position: LatLng(currentLat, currentLng),
              infoWindow: InfoWindow(title: "Start Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueRed),
            ),
          );

          _markers.add(
            Marker(
              markerId: MarkerId("end"),
              position: LatLng(destinationLat, destinationLng),
              infoWindow: InfoWindow(title: "Destination Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueGreen),
            ),
          );
        });
      }
    } else {
      print('Failed to load directions');
    }
  }

  // Function to decode polyline points from the Directions API response
  List<LatLng> _decodePolyline(String encodedPolyline) {
    List<LatLng> polyline = [];
    int index = 0;
    int len = encodedPolyline.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int shift = 0;
      int result = 0;
      int byte;

      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lat += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      shift = 0;
      result = 0;
      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lng += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      polyline.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return polyline;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: GoogleMap(
              initialCameraPosition: _initialCameraPosition,
              mapType: MapType.normal,
              onMapCreated: (GoogleMapController controller) {
                mapController = controller;
              },
              polylines: _polylines, // Display the polyline
              markers: _markers, // Display the markers
              zoomControlsEnabled: true, // Allow zoom controls
            ),
          ),
          Positioned(
            top: 40,
            left: 16,
            child: CircleAvatar(
              backgroundColor: Colors.white,
              child: IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10.0,
                    spreadRadius: 5.0,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 15),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Distance',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                          color: Colors.black,
                        ),
                      ),
                      Text(
                        distanceText,
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15),
                  Divider(
                    thickness: 1.0,
                    height: 10.0,
                    color: Colors.grey,
                  ),
                  ListTile(
                    leading: SvgPicture.asset(
                      ImageConstant.bluedot,
                      height: 30.0,
                      width: 30.0,
                    ),
                    title: Text(fromename ?? "Current Location"),
                    subtitle: Text(fromaddress ?? "Current Location"),
                    trailing: InkWell(
                      onTap: () {
                        print('Start location edit clicked!');
                        /*  Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SetLocationScreen(),
                          ),
                        );*/

                        Navigator.pop(context);
                      },
                      child: SvgPicture.asset(
                        ImageConstant.liteblueedit,
                        height: 30.0,
                        width: 30.0,
                      ),
                    ),
                  ),
                  ListTile(
                    leading: SvgPicture.asset(
                      ImageConstant.bluelocation,
                      height: 30.0,
                      width: 30.0,
                    ),
                    title: Text(toname ?? "Destination Location"),
                    subtitle: Text(toaddress ?? "Destination Location"),
                    trailing: InkWell(
                      onTap: () {
                        print('Destination location edit clicked!');
                        /*    Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SetLocationScreen(),
                          ),
                        );*/
                        Navigator.pop(context);
                      },
                      child: SvgPicture.asset(
                        ImageConstant.liteblueedit,
                        height: 30.0,
                        width: 30.0,
                      ),
                    ),
                  ),
                  SizedBox(height: 15),
                  buildUpdateButton(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildUpdateButton() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 70.0),
      child: CustomElevatedButton(
        text: "Search",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => SelectCarScreen()),
          );
        },
      ),
    );
  }
}

/*import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertickect365/core/app_export.dart';
import 'package:fluttertickect365/presentation/map_location/SetLocationScreen.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../car/SelectCarScreen.dart';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  late GoogleMapController mapController;

  final LatLng _startLocation = LatLng(37.7749, -122.4194); // starting point
  final LatLng _endLocation = LatLng(37.7749, -122.4094); // ending point
  String? carname;
  String? vtId;
  String? carprice;
  String? current_address;
  String? destination_address;
  String? fromename;
  String? fromaddress;
  String? toname;
  String? toaddress;
  String? bookingID;
  late double currentLat;
  late double currentLng;
  late double destinationLat;
  late double destinationLng;

  // List of LatLng for the polygon
  Set<Polygon> _polygons = {};

  @override
  void initState() {
    super.initState();
    _loadSharedPreferences();
  }

  final CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(8.189653, 77.401716), // Coordinates for the initial position
    zoom: 12.0,
  );

  // Load SharedPreferences asynchronously
  Future<void> _loadSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentLat = prefs.getDouble('current_lat') ?? 0.0;
      currentLng = prefs.getDouble('current_lng') ?? 0.0;
      destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
      destinationLng = prefs.getDouble('destination_lng') ?? 0.0;
      carname = prefs.getString('carname');
      vtId = prefs.getString('vtId');
      carprice = prefs.getString('carprice');
      current_address = prefs.getString('current_address');
      destination_address = prefs.getString('destination_address');

      Map<String, String> addressParts = splitAddress(current_address!);
      Map<String, String> addressPartsto = splitAddressto(destination_address!);
      fromename = addressParts["mainAddress"];
      fromaddress = addressParts["secondaryAddress"];

      toname = addressPartsto["mainAddress"];
      toaddress = addressPartsto["secondaryAddress"];

      // Initialize the polygon
      _polygons.add(Polygon(
        polygonId: PolygonId('route'),
        points: [
          LatLng(currentLat, currentLng),
          LatLng(destinationLat, destinationLng),
        ],
        strokeColor: Colors.blue,
        strokeWidth: 3,
        fillColor: Colors.blue.withOpacity(0.2),
      ));
    });
  }

  Map<String, String> splitAddress(String fullAddress) {
    // Split the address by the first comma
    List<String> addressParts = fullAddress.split(', ');

    // Extract the main and secondary parts
    String mainAddress =
        addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
    String secondaryAddress = addressParts.length > 1
        ? addressParts
            .sublist(1)
            .join(', ') // Join the remaining parts with commas
        : "";

    return {
      "mainAddress": mainAddress,
      "secondaryAddress": secondaryAddress,
    };
  }

  Map<String, String> splitAddressto(String fullAddress) {
    // Split the address by the first comma
    List<String> addressParts = fullAddress.split(', ');

    // Extract the main and secondary parts
    String mainAddress =
        addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
    String secondaryAddress = addressParts.length > 1
        ? addressParts
            .sublist(1)
            .join(', ') // Join the remaining parts with commas
        : "";

    return {
      "mainAddress": mainAddress,
      "secondaryAddress": secondaryAddress,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Google Map
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: GoogleMap(
              initialCameraPosition: _initialCameraPosition,
              mapType: MapType.normal,
              onMapCreated: (GoogleMapController controller) {
                mapController = controller;
              },
              polygons: _polygons, // Set the polygons on the map
            ),
          ),
          // Back Button
          Positioned(
            top: 40,
            left: 16,
            child: CircleAvatar(
              backgroundColor: Colors.white,
              child: IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ),
          // Bottom Container
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10.0,
                    spreadRadius: 5.0,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 15.h),
                  // Distance Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Distance',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                          color: Colors.black,
                        ),
                      ),
                      Text(
                        '4.5 km',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15.h),
                  Divider(
                    thickness: 1.0, // Divider thickness
                    height: 10.0, // Space around the divider
                    color: Colors.grey,
                  ),
                  // Starting Location
                  ListTile(
                    leading: SvgPicture.asset(
                      ImageConstant.bluedot, // Your SVG asset path
                      height: 30.0,
                      width: 30.0,
                    ),
                    title: Text(fromename ?? "Current Location"),
                    subtitle: Text(fromaddress ?? "Current Location"),
                    trailing: InkWell(
                      onTap: () {
                        // Action for starting location edit button
                        print('Start location edit clicked!');
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SetLocationScreen()),
                        );
                      },
                      child: SvgPicture.asset(
                        ImageConstant.liteblueedit, // Your SVG asset path
                        height: 30.0,
                        width: 30.0,
                      ),
                    ),
                  ),
                  // Destination Location
                  ListTile(
                    leading: SvgPicture.asset(
                      ImageConstant.bluelocation, // Your SVG asset path
                      height: 30.0,
                      width: 30.0,
                    ),
                    title: Text(toname ?? "Current Location"),
                    subtitle: Text(toaddress ?? "Current Location"),
                    trailing: InkWell(
                      onTap: () {
                        // Action for destination location edit button
                        print('Destination location edit clicked!');

                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SetLocationScreen()),
                        );
                      },
                      child: SvgPicture.asset(
                        ImageConstant.liteblueedit, // Your SVG asset path
                        height: 30.0,
                        width: 30.0,
                      ),
                    ),
                  ),
                  SizedBox(height: 15.h),
                  // Update Button
                  buildUpdateButton(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildUpdateButton() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 70.0), // Horizontal margin only,
      child: CustomElevatedButton(
        text: "search",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Handle continue button action

          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => SelectCarScreen()),
          );
        },
      ),
    );
  }
}*/

/*import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertickect365/core/app_export.dart';
import 'package:fluttertickect365/presentation/map_location/SetLocationScreen.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../car/SelectCarScreen.dart';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  late GoogleMapController mapController;

  final LatLng _startLocation = LatLng(37.7749, -122.4194); // starting point
  final LatLng _endLocation = LatLng(37.7749, -122.4094); // ending point
  String? carname;
  String? vtId;
  String? carprice;
  String? current_address;
  String? destination_address;
  String? fromename;
  String? fromaddress;
  String? toname;
  String? toaddress;
  String? bookingID;
  late double currentLat;
  late double currentLng;
  late double destinationLat;
  late double destinationLng;

  @override
  void initState() {
    super.initState();
    _loadSharedPreferences();
  }

  final CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(8.189653, 77.401716), // Coordinates for the initial position
    zoom: 12.0,
  );

  // Load SharedPreferences asynchronously
  Future<void> _loadSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentLat = prefs.getDouble('current_lat') ?? 0.0;
      currentLng = prefs.getDouble('current_lng') ?? 0.0;
      destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
      destinationLng = prefs.getDouble('destination_lng') ?? 0.0;
      carname = prefs.getString('carname');
      vtId = prefs.getString('vtId');
      carprice = prefs.getString('carprice');
      current_address = prefs.getString('current_address');
      destination_address = prefs.getString('destination_address');

      Map<String, String> addressParts = splitAddress(current_address!);
      Map<String, String> addressPartsto = splitAddressto(destination_address!);
      fromename = addressParts["mainAddress"];
      fromaddress = addressParts["secondaryAddress"];

      toname = addressPartsto["mainAddress"];
      toaddress = addressPartsto["secondaryAddress"];
    });
  }

  Map<String, String> splitAddress(String fullAddress) {
    // Split the address by the first comma
    List<String> addressParts = fullAddress.split(', ');

    // Extract the main and secondary parts
    String mainAddress =
        addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
    String secondaryAddress = addressParts.length > 1
        ? addressParts
            .sublist(1)
            .join(', ') // Join the remaining parts with commas
        : "";

    return {
      "mainAddress": mainAddress,
      "secondaryAddress": secondaryAddress,
    };
  }

  Map<String, String> splitAddressto(String fullAddress) {
    // Split the address by the first comma
    List<String> addressParts = fullAddress.split(', ');

    // Extract the main and secondary parts
    String mainAddress =
        addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
    String secondaryAddress = addressParts.length > 1
        ? addressParts
            .sublist(1)
            .join(', ') // Join the remaining parts with commas
        : "";

    return {
      "mainAddress": mainAddress,
      "secondaryAddress": secondaryAddress,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Google Map
          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: GoogleMap(
              initialCameraPosition: _initialCameraPosition,
              mapType: MapType.normal,
              onMapCreated: (GoogleMapController controller) {
                // Store the controller for later use if needed
                mapController = controller;
              },
            ),
          ),
          // Back Button
          Positioned(
            top: 40,
            left: 16,
            child: CircleAvatar(
              backgroundColor: Colors.white,
              child: IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ),
          // Bottom Container
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10.0,
                    spreadRadius: 5.0,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 15.h),
                  // Distance Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Distance',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                          color: Colors.black,
                        ),
                      ),
                      Text(
                        '4.5 km',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15.h),
                  Divider(
                    thickness: 1.0, // Divider thickness
                    height: 10.0, // Space around the divider
                    color: Colors.grey,
                  ),
                  // Starting Location
                  ListTile(
                    leading: SvgPicture.asset(
                      ImageConstant.bluedot, // Your SVG asset path
                      height: 30.0,
                      width: 30.0,
                    ),
                    title: Text(fromename ?? "Current Location"),
                    subtitle: Text(fromaddress ?? "Current Location"),
                    trailing: InkWell(
                      onTap: () {
                        // Action for starting location edit button
                        print('Start location edit clicked!');
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SetLocationScreen()),
                        );
                      },
                      child: SvgPicture.asset(
                        ImageConstant.liteblueedit, // Your SVG asset path
                        height: 30.0,
                        width: 30.0,
                      ),
                    ),
                  ),
                  // Destination Location
                  ListTile(
                    leading: SvgPicture.asset(
                      ImageConstant.bluelocation, // Your SVG asset path
                      height: 30.0,
                      width: 30.0,
                    ),
                    title: Text(toname ?? "Current Location"),
                    subtitle: Text(toaddress ?? "Current Location"),
                    trailing: InkWell(
                      onTap: () {
                        // Action for destination location edit button
                        print('Destination location edit clicked!');

                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SetLocationScreen()),
                        );
                      },
                      child: SvgPicture.asset(
                        ImageConstant.liteblueedit, // Your SVG asset path
                        height: 30.0,
                        width: 30.0,
                      ),
                    ),
                  ),
                  SizedBox(height: 15.h),
                  // Update Button
                  buildUpdateButton(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildUpdateButton() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 70.0), // Horizontal margin only,
      child: CustomElevatedButton(
        text: "search",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Handle continue button action

          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => SelectCarScreen()),
          );
        },
      ),
    );
  }
}*/

/*  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //    appBar: AppBar(
      //   title: Text("Map View"),
      // ),
      body: Stack(
        children: [
          //    GoogleMap(
          //   initialCameraPosition: CameraPosition(
          //     target: _startLocation,
          //     zoom: 14,
          //   ),
          //   markers: {
          //     Marker(
          //       markerId: MarkerId("start"),
          //       position: _startLocation,
          //       icon: BitmapDescriptor.defaultMarkerWithHue(
          //           BitmapDescriptor.hueGreen),
          //     ),
          //     Marker(
          //       markerId: MarkerId("end"),
          //       position: _endLocation,
          //       //icon: BitmapDescriptor.defaultMarkerWithHue(
          //       //BitmapDescriptor.hueBlack),
          //       icon: BitmapDescriptor.defaultMarkerWithHue(
          //           BitmapDescriptor.hueGreen),
          //     ),
          //   },
          //   polylines: {
          //     Polyline(
          //       polylineId: PolylineId("route"),
          //       points: [_startLocation, _endLocation],
          //       color: Colors.blue,
          //       width: 5,
          //     ),
          //   },
          //   onMapCreated: (controller) {
          //     mapController = controller;
          //   },
          // ),

          Padding(
            padding: const EdgeInsets.only(top: 5),
            child: GoogleMap(
              initialCameraPosition: _initialCameraPosition,
              mapType: MapType.normal,
              onMapCreated: (GoogleMapController controller) {
                // You can store the controller for later use if needed
              },
            ),
          ),
          Positioned(
            top: 40,
            left: 16,
            child: CircleAvatar(
              backgroundColor: Colors.white,
              child: IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10.0,
                    spreadRadius: 5.0,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(height: 15.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Distance',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                          color: Colors.black,
                        ),
                      ),
                      Text(
                        '4.5 km',
                        style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                            color: Colors.black),
                      ),
                    ],
                  ),
                  SizedBox(height: 15.h),
                  Divider(
                    thickness: 1.0, // Adjusts the thickness of the line
                    height: 10.0, // Adjusts the space around the divider
                    color: Colors.grey, // Change the color if needed
                  ),
                  ListTile(
                    leading: SvgPicture.asset(
                      ImageConstant.bluedot, // Your SVG asset path
                      height: 30.0,
                      width: 30.0,
                    ),
                    // title: Text('Pothys, Nagercoil'),
                    title: Text(fromename ?? "Current Location"),
                    subtitle: Text(fromaddress ?? "Current Location"),
                    trailing: SvgPicture.asset(
                        ImageConstant.liteblueedit, // Your SVG asset path
                        height: 30.0,
                        width: 30.0),
                  ),
                  ListTile(
                    leading: SvgPicture.asset(
                      ImageConstant.bluelocation, // Your SVG asset path
                      height: 30.0,
                      width: 30.0,
                    ),
                    title: Text(toname ?? "Current Location"),
                    subtitle: Text(toaddress ?? "Current Location"),
                  //   trailing: SvgPicture.asset(
                  //       ImageConstant.liteblueedit, // Your SVG asset path
                  //       height: 30.0,
                  //       width: 30.0),
                  // ),
                    trailing: InkWell(
                      onTap: () {
                        // Your onTap action here
                        print('SVG clicked!');
                      },
                      child: SvgPicture.asset(
                        ImageConstant.liteblueedit, // Your SVG asset path
                        height: 30.0,
                        width: 30.0,
                      ),
                    ),


                    SizedBox(height: 8),


                  SizedBox(height: 15.h),
                  buildUpdateButton()
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}*/
