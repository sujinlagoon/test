import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/app_export.dart';
import '../../sujin_screen/Profile/profile__controller.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../Account_screen/AccountScreen.dart';
import '../BookingList/MyBookingPage.dart';
import '../Edit_profile/EditProfilePage.dart';
import '../chat/ChatScreen.dart'; // Import ChatScreen
import 'apiModel/HomePage.dart';
import 'cab_homepage_initial_page.dart';

/*
class CabHomepageScreen extends StatefulWidget {
  CabHomepageScreen({Key? key}) : super(key: key);

  @override
  _CabHomepageScreenState createState() => _CabHomepageScreenState();
}

class _CabHomepageScreenState extends State<CabHomepageScreen> {
  final PageController _pageController = PageController();
  int _currentIndex = 0;
  final ProfileController controller = Get.find<ProfileController>();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: PageView(
          controller: _pageController,
          onPageChanged: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          physics: NeverScrollableScrollPhysics(),
          children: [
            AppointmentView(),
            MyBookingPage(),
            AccountScreen(),
            //ChatScreen(),
          ],
        ),
        bottomNavigationBar: _currentIndex == 3 // Index of ChatScreen
            ? null
            : _buildBottomBar(context),
      ),
    );
  }

  /// Widget for Bottom Bar
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        final int index = getPageIndex(type);
        _pageController.jumpToPage(index);
      },
    );
  }

  /// Get page index based on bottom navigation selection
  int getPageIndex(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return 0;
      case BottomBarEnum.Bookings:
        return 1;
      case BottomBarEnum.Profile:
        return 2;
      default:
        return 0;
    }
  }
}*/
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'cab_homepage_initial_page.dart';

class CabHomepageScreen extends StatefulWidget {
  CabHomepageScreen({Key? key}) : super(key: key);

  @override
  _CabHomepageScreenState createState() => _CabHomepageScreenState();
}

class _CabHomepageScreenState extends State<CabHomepageScreen> {
  final PageController _pageController = PageController();
  int _currentIndex = 0;
  final ProfileController controller = Get.find<ProfileController>();

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_currentIndex == 1 || _currentIndex == 2) {
          setState(() {
            _currentIndex = 0;
          });
          _pageController.jumpToPage(0);
          return false; // Prevent app exit
        }
        return true; // Exit app
      },
      child: Scaffold(
        body: PageView(
          controller: _pageController,
          onPageChanged: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          physics: NeverScrollableScrollPhysics(),
          children: [
            AppointmentView(),
            MyBookingPage(),
            AccountScreen(),
          ],
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Widget for Bottom Bar
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      selectedIndex: _currentIndex,
      onChanged: (BottomBarEnum type) {
        final int index = getPageIndex(type);
        if (index != _currentIndex) {  // Prevent unnecessary updates
          setState(() {
            _currentIndex = index;
          });
          Future.delayed(Duration(milliseconds: 100), () {
            _pageController.jumpToPage(index);
          });
        }
      },
    );
  }

  /// Get page index based on bottom navigation selection
  int getPageIndex(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return 0;
      case BottomBarEnum.Bookings:
        return 1;
      case BottomBarEnum.Profile:
        return 2;
      default:
        return 0;
    }
  }
}
