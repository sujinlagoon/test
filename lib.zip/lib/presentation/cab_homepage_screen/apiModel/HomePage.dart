import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertickect365/core/app_export.dart';
import 'package:fluttertickect365/presentation/cab_homepage_screen/BusTabPage.dart';
import 'package:fluttertickect365/sujin_screen/Profile/profile__controller.dart';
import 'package:fluttertickect365/sujin_screen/Profile/profile_modal/profile_modal.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/utils/image_constant.dart';
import '../../../widgets/app_bar/appbar_subtitle.dart';
import '../../../widgets/app_bar/appbar_subtitle_one.dart';
import '../../../widgets/app_bar/custom_app_bar.dart';
import '../../Notification/NotificationPage.dart';
import '../CabTabPageState.dart';

class AppointmentView extends StatefulWidget {
  AppointmentView({super.key});

  @override
  State<AppointmentView> createState() => _AppointmentViewState();
}

class _AppointmentViewState extends State<AppointmentView>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    setloginstatus();
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        setState(() {});
      }
    });
    controller.getProfile();
  }

  Future<String?> getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('username');
  }

  Future<bool> setloginstatus() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setString(
        'login', 'yes'); // Returns a boolean indicating success
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  //ProfileController controller = Get.put(ProfileController());
  final ProfileController controller = Get.find<ProfileController>();
  DateTime? lastPressed;

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (lastPressed == null ||
            DateTime.now().difference(lastPressed!) > Duration(seconds: 2)) {
          lastPressed = DateTime.now();
          Fluttertoast.showToast(
            msg: "Press again to exit",
            toastLength: Toast.LENGTH_SHORT,
          );
          return Future.value(false);
        }
        return Future.value(true);
      },
      child: DefaultTabController(
        length: 2,
        child: GetBuilder<ProfileController>(builder: (v) {
          return Scaffold(
            body: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.center,
                  colors: [Color(0xFF2684FF), Colors.white],
                ),
              ),
              child: Column(
                children: [
                  SafeArea(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      child: AppBar(
                        automaticallyImplyLeading: false,
                        backgroundColor: Color(0xFF4D96F8),
                        title: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding:  EdgeInsets.all(7.r),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  /*  FutureBuilder<String?>(
                                      future: getUsername(),
                                      builder: (context, snapshot) {
                                        if (snapshot.connectionState ==
                                            ConnectionState.waiting) {
                                          return AppbarSubtitle(
                                            text: "Loading...",
                                            margin: EdgeInsets.only(right: 42),
                                          );
                                        } else if (snapshot.hasError) {
                                          return AppbarSubtitle(
                                            text: "Error",
                                            margin: EdgeInsets.only(right: 42),
                                          );
                                        } else if (snapshot.hasData) {
                                          return AppbarSubtitle(
                                            text: "Hello ${snapshot.data}",
                                            margin: EdgeInsets.only(right: 42),
                                          );
                                        } else {
                                          return AppbarSubtitle(
                                            text: LocalizationExtension("lbl_hello_guest").tr,
                                            margin: EdgeInsets.only(right: 42),
                                          );
                                        }
                                      },
                                    ),*/
                                  GetBuilder<ProfileController>(builder: (v) {
                                    return Text(
                                      v.profile != null &&
                                              v.profile!.data != null
                                          ? "Hello ${v.profile!.data!.userName}"
                                          : "Hello Guest",
                                      style: CustomTextStyles
                                          .titleMediumOnPrimary
                                          .copyWith(
                                        color: theme.colorScheme.onPrimary,
                                      ),
                                    );
                                  }),
                                  SizedBox(height: 2),
                                  AppbarSubtitleOne(
                                    text: LocalizationExtension(
                                            "msg_let_s_holiday_together")
                                        .tr,
                                  ),
                                ],
                              ),
                            ),
                            Spacer(),
                            GestureDetector(
                              onTap: () {
                                Get.to(() => NotificationPage());
                                /*     Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => NotificationPage(),
                                  ),
                                );*/
                              },
                              child: Padding(
                                padding: EdgeInsets.only(
                                    top: MediaQuery.sizeOf(context).height * 0.01,
                                    right: MediaQuery.sizeOf(context).width * 0.01,
                                    bottom: MediaQuery.sizeOf(context).height * 0.01
                                ),
                                child: SvgPicture.asset(
                                  ImageConstant.icon_notification,
                                  height: 27.h,
                                  width: 27.w,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 15.0),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: 60.0,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      child: TabBar(
                        controller: _tabController,
                        unselectedLabelColor: Colors.grey,
                        indicatorColor: Colors.blue,
                        dividerColor: Colors.transparent,
                        tabs: [
                          Tab(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                AnimatedBuilder(
                                  animation: _tabController.animation!,
                                  builder: (context, child) {
                                    return SvgPicture.asset(
                                      'assets/images/bus1.svg',
                                      width: 24.0,
                                      height: 24.0,
                                      color: _tabController.index == 0
                                          ? Colors.blue
                                          : Colors.grey,
                                    );
                                  },
                                ),
                                SizedBox(width: 8.0),
                                AnimatedBuilder(
                                  animation: _tabController.animation!,
                                  builder: (context, child) {
                                    return Text(
                                      "Buses",
                                      style: TextStyle(
                                          color: _tabController.index == 0
                                              ? Colors.blue
                                              : Colors.grey),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                          Tab(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                AnimatedBuilder(
                                  animation: _tabController.animation!,
                                  builder: (context, child) {
                                    return SvgPicture.asset(
                                      'assets/images/img_grey_taxi.svg',
                                      width: 24.0,
                                      height: 24.0,
                                      color: _tabController.index == 1
                                          ? Colors.blue
                                          : Colors.grey,
                                    );
                                  },
                                ),
                                SizedBox(width: 8.0),
                                AnimatedBuilder(
                                  animation: _tabController.animation!,
                                  builder: (context, child) {
                                    return Text(
                                      "Cab",
                                      style: TextStyle(
                                          color: _tabController.index == 1
                                              ? Colors.blue
                                              : Colors.grey),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        BusTabPage(),
                        CabTabPage(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}
