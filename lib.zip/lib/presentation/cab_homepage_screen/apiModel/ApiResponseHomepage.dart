class UpcomingTrip {
  final String bookingId;
  final String fromLocation;
  final String fromaddress;
  final String toaddress;
  final String toLocation;
  final String arriving_time;
  final String isBookingAccepted;
  final String BookingStatus;
  final String BookingFromLat;
  final String BookingFromLong;
  final String BookingToLat;
  final String BookingToLong;

  UpcomingTrip({
    required this.bookingId,
    required this.fromLocation,
    required this.toLocation,
    required this.fromaddress,
    required this.toaddress,
    required this.arriving_time,
    required this.isBookingAccepted,
    required this.BookingStatus,
    required this.BookingFromLat,
    required this.BookingFromLong,
    required this.BookingToLat,
    required this.BookingToLong,
  });

  factory UpcomingTrip.fromJson(Map<String, dynamic> json) {
    return UpcomingTrip(
      bookingId: json['booking_id'].toString(),
      fromLocation: json['BookingFromName'],
      toLocation: json['BookingToName'],
      fromaddress: json['BookingFromAddress'],
      toaddress: json['BookingToAddress'],
      arriving_time: json['arriving_time'],
      isBookingAccepted: json['isBookingAccepted'].toString(), // Convert int to String
      BookingStatus: json['BookingStatus'].toString(), // Convert int to String
      BookingFromLat: json['BookingFromLat'],
      BookingFromLong: json['BookingFromLong'],
      BookingToLat: json['BookingToLat'],
      BookingToLong: json['BookingToLong'],
    );
  }
}

class RecentTrip {
  final String bookingId;
  final String fromLocation;
  final String toLocation;

  RecentTrip({
    required this.bookingId,
    required this.fromLocation,
    required this.toLocation,
  });

  factory RecentTrip.fromJson(Map<String, dynamic> json) {
    return RecentTrip(
      bookingId: json['booking_id'],
      fromLocation: json['from_location'],
      toLocation: json['to_location'],
    );
  }
}

class Offer {
  final int offerID;
  final String offerName;
  final String?
      offerImage; // Make offerImage nullable to handle cases where it might be missing
  final String? offerDescription;
  final int offerCouponID;
  final int couponValue;

  Offer({
    required this.offerID,
    required this.offerName,
    this.offerImage, // This is now optional
    this.offerDescription,
    required this.offerCouponID,
    required this.couponValue,
  });

  factory Offer.fromJson(Map<String, dynamic> json) {
    return Offer(
      offerID: json['OfferID'],
      offerName: json['OfferName'],
      offerImage:
          json['OfferImage'], // Can be null if not provided in the response
      offerDescription: json['OfferDescription'],
      offerCouponID: json['OfferCouponID'],
      couponValue: json['CouponValue'],
    );
  }
}

class ApiResponseHomepage {
  final List<UpcomingTrip> upcomingTrips;
  final List<RecentTrip> recentTrips;
  final List<Offer> offers;

  ApiResponseHomepage({
    required this.upcomingTrips,
    required this.recentTrips,
    required this.offers,
  });

  factory ApiResponseHomepage.fromJson(Map<String, dynamic> json) {
    // Handle null check for each list and default to an empty list if null
    var upcomingTripsJson = json['upcoming_trip'] as List? ?? [];
    var recentTripsJson = json['recent_trips'] as List? ?? [];
    var offersJson = json['offers'] as List? ?? [];

    return ApiResponseHomepage(
      upcomingTrips:
          upcomingTripsJson.map((i) => UpcomingTrip.fromJson(i)).toList(),
      recentTrips: recentTripsJson.map((i) => RecentTrip.fromJson(i)).toList(),
      offers: offersJson.map((i) => Offer.fromJson(i)).toList(),
    );
  }
}

/*
class ApiResponseHomepage {
  final List<UpcomingTrip> upcomingTrips;
  final List<RecentTrip> recentTrips;
  final List<Offer> offers;

  ApiResponseHomepage({
    required this.upcomingTrips,
    required this.recentTrips,
    required this.offers,
  });

  factory ApiResponseHomepage.fromJson(Map<String, dynamic> json) {
    var upcomingTripsJson = json['upcoming_trip'] as List;
    var recentTripsJson = json['recent_trips'] as List;
    var offersJson = json['offers'] as List;

    return ApiResponseHomepage(
      upcomingTrips:
          upcomingTripsJson.map((i) => UpcomingTrip.fromJson(i)).toList(),
      recentTrips: recentTripsJson.map((i) => RecentTrip.fromJson(i)).toList(),
      offers: offersJson.map((i) => Offer.fromJson(i)).toList(),
    );
  }
}
*/
/*
class Offer {
  final int offerID;
  final String offerName;
  final String offerImage;
  final String? offerDescription;
  final int offerCouponID;
  final int couponValue;

  Offer({
    required this.offerID,
    required this.offerName,
    this.offerImage,
    this.offerDescription,
    required this.offerCouponID,
    required this.couponValue,
  });

  factory Offer.fromJson(Map<String, dynamic> json) {
    return Offer(
      offerID: json['OfferID'],
      offerName: json['OfferName'],
      offerImage: json['OfferImage'],
      offerDescription: json['OfferDescription'],
      offerCouponID: json['OfferCouponID'],
      couponValue: json['CouponValue'],
    );
  }
}
*/
