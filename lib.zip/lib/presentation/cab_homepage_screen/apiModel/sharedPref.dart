import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';

class sharedPref {
  saveCheckID(String checkID) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('checkID', checkID);
    debugPrint('checkID saved: $checkID');
  }

  saveCheckID1(String checkID) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('checkID1', checkID);
    debugPrint('checkID saved: $checkID');
  }

  saveCity(int cityID) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt('cityID', cityID);
    debugPrint('cityID saved: $cityID');
  }

  saveCityDeparture(int cityID) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt('departureCityID', cityID);
    debugPrint('departureCityID saved: $cityID');
  }

  saveJourneyDate(String  date) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('journeyDate', date);
    debugPrint('journeyDate saved: $date');
  }


  static Future<String?> getCheckID() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('checkID');
    }


  static Future<String?> getCheckID1() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('checkID1');
  }

  static Future<int?> getCityID() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getInt('cityID');
  }

  static Future<int?> getDepartureCityID() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getInt('departureCityID');
  }

  static Future<String?> getJourneyDate() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('journeyDate');
  }


}