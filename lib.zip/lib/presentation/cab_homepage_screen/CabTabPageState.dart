import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertickect365/core/app_export.dart'; // Assuming you have this in your project
import 'package:fluttertickect365/presentation/car/SearchingForCarScreen.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../car/CabDriverRatings.dart';
import '../car/Cab_Driver_details.dart';
import '../car/DriverProfile.dart';
import '../car/SelectCarScreen.dart';
import '../car/TripDetailsPage.dart';
import '../map_location/SetLocationScreen.dart';
import '../offerscreen/OfferScreen.dart';
import '../payment_page/PaymentMethodsPage.dart';
import '../utils/AppConstants.dart';
import 'apiModel/ApiResponseHomepage.dart'; // Import your models

class CabTabPage extends StatefulWidget {
  const CabTabPage({Key? key}) : super(key: key);

  @override
  CabTabPageState createState() => CabTabPageState();
}

class CabTabPageState extends State<CabTabPage> {
  String setlocationclick = "";
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<ApiResponseHomepage>(
      future: fetchData(), // Fetch data from API
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        } else if (snapshot.hasData) {
          final apiResponse = snapshot.data!;

          return Container(
            // padding: EdgeInsets.symmetric(vertical: 60.h),//for tab unhide this
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    child: Container(
                      width: double.maxFinite,
                      margin: EdgeInsets.only(left: 14),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildSelectLocationSection(context),
                          _buildUpcomingRideSection(
                              context, apiResponse.upcomingTrips),
                          //  _buildOffersSection(context, apiResponse.offers),//offers
                          _buildRecentTripsSection(
                              context, apiResponse.recentTrips),
                          SizedBox(width: 150, height: 150)
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        } else {
          return Center(child: Text('No data available'));
        }
      },
    );
  }

  Widget _buildSelectLocationSection(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(right: 16),
      child: Column(
        children: [
          SizedBox(height: 20),
          CustomImageView(
            imagePath: ImageConstant.img_home_car,
            height: 300,
            width: double.maxFinite,
          ),
          CustomElevatedButton(
            height: 36,
            width: 156,
            text: "lbl_select_location".tr,
            buttonStyle: CustomButtonStyles.none,
            decoration: CustomButtonStyles.gradientBlueAToPrimaryTL6Decoration,
            onPressed: () async {
              // setlocationclick = getLocationBtnStatus() as String;
              setlocationclick = (await getLocationBtnStatus())!;

              if (setlocationclick == "") {
                Navigator.push(
                  context,
                  //  MaterialPageRoute(builder: (context) => SelectCarScreen()),
                  MaterialPageRoute(builder: (context) => SetLocationScreen()),
                  // MaterialPageRoute(builder: (context) => CabDriverDetails()),
                  //MaterialPageRoute(builder: (context) => TripDetailsPage()),
                  //MaterialPageRoute(builder: (context) => DriverProfile()),
                );
              } else {
                Fluttertoast.showToast(
                  msg: 'Please complete Upcoming Trip',
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.BOTTOM,
                );
              }
            },
          ),
        ],
      ),
    );
  }

  void checkLocationButtonStatus() async {
    String? bookingID = await getLocationBtnStatus();
    if (bookingID != null) {
      setlocationclick = bookingID;
      print("Stored booking ID: $bookingID");
    } else {
      print("No booking ID found");
    }
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<ApiResponseHomepage> fetchData() async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'home_view');
    String? token = await getToken();

    print('Authorization $token');
    if (token == null) {
      Fluttertoast.showToast(msg: "No authentication token found.");
      return Future.error("No token");
    }

    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };


    try {
      var response =
          await http.post(url, headers: headers, body: jsonEncode({}));
      print(("in.."));
      print(("chehckresponse: $response"));


      if (response.statusCode == 200) {
        print(("200.."));

        final data = jsonDecode(response.body);
        print('checkdata: $data');
        if (data['status'] == true) {
          saveName(data['data']['user_name'] ?? "N/A");
          print(("true.."));

          return ApiResponseHomepage.fromJson(data['data']);
        } else {
          Fluttertoast.showToast(
            msg: data['message'] ?? 'An error occurred. Please try again.',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
          return Future.error('Error: ${data['message']}');
        }
      } else {
        Fluttertoast.showToast(
          msg: 'Failed to fetch data. Please try again.',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
        return Future.error('Failed to fetch data');
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: 'An error occurred: $e',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      return Future.error(e.toString());
    }
  }

  Future<bool> setBookingID(String bookingID) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setString(
        'bookingid', bookingID); // Returns a boolean indicating success
  }

  Future<bool> setlocationBtnsatus(String bookingID) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setString('location_buttonstatus',
        bookingID); // Returns a boolean indicating success
  }

  Future<String?> getLocationBtnStatus() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(
        'location_buttonstatus'); // Returns the stored string or null if not found
  }

  Widget _buildUpcomingRideSection(
      BuildContext context, List<UpcomingTrip> upcomingTrips) {
    debugPrint('Upcoming Trips: ${upcomingTrips.toString()}');

    // Show "No data" message if the list is empty
    if (upcomingTrips.isEmpty) {
      setlocationclick == "";
      setlocationBtnsatus("");

      return Center(
        child: Text(
          "",
          style: TextStyle(color: Colors.grey, fontSize: 16),
        ),
      );
    } else {
      /*  Fluttertoast.showToast(
        msg: 'in',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );*/
      setlocationBtnsatus(
          "in"); //this is used to validate wheather upcoming list has more then one order
      //setlocationBtnsatus("");
    }

    // If the list is not empty, display the horizontal list
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 14.0),
          child: Text(
            "Upcoming Ride",
            style: TextStyle(
              fontFamily: 'Poppins',
              color: Color(0XFF404040),
              fontWeight: FontWeight.w600,
              fontSize: 17,
            ),
          ),
        ),
        SizedBox(height: 8),
        Container(
          height: 190, // Height of the horizontal list view
          child: ListView.builder(
            scrollDirection:
                Axis.horizontal, // Set scroll direction to horizontal
            itemCount: upcomingTrips.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(right: 10), // Add right margin
                child: _buildLocationRow(upcomingTrips[index]),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildLocationRow(UpcomingTrip trip) {
    /* Fluttertoast.showToast(
      msg: trip.bookingId,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );*/
    setBookingID(trip.bookingId);
    return GestureDetector(
      onTap: () async {
        //setBookingID("88");
        setBookingID(trip.bookingId);
        // print("booid = "+trip.bookingId);
        print("isBookingAccepted = " + trip.isBookingAccepted);

        final prefs = await SharedPreferences.getInstance();

        final BookingToAddress = trip.toLocation + ", " + trip.toaddress;
        final currentAddress = trip.fromLocation + ", " + trip.fromaddress;
        double BookingFromLat = double.parse(trip.BookingFromLat);
        double BookingFromLong = double.parse(trip.BookingFromLong);
        double BookingToLat = double.parse(trip.BookingToLat);
        double BookingToLong = double.parse(trip.BookingToLong);

        // Save values to SharedPreferences
        await prefs.setDouble('destination_lat', BookingToLat);
        await prefs.setDouble('destination_lng', BookingToLong);
        await prefs.setString('destination_address', BookingToAddress);

        await prefs.setDouble('current_lat', BookingFromLat);
        await prefs.setDouble('current_lng', BookingFromLong);
        await prefs.setString('current_address', currentAddress ?? "Unknown");

        if (trip.isBookingAccepted.isNotEmpty &&
            trip.isBookingAccepted == "1") {
          print("success = ");
          // Navigate to the next page when the item is clicked

          if (trip.BookingStatus == "1") {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => TripDetailsPage(),
              ),
            );
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CabDriverDetails(),
              ),
            );
          }
        } else {
          // Navigate to the next page when the item is clicked
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SearchingForCarScreen(),
              //builder: (context) => PaymentMethodsPage(),
              //  builder: (context) => DriverProfile(),
              //  builder: (context) => CabDriverRatings(),
              // builder: (context) => TripDetailsPage(),
            ),
          );
        }
      },
      child: Container(
        width: 300,
        // Fixed width for each item in the horizontal list
        margin: EdgeInsets.only(right: 14),
        // Right margin
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF4181FF), Color(0xFF274E99)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildLocationRowContent(trip.fromLocation,
                          trip.toLocation, trip.fromaddress, trip.toaddress),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Align(
              alignment: Alignment.center,
              child: Text(
                trip.arriving_time, // Display arrival time
                style: TextStyle(
                    fontFamily: 'Poppins',
                    color: Color(0XFF00FFA1),
                    fontWeight: FontWeight.w500,
                    fontSize: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationRowContent(String fromLocation, String toLocation,
      String fromAddress, String toAddress) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // From Location Row with SVG Icon
        Row(
          children: [
            SvgPicture.asset(
              'assets/images/white_dot.svg', // Path to your SVG file
              width: 18.0, // Set the width of the SVG
              height: 18.0, // Set the height of the SVG
              color: Colors.white, // Optional: Apply a color filter if needed
            ),
            SizedBox(width: 8), // Space between icon and text
            // Wrap the text with Expanded to avoid overflow
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    fromLocation,
                    maxLines: 2, // Allow up to 2 lines
                    overflow: TextOverflow
                        .ellipsis, // Add ellipsis if the text overflows
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(height: 4), // Space between location and address
                  Text(
                    fromAddress,
                    maxLines: 2, // Allow up to 2 lines
                    overflow: TextOverflow
                        .ellipsis, // Add ellipsis if the text overflows
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: Color(0xFFBDBDBD),
                      fontWeight: FontWeight.w500,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        SizedBox(height: 25), // Space between from and to location
        // To Location Row with Icon
        Row(
          children: [
            Icon(
              Icons.location_on, // Use the same or different icon here
              color: Colors.white, // Icon color
              size: 18, // Icon size
            ),
            SizedBox(width: 8), // Space between icon and text
            // Wrap the text with Expanded to avoid overflow
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    toLocation,
                    maxLines: 2, // Allow up to 2 lines
                    overflow: TextOverflow
                        .ellipsis, // Add ellipsis if the text overflows
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(height: 4), // Space between location and address
                  Text(
                    toAddress,
                    maxLines: 2, // Allow up to 2 lines
                    overflow: TextOverflow
                        .ellipsis, // Add ellipsis if the text overflows
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: Color(0xFFBDBDBD),
                      fontWeight: FontWeight.w500,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  // Recent Trips Section

  Widget _buildRecentTripsSection(
      BuildContext context, List<RecentTrip> recentTrips) {
    debugPrint('recentTrips Trips: ${recentTrips.toString()}');
    if (recentTrips.isEmpty) {
      return Center(
        child: Text(
          "",
          style: TextStyle(color: Colors.grey, fontSize: 16),
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 14.0),
          child: Text(
            "Recent Ride",
            style: TextStyle(
              fontFamily: 'Poppins',
              color: Color(0XFF404040),
              fontWeight: FontWeight.w600,
              fontSize: 17,
            ),
          ),
        ),
        SizedBox(height: 8),
        // Horizontal ListView
        Container(
          height: 150, // Height of the horizontal list view
          child: ListView.builder(
            scrollDirection:
                Axis.horizontal, // Set scroll direction to horizontal
            itemCount: recentTrips.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(right: 10), // Add right margin
                child: _buildLocationRowrecentRide(recentTrips[index]),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildLocationRowrecentRide(RecentTrip trip) {
    return Container(
      width: 300,
      // Fixed width for each item in the horizontal list
      margin: EdgeInsets.only(right: 14),
      // Right margin
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF4181FF), Color(0xFF274E99)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildLocationRowContent2(
                        trip.fromLocation, trip.toLocation),
                  ],
                ),
              ),
            ],
          ),
          //SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildLocationRowContent2(String fromLocation, String toLocation) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // From Location Row
        Row(
          children: [
            SizedBox(width: 8), // Space between icon and text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    fromLocation,
                    maxLines: 2,
                    // Allow up to 2 lines
                    overflow: TextOverflow.ellipsis,
                    // Add ellipsis if the text overflows after 2 lines
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(height: 4), // Space between location and address
                ],
              ),
            ),
          ],
        ),
        SizedBox(height: 8), // Space between locations

        // Text between From and To Locations
        Text(
          "  To", // You can replace this with any text you want
          style: TextStyle(
            fontFamily: 'Poppins',
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 14,
          ),
        ),
        SizedBox(height: 8), // Space between "To" text and next location

        // To Location Row
        Row(
          children: [
            SizedBox(width: 8), // Space between icon and text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    toLocation,
                    maxLines: 2,
                    // Allow up to 2 lines
                    overflow: TextOverflow.ellipsis,
                    // Add ellipsis if the text overflows after 2 lines
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(height: 4), // Space between location and address
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildOffersSection(BuildContext context, List<Offer> offers) {
    return SizedBox(
      width: double.maxFinite,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 0.0, vertical: 14.0),
            child: Text(
              "offers",
              style: TextStyle(
                fontFamily: 'Poppins',
                color: Color(0XFF404040),
                fontWeight: FontWeight.w600,
                fontSize: 17,
              ),
            ),
          ),
          // Wrap the Row with SingleChildScrollView for horizontal scrolling
          SizedBox(
            height: 160, // Set a height for the scrolling area
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  for (var offer in offers) _buildOfferRow(offer),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPopularRoutesRow(
    BuildContext context, {
    required String titleText,
    required String viewAllText,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
          alignment: Alignment.center,
          child: Text(
            titleText,
            style: TextStyle(
                fontFamily: 'Poppins',
                color: Color(0XFF404040),
                fontWeight: FontWeight.w600,
                fontSize: 17),
          ),
        ),
        Text(
          viewAllText,
          style: TextStyle(
              fontFamily: 'Poppins',
              color: Color(0XFF4181FF),
              fontWeight: FontWeight.w500,
              fontSize: 13),
        ),
      ],
    );
  }

  Future<void> saveName(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('username', token);
  }

  Widget _buildOfferRow(Offer offer) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            // builder: (context) => OfferScreen(offerID: offer.offerID),
            builder: (context) =>
                OfferScreen(offerId: offer.offerID), // Fixed: offerId
          ),
        );
      },
      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start, // Align children to the top
        children: [
          // If offerImage is not null, display it
          if (offer.offerImage != null)
            Image.network(
              AppConstants.HOST + offer.offerImage!, // Load image from network
              height: 140, // Specify a height (optional)
              fit: BoxFit.cover, // Ensure the image fits nicely
            ),
          SizedBox(width: 8), // Space between image and text
          // Display the offer name
        ],
      ),
    );
  }
}
