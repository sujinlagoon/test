import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertickect365/presentation/Bus/UI/SelectDepature.dart';
import 'package:fluttertickect365/sujin_screen/both/bothCitiesController.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/sizes.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/select_source/select_source_view.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';
import '../../sujin_screen/Profile/profile__controller.dart';
import '../../sujin_screen/both/both_from_to_view.dart';
import '../../sujin_screen/bus_list/bus_List.dart';
import '../../sujin_screen/common_update/allCities_search/co_allCities_view.dart';
import '../../sujin_screen/common_update/allCities_search/controller/co_searchCities_controller.dart';
import '../../sujin_screen/common_update/co_allBusList/co_allBusList_view.dart';
import '../../sujin_screen/common_update/co_allBusList/controller/co_allBusList_controller.dart';
import '../../sujin_screen/orbit_Api/orbit_allBuslistView/controller/orbit_allBusView_controller.dart';
import '../../sujin_screen/orbit_Api/orbit_allBuslistView/orbit_allBusListView_.dart';
import '../../sujin_screen/orbit_Api/select_source/controller/O_source_destination_controller.dart';
import '../Bus/Controller/BusAvailabilityController.dart';
import '../Bus/UI/SelectArrival.dart';
import 'apiModel/sharedPref.dart';

class BusTabPage extends StatefulWidget {
  BusTabPage({Key? key}) : super(key: key);

  @override
  BusTabPageState createState() => BusTabPageState();
}

class BusTabPageState extends State<BusTabPage> {
  String? fromLocation = '';
  String? toLocation = '', date = '';
  int fromId = 0;
  int toId = 0;
  int adultCount = 1;
  int childCount = 1;
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    getToken();
    // clearAllSharedPref();
    super.initState();
    // _selectedDate = controller.oSelectedDate!;
    //   profileController.getProfile();
    // Reset location values when coming back
    if (profileController.profile?.busapiname == "orbit") {
      controller.fromLocation = '';
      controller.toLocation = '';
      //controller.update();
    } else if (profileController.profile?.busapiname == "seatseller") {
      seatSellerCitiesController.fromLocation = '';
      seatSellerCitiesController.toLocation = '';

      /// seatSellerCitiesController.update();
    } else {
      bothCitiesController.fromLocationBoth = '';
      bothCitiesController.ToLocationBoth = '';
      // bothCitiesController.update();
    }
  }

  void clearAllSharedPref() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    setState(() {
      fromLocation = '';
      toLocation = '';
      date = '';
    });

    //Fluttertoast.showToast(msg: "All data cleared!");
  }

  void getToken() async {
    final fetchedLocation = await sharedPref.getCheckID();
    final fetchedLocation1 = await sharedPref.getCheckID1();
    final fetchFromId = await sharedPref.getCityID();
    final fetchToId = await sharedPref.getDepartureCityID();
    final fetchDate = await sharedPref.getJourneyDate();

    setState(() {
      fromLocation = fetchedLocation ?? '';
      toLocation = fetchedLocation1 ?? '';
      fromId = fetchFromId ?? 0;
      toId = fetchToId ?? 0;
      date = fetchDate ?? '';
      //Fluttertoast.showToast(msg: '$date');
    });
  }

  OSourceDestinationController controller =
      Get.put(OSourceDestinationController());
  final ProfileController profileController = Get.find<ProfileController>();
  final OrbitAllBusListController allBusListController =
      Get.put(OrbitAllBusListController());
  final BothCitiesController bothCitiesController =
      Get.put(BothCitiesController());
  final BusAvailabilityController seatSellerCitiesController =
      Get.put(BusAvailabilityController());
  final CoAllCitiesController coAllCitiesController =
      Get.put(CoAllCitiesController());
  final CoAllBusListController cc = Get.put(CoAllBusListController());

  @override
  Widget build(BuildContext context) {
    return profileController.isLoading
        ? Shimmer.fromColors(
            baseColor: Colors.white.withOpacity(0.6),
            highlightColor: Colors.grey[100]!,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: MediaQuery.sizeOf(context).height * 0.20,
                width: MediaQuery.sizeOf(context).width,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16.0),
                ),
              ),
            ),
          )
        : Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 40),
            child: Column(
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      IntrinsicHeight(
                        child: Container(
                          padding: const EdgeInsets.all(16.0),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16.0),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.5),
                                spreadRadius: 2,
                                blurRadius: 6,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              if (profileController.profile?.busapiname ==
                                  "common")
                                GetBuilder<CoAllCitiesController>(builder: (o) {
                                  return _buildInputField(
                                    icon: SvgPicture.asset(
                                      'assets/images/bus_source_svg.svg',
                                    ),
                                    label: 'From',
                                    value:
                                        o.fromLocation ?? "Select a location",
                                    onTap: () async {
                                      o.coCitySearchCTT.clear();
                                      Get.to(() => CoAllCityView(
                                            isSelectingFrom: true,
                                          ));
                                    },
                                  );
                                }),
                              kHeight10,
                              if (profileController.profile?.busapiname ==
                                  "common")
                                GetBuilder<CoAllCitiesController>(builder: (o) {
                                  return _buildInputField(
                                    icon: SvgPicture.asset(
                                      'assets/images/bus_source_svg.svg',
                                    ),
                                    label: 'To',
                                    value: o.toLocation ?? "Select a location",
                                    onTap: () async {
                                      o.coCitySearchCTT.clear();
                                      Get.to(() => CoAllCityView(
                                            isSelectingFrom: false,
                                          ));
                                    },
                                  );
                                }),
                              if (profileController.profile?.busapiname ==
                                  "orbit")
                                GetBuilder<OSourceDestinationController>(
                                    builder: (o) {
                                  print("wwww${controller.fromLocation}");
                                  o.fromLocation == "";
                                  fromLocation == '';
                                  return _buildInputField(
                                    icon: SvgPicture.asset(
                                      'assets/images/bus_source_svg.svg',
                                    ),
                                    label: 'From',
                                    value: controller.fromLocation ??
                                        "Select a location",
                                    onTap: () async {
                                      controller.fromLocation = '';
                                      controller.searchController.clear();
                                      Get.to(() => SelectSourceView(
                                            isSelectingFrom: true,
                                          ));
                                    },
                                  );
                                }),
                              if (profileController.profile?.busapiname ==
                                  "both")
                                GetBuilder<BothCitiesController>(builder: (o) {
                                  o.fromLocationBoth == "";
                                  fromLocation == '';
                                  return _buildInputField(
                                    icon: SvgPicture.asset(
                                      'assets/images/bus_source_svg.svg',
                                    ),
                                    label: 'From',
                                    value: o.fromLocationBoth ??
                                        "Select a location",
                                    onTap: () async {
                                      o.fromLocationBoth = '';
                                      o.searchController.clear();
                                      Get.to(() => SelectBothSourceView(
                                            isSelectingFrom: true,
                                          ));
                                    },
                                  );
                                }),
                              if (profileController.profile?.busapiname ==
                                  "seatseller")
                                GetBuilder<BusAvailabilityController>(
                                    builder: (o) {
                                  return _buildInputField(
                                    icon: SvgPicture.asset(
                                      'assets/images/bus_dest_sv.svg',
                                    ),
                                    label: 'From',
                                    value:
                                        o.fromLocation ?? "Select a location",
                                    onTap: () async {
                                      print("this");
                                      o.fromLocation = '';
                                      o.searchController.clear();
                                      Get.to(() => SelectArrivalScreen(
                                            isSelectingFrom: true,
                                          ));
                                    },
                                  );
                                }),
                              const SizedBox(height: 16),
                              if (profileController.profile?.busapiname ==
                                  "orbit")
                                GetBuilder<OSourceDestinationController>(
                                    builder: (o) {
                                  return _buildInputField(
                                    icon: SvgPicture.asset(
                                      'assets/images/bus_dest_sv.svg',
                                    ),
                                    label: 'To',
                                    value: controller.toLocation ??
                                        "Select a location",
                                    onTap: () async {
                                      controller.toLocation = '';
                                      controller.searchController.clear();
                                      Get.to(() => SelectSourceView(
                                            isSelectingFrom: false,
                                          ));
                                    },
                                  );
                                }),
                              if (profileController.profile?.busapiname ==
                                  "seatseller")
                                GetBuilder<BusAvailabilityController>(
                                    builder: (o) {
                                  return _buildInputField(
                                    icon: SvgPicture.asset(
                                      'assets/images/bus_dest_sv.svg',
                                    ),
                                    label: 'To',
                                    value: o.toLocation ?? "Select a location",
                                    onTap: () async {
                                      print("this");
                                      o.toLocation = '';
                                      o.searchController.clear();
                                      Get.to(() => SelectArrivalScreen(
                                            isSelectingFrom: false,
                                          ));
                                    },
                                  );
                                }),
                              if (profileController.profile?.busapiname ==
                                  "both")
                                GetBuilder<BothCitiesController>(builder: (o) {
                                  return _buildInputField(
                                    icon: SvgPicture.asset(
                                      'assets/images/bus_dest_sv.svg',
                                    ),
                                    label: 'To',
                                    value:
                                        o.ToLocationBoth ?? "Select a location",
                                    onTap: () async {
                                      o.ToLocationBoth = '';
                                      o.searchController.clear();
                                      Get.to(() => SelectBothSourceView(
                                            isSelectingFrom: false,
                                          ));
                                    },
                                  );
                                }),
                              const SizedBox(height: 16),
                              Row(
                                children: [
                                  Flexible(
                                    child: InkWell(
                                      onTap: () => _selectDate(context),
                                      // Call _selectDate on tap
                                      child: _buildInputField(
                                        icon: SvgPicture.asset(
                                            'assets/images/bus_cal.svg'),
                                        label: 'Date of Journey',
                                        value: _selectedDate != null
                                            ? DateFormat.yMMMd().format(
                                                _selectedDate) // Show date and time
                                            : "No date selected", // Display selected date
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        top: 60,
                        // Adjust this value to position the button between fields
                        right: MediaQuery.of(context).size.width * 0.16 - 12,
                        // Center alignment
                        child: GestureDetector(
                          onTap: () async {
                            print(
                                'Orbit Before swapping: fromLocation = $fromLocation, toLocation = $toLocation');
                            if (profileController.profile?.busapiname ==
                                "orbit") {
                              setState(() {
                                final tempLocation = controller.fromLocation;
                                controller.fromLocation = controller.toLocation;
                                controller.toLocation = tempLocation;

                                final tempCode = controller.fromLocationCode;
                                controller.fromLocationCode =
                                    controller.toLocationCode;
                                controller.toLocationCode = tempCode;
                              });

                              // Save swapped locations in SharedPreferences (if needed)
                              await sharedPref()
                                  .saveCheckID(controller.fromLocation!);
                              await sharedPref()
                                  .saveCheckID1(controller.toLocation!);
                            } else if (profileController.profile?.busapiname == "both") {
                              setState(() {
                                final temp =
                                    bothCitiesController.fromLocationBoth;
                                bothCitiesController.fromLocationBoth =
                                    bothCitiesController.ToLocationBoth;
                                bothCitiesController.ToLocationBoth = temp;

                                final tempId =
                                    bothCitiesController.fromLocationCodeBoth;
                                bothCitiesController.fromLocationCodeBoth =
                                    bothCitiesController.toLocationCodeBoth;
                                bothCitiesController.toLocationCodeBoth =
                                    tempId;
                              });

                              await sharedPref().saveCheckID(
                                  bothCitiesController.fromLocationBoth!);
                              await sharedPref().saveCheckID1(
                                  bothCitiesController.ToLocationBoth!);

                              await sharedPref().saveCity(int.parse(
                                  bothCitiesController.fromLocationCodeBoth!));
                              await sharedPref().saveCityDeparture(int.parse(
                                  bothCitiesController.toLocationCodeBoth!));

                              // Debugging: Print after swapping
                              print(
                                  'After swapping (Both): fromLocation = ${bothCitiesController.fromLocationBoth}, toLocation = ${bothCitiesController.ToLocationBoth}');
                            }   else if (profileController.profile?.busapiname == "common") {


                                final tempFromLocation = coAllCitiesController.fromLocation;
                                final tempFromLocationCode = coAllCitiesController.fromLocationCode;
                                final tempToLocation = coAllCitiesController.toLocation;
                                final tempToLocationCode = coAllCitiesController.toLocationCode;
                                final tempFromPkID = coAllCitiesController.fromGeneralCityPKID;
                                final tempToPkID = coAllCitiesController.toGeneralCityPKID;


                                coAllCitiesController.fromLocation = tempToLocation;
                                coAllCitiesController.fromLocationCode = tempToLocationCode;
                                coAllCitiesController.toLocation = tempFromLocation;
                                coAllCitiesController.toLocationCode = tempFromLocationCode;
                                coAllCitiesController.fromGeneralCityPKID=tempToPkID;
                                coAllCitiesController.toGeneralCityPKID =tempFromPkID;
                                coAllCitiesController.update();
                            }
                            else {
                              setState(() {
                                final temp = fromLocation;
                                fromLocation = toLocation;
                                toLocation = temp;

                                final tempId = fromId;
                                fromId = toId;
                                toId = tempId;
                              });

                              await sharedPref().saveCheckID(fromLocation!);
                              await sharedPref().saveCheckID1(toLocation!);

                              await sharedPref().saveCity(fromId);
                              await sharedPref().saveCityDeparture(toId);

                              // Debugging: Print after swapping
                              print(
                                  'After swapping: fromLocation = $fromLocation, toLocation = $toLocation');
                            }
                          },
                          child: SvgPicture.asset(
                            'assets/images/swap.svg',
                            width: 45,
                            height: 45,
                          ),
                        ),
                      ),
                      Positioned(
                        top: Get.height *
                            0.29 /*MediaQuery.of(context).size.height * 0.29*/,
                        left: /*MediaQuery.of(context).size.width * */
                            Get.width * 0.40 - 50,
                        child: InkWell(
                          onTap: () async {
                            if (profileController.profile!.busapiname ==
                                "seatseller") {
                              if (seatSellerCitiesController
                                  .fromLocation!.isEmpty) {
                                Fluttertoast.showToast(
                                    msg: 'Select From Location',
                                    toastLength: Toast.LENGTH_SHORT);
                              } else if (seatSellerCitiesController
                                  .toLocation!.isEmpty) {
                                Fluttertoast.showToast(
                                    msg: 'Select To Location',
                                    toastLength: Toast.LENGTH_SHORT);
                              } else if (_selectedDate == DateTime.now()) {
                                Fluttertoast.showToast(
                                    msg: 'Select Date',
                                    toastLength: Toast.LENGTH_SHORT);
                              } else {
                                Get.to(() => BusLists(
                                      fromLocationCode:
                                          seatSellerCitiesController
                                              .fromLocationCode,
                                      toLocationCode: seatSellerCitiesController
                                          .toLocationCode,
                                      fromLocation: seatSellerCitiesController
                                          .fromLocation,
                                      toLocation:
                                          seatSellerCitiesController.toLocation,
                                      selectedDate: _selectedDate,
                                    ));
                              }
                            } else if (profileController.profile!.busapiname ==
                                "orbit") {
                              if (controller.fromLocation == null) {
                                Fluttertoast.showToast(
                                  msg: 'Select From Location',
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              } else if (controller.toLocation == null) {
                                Fluttertoast.showToast(
                                  msg: 'Select To Location',
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              } else if (controller.oSelectedDate ==
                                  DateTime.now()) {
                                Fluttertoast.showToast(
                                  msg: 'Select Date',
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              } else {
                                await allBusListController
                                    .getOrbitAllBusListApi(
                                        fomCode: controller.fromLocationCode,
                                        toCode: controller.toLocationCode,
                                        selectedDate: DateTime.parse(
                                            DateFormat('yyyy-MM-dd').format(
                                                controller.oSelectedDate!)));
                              }
                            } else if(profileController.profile!.busapiname ==
                                "common"){
                              if (coAllCitiesController.fromLocation == null) {
                                Fluttertoast.showToast(
                                  msg: 'Select From Location',
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              } else if (coAllCitiesController.toLocation == null) {
                                Fluttertoast.showToast(
                                  msg: 'Select To Location',
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              }  else {
                                Get.to(() =>
                                    CoAllBusViewList(
                                      toLocationCode: coAllCitiesController.toGeneralCityPKID.toString(),
                                      fromLocationCode: coAllCitiesController.fromGeneralCityPKID.toString(),
                                      fromLocation: coAllCitiesController.fromLocation,
                                      toLocation: coAllCitiesController.toLocation,
                                      tripDate: _selectedDate.toIso8601String(),
                                    ));
                              }
                            }{
                              if (bothCitiesController.fromLocationBoth ==
                                  null) {
                                Fluttertoast.showToast(
                                  msg: 'Select From Location',
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              } else if (bothCitiesController.ToLocationBoth ==
                                  null) {
                                Fluttertoast.showToast(
                                  msg: 'Select To Location',
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              } else if (_selectedDate == DateTime.now()) {
                                Fluttertoast.showToast(
                                  msg: 'Select Date',
                                  toastLength: Toast.LENGTH_SHORT,
                                );
                              } else {
                                /*         print(
                                    "bo${bothCitiesController.toLocationCodeBoth}");
                                print(
                                    "bo${bothCitiesController.fromLocationCodeBoth}");
                                print("bo${bothCitiesController.ProviderType}");*/

                                if (bothCitiesController.ProviderType ==
                                    "orbit") {
                                  controller.fromLocationCode =
                                      bothCitiesController.fromLocationCodeBoth;
                                  controller.toLocationCode =
                                      bothCitiesController.toLocationCodeBoth;
                                  controller.fromLocation =
                                      bothCitiesController.fromLocationBoth;
                                  controller.toLocation =
                                      bothCitiesController.ToLocationBoth;
                                  await allBusListController
                                      .getOrbitAllBusListApi(
                                          fomCode: controller.fromLocationCode,
                                          toCode: controller.toLocationCode,
                                          selectedDate: DateTime.parse(
                                              DateFormat('yyyy-MM-dd').format(
                                                  controller.oSelectedDate!)));
                                } else if (bothCitiesController.ProviderType == "seatseller") {
                                  seatSellerCitiesController.fromLocationCode =
                                      bothCitiesController.fromLocationCodeBoth;
                                  seatSellerCitiesController.toLocationCode =
                                      bothCitiesController.toLocationCodeBoth;
                                  seatSellerCitiesController.fromLocation =
                                      bothCitiesController.fromLocationBoth;
                                  seatSellerCitiesController.toLocation =
                                      bothCitiesController.ToLocationBoth;
                                  Get.to(() => BusLists(
                                        fromLocationCode: seatSellerCitiesController.fromLocationCode,
                                        toLocationCode: seatSellerCitiesController.toLocationCode,
                                        fromLocation: seatSellerCitiesController.fromLocation,
                                        toLocation: seatSellerCitiesController.toLocation,
                                        selectedDate: _selectedDate,
                                      ));
                                } else {
                                 /* Get.to(() =>
                                      CoAllBusViewList(
                                        toLocationCode: coAllCitiesController.toGeneralCityPKID.toString(),
                                        fromLocationCode: coAllCitiesController.fromGeneralCityPKID.toString(),
                                        fromLocation: coAllCitiesController.fromLocation,
                                        toLocation: coAllCitiesController.toLocation,
                                        tripDate: _selectedDate.toIso8601String(),
                                      ));*/
                                }
                              }
                            }
                          },
                          child: Container(
                            height: MediaQuery.sizeOf(context).height * 0.05,
                            width: MediaQuery.sizeOf(context).width * 0.40,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFF4181FF), Color(0xFF274E99)],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(6.r),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 6.r,
                                  offset: Offset(0, 5),
                                ),
                              ],
                            ),
                            child: Center(
                                child: DefaultTextStyle(
                              style: TextStyle(
                                fontSize: 18.sp,
                                fontFamily: 'Poppins-SemiBold',
                                color: Colors.white,
                              ),
                              child: Text(
                                'Search Buses',
                              ),
                            )),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            //),
          );
  }

  Widget _buildCounterRow({
    required String title,
    required String subtitle,
    required int count,
    required VoidCallback onIncrement,
    required VoidCallback onDecrement,
  }) {
    return IntrinsicHeight(
      child: SizedBox(
        width: double.infinity,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8.0),
            border: Border.all(color: Color(0xFFA4BFF4)),
          ),
          child: Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontFamily: 'Poppins',
                          fontSize: 14),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Spacer(),
              Row(
                children: [
                  IconButton(
                    onPressed: onDecrement,
                    icon: SvgPicture.asset('assets/images/minus_ring.svg'),
                  ),
                  Text(
                    '$count',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    onPressed: onIncrement,
                    icon: SvgPicture.asset('assets/images/add_ring.svg'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputField({
    required Widget icon,
    required String label,
    required dynamic value, // Accepts both String and DateTime
    VoidCallback? onTap,
  }) {
    // Handle value based on its type
    String displayValue;
    if (value is DateTime) {
      // If value is DateTime, format it
      displayValue = DateFormat.yMMMd().add_jm().format(value);
    } else if (value is String) {
      // If value is a String, use it directly
      displayValue = value;
    } else {
      // Fallback for unexpected types
      displayValue = "Invalid value";
    }

    return InkWell(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: Color(0xFFEBEBEB),
            width: 1.0,
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            SizedBox(
              height: Get.height * 0.03,
              width: Get.width * 0.06,
              child: icon,
            ),
            SizedBox(
              width: Get.width * 0.03,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 9.sp,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      decoration: TextDecoration.none,
                    ),
                    overflow: TextOverflow
                        .ellipsis, // Ensures text truncation if needed
                  ),
                  const SizedBox(height: 4),
                  Text(
                    displayValue,
                    style: TextStyle(
                      fontSize: 14,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF404040),
                      decoration: TextDecoration.none,
                    ),
                    overflow: TextOverflow
                        .ellipsis, // Ensures text truncation if needed
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  orbitSelectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: controller.oSelectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != controller.oSelectedDate) {
      controller.oSelectedDate = picked;
      controller.update();
    }
  }

  bothSelectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: bothCitiesController.bSelectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != bothCitiesController.bSelectedDate) {
      bothCitiesController.bSelectedDate = picked;
      bothCitiesController.update();
    }
  }
}
