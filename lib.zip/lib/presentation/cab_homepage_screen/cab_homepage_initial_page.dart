import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart'; // Import flutter_svg package
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/app_export.dart';
import '../../widgets/app_bar/appbar_subtitle.dart';
import '../../widgets/app_bar/appbar_subtitle_one.dart';
import '../../widgets/app_bar/appbar_trailing_iconbutton.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../Notification/NotificationPage.dart';
import '../car/CabDriverRatings.dart';
import '../utils/NotificationService.dart';
import 'CabTabPageState.dart';

class CabHomepageInitialPage extends StatefulWidget {
  const CabHomepageInitialPage({Key? key}) : super(key: key);

  @override
  CabHomepageInitialPageState createState() => CabHomepageInitialPageState();
}

// State class for CabHomepageInitialPage
class CabHomepageInitialPageState extends State<CabHomepageInitialPage>
    with TickerProviderStateMixin {
  late TabController tabviewController;
  FocusNode focusNode = FocusNode();
  String selectedOption = "Cab";
  TabController? _tabController;
  @override
  void initState() {
    super.initState();
    setloginstatus();
    focusNode.requestFocus(); // Request focus for the widget
    _tabController = TabController(length: 4, vsync: this);
    print("oksuccesss");
  }

  @override
  void dispose() {
    tabviewController.dispose();
    focusNode.dispose(); // Dispose the focus node
    super.dispose();
  }

  Future<String?> getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('username');
  }

  Future<bool> setloginstatus() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setString(
        'login', 'yes'); // Returns a boolean indicating success
  }

/*  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 2, // Number of tabs
        child:Scaffold(
      body: SingleChildScrollView(
        child: Container(
          width: double.maxFinite,
          color: theme.colorScheme.onPrimary,
          child: Column(
            children: [
              SafeArea(
                child: Container(
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: Color(0xFF2684FF), // Blue background color
                  ),
                  child: CustomAppBar(
                    title: Padding(
                      padding:
                          EdgeInsets.only(left: 16.h, top: 30.h, bottom: 30.h),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              FutureBuilder<String?>(
                                future: getUsername(),
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return AppbarSubtitle(
                                      text:
                                          "Loading...", // Placeholder while loading
                                      margin: EdgeInsets.only(right: 42.h),
                                    );
                                  } else if (snapshot.hasError) {
                                    return AppbarSubtitle(
                                      text: "Error", // Error placeholder
                                      margin: EdgeInsets.only(right: 42.h),
                                    );
                                  } else if (snapshot.hasData) {
                                    return AppbarSubtitle(
                                      text: "hello ${snapshot.data}".tr,
                                      margin: EdgeInsets.only(right: 42.h),
                                    );
                                  } else {
                                    return AppbarSubtitle(
                                      text: "lbl_hello_guest".tr,
                                      margin: EdgeInsets.only(right: 42.h),
                                    );
                                  }
                                },
                              ),
                              SizedBox(height: 2.h),
                              AppbarSubtitleOne(
                                text: "msg_let_s_holiday_together".tr,
                              ),
                            ],
                          ),
                          Spacer(),
                          GestureDetector(
                            onTap: () {
                              print('Notification icon tapped');
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => NotificationPage()),
                              );
                            },

                            child: Padding(
                              padding: EdgeInsets.only(
                                  top: 5.h, right: 15.h, bottom: 6.h),
                              child: SvgPicture.asset(
                                ImageConstant.icon_notification,
                                height: 24.h,
                                width: 24.h,
                              ),
                            ),
                          ),

                        ],
                      ),

                    ),
                  ),

                ),

              ),

        ClipRRect( // for tab unhide this
          borderRadius: BorderRadius.circular(6.0),
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 10.0),
            child: TabBar(
              controller: tabviewController,
              labelPadding: EdgeInsets.zero,
              labelColor: Colors.blue,
              labelStyle: TextStyle(
                fontSize: 16.0,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
              ),
              unselectedLabelColor: Colors.grey,
              unselectedLabelStyle: TextStyle(
                fontSize: 16.0,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
              ),
              indicatorColor: Colors.blue,
              indicatorSize: TabBarIndicatorSize.tab,
              tabs: [
                Tab(
                  child: Column(
                    children: [
                      Icon(Icons.directions_bus, size: 24),
                      Text("Buses"),
                    ],
                  ),
                ),
                Tab(
                  child: Column(
                    children: [
                      Icon(Icons.flight_takeoff, size: 24),
                      Text("Flights"),
                    ],
                  ),
                ),
                Tab(
                  child: Column(
                    children: [
                      Icon(Icons.local_taxi, size: 24),
                      Text("Cabs"),
                    ],
                  ),
                ),
                Tab(
                  child: Column(
                    children: [
                      Icon(Icons.hotel, size: 24),
                      Text("Hotels"),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),


              Container(
                margin: EdgeInsets.only(top: 0.h), // Add margin at the top
                child: SizedBox(
                  // height: 876.h,
                  height: 750.h,
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      _buildHelloSmithSection(context),
                      Positioned(
                        child: TabBarView(
                          controller: tabviewController,
                          children: [
                            // Center(child: Text("Buses Content")),
                            //Center(child: Text("Flights Content")),
                            CabTabPage(),
                            // Center(child: Text("Hotels Content")),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
        ),
    );
  }*/

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4, // Number of tabs
      child: Scaffold(
        body: SingleChildScrollView(
          child: Container(
            width: double.maxFinite,

            color: theme.colorScheme.onPrimary,
              child: Column(
                children: [
                    SafeArea(
                      child: Container(
                        width: double.maxFinite,
                        decoration: BoxDecoration(
                          color: Color(0xFF2684FF), // Blue background color
                        ),
                        child: CustomAppBar(
                          title: Padding(
                            padding: EdgeInsets.only(left: 16, top: 30, bottom: 30),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    FutureBuilder<String?>(
                                      future: getUsername(),
                                      builder: (context, snapshot) {
                                        if (snapshot.connectionState == ConnectionState.waiting) {
                                          return AppbarSubtitle(
                                            text: "Loading...", // Placeholder while loading
                                            margin: EdgeInsets.only(right: 42),
                                          );
                                        } else if (snapshot.hasError) {
                                          return AppbarSubtitle(
                                            text: "Error", // Error placeholder
                                            margin: EdgeInsets.only(right: 42),
                                          );
                                        } else if (snapshot.hasData) {
                                          return AppbarSubtitle(
                                            text: "hello ${snapshot.data}".tr,
                                            margin: EdgeInsets.only(right: 42),
                                          );
                                        } else {
                                          return AppbarSubtitle(
                                            text: "lbl_hello_guest".tr,
                                            margin: EdgeInsets.only(right: 42),
                                          );
                                        }
                                      },
                                    ),
                                    SizedBox(height: 2),
                                    AppbarSubtitleOne(
                                      text: "msg_let_s_holiday_together".tr,
                                    ),
                                  ],
                                ),
                                Spacer(),
                                GestureDetector(
                                  onTap: () {
                                    print('Notification icon tapped');
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => NotificationPage()),
                                    );
                                  },
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 5, right: 15, bottom: 6),
                                    child: SvgPicture.asset(
                                      ImageConstant.icon_notification,
                                      height: 24,
                                      width: 24,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6.0),
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 10.0),
                    child: TabBar(
                      labelPadding: EdgeInsets.zero,
                      labelColor: Colors.blue,
                      labelStyle: TextStyle(
                        fontSize: 16.0,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                      unselectedLabelColor: Colors.grey,
                      unselectedLabelStyle: TextStyle(
                        fontSize: 16.0,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                      indicatorColor: Colors.blue,
                      indicatorSize: TabBarIndicatorSize.tab,
                      tabs: [
                        Tab(
                          child: Column(
                            children: [
                              Icon(Icons.directions_bus, size: 24),
                              Text("Buses"),
                            ],
                          ),
                        ),
                        Tab(
                          child: Column(
                            children: [
                              Icon(Icons.flight_takeoff, size: 24),
                              Text("Flights"),
                            ],
                          ),
                        ),
                        Tab(
                          child: Column(
                            children: [
                              Icon(Icons.local_taxi, size: 24),
                              Text("Cabs"),
                            ],
                          ),
                        ),
                        Tab(
                          child: Column(
                            children: [
                              Icon(Icons.hotel, size: 24),
                              Text("Hotels"),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                   // Provide a fixed height to avoid unbounded constraints
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      // Content for Buses tab
                      CabTabPage(),
                      // Content for Flights tab
                      Center(child: Text('Flights content')),
                      // Content for Cabs tab
                      Center(child: Text('Cabs content')),
                      // Content for Hotels tab
                      Center(child: Text('Hotels content')),
                    ],
                  ),
                ),



              ],
            ),
          ),
        ),
      ),
    );
  }



  Widget _buildHelloSmithSection(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        width: double.maxFinite,
        padding: EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment(0.5, 1),
            end: Alignment(0.5, 0),
            colors: [theme.colorScheme.onPrimary, appTheme.blueA400],
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: double.maxFinite,
              margin: EdgeInsets.symmetric(horizontal: 14),
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Column(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: theme.colorScheme.onPrimary,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    width: double.maxFinite,
                  ),
                  SizedBox(height: 214),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
