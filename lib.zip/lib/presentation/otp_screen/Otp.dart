import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/core/app_export.dart';
import 'package:fluttertickect365/sujin_screen/Profile/profile__controller.dart';
import 'package:fluttertickect365/sujin_screen/SharedPref/sharedPref.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import '../../core/utils/navigator_service.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../UserRegistration/PersonalInfo.dart';
import '../cab_homepage_screen/cab_homepage_screen.dart';
import '../login_screen/login_screen.dart';
import '../utils/AppConstants.dart';

/*class Otp extends StatelessWidget {
  final String otp;
  final String number;

  Otp({required this.otp, required this.number});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.black, // Transparent status bar
      statusBarBrightness: Brightness.dark, // Dark text for status bar
    ));
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: OtpScreen(
          otp: otp, number: number), // Pass the OTP and number to OtpScreen
    );
  }
}*/

class OtpScreen extends StatefulWidget {
  final String otp;
  final String number;

  OtpScreen({required this.otp, required this.number});

  @override
  _OtpScreenState createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  late String otp;
  late String phNumber;
  final TextEditingController otpController = TextEditingController();
  late Timer _timer;
  int _start = 30;
  bool _canResend = false;

  @override
  void initState() {
    super.initState();
    _startTimer();
    otp = widget.otp;
    phNumber = widget.number;
  }

  @override
  void dispose() {
    _timer.cancel(); // Cancel the timer when the widget is disposed
    super.dispose();
  }

  // Start the timer for 30 seconds
  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_start == 0) {
        setState(() {
          _canResend = true; // Enable resend after 30 seconds
        });
        timer.cancel();
      } else {
        setState(() {
          _start--;
        });
      }
    });
  }

  void _resendOtp() {
    // Logic to resend OTP can be implemented here
    /* Fluttertoast.showToast(
        msg: "Resend OTP functionality", toastLength: Toast.LENGTH_SHORT);*/
    setState(() {
      _start = 30; // Reset the countdown
      _canResend = false; // Disable resend until 30 seconds
    });
    // Start the timer again
    loginAPI(context, widget.number);
  }

  void updateOTP(String newOtp) {
    setState(() {
      otp = newOtp;
      /*  Fluttertoast.showToast(
        msg: otp,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );*/
    });
  }

  ProfileController controller = Get.put(ProfileController());

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Navigate to Login Page
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => LoginScreen(
              number: widget.number,
            ),
          ),
        );
        return false; // Prevent default back navigation
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: MediaQuery.of(context).size.height,
              ),
              child: IntrinsicHeight(
                child: Center(
                  child: Container(
                    width: double.infinity,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 0.0, vertical: 15.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 25.0, vertical: 10.0),
                            child: Row(
                              children: [
                                /*  Image.asset(
                                  //'assets/images/arrow_left.png',
                                  ImageConstant.arrow_left,
                                  width: 20.0,
                                ),*/

                                InkWell(
                                  onTap: () {
                                    // Handle the tap action here
                                    print('Arrow clicked!');

                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LoginScreen(
                                                number: widget.number, //change
                                              )),
                                    );
                                    // You can navigate, change a state, or any other action
                                  },
                                  child: Image.asset(
                                    ImageConstant.arrow_left,
                                    width: 20.0,
                                  ),
                                ),
                                SizedBox(width: 15.0),
                                Text(
                                  'OTP Verification',
                                  style: TextStyle(
                                    fontFamily: 'Poppins-SemiBold',
                                    fontSize: 19.0,
                                    color: Color(0xFF282828),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Divider(
                            color: Color(0xFfE6E6E6),
                            thickness: 1,
                          ),
                          SizedBox(height: 30.0),
                          Text(
                            'We have sent a verification code to',
                            style: TextStyle(
                                fontSize: 15.0,
                                fontFamily: 'Poppins Medium',
                                color: Color(0xFF747474)),
                          ),
                          SizedBox(height: 5.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              InkWell(
                                onTap: () {
                                  Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => LoginScreen(
                                              number: widget.number, //change
                                            )),
                                  );
                                },
                                child: Image.asset(
                                  //'assets/images/edit_num.png',
                                  ImageConstant.edit_num,
                                  width: 20.0,
                                ),
                              ),
                              SizedBox(width: 10.0),
                              Text(
                                '+91-' + _maskPhoneNumber(widget.number),
                                style: TextStyle(
                                  fontFamily: 'Poppins-SemiBold',
                                  fontSize: 15.0,
                                  color: Color(0xFF282828),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 30.0),
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal:
                                    MediaQuery.sizeOf(context).width * 0.10),
                            child: PinCodeTextField(
                              controller: otpController,
                              appContext: context,
                              length: 4,
                              obscureText: false,
                              animationType: AnimationType.fade,
                              keyboardType: TextInputType.number,
                              pinTheme: PinTheme(
                                shape: PinCodeFieldShape.box,
                                borderRadius: BorderRadius.circular(7),
                                fieldHeight: 53,
                                fieldWidth: 55,
                                activeFillColor: Colors.white,
                                selectedFillColor: Colors.white,
                                inactiveFillColor: Colors.white,
                                activeColor: Color(0xFF414141),
                                selectedColor: Color(0xFF414141),
                                inactiveColor: Color(0xFF414141),
                              ),
                            ),
                          ),
                          SizedBox(height: 30.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Didn't get the otp?",
                                style: TextStyle(
                                    fontFamily: 'Poppins Medium',
                                    fontSize: 14.0,
                                    color: Color(0xFF282828)),
                              ),
                              SizedBox(width: 0.0),
                              TextButton(
                                onPressed: _canResend ? _resendOtp : null,
                                child: Text(
                                  _canResend
                                      ? "Resend OTP"
                                      : "Resend SMS in $_start s",
                                  style: TextStyle(
                                    fontFamily: 'Poppins Medium',
                                    fontSize: 14.0,
                                    color: _canResend
                                        ? Colors.blue
                                        : Color(0xFF747474),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 250.0),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 25.0),
                            child: SizedBox(
                              width: double.infinity,
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Color(0xFF4181FF),
                                      Color(0xFF274E99)
                                    ],
                                    begin: Alignment.centerLeft,
                                    end: Alignment.centerRight,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      blurRadius: 10,
                                      offset: Offset(0, 5),
                                    ),
                                  ],
                                ),
                                child: ElevatedButton(
                                  onPressed: () {
                                    String otpText = otpController.text;

                                    if (otpText.isEmpty) {
                                      Fluttertoast.showToast(
                                        msg: "Enter OTP",
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.BOTTOM,
                                      );
                                    } else if (otpText != otp) {
                                      Fluttertoast.showToast(
                                        msg: "Invalid OTP",
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.BOTTOM,
                                      );
                                    } else {
                                      verifyOtpAPI(context, otp, widget.number);
                                      controller.getProfile();
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.transparent,
                                    shadowColor: Colors.transparent,
                                    padding:
                                        EdgeInsets.symmetric(vertical: 10.0),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15.0),
                                    ), //
                                  ),
                                  child: Text(
                                    'Verify',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontFamily: 'Poppins-SemiBold',
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  String _maskPhoneNumber(String number) {
    if (number.length >= 10) {
      return number.substring(0, 4) + '*****' + number.substring(9);
    }
    return number;
  }

  void loginAPI(BuildContext context, String phNum) async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'sendOTP');
    final requestBody = {
      'phone': phNum,
    };

    // Show loading dialog
    bool isDialogVisible = true; // Flag to track dialog visibility
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFF4181FF),
          ),
        );
      },
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(requestBody),
      );

      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog
        isDialogVisible = false;
      }

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == true) {
          print('Login successful: $data');
          String otp = data['otp'].toString();
          updateOTP(otp);
          _startTimer();
        } else {
          String errorMessage = '';
          if (data['message'] is List && data['message'].isNotEmpty) {
            errorMessage = data['message'][0];
          }

          Fluttertoast.showToast(
            msg: errorMessage,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
      } else {
        print('Login failed with status: ${response.statusCode}');
      }
    } catch (e) {
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog on error
        isDialogVisible = false;
      }
      print('An error occurred: $e');
    }
  }

  void verifyOtpAPI(BuildContext context, String otp, String number) async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'verifyOTP');
    final requestBody = {
      'phone': number,
      'otp': otp,
    };

    // Show loading dialog
    bool isDialogVisible = true; // Flag to track dialog visibility
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child:  LoadingAnimationWidget.beat(
            color: Colors.blue,
            size: 50.sp,
          ),
        );
      },
    );

/*    try {*/
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(requestBody),
    );

    if (isDialogVisible) {
      Navigator.of(context, rootNavigator: true)
          .pop(); // Dismiss loading dialog
      isDialogVisible = false;
    }

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      print(data);
      /*  if (data['status'] == true) {
          print('Login successful: $data');

          String token = data['token'];
          String UserID = data['UserID'];

          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('auth_token', token);
          await prefs.setString('UserID', UserID);

          */ /* Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PersonalInfo(),

            ),
          );*/ /*

          if (data["page"] == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PersonalInfo(),
              ),
            );
          } else {
            NavigatorService.pushReplacementNamed(AppRoutes.cabHomepageScreen);
          }
        } else {
          String errorMessage = '';
          if (data['message'] is String && data['message'].isNotEmpty) {
            errorMessage = data['message'];
          }

           Fluttertoast.showToast(
            msg: errorMessage,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
*/

      if (data['status'] == true) {
        print('Login successful: $data');

        String token = data['token'];
        log(token.toString());
        String userID = data['UserID'].toString();
        await sharedPrefer().saveToken(token);


        // Save token and UserID in SharedPreferences
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('auth_token', token);
        await prefs.setString('UserID', userID);

        // Check the 'page' value and navigate accordingly
        if (data["page"] == 1) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PersonalInfoScreen(),
            ),
          );
        } else {
          //NavigatorService.pushReplacementNamed(AppRoutes.cabHomepageScreen);

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => CabHomepageScreen(),
            ),
          );
        }
      } else {
        String errorMessage =
            data['message'] ?? 'An error occurred. Please try again.';
        Fluttertoast.showToast(
          msg: errorMessage,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    } else {
      print('Login failed with status: ${response.statusCode}');
    }
    /*  } catch (e) {
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog on error
        isDialogVisible = false;
      }
      print('An error occurred: $e');
    }*/
  }

  /*Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
  }*/
}
