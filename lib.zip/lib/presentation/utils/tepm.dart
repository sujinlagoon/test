/*
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:fluttertoast/fluttertoast.dart';
//import 'package:ticket_365_cab_driver/Upload_Document.dart';
import 'AppConstants.dart';
//import 'MyDocumentsandEarnings.dart';
//import 'RideDetails.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController bookingController = TextEditingController();
  final TextEditingController earningController = TextEditingController();
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    HomeScreenContent(),
    ProfileScreenContent(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          _screens[_selectedIndex],
          Positioned(
            left: 100.0,
            right: 100.0,
            bottom: 20.0,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.8),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    offset: Offset(0, -2),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: BottomNavigationBar(
                  items: [
                    BottomNavigationBarItem(
                      icon: ImageIcon(AssetImage('assets/images/home1.png')),
                      label: 'Home',
                    ),
                    BottomNavigationBarItem(
                      icon: ImageIcon(AssetImage('assets/images/profile.png')),
                      label: 'Profile',
                    ),
                  ],
                  currentIndex: _selectedIndex,
                  selectedItemColor: Colors.blue,
                  unselectedItemColor: Colors.black54,
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  onTap: _onItemTapped,
                  type: BottomNavigationBarType.fixed,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class HomeScreenContent extends StatefulWidget {
  @override
  _HomeScreenContentState createState() => _HomeScreenContentState();
}

class _HomeScreenContentState extends State<HomeScreenContent> {
  final CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(8.189653, 77.401716),
    zoom: 12.0,
  );
  bool isOnline = false;
  String totalEarnings = "", todayBooking = "";
  late int status = 0;
  String? _authToken;
  List<Booking> _bookings = [];

  Future<void> _checkAuthToken() async {
    String? token = await getToken();
    setState(() {
      _authToken = token;
    });

    if (_authToken != null) {
      print("Auth Token: $_authToken");
    } else {
      print("No auth token found");
    }

    if (_authToken != null) {
      homeAPI();
    }
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  @override
  void initState() {
    super.initState();
    _checkAuthToken();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(
            padding:
            const EdgeInsets.symmetric(horizontal: 18.0, vertical: 10.0),
            child: Row(
              children: [
                Image.asset(
                  'assets/images/logo1.png',
                  width: 150.0,
                  height: 150.0,
                ),
                Spacer(),
                OnlineOfflineSwitch(status: status),
              ],
            ),
          ),
          SizedBox(height: 30.0),
          Positioned(
            top: 130.0,
            left: 0.0,
            right: 0.0,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildCard('Total Earnings', '₹$totalEarnings', Colors.white),
                  SizedBox(width: 10.0),
                  _buildCard('Today\'s Ride', '$todayBooking', Colors.white),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 300),
            child: GoogleMap(
              initialCameraPosition: _initialCameraPosition,
              mapType: MapType.normal,
              onMapCreated: (GoogleMapController controller) {},
            ),
          ),
          Positioned(
            top: 350,
            left: 0.0,
            right: 0.0,
            bottom: 0.0,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _bookings.length,
              itemBuilder: (context, index) {
                var booking = _bookings[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0),
                  child: SizedBox(
                    width: 350.0,
                    height: 100.0,
                    child: Card(
                      elevation: 8.0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0), // Reduced padding
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(
                              children: [
                                CircleAvatar(
                                  backgroundImage: booking.bookingUserImage !=
                                      null &&
                                      booking.bookingUserImage!.isNotEmpty
                                      ? NetworkImage(booking.bookingUserImage!)
                                      : AssetImage('assets/images/profile.png')
                                  as ImageProvider,
                                  radius: 20.0, // Reduced radius
                                ),
                                SizedBox(width: 12.0), // Reduced spacing
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        booking.bookingUserName,
                                        style: TextStyle(
                                          fontSize: 16.0, // Reduced font size
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Text(
                                        booking.bookingUserPhone,
                                        style: TextStyle(
                                          fontSize: 14.0, // Reduced font size
                                          color: Colors.grey[600],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      '${booking.bookingDistance} Km',
                                      style: TextStyle(
                                        fontSize: 14.0, // Reduced font size
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      '₹${booking.bookingTotalPrice}',
                                      style: TextStyle(
                                        fontSize: 14.0, // Reduced font size
                                        fontWeight: FontWeight.bold,
                                        color: Colors.green,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Divider(height: 8.0), // Reduced divider height
                            ListTile(
                              leading: Image.asset(
                                'assets/images/dot1.png',
                                width: 16.0, // Reduced size
                              ),
                              title: Text(
                                '${booking.bookingFromName}',
                                style: TextStyle(
                                    fontSize: 14.0), // Adjusted font size
                              ),
                              subtitle: Text(
                                '${booking.bookingFromAddress}',
                                style: TextStyle(
                                    fontSize: 12.0), // Adjusted font size
                              ),
                            ),
                            Align(
                              alignment: Alignment.topLeft,
                              child: Image.asset(
                                'assets/images/dot_line.png',
                                width: 40.0, // Reduced size
                                height: 30.0, // Reduced size
                              ),
                            ),
                            ListTile(
                              leading: Image.asset(
                                'assets/images/location.png',
                                width: 16.0, // Reduced size
                              ),
                              title: Text(
                                '${booking.bookingToName}',
                                style: TextStyle(
                                    fontSize: 14.0), // Adjusted font size
                              ),
                              subtitle: Text(
                                '${booking.bookingToAddress}',
                                style: TextStyle(
                                    fontSize: 12.0), // Adjusted font size
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 100.0, // Reduced width
                                  child: ElevatedButton(
                                    onPressed: () {
                                      // Decline action
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Color(0xFFEEF4FF),
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(15.0),
                                        side: BorderSide(
                                          color: Color(0xFF4181FF),
                                          width: 1.5,
                                        ),
                                      ),
                                      padding:
                                      EdgeInsets.symmetric(vertical: 12.0),
                                    ),
                                    child: Text(
                                      'Decline',
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontFamily: 'Poppins Medium',
                                        color: Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(width: 16.0), // Reduced spacing
                                SizedBox(
                                  width: 100.0, // Reduced width
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          Color(0xFF4181FF),
                                          Color(0xFF274E99),
                                        ],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      ),
                                      borderRadius: BorderRadius.circular(15.0),
                                    ),
                                    child: ElevatedButton(
                                      onPressed: () {
                                        int bookingId = booking.bookingID;
                                        String image = booking
                                            .bookingUserImage ??
                                            'default_image_path'; // Use a default image path if null
                                        String name = booking.bookingUserName ??
                                            'Unknown'; // Default name if null
                                        String number = booking
                                            .bookingUserPhone ??
                                            'Unknown'; // Default phone number if null
                                        double distance =
                                            booking.bookingDistance;
                                        double amount =
                                            booking.bookingTotalPrice;
                                        String from = booking.bookingFromName ??
                                            'Unknown location'; // Default from location
                                        String to = booking.bookingToName ??
                                            'Unknown location'; // Default to location
                                        String fromAddress = booking
                                            .bookingFromAddress ??
                                            'Unknown address'; // Default from address
                                        String toAddress = booking
                                            .bookingToAddress ??
                                            'Unknown address'; // Default to address

                                        acceptAPI(
                                          bookingId,
                                          image,
                                          name,
                                          number,
                                          distance,
                                          amount,
                                          from,
                                          to,
                                          fromAddress,
                                          toAddress,
                                        );
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.transparent,
                                        shadowColor: Colors.transparent,
                                        padding: EdgeInsets.symmetric(
                                            vertical: 12.0),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(15.0),
                                        ),
                                      ),
                                      child: Text(
                                        'Accept',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontFamily: 'Poppins Medium',
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> homeAPI() async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'agent_Home');

    bool isDialogVisible = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFF4181FF),
          ),
        );
      },
    );

    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_authToken',
    };

    try {
      var response = await http.post(url, headers: headers);
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true).pop();
        isDialogVisible = false;
      }

      if (response.statusCode == 200) {
        // Ensure Toast is shown after the request is completed
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            final List<dynamic> bookingData = data['result']['bookingData'];
            print('bbdata: $bookingData');
            totalEarnings = data['result']['Total_earning'].toString();
            todayBooking = data['result']['Total_Bookings'].toString();
            status = data['result']['AgentIsOnline'];
            _bookings = bookingData
                .map((bookingJson) => Booking.fromJson(bookingJson))
                .toList();
          });
        } else {
          String errorMessage =
              data['message'] ?? 'An error occurred. Please try again.';
          if (mounted) {
            Fluttertoast.showToast(
              msg: errorMessage,
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
            );
          }
        }
      } else {
        String errorMsg = "Request failed with status: ${response.statusCode}";
        if (mounted) {
          Fluttertoast.showToast(
            msg: errorMsg,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
      }
    } catch (e) {
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true).pop();
        isDialogVisible = false;
      }
      print('An error occurred: $e');
      if (mounted) {
        Fluttertoast.showToast(
          msg: 'An error occurred. Please try again.',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    }
  }

  Future<void> acceptAPI(
      int bookingId,
      String image,
      String name,
      String number,
      double distance,
      double amount,
      String from,
      String to,
      String fromAddress,
      String toAddress) async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'trip_accept');

    // Show loading dialog
    bool isDialogVisible = true; // Flag to track dialog visibility
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFF4181FF),
          ),
        );
      },
    );

    // Prepare the headers
    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_authToken', // Pass the auth token
    };

    // Prepare the body of the request
    var body = jsonEncode({
      'BookingID': bookingId,
    });

    // Send the request to update the profile
    try {
      var response = await http.post(url, headers: headers, body: body);
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog
        isDialogVisible = false;
      }
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
  Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => RideDetails(
                  image: image,
                  name: name,
                  number: number,
                  distance: distance,
                  amount: amount,
                  from: from,
                  to: to,
                  fromAddress: fromAddress,
                  toAddress: toAddress,
                  bookingId: bookingId),
            ),
          );

        } else {
          String errorMessage =
              data['message'] ?? 'An error occurred. Please try again.';
          Fluttertoast.showToast(
            msg: errorMessage,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }

        //NavigatorService.pushReplacementNamed(AppRoutes.cabHomepageScreen);
      } else if (response.statusCode == 500) {
        // Handle 500 error specifically
        Fluttertoast.showToast(
          msg: "Request failed with status: ${response.statusCode}",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      } else {
        // Handle other status codes
        Fluttertoast.showToast(
          msg: "Request failed with status: ${response.statusCode}",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    } catch (e) {
      // Handle network or other errors
      //print('Error: $e');
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog on error
        isDialogVisible = false;
      }
      print('An error occurred: $e');
    }
  }
}

Widget _buildCard(String title, String value, Color backgroundColor) {
  return Expanded(
    child: Card(
      elevation: 4.0, // Set elevation for shadow effect
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.0), // Rounded corners
      ),
      child: Container(
 constraints: BoxConstraints(
          minHeight: 180.0, // Minimum height
          minWidth: 250.0, // Minimum width
        ),

        decoration: BoxDecoration(
          color: backgroundColor, // Set custom background color here
          borderRadius:
          BorderRadius.circular(8.0), // Match border radius with the card
        ),
        padding: EdgeInsets.all(24.0), // Increased padding
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              title,
              style: TextStyle(
                  fontSize: 14.0,
                  color: Color(0xFF4181FF),
                  fontFamily: 'Poppins-SemiBold'),
            ),
            SizedBox(height: 8.0),
            Text(
              value,
              style: TextStyle(
                  fontSize: 30.0,
                  color: Color(0xFF5F5F5F),
                  fontFamily: 'Poppins-SemiBold'),
            ),
          ],
        ),
      ),
    ),
  );
}

class ProfileScreenContent extends StatefulWidget {
  @override
  _ProfileScreenContentState createState() => _ProfileScreenContentState();
}

class _ProfileScreenContentState extends State<ProfileScreenContent> {
  String? _authToken;
  String? name;
  String? number;

  Future<void> _checkAuthToken() async {
    String? token = await getToken();
    setState(() {
      _authToken = token;
    });

    if (_authToken != null) {
      print("Auth Token: $_authToken");
    } else {
      print("No auth token found");
    }
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  @override
  void initState() {
    super.initState();
    _checkAuthToken();
    profileAPI(); // Call the profile API when the page is loaded
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          'Profile',
          style: TextStyle(
            fontFamily: 'Poppins-SemiBold',
            fontSize: 20.0,
            color: Color(0xFF282828),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(1.0),
          child: Divider(
            color: Color(0xFFE6E6E6),
            thickness: 1,
            height: 1.0,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Color(0xFF9FC0FF)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade200,
                    blurRadius: 8,
                    spreadRadius: 2,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage(
                        'assets/images/profile.png'), // Replace with your image asset
                  ),
                  SizedBox(height: 12),
                  Text(
                    '$name',
                    style: TextStyle(
                      fontSize: 20,
                      fontFamily: 'Poppins-SemiBold',
                      color: Color(0xFF282828),
                    ),
                  ),
                  SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '$number',
                        style: TextStyle(
                          fontSize: 16,
                          fontFamily: 'Poppins Medium',
                          color: Color(0xFF282828),
                        ),
                      ),
                      SizedBox(width: 8),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(
                              ClipboardData(text: '+91 76784 25635'));
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Phone number copied to clipboard'),
                            ),
                          );
                        },
                        child: Icon(
                          Icons.copy,
                          color: Colors.grey,
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 30.0,
            ),
            Padding(
              padding:
              const EdgeInsets.symmetric(horizontal: 1.0, vertical: 0.0),
              child: Row(
                children: [
                  Image.asset(
                    'assets/images/user1.png',
                    width: 30.0,
                    height: 20.0,
                  ),
                  SizedBox(
                    width: 10.0,
                  ),
                  Text(
                    'Profile',
                    style: TextStyle(
                        fontFamily: 'Poppins Medium',
                        fontSize: 15.0,
                        color: Color(0xFF282828)),
                  ),
                  Spacer(),
                  Image.asset(
                    'assets/images/right_arrow1.png',
                    width: 25.0,
                    height: 15.0,
                  ),
                ],
              ),
            ),
            Padding(
              padding:
              const EdgeInsets.symmetric(horizontal: 1.0, vertical: 25.0),
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
 MaterialPageRoute(
                        builder: (context) => DocumentAndEarningsScreen()),
                  );

                },
                child: Row(
                  children: [
                    Image.asset(
                      'assets/images/document.png',
                      width: 30.0,
                      height: 22.0,
                    ),
                    SizedBox(width: 10.0),
                    Text(
                      'My Documents and Earnings',
                      style: TextStyle(
                          fontFamily: 'Poppins Medium',
                          fontSize: 15.0,
                          color: Color(0xFF282828)),
                    ),
                    Spacer(),
                    Image.asset(
                      'assets/images/right_arrow1.png',
                      width: 25.0,
                      height: 15.0,
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding:
              const EdgeInsets.symmetric(horizontal: 1.0, vertical: 0.0),
              child: Row(
                children: [
                  Image.asset(
                    'assets/images/rides.png',
                    width: 30.0,
                    height: 22.0,
                  ),
                  SizedBox(
                    width: 10.0,
                  ),
                  Text(
                    'My Rides',
                    style: TextStyle(
                        fontFamily: 'Poppins Medium',
                        fontSize: 15.0,
                        color: Color(0xFF282828)),
                  ),
                  Spacer(),
                  Image.asset(
                    'assets/images/right_arrow1.png',
                    width: 25.0,
                    height: 15.0,
                  ),
                ],
              ),
            ),
            Padding(
              padding:
              const EdgeInsets.symmetric(horizontal: 1.0, vertical: 25.0),
              child: Row(
                children: [
                  Image.asset(
                    'assets/images/logout.png',
                    width: 30.0,
                    height: 22.0,
                  ),
                  SizedBox(
                    width: 10.0,
                  ),
                  Text(
                    'Logout',
                    style: TextStyle(
                        fontFamily: 'Poppins Medium',
                        fontSize: 15.0,
                        color: Color(0xFFFF2929)),
                  ),
                  Spacer(),
                  Image.asset(
                    'assets/images/right_arrow1.png',
                    width: 25.0,
                    height: 15.0,
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<void> profileAPI() async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'view_agent_info');

    bool isDialogVisible = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFF4181FF),
          ),
        );
      },
    );

    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_authToken',
    };

    try {
      var response = await http.post(url, headers: headers);
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true).pop();
        isDialogVisible = false;
      }

      if (response.statusCode == 200) {
        // Ensure Toast is shown after the request is completed
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          name = data['data']['UserName'];
          number = data['data']['UserPhone'];
          print("Name: $name, Phone: $number");
        } else {
          String errorMessage =
              data['message'] ?? 'An error occurred. Please try again.';
          if (mounted) {
            Fluttertoast.showToast(
              msg: errorMessage,
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
            );
          }
        }
      } else {
        String errorMsg = "Request failed with status: ${response.statusCode}";
        if (mounted) {
          Fluttertoast.showToast(
            msg: errorMsg,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
      }
    } catch (e) {
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true).pop();
        isDialogVisible = false;
      }
      print('An error occurred: $e');
      if (mounted) {
        Fluttertoast.showToast(
          msg: 'An error occurred. Please try again.',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    }
  }
}

class OnlineOfflineSwitch extends StatefulWidget {
  final int status; // 1 means online, 0 means offline

  OnlineOfflineSwitch({required this.status});

  @override
  _OnlineOfflineSwitchState createState() => _OnlineOfflineSwitchState();
}

class _OnlineOfflineSwitchState extends State<OnlineOfflineSwitch> {
  late bool isOnline;

  @override
  void initState() {
    super.initState();
    // Initialize the state based on the passed status (1 or 0)
    isOnline = widget.status == 1;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          isOnline = !isOnline;
        });
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        width: 100,
        height: 42,
        padding: EdgeInsets.only(
          left: isOnline ? 10.0 : 4.0,
          right: isOnline ? 4.0 : 10.0,
        ),
        decoration: BoxDecoration(
          color: isOnline ? Colors.green : Colors.red,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimatedAlign(
              duration: Duration(milliseconds: 300),
              alignment:
              isOnline ? Alignment.centerRight : Alignment.centerLeft,
              curve: Curves.easeInOut,
              child: Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
              ),
            ),
            AnimatedAlign(
              duration: Duration(milliseconds: 300),
              alignment:
              isOnline ? Alignment.centerLeft : Alignment.centerRight,
              curve: Curves.easeInOut,
              child: Text(
                isOnline ? "Offline" : "Online",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Poppins Medium',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Booking {
  final int bookingID;
  final int bookingUserID;
  final String bookingUserName;
  final String? bookingUserImage; // Nullable field
  final String bookingUserPhone;
  final DateTime? bookingDate; // Changed to DateTime?
  final double bookingTotalPrice;
  final double bookingDistance;
  final double bookingFromLatitude;
  final double bookingFromLongitude;
  final String bookingFromName;
  final String bookingFromAddress;
  final double bookingToLatitude;
  final double bookingToLongitude;
  final String bookingToName;
  final String bookingToAddress;

  Booking({
    required this.bookingID,
    required this.bookingUserID,
    required this.bookingUserName,
    this.bookingUserImage, // Allow null
    required this.bookingUserPhone,
    required this.bookingDate,
    required this.bookingTotalPrice,
    required this.bookingDistance,
    required this.bookingFromLatitude,
    required this.bookingFromLongitude,
    required this.bookingFromName,
    required this.bookingFromAddress,
    required this.bookingToLatitude,
    required this.bookingToLongitude,
    required this.bookingToName,
    required this.bookingToAddress,
  });

  factory Booking.fromJson(Map<String, dynamic> json) {
    double _parseToDouble(dynamic value) {
      if (value is double) {
        return value;
      } else if (value is String) {
        return double.tryParse(value) ?? 0.0;
      } else {
        return 0.0;
      }
    }

    print('BookingTotalPrice from JSON: ${json['BookingTotalPrice']}');

    // Parsing date and logging warnings for nulls
    final String bookingDateString = json['BookingDate'] ?? '';
    final DateTime? bookingDate = bookingDateString.isNotEmpty
        ? DateTime.tryParse(bookingDateString)
        : null;

    return Booking(
      bookingID: json['BookingID'] ?? 0,
      bookingUserID: json['BookingUserID'] ?? 0,
      bookingUserName: json['BookingUserName'] ?? '',
      bookingUserImage: json['BookingUserImage'],
      // Nullable field
      bookingUserPhone: json['BookingUserPhone'] ?? '',
      bookingDate: bookingDate,
      bookingTotalPrice: _parseToDouble(json['BookingTotalPrice']),

      bookingDistance: _parseToDouble(json['BookingDistance']),
      bookingFromLatitude: _parseToDouble(json['BookingFromLatitude']),
      bookingFromLongitude: _parseToDouble(json['BookingFromLongitude']),
      bookingFromName: json['BookingFromName'] ?? '',
      bookingFromAddress: json['BookingFromAddress'] ?? '',
      bookingToLatitude: _parseToDouble(json['BookingToLatitude']),
      bookingToLongitude: _parseToDouble(json['BookingToLongitude']),
      bookingToName: json['BookingToName'] ?? '',
      bookingToAddress: json['BookingToAddress'] ?? '',
    );
  }

  void validate() {
    if (bookingID == 0 || bookingUserName.isEmpty) {
      print('Warning: Essential booking data is missing!');
    }
    if (bookingDate == null) {
      print('Warning: Booking date is invalid or missing.');
    }
  }
*/
