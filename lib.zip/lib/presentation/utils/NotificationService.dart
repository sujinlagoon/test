import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fluttertickect365/presentation/car/TripDetailsPage.dart';
import 'package:http/http.dart' as http;
import '../../core/utils/navigator_service.dart';
import '../car/CabDriverRatings.dart';
import '../car/Cab_Driver_details.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  static void initialize() async {
    const AndroidInitializationSettings androidInitializationSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
        InitializationSettings(android: androidInitializationSettings);

    await _notificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        print("Notification clicked");
        // Check if the payload is valid
        if (response.payload == 'cab_screen') {
          print("Navigating to CabDriverRatings based on payload");
          // Navigate to CabDriverRatings screen
          NavigatorService.navigatorKey.currentState?.pushReplacement(
            MaterialPageRoute(builder: (context) => CabDriverRatings()),
          );
        } else if (response.payload == 'CabDriverDetails') {
          // Navigate to CabDriverRatings screen
          NavigatorService.navigatorKey.currentState?.pushReplacement(
            MaterialPageRoute(builder: (context) => CabDriverDetails()),
          );
        } else if (response.payload == "tripdetails") {
          // Navigate to CabDriverRatings screen
          NavigatorService.navigatorKey.currentState?.pushReplacement(
            MaterialPageRoute(builder: (context) => TripDetailsPage()),
          );
        }
      },
    );
  }

  static Future<void> showNotification({
    required String title,
    required String body,
    String? imageUrl,
  }) async {
    BigPictureStyleInformation? bigPictureStyle;

    // If there's an image URL, try to load the image
    if (imageUrl != null && imageUrl.isNotEmpty) {
      try {
        final http.Response response = await http.get(Uri.parse(imageUrl));
        if (response.statusCode == 200) {
          final ByteArrayAndroidBitmap imageBitmap =
              ByteArrayAndroidBitmap(response.bodyBytes);
          bigPictureStyle = BigPictureStyleInformation(
            imageBitmap,
            largeIcon: imageBitmap,
            contentTitle: title,
            summaryText: body,
          );
        }
      } catch (e) {
        print('Error loading notification image: $e');
      }
    }

    final NotificationDetails details = NotificationDetails(
      android: AndroidNotificationDetails(
        'my_channel_01',
        'Notifications',
        channelDescription: 'This channel is used for app notifications.',
        importance: Importance.max,
        priority: Priority.high,
        styleInformation: bigPictureStyle,
      ),
    );

    // Print some debug information
    print("NotificationDetails..");
    print("title.. $title");

    String payload = '';
    // if (title.trim() == 'test') {
    if (title.trim() == "Your Ride has ended successfully.") {
      print("Setting payload to 'cab_screen' as title matches");
      payload = 'cab_screen'; // Set payload to indicate navigation target
      // **Navigate immediately after notification is shown**
      WidgetsBinding.instance?.addPostFrameCallback((_) {
        // Navigate to CabDriverRatings screen
        NavigatorService.navigatorKey.currentState?.pushReplacement(
          MaterialPageRoute(builder: (context) => CabDriverRatings()),
        );
      });
    } else if (title.trim() == "Driver Assigned") {
      WidgetsBinding.instance?.addPostFrameCallback((_) {
        payload = 'CabDriverDetails';
        // Navigate to CabDriverRatings screen
        NavigatorService.navigatorKey.currentState?.pushReplacement(
          MaterialPageRoute(builder: (context) => CabDriverDetails()),
        );
      });
    } else if (title.trim() == "Trip started") {
      payload = 'tripdetails';
      NavigatorService.navigatorKey.currentState?.pushReplacement(
        MaterialPageRoute(builder: (context) => TripDetailsPage()),
      );
    }

    // Show the notification with the payload
    await _notificationsPlugin.show(
      0,
      title,
      body,
      details,
      payload: payload,
    );
  }
}

/*import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import '../../core/utils/navigator_service.dart';
import '../car/CabDriverRatings.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  static void initialize() async {
    const AndroidInitializationSettings androidInitializationSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
        InitializationSettings(android: androidInitializationSettings);

    await _notificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        print("response..");
        if (response.payload == 'cab_screen') {
          print("payload..");
          // Navigate to CabScreen using NavigatorService's global key
          NavigatorService.navigatorKey.currentState?.pushReplacement(
            MaterialPageRoute(builder: (context) => CabDriverRatings()),
          );
        }
      },
    );
  }

  static Future<void> showNotification({
    required String title,
    required String body,
    String? imageUrl,
  }) async {
    BigPictureStyleInformation? bigPictureStyle;

    if (imageUrl != null && imageUrl.isNotEmpty) {
      try {
        final http.Response response = await http.get(Uri.parse(imageUrl));
        if (response.statusCode == 200) {
          final ByteArrayAndroidBitmap imageBitmap =
              ByteArrayAndroidBitmap(response.bodyBytes);
          bigPictureStyle = BigPictureStyleInformation(
            imageBitmap,
            largeIcon: imageBitmap,
            contentTitle: title,
            summaryText: body,
          );
        }
      } catch (e) {
        print('Error loading notification image: $e');
      }
    }

    final NotificationDetails details = NotificationDetails(
      android: AndroidNotificationDetails(
        'my_channel_01',
        'Notifications',
        channelDescription: 'This channel is used for app notifications.',
        importance: Importance.max,
        priority: Priority.high,
        styleInformation: bigPictureStyle,
      ),
    );

    print("NotificationDetails..");
    String payload = '';
    print("title.." + title);
    // if (title.trim() == 'Your Ride has ended successfully.') {
    if (title.trim() == 'test') {
      print("cab_screen..in");
      payload = 'cab_screen'; // Set payload to indicate navigation target
      NavigatorService.navigatorKey.currentState?.pushReplacement(
        MaterialPageRoute(builder: (context) => CabDriverRatings());
    }

    await _notificationsPlugin.show(
      0,
      title,
      body,
      details,
      payload: payload,
    );
  }
}*/

/*import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;

import '../car/CabDriverRatings.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
  FlutterLocalNotificationsPlugin();

  static void initialize(BuildContext context) async {
    const AndroidInitializationSettings androidInitializationSettings =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
    InitializationSettings(android: androidInitializationSettings);

    await _notificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        if (response.payload == 'cab_screen') {
          // Navigate to CabScreen
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => CabDriverRatings()),
          );
        }
      },
    );
  }

  static Future<void> showNotification({
    required String title,
    required String body,
    String? imageUrl,
  }) async {
    BigPictureStyleInformation? bigPictureStyle;

    if (imageUrl != null && imageUrl.isNotEmpty) {
      try {
        final http.Response response = await http.get(Uri.parse(imageUrl));
        if (response.statusCode == 200) {
          final ByteArrayAndroidBitmap imageBitmap =
          ByteArrayAndroidBitmap(response.bodyBytes);
          bigPictureStyle = BigPictureStyleInformation(
            imageBitmap,
            largeIcon: imageBitmap,
            contentTitle: title,
            summaryText: body,
          );
        }
      } catch (e) {
        print('Error loading notification image: $e');
      }
    }

    final NotificationDetails details = NotificationDetails(
      android: AndroidNotificationDetails(
        'my_channel_01',
        'Notifications',
        channelDescription: 'This channel is used for app notifications.',
        importance: Importance.max,
        priority: Priority.high,
        styleInformation: bigPictureStyle,
      ),
    );

    String payload = '';
    if (title == 'Your Ride has ended successfully.') {
      payload = 'cab_screen'; // Set payload to indicate navigation target
    }

    await _notificationsPlugin.show(
      0,
      title,
      body,
      details,
      payload: payload,
    );
  }
}*/

/*
import 'dart:typed_data';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
  FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    const AndroidInitializationSettings androidInitializationSettings =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
    InitializationSettings(android: androidInitializationSettings);

    await _notificationsPlugin.initialize(initializationSettings);
  }

  static Future<void> showNotification({
    required String title,
    required String body,
    String? imageUrl,
  }) async {
    BigPictureStyleInformation? bigPictureStyle;

    if (imageUrl != null && imageUrl.isNotEmpty) {
      try {
        final http.Response response = await http.get(Uri.parse(imageUrl));
        if (response.statusCode == 200) {
          final ByteArrayAndroidBitmap imageBitmap =
          ByteArrayAndroidBitmap(response.bodyBytes);
          bigPictureStyle = BigPictureStyleInformation(
            imageBitmap,
            largeIcon: imageBitmap,
            contentTitle: title,
            summaryText: body,
          );
        }
      } catch (e) {
        print('Error loading notification image: $e');
      }
    }

    final NotificationDetails details = NotificationDetails(
      android: AndroidNotificationDetails(
        'my_channel_01',
        'Notifications',
        channelDescription: 'This channel is used for app notifications.',
        importance: Importance.max,
        priority: Priority.high,
        styleInformation: bigPictureStyle,
      ),
    );

    await _notificationsPlugin.show(
      0,
      title,
      body,
      details,
    );
  }
}*/
