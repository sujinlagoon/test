class AppConstants {
  static const String HOST = "https://ticketapp365.akprojects.co/";
  static const String MAIN_URL = HOST + "api/user/";
}
