import 'package:flutter/services.dart';

class AppSignatureHelper {
  static const MethodChannel _channel = MethodChannel('app_signature_channel');

  static Future<String?> getAppSignatures() async {
    try {
      final String? signature = await _channel.invokeMethod('getAppSignatures');
      return signature;
    } catch (e) {
      print("Failed to get app signature: $e");
      return null;
    }
  }
}
