import 'dart:convert';

BusAvailabilty seatAvailabiltyFromJson(String str) =>
    BusAvailabilty.fromJson(json.decode(str));

String seatAvailabiltyToJson(BusAvailabilty data) => json.encode(data.toJson());

class BusAvailabilty {
  String ac;
  String additionalCommission;
  String agentServiceCharge;
  String agentServiceChargeAllowed;
  String arrivalTime;
  String availCatCard;
  String availSrCitizen;
  String availableSeats;
  String availableSingleSeat;
  String avlWindowSeats;
  String boCommission;
  String boPriorityOperator;
  List<BoardingPoint> boardingTimes;
  String bookable;
  String bpDpSeatLayout;
  String busCancelled;
  String busImageCount;
  String busRoutes;
  String busType;
  String busTypeId;
  String callFareBreakUpApi;
  String cancellationCalculationTimestamp;
  String cancellationPolicy;
  String cpId;
  String departureTime;
  String destination;
  String doj;
  String dropPointMandatory;
  List<DroppingPoint> droppingTimes;
  String duration;
  String exactSearch;

  // FareDetail fareDetails;
  // String fares;
  String flatComApplicable;
  String flatSSComApplicable;
  String gdsCommission;
  String groupOfferPriceEnabled;
  String happyHours;
  String id;
  String idProofRequired;
  String imagesMetadataUrl;
  String isLMBAllowed;
  String liveTrackingAvailable;
  String maxSeatsPerTicket;
  String nextDay;
  String noSeatLayoutEnabled;
  String nonAC;
  String offerPriceEnabled;
  String operator;
  String otgEnabled;
  String partialCancellationAllowed;
  String partnerBaseCommission;
  String primaryPaxCancellable;
  String primo;
  String rbServiceId;
  String routeId;
  String rtc;
  String ssAgentAccount;
  String seater;
  String selfInventory;
  String serviceStartTime;
  String singleLadies;
  String sleeper;
  String source;
  String tatkalTime;
  String travels;
  String unAvailable;
  String vaccinatedBus;
  String vaccinatedStaff;
  String vehicleType;
  String zeroCancellationTime;
  String mTicketEnabled;
  List<Map<String, dynamic>> availableTrips;

  BusAvailabilty({
    required this.ac,
    required this.additionalCommission,
    required this.agentServiceCharge,
    required this.agentServiceChargeAllowed,
    required this.arrivalTime,
    required this.availCatCard,
    required this.availSrCitizen,
    required this.availableSeats,
    required this.availableSingleSeat,
    required this.avlWindowSeats,
    required this.boCommission,
    required this.boPriorityOperator,
    required this.boardingTimes,
    required this.bookable,
    required this.bpDpSeatLayout,
    required this.busCancelled,
    required this.busImageCount,
    required this.busRoutes,
    required this.busType,
    required this.busTypeId,
    required this.callFareBreakUpApi,
    required this.cancellationCalculationTimestamp,
    required this.cancellationPolicy,
    required this.cpId,
    required this.departureTime,
    required this.destination,
    required this.doj,
    required this.dropPointMandatory,
    required this.droppingTimes,
    required this.duration,
    required this.exactSearch,
    //  required this.fareDetails,
    //required this.fares,
    required this.flatComApplicable,
    required this.flatSSComApplicable,
    required this.gdsCommission,
    required this.groupOfferPriceEnabled,
    required this.happyHours,
    required this.id,
    required this.idProofRequired,
    required this.imagesMetadataUrl,
    required this.isLMBAllowed,
    required this.liveTrackingAvailable,
    required this.maxSeatsPerTicket,
    required this.nextDay,
    required this.noSeatLayoutEnabled,
    required this.nonAC,
    required this.offerPriceEnabled,
    required this.operator,
    required this.otgEnabled,
    required this.partialCancellationAllowed,
    required this.partnerBaseCommission,
    required this.primaryPaxCancellable,
    required this.primo,
    required this.rbServiceId,
    required this.routeId,
    required this.rtc,
    required this.ssAgentAccount,
    required this.seater,
    required this.selfInventory,
    required this.serviceStartTime,
    required this.singleLadies,
    required this.sleeper,
    required this.source,
    required this.tatkalTime,
    required this.travels,
    required this.unAvailable,
    required this.vaccinatedBus,
    required this.vaccinatedStaff,
    required this.vehicleType,
    required this.zeroCancellationTime,
    required this.mTicketEnabled,
    required this.availableTrips,
  });

  factory BusAvailabilty.fromJson(Map<String, dynamic> json) => BusAvailabilty(
        ac: json["AC"] ?? "",
        additionalCommission: json["additionalCommission"] ?? "",
        agentServiceCharge: json["agentServiceCharge"] ?? "",
        agentServiceChargeAllowed: json["agentServiceChargeAllowed"] ?? "",
        arrivalTime: json["arrivalTime"] ?? "",
        availCatCard: json["availCatCard"] ?? "",
        availSrCitizen: json["availSrCitizen"] ?? "",
        availableSeats: json["availableSeats"] ?? "",
        availableSingleSeat: json["availableSingleSeat"] ?? "",
        avlWindowSeats: json["avlWindowSeats"] ?? "",
        boCommission: json["boCommission"] ?? "",
        boPriorityOperator: json["boPriorityOperator"] ?? "",
        boardingTimes: _parseBoardingTimes(json['boardingTimes']),
        bookable: json["bookable"] ?? "",
        bpDpSeatLayout: json["bpDpSeatLayout"] ?? "",
        busCancelled: json["busCancelled"] ?? "",
        busImageCount: json["busImageCount"] ?? "",
        busRoutes: json["busRoutes"] ?? "",
        busType: json["busType"] ?? "",
        busTypeId: json["busTypeId"] ?? "",
        callFareBreakUpApi: json["callFareBreakUpApi"] ?? "",
        // Adjusted field name
        cancellationCalculationTimestamp:
            json["cancellationCalculationTimestamp"] ?? "",
        cancellationPolicy: json["cancellationPolicy"] ?? "",
        cpId: json["cpId"] ?? "",
        departureTime: json["departureTime"] ?? "",
        destination: json["destination"] ?? "",
        doj: json["doj"] ?? "",
        dropPointMandatory: json["dropPointMandatory"] ?? "",
        droppingTimes: _parseDroppingTimes(json['droppingTimes']),
        duration: json["duration"] ?? "",
        exactSearch: json["exactSearch"] ?? "",
        /*  fareDetails: json["fareDetails"] != null
              ? FareDetail.fromJson(json["fareDetails"])
              : FareDetail(totalFare: "", baseFare: ""),*/
        //fares: json["fares"] ?? "",
        flatComApplicable: json["flatComApplicable"] ?? "",
        flatSSComApplicable: json["flatSSComApplicable"] ?? "",
        gdsCommission: json["gdsCommission"] ?? "",
        groupOfferPriceEnabled: json["groupOfferPriceEnabled"] ?? "",
        happyHours: json["happyHours"] ?? "",
        id: json["id"] ?? "",
        idProofRequired: json["idProofRequired"] ?? "",
        imagesMetadataUrl: json["imagesMetadataUrl"] ?? "",
        isLMBAllowed: json["isLMBAllowed"] ?? "",
        liveTrackingAvailable: json["liveTrackingAvailable"] ?? "",
        maxSeatsPerTicket: json["maxSeatsPerTicket"] ?? "",
        nextDay: json["nextDay"] ?? "",
        noSeatLayoutEnabled: json["noSeatLayoutEnabled"] ?? "",
        nonAC: json["nonAC"] ?? "",
        offerPriceEnabled: json["offerPriceEnabled"] ?? "",
        operator: json["operator"] ?? "",
        otgEnabled: json["otgEnabled"] ?? "",
        partialCancellationAllowed: json["partialCancellationAllowed"] ?? "",
        partnerBaseCommission: json["partnerBaseCommission"] ?? "",
        primaryPaxCancellable: json["primaryPaxCancellable"] ?? "",
        primo: json["primo"] ?? "",
        rbServiceId: json["rbServiceId"] ?? "",
        routeId: json["routeId"] ?? "",
        rtc: json["rtc"] ?? "",
        ssAgentAccount: json["SSAgentAccount"] ?? "",
        seater: json["seater"] ?? "",
        selfInventory: json["selfInventory"] ?? "",
        serviceStartTime: json["serviceStartTime"] ?? "",
        singleLadies: json["singleLadies"] ?? "",
        sleeper: json["sleeper"] ?? "",
        source: json["source"] ?? "",
        tatkalTime: json["tatkalTime"] ?? "",
        travels: json["travels"] ?? "",
        unAvailable: json["unAvailable"] ?? "",
        vaccinatedBus: json["vaccinatedBus"] ?? "",
        vaccinatedStaff: json["vaccinatedStaff"] ?? "",
        vehicleType: json["vehicleType"] ?? "",
        zeroCancellationTime: json["zeroCancellationTime"] ?? "",
        mTicketEnabled: json["mTicketEnabled"] ?? "",
        availableTrips: json["availableTrips"] != null
            ? List<Map<String, dynamic>>.from(json["availableTrips"])
            : [],
      );

  static List<BoardingPoint> _parseBoardingTimes(dynamic data) {
    if (data is List) {
      return List<BoardingPoint>.from(data
          .map((x) => BoardingPoint.fromJson(Map<String, dynamic>.from(x))));
    } else if (data is Map) {
      return [BoardingPoint.fromJson(Map<String, dynamic>.from(data))];
    } else {
      return [];
    }
  }

  static List<DroppingPoint> _parseDroppingTimes(dynamic data) {
    if (data is List) {
      return List<DroppingPoint>.from(data
          .map((x) => DroppingPoint.fromJson(Map<String, dynamic>.from(x))));
    } else if (data is Map) {
      return [DroppingPoint.fromJson(Map<String, dynamic>.from(data))];
    } else {
      return [];
    }
  }

  Map<String, dynamic> toJson() => {
        "AC": ac,
        "additionalCommission": additionalCommission,
        "agentServiceCharge": agentServiceCharge,
        "agentServiceChargeAllowed": agentServiceChargeAllowed,
        "arrivalTime": arrivalTime,
        "availCatCard": availCatCard,
        "availSrCitizen": availSrCitizen,
        "availableSeats": availableSeats,
        "availableSingleSeat": availableSingleSeat,
        "avlWindowSeats": avlWindowSeats,
        "boCommission": boCommission,
        "boPriorityOperator": boPriorityOperator,
        "boardingTimes": boardingTimes.map((x) => x.toJson()).toList(),
        "bookable": bookable,
        "bpDpSeatLayout": bpDpSeatLayout,
        "busCancelled": busCancelled,
        "busImageCount": busImageCount,
        "busRoutes": busRoutes,
        "busType": busType,
        "busTypeId": busTypeId,
        "callFareBreakUpApi": callFareBreakUpApi, // Adjusted field name
        "cancellationCalculationTimestamp": cancellationCalculationTimestamp,
        "cancellationPolicy": cancellationPolicy,
        "cpId": cpId,
        "departureTime": departureTime,
        "destination": destination,
        "doj": doj,
        "dropPointMandatory": dropPointMandatory,

        "duration": duration,
        "exactSearch": exactSearch,
        // "fareDetails": fareDetails.toJson(),
        //"fares": fares,
        "flatComApplicable": flatComApplicable,
        "flatSSComApplicable": flatSSComApplicable,
        "gdsCommission": gdsCommission,
        "groupOfferPriceEnabled": groupOfferPriceEnabled,
        "happyHours": happyHours,
        "id": id,
        "idProofRequired": idProofRequired,
        "imagesMetadataUrl": imagesMetadataUrl,
        "isLMBAllowed": isLMBAllowed,
        "liveTrackingAvailable": liveTrackingAvailable,
        "maxSeatsPerTicket": maxSeatsPerTicket,
        "nextDay": nextDay,
        "noSeatLayoutEnabled": noSeatLayoutEnabled,
        "nonAC": nonAC,
        "offerPriceEnabled": offerPriceEnabled,
        "operator": operator,
        "otgEnabled": otgEnabled,
        "partialCancellationAllowed": partialCancellationAllowed,
        "partnerBaseCommission": partnerBaseCommission,
        "primaryPaxCancellable": primaryPaxCancellable,
        "primo": primo,
        "rbServiceId": rbServiceId,
        "routeId": routeId,
        "rtc": rtc,
        "SSAgentAccount": ssAgentAccount,
        "seater": seater,
        "selfInventory": selfInventory,
        "serviceStartTime": serviceStartTime,
        "singleLadies": singleLadies,
        "sleeper": sleeper,
        "source": source,
        "tatkalTime": tatkalTime,
        "travels": travels,
        "unAvailable": unAvailable,
        "vaccinatedBus": vaccinatedBus,
        "vaccinatedStaff": vaccinatedStaff,
        "vehicleType": vehicleType,
        "zeroCancellationTime": zeroCancellationTime,
        "mTicketEnabled": mTicketEnabled,
        "availableTrips": List<dynamic>.from(availableTrips),
      };
}

class FareDetail {
  String totalFare;
  String baseFare;

  FareDetail({
    required this.totalFare,
    required this.baseFare,
  });

  factory FareDetail.fromJson(Map<String, dynamic> json) => FareDetail(
        totalFare: json["totalFare"] ?? "",
        baseFare: json["baseFare"] ?? "",
      );

  Map<String, dynamic> toJson() => {
        "totalFare": totalFare,
        "baseFare": baseFare,
      };
}

class BoardingPoint {
  String address;
  String bpId;
  String bpName;
  String contactNumber;
  String landmark;
  String location;
  String prime;
  String time;

  BoardingPoint({
    required this.address,
    required this.bpId,
    required this.bpName,
    required this.contactNumber,
    required this.landmark,
    required this.location,
    required this.prime,
    required this.time,
  });

  factory BoardingPoint.fromJson(Map<String, dynamic> json) => BoardingPoint(
        address: json["address"] ?? "",
        bpId: json["bpId"] ?? "",
        bpName: json["bpName"] ?? "",
        contactNumber: json["contactNumber"] ?? "",
        landmark: json["landmark"] ?? "",
        location: json["location"] ?? "",
        prime: json["prime"] ?? "",
        time: json["time"] ?? "",
      );

  Map<String, dynamic> toJson() => {
        "address": address,
        "bpId": bpId,
        "bpName": bpName,
        "contactNumber": contactNumber,
        "landmark": landmark,
        "location": location,
        "prime": prime,
        "time": time,
      };
}

class DroppingPoint {
  String address;
  String bpId;
  String bpName;
  String contactNumber;
  String landmark;
  String location;
  String prime;
  String time;

  DroppingPoint({
    required this.address,
    required this.bpId,
    required this.bpName,
    required this.contactNumber,
    required this.landmark,
    required this.location,
    required this.prime,
    required this.time,
  });



  factory DroppingPoint.fromJson(Map<String, dynamic> json) => DroppingPoint(
        address: json["address"] ?? "",
        bpId: json["bpId"] ?? "",
        bpName: json["bpName"] ?? "",
        contactNumber: json["contactNumber"] ?? "",
        landmark: json["landmark"] ?? "",
        location: json["location"] ?? "",
        prime: json["prime"] ?? "",
        time: json["time"] ?? "",
      );

  Map<String, dynamic> toJson() => {
        "address": address,
        "bpId": bpId,
        "bpName": bpName,
        "contactNumber": contactNumber,
        "landmark": landmark,
        "location": location,
        "prime": prime,
        "time": time,
      };
}
