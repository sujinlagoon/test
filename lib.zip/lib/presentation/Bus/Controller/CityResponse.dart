// To parse this JSON data, do
//
//     final cities = citiesFromJson(jsonString);

import 'dart:convert';

Cities citiesFromJson(String str) => Cities.fromJson(json.decode(str));

String citiesToJson(Cities data) => json.encode(data.toJson());

class Cities {
  bool status;
  String message;
  Data data;

  Cities({
    required this.status,
    required this.message,
    required this.data,
  });

  factory Cities.fromJson(Map<String, dynamic> json) => Cities(
    status: json["status"],
    message: json["message"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data.toJson(),
  };
}

class Data {
  List<City> popularcities;
  List<City> cities;

  Data({
    required this.popularcities,
    required this.cities,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    popularcities: List<City>.from(json["popularcities"].map((x) => City.fromJson(x))),
    cities: List<City>.from(json["cities"].map((x) => City.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "popularcities": List<dynamic>.from(popularcities.map((x) => x.toJson())),
    "cities": List<dynamic>.from(cities.map((x) => x.toJson())),
  };
}

class City {
  int cityId;
  int cityStateId;
  String cityName;
  CityLocationType cityLocationType;
  String cityLatitude;
  String cityLongitude;
  String cityState;

  City({
    required this.cityId,
    required this.cityStateId,
    required this.cityName,
    required this.cityLocationType,
    required this.cityLatitude,
    required this.cityLongitude,
    required this.cityState,
  });

  factory City.fromJson(Map<String, dynamic> json) => City(
    cityId: json["CityID"],
    cityStateId: json["CityStateID"],
    cityName: json["CityName"],
    cityLocationType: cityLocationTypeValues.map[json["CityLocationType"]]!,
    cityLatitude: json["CityLatitude"],
    cityLongitude: json["CityLongitude"],
    cityState: json["CityState"],
  );

  Map<String, dynamic> toJson() => {
    "CityID": cityId,
    "CityStateID": cityStateId,
    "CityName": cityName,
    "CityLocationType": cityLocationTypeValues.reverse[cityLocationType],
    "CityLatitude": cityLatitude,
    "CityLongitude": cityLongitude,
    "CityState": cityState,
  };
}

enum CityLocationType {
  CITY
}

final cityLocationTypeValues = EnumValues({
  "CITY": CityLocationType.CITY
});

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap = map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
