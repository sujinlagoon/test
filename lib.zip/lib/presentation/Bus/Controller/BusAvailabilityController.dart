import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:fluttertickect365/presentation/Bus/Controller/CityResponse.dart';
import 'package:fluttertickect365/presentation/utils/AppConstants.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:oauth1/oauth1.dart' as oauth1;
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../cab_homepage_screen/apiModel/sharedPref.dart';
import 'BusAvailability.dart';
import 'package:http/http.dart' as http;

class BusAvailabilityController extends GetxController {
  late Future<List<BusAvailabilty>> busList;
  Cities? cities;
  List<City> listPopular = [];
  List<City> listCities = [];
  TextEditingController searchController = TextEditingController();
  String? fromLocation;
  String? toLocation;
  String? fromLocationCode;
  String? toLocationCode;
  List<City> filteredCities = [];
  List<BoardingPoint> boardingList = [];
  List<DroppingPoint> droppingList = [];
  bool isLoading = false;
  int fromId = 0;
  int toId = 0;
  Timer? _debounce;
  final String consumerKey = 'MCycaVxF6XVV0ImKgqFPBAncx0prPp';
  final String consumerSecret = '5f0lpy9heMvXNQ069lQPNMomysX6rt';
  List<Map<String, dynamic>> filterList = [];

  Future<List<BusAvailabilty>> availabilitySeatGet(
      int fromId, int toId, String date) async {
    final clientCredentials =
        oauth1.ClientCredentials(consumerKey, consumerSecret);
    final authClient = oauth1.Client(
        oauth1.SignatureMethods.hmacSha1, clientCredentials, null);

    /*final url = Uri.parse(
        'http://api.seatseller.travel/availabletrips?source=3&destination=102&doj=2024-12-26');*/
    final url = Uri.parse(
        'http://api.seatseller.travel/availabletrips?source=$fromId&destination=$toId&doj=$date');
    final response = await authClient.get(url);

    if (response.statusCode == 200) {
      try {
        final data = seatAvailabiltyFromJson(response.body);
        boardingList = data.boardingTimes;
        droppingList = data.droppingTimes;
        print("Full Response: ${response.body}");

        if (data != null) {
          List<BusAvailabilty> seatList = List<BusAvailabilty>.from(
              data.availableTrips.map((trip) => BusAvailabilty.fromJson(trip)));

          print("seatlistcheck: $seatList");
          return seatList;
        } else {
          print("Error: Unable to parse seat availability data.");
          return []; // Return empty list if parsing fails
        }
      } catch (e) {
        print("Error while parsing the response: $e");
        return []; // Return empty list on error
      }
    } else {
      print("Error: ${response.statusCode} - ${response.body}");
      return []; // Return empty list if the request fails
    }
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  selectArrivalDeparture(String place) async {

    if (place.isEmpty) {
      filteredCities.clear();
      //update();
      return;
    }
    isLoading = true;
    update();

    try {
      String? token = await getToken();
      final bearerToken = token;

      final url = Uri.parse('https://ticketapp365.akprojects.co/api/bus/SearchPageCities');

      var body = jsonEncode({'search': place});

      var headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $bearerToken',
      };

      final response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        cities = citiesFromJson(response.body);
        listPopular = cities!.data.popularcities;
        listCities = cities!.data.cities;
        filteredCities = listCities;
        update();
      } else {
        print('Failed to fetch city data');
      }
    } catch (e) {
      // Handle any errors that occur during the API call
      print('Error while fetching city data: $e');
    } finally {
      // Dismiss loading spinner
      isLoading = false;
      update(); // Update UI to hide loading spinner
    }
  }

  void getId() async {
    final fetchFromId = await sharedPref.getCityID();
    final fetchToId = await sharedPref.getDepartureCityID();
    fromId = fetchFromId ?? 0;
    toId = fetchToId ?? 0;
  }

  void setFromLocation(String location, String code) {
    fromLocationCode = code;
    fromLocation = location;
    update();
  }

  void setToLocation(String location, String code) {
    toLocationCode = code;
    toLocation = location;
    update();
  }

  void filterCities(String query) {
    String trimUnwantedSpaces = query.trim();
    if (trimUnwantedSpaces.isEmpty) {
      filteredCities = List.from(listCities);
    } else {
      filteredCities = listCities.where((city) => city.cityName.toLowerCase().startsWith(trimUnwantedSpaces.toLowerCase())).toList();
    }
    update();
  }
/*  void onSearchTextChanged(String query) {
    if (_debounce?.isActive ?? false) _debounce!.cancel();

    _debounce = Timer(Duration(milliseconds: 10), () {
      selectArrivalDeparture(query);
    });
  }*/


/*  @override
  void onInit() {
    print("--------------------------------------Inside");
    super.onInit();
    getId();
   selectArrivalDeparture('');
    searchController.addListener(() {
      filterCities(searchController.text);
    });
  }*/
}

