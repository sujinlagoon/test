import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertickect365/presentation/Bus/UI/BookingPage.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import '../../cab_homepage_screen/apiModel/sharedPref.dart';
import '../Controller/BusAvailability.dart';
import '../Controller/BusAvailabilityController.dart';

class BuslistScreen extends StatefulWidget {
  @override
  _BuslistScreenState createState() => _BuslistScreenState();
}

class _BuslistScreenState extends State<BuslistScreen> {
  String selectedContainer = '';
  String selectedContainerList = '';
  String? fromLocation = '';
  String? toLocation = '';
  int fromId = 0;
  int toId = 0;
  late Future<List<BusAvailabilty>> busList;
  BusAvailabilityController vv = Get.put(BusAvailabilityController());
  bool isLoading = true;
  bool _isACSelected = false;


  @override
  void initState() {
    super.initState();
    getToken();
    vv.availabilitySeatGet(3, 102, '2024-12-26');
    busList = vv.busList;
  }

  void getToken() async {
    final fetchedLocation = await sharedPref.getCheckID();
    final fetchedLocation1 = await sharedPref.getCheckID1();
    final fetchFromId = await sharedPref.getCityID();
    final fetchToId = await sharedPref.getDepartureCityID();;

    setState(() {
      fromLocation = fetchedLocation ?? 'Select a location';
      toLocation = fetchedLocation1 ?? 'Select a location';
      fromId = fetchFromId ?? 0;
      toId = fetchToId ?? 0;
    });
  }

  String? _selectedChip;
  List<String> staticBusList = [
    'AC',
    'Non-AC',
    'Sleeper',
    'Semi-Sleeper',
    'Seater',
  ];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    setState(() {
      getToken();
      busList = vv.availabilitySeatGet(3, 102, '2024-12-26');


    });
  }

  void _onContainerClick(String container) {
    setState(() {
      if (selectedContainer == container) {
        selectedContainer = '';
      } else {
        selectedContainer = container;
      }
    });
  }

  void _onContainerClickList(String container) {
    setState(() {
      if (selectedContainer == container) {
        selectedContainer = '';
      } else {
        selectedContainer = container;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    /* SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Colors.black,
        statusBarBrightness: Brightness.dark,
      ),
    );*/

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                  top: 50.0,
                  left: 15.0,
                  right: 15.0,
                  bottom: 20.0,
                ),
                child: Row(
                  children: [
                    Image.asset(
                      'assets/images/arrow_left.png',
                      width: 20.0,
                    ),
                    SizedBox(width: 15.0),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              '$fromLocation - $toLocation',
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w600,
                                fontSize: 13.0,
                                color: Color(0xFF282828),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            SvgPicture.asset(
                              'assets/images/edit_icon.svg',
                            ),


                          ],
                        ),
                        Text(
                          'Fri, 24 June',
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                            fontSize: 14.0,
                            color: Color(0xFF8C8C8C),
                          ),
                        ),
                      ],
                    ),
                    Spacer(),
                    /*Text(
                      '70 Busses',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 14.0,
                        color: Color(0xFF8C8C8C),
                      ),
                    ),*/
                  ],
                ),
              ),
              const Divider(
                thickness: 1, // Thickness of the line
                color: Color(0xFFE0E0E0), // Light gray color for the divider
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 15),
            child: Row(
              children: [
                customContainer(
                  context,
                  text: 'Filters',
                  svgIconPath: 'assets/images/filter.svg',
                  onTap: () {
                    _onContainerClick('Filters');
                    showFilterBottomSheet(context);
                  },
                  backgroundColor: selectedContainer == 'Filters'
                      ? Color(0xFF5B93FF)
                      : Colors.white,
                  textColor: selectedContainer == 'Filters'
                      ? Colors.white
                      : Color(0xFF8C8C8C),
                ),
                SizedBox(width: 10),
                customContainer(
                  context,
                  text: 'Sort',
                  svgIconPath: 'assets/images/sort.svg',
                  onTap: () {
                    _onContainerClick('Sort');
                    _showSortOptions(context);
                  },
                  backgroundColor: selectedContainer == 'Sort'
                      ? Color(0xFF5B93FF)
                      : Colors.white,
                  textColor: selectedContainer == 'Sort'
                      ? Colors.white
                      : Color(0xFF8C8C8C),
                ),
                SizedBox(width: 10),
                /*  Container(
                  height: 70.0,
                  width: MediaQuery.sizeOf(context).width * 0.45,
                  child: FutureBuilder<List<BusAvailabilty>>(
                    future: busList,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator());
                      } else if (snapshot.hasError) {
                        return Center(child: Text('Error loading buses.'));
                      } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                        return Center(child: Text('No buses available.'));
                      } else {
                        return ListView.builder(
                          scrollDirection: Axis.horizontal,
                          // Horizontal scrolling
                          itemCount: vv.filterList.length,
                          itemBuilder: (context, index) {
                            final bus = vv.filterList[index];
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8.0),
                              child: Chip(
                                label: Text(
                                  bus['AC'] == "true"
                                      ? "AC"
                                      : bus['sleeper'] == "true"
                                          ? "Sleeper"
                                          : bus['seater'] == "true"
                                              ? "Seater"
                                              : "Non AC",
                                  style: TextStyle(color: Colors.black),
                                ),
                                backgroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                  side: BorderSide(color: Colors.grey.shade300),
                                ),
                              ),
                            );
                          },
                        );
                      }
                    },
                  ),
                ),*/
                Container(
                  height: 70.0,
                  width: MediaQuery.sizeOf(context).width * 0.45,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: staticBusList.length,
                    itemBuilder: (context, index) {
                      final busType = staticBusList[index];
                      final isSelected = _selectedChip == busType;

                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedChip = busType;
                              vv.availabilitySeatGet(3, 102, '2024-12-26');
                            });
                          },
                          child: Chip(
                            label: Text(
                              busType,
                              style: TextStyle(
                                color: isSelected ? Colors.white : Colors.black,
                              ),
                            ),
                            backgroundColor:
                                isSelected ? Color(0xFF5B93FF) : Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              side: BorderSide(
                                color: isSelected
                                    ? Color(0xFF5B93FF)
                                    : Colors.grey.shade300,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: 10),
          Container(
            height: MediaQuery.sizeOf(context).height * 0.70,
            child: FutureBuilder<List<BusAvailabilty>>(
              future: busList, // Use the busList future
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(child: Text('No buses available'));
                } else {
                  return ListView.builder(
                    itemCount: snapshot.data!.length,
                    itemBuilder: (context, index) {
                      final bus = snapshot
                          .data![index]; // Access each BusAvailabilty object
                      final boardingTimes =
                          bus.boardingTimes as List<BoardingPoint>;
                      final droppingTimes =
                          bus.droppingTimes as List<DroppingPoint>;

                      return Column(
                        children: [
                          customBusList(
                            context,
                            busName: bus.travels,
                            rating: 0.00,
                            busType: bus.busType,
                            startTimes: formatBoardingTimes(boardingTimes),
                            endTimes: formatDroppingTimes(droppingTimes),
                            totalHours: bus.duration,
                            amount: 100,
                            seats: bus.availableSeats,
                            busDetail: bus.arrivalTime,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => BookingPage(),
                                ),
                              );
                            },
                          ),
                          SizedBox(height: 10),
                        ],
                      );
                    },
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  List<String> formatBoardingTimes(List<BoardingPoint> boardingTimes) {
    String formattedTimes = boardingTimes.map((point) => point.time).join(', ');
    return formatTimeFromMinutesString(formattedTimes);
  }

  List<String> formatDroppingTimes(List<DroppingPoint> droppingTimes) {
    String formattedTimes = droppingTimes.map((point) => point.time).join(', ');
    return formatTimeFromMinutesString(formattedTimes);
  }

  List<String> formatTimeFromMinutesString(String timeInMinutes) {
    List<String> formattedTimes = [];
    // Split the comma-separated string into a list
    List<String> timeList = timeInMinutes.split(',');

    for (String time in timeList) {
      int? totalMinutes = int.tryParse(time.trim());
      if (totalMinutes == null) {
        throw FormatException("Invalid input: '$time' is not a valid number.");
      }

      int hours = totalMinutes ~/ 60;
      int minutes = totalMinutes % 60;
      String period = hours >= 12 ? "PM" : "AM";
      hours = hours % 12;
      if (hours == 0) {
        hours = 12;
      }
      String formattedTime =
          "${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')} $period";
      formattedTimes.add(formattedTime);
    }

    return formattedTimes;
  }

  Widget customBusList(
    BuildContext context, {
    required String busName,
    required double rating,
    required String busType,
    required List<String> startTimes,
    required List<String> endTimes,
    required String totalHours,
    required int amount,
    required String seats,
    required String busDetail,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: Color(0xFFE1E1E1), // Set the border color
              width: 2.0, // Set the border width
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(busName,
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Poppins',
                                  color: Color(0xFF282828))),
                          Spacer(),
                          Text(
                            '₹ $amount',
                            style: TextStyle(
                              fontSize: 18,
                              color: Color(0xFF282828),
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 4),
                      Text(busType,
                          style: TextStyle(
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w400,
                              color: Color(0xFF8C8C8C))),
                      SizedBox(height: 12),
                      if (startTimes.isNotEmpty &&
                          endTimes.isNotEmpty &&
                          startTimes.length == endTimes.length)
                        ...List.generate(
                          startTimes.length,
                          (index) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      '${startTimes[index]} - ${endTimes[index]}',
                                      style: TextStyle(
                                        fontSize: 18,
                                        color: Color(0xFF282828),
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    SizedBox(width: 8),
                                    Text(
                                      '($totalHours)',
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Color(0xFF8C8C8C),
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      SizedBox(height: 12),
                      Row(
                        children: [
                          Text(
                            '$seats Seats Left',
                            style: TextStyle(
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              color: int.tryParse(seats) != null &&
                                      int.parse(seats) < 20
                                  ? Colors.red
                                  : Color(
                                      0xFF3EB557), // Green color for 20 or more seats
                            ),
                          ),
                          Spacer(),
                          Text(
                            'Bus Details',
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                color: Color(0xFF2D88FF)),
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget customContainer(
    BuildContext context, {
    required String text,
    required String svgIconPath,
    required VoidCallback onTap,
    required Color backgroundColor,
    required Color textColor,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: MediaQuery.sizeOf(context).height * 0.04,
        width: MediaQuery.sizeOf(context).width * 0.20,
        decoration: BoxDecoration(
          color: backgroundColor, // Dynamic background color
          border: Border.all(color: Color(0xFFD7D4D4), width: 0.2),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SvgPicture.asset(
              svgIconPath,
              color: textColor, // Optional: set the size of the icon
            ),
            SizedBox(width: 10),
            Text(
              text,
              style: TextStyle(
                color: textColor, // Text color based on selected state
                fontSize: 15.0,
                fontFamily: 'Poppins Medium',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget customContainerList(
  BuildContext context, {
  required String text,
  required VoidCallback onTap,
  required Color backgroundColor,
  required Color textColor,
}) {
  return InkWell(
    onTap: onTap,
    child: Container(
      height: MediaQuery.sizeOf(context).height * 0.04,
      width: MediaQuery.sizeOf(context).width * 0.20,
      decoration: BoxDecoration(
        color: backgroundColor, // Dynamic background color
        border: Border.all(color: Color(0xFFD7D4D4), width: 0.2),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            text,
            style: TextStyle(
              color: textColor, // Text color based on selected state
              fontSize: 15.0,
              fontFamily: 'Poppins Medium',
            ),
          ),
        ],
      ),
    ),
  );
}

void showFilterBottomSheet(BuildContext context) {
  showModalBottomSheet(
    backgroundColor: Colors.white,
    context: context,
    isScrollControlled: true,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(20),
      ),
    ),
    builder: (context) {
      return DraggableScrollableSheet(
        expand: false,
        maxChildSize: 0.8,
        minChildSize: 0.5,
        builder: (context, scrollController) {
          return ListView(
            controller: scrollController,
            padding: EdgeInsets.all(16),
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(
                  "Filter By",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Poppins',
                    color: Color(0xFF4181FF),
                  ),
                ),
              ),
              Divider(
                thickness: 1,
              ),
              SizedBox(height: 10),
              FilterContainer(
                title: "Operator Rating",
                options: ["5 ★", "4–3 ★", "1–2 ★"],
              ),
              SizedBox(height: 10),
              FilterContainer(
                title: "Bus Operators",
                options: ["Operator 1", "Operator 2", "Operator 3"],
              ),
              SizedBox(height: 10),
              FilterContainer(
                title: "Bus Types",
                options: [
                  "Sleeper",
                  "AC Sleeper",
                  "Multi Axle",
                  "Non-AC Sleeper",
                ],
              ),
              SizedBox(height: 10),
              FilterContainer(
                title: "Departure Time",
                options: ["Morning", "Afternoon", "Night"],
              ),
              SizedBox(height: 10),
              FilterContainer(
                title: "Arrival Time",
                options: ["Morning", "Afternoon", "Night"],
              ),
              SizedBox(height: 20),
              Divider(
                thickness: 1,
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 40,
                    width: 150.0,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10.0),
                      border: Border.all(
                        color: Color(0xFF4181FF),
                        width: 1.5,
                      ),
                    ),
                    child: ElevatedButton(
                      onPressed: () {
                        // Add your "Clear All" logic here
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        // Set transparent to avoid overriding Container's color
                        shadowColor: Colors.transparent,
                        // Disable shadow
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        padding: EdgeInsets.symmetric(vertical: 12.0),
                      ),
                      child: Text(
                        'Clear All',
                        style: TextStyle(
                          fontSize: 14,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 16.0),
                  Container(
                    height: 40,
                    width: 130.0,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFF4181FF),
                          Color(0xFF274E99),
                        ],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    child: ElevatedButton(
                      onPressed: () {
                        // Add your "Next" logic here
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        padding: EdgeInsets.symmetric(vertical: 12.0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              12.0), // Match with the container
                        ),
                      ),
                      child: Text(
                        'Next',
                        style: TextStyle(
                          fontSize: 14,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          );
        },
      );
    },
  );
}

class FilterContainer extends StatefulWidget {
  final String title;
  final List<String> options;

  const FilterContainer({required this.title, required this.options});

  @override
  _FilterContainerState createState() => _FilterContainerState();
}

class _FilterContainerState extends State<FilterContainer> {
  late Map<String, bool> selectedOptions;

  @override
  void initState() {
    super.initState();
    // Initialize all options as unchecked
    selectedOptions = {for (var option in widget.options) option: false};
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Color(0xFFF1F6FF),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Color(0xFFD9D9D9)),
      ),
      child: ExpansionTile(
        shape: Border.all(color: Colors.transparent),
        title: Text(
          widget.title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        children: widget.options.map((option) {
          return CheckboxListTile(
            title: Text(option),
            value: selectedOptions[option],
            onChanged: (value) {
              setState(() {
                selectedOptions[option] = value ?? false;
              });
            },
            controlAffinity: ListTileControlAffinity.leading,
          );
        }).toList(),
      ),
    );
  }
}

void _showSortOptions(BuildContext context) {
  // Dynamic list of sort options
  final List<String> sortOptions = [
    'Most Popular',
    'Low to High',
    'High to Low',
    'Best Rated',
    'Early Departure',
    'Late Departure',
  ];

  // Variable to keep track of the selected option
  String selectedOption = 'Low to High'; // Default selected option

  showModalBottomSheet(
    backgroundColor: Colors.white,
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(
        top: Radius.circular(16.0),
      ),
    ),
    builder: (BuildContext context) {
      return Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  'Sort By',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Poppins',
                  ),
                ),
                Spacer(),
                IconButton(
                  onPressed: () {
                    Navigator.pop(context); // Closes the bottom sheet
                  },
                  icon: SvgPicture.asset(
                    'assets/images/close_sort.svg',
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            // Dynamically generate ListTile widgets based on sortOptions
            ...sortOptions.map((option) {
              return ListTile(
                leading: Radio<String>(
                  value: option,
                  groupValue: selectedOption,
                  onChanged: (value) {
                    // Update the selected option
                    selectedOption = value!;
                    // Ensure the UI is updated immediately
                    (context as Element).markNeedsBuild();
                  },
                ),
                title: Text(option),
              );
            }).toList(),
          ],
        ),
      );
    },
  );
}
