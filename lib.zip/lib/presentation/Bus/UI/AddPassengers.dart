import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'ReviewBooking.dart';

class Addpassengers extends StatefulWidget {
  const Addpassengers({Key? key}) : super(key: key);

  @override
  _AddpassengersState createState() => _AddpassengersState();
}

class _AddpassengersState extends State<Addpassengers>
    with SingleTickerProviderStateMixin {
  String? selectedGender;

  @override
  void initState() {}
  List<bool> _checkboxValues = List.generate(10, (index) => false);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(
              top: 50.0,
              left: 15.0,
              right: 15.0,
              bottom: 10.0,
            ),
            child: Row(
              children: [
                Image.asset(
                  'assets/images/arrow_left.png',
                  width: 20.0,
                ),
                SizedBox(width: 15.0),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Add Passengers',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        fontSize: 19.0,
                        color: Color(0xFF282828),
                      ),
                    ),
                    Text(
                      'Nagercoil > Chennai',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 14.0,
                        color: Color(0xFF8C8C8C),
                      ),
                    ),
                  ],
                ),
                Spacer(),
                SvgPicture.asset(
                  'assets/images/offer_svg.svg',
                  width: 20.0,
                ),
              ],
            ),
          ),
          const Divider(
            thickness: 1, // Thickness of the line
            color: Color(0xFFE0E0E0), // Light gray color for the divider
          ),
          Expanded(
            child: ListView.builder(
              itemCount: 10,
              itemBuilder: (context, index) {
                return boardingList(
                  context,
                  location: "Anu",
                  address: "Female",
                  date: "24 age",
                  onChanged: (bool? newValue) {
                    setState(() {
                      // Handle the checkbox state change here
                      _checkboxValues[index] = newValue ?? false;
                    });
                  },
                  value: _checkboxValues[
                      index], // Pass the current checkbox state for the index
                );
              },
            ),
          ),
          Align(
            alignment: Alignment.center, // Horizontally center
            child: GestureDetector(
              onTap: () {
                showPassengerDialog(context);
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 50.0),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Color(0xFF4181FF), // Border color
                    width: 1.3, // Border width
                  ),
                  borderRadius: BorderRadius.circular(10.0), // Rounded corners
                ),
                child: Text(
                  'Add New Passengers',
                  style: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w600,
                    color: Colors.black, // Text color
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Column(
            children: [
              Divider(
                thickness: 2, // Bottom divider
                color: Color(0xFF8C8C8C), // Divider color
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10),
                child: Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Seat No. L6,L7',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF282828),
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          'Total fare',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF4181FF),
                          ),
                        ),
                        SizedBox(height: 5),
                        Text(
                          '₹350',
                          style: TextStyle(
                            fontSize: 18,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF282828),
                          ),
                        ),
                      ],
                    ),
                    Spacer(),
                    Container(
                      height: 40,
                      width: 130.0,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Color(0xFF4181FF),
                            Color(0xFF274E99),
                          ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      child: ElevatedButton(
                        onPressed: () {
                          // Add your "Next" logic here
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Reviewbooking()));
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          padding: EdgeInsets.symmetric(vertical: 12.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                                12.0), // Match with the container
                          ),
                        ),
                        child: Text(
                          'Proceed to pay',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void showPassengerDialog(BuildContext context) {
    // State variable for selected gender
    String? selectedGender;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding: EdgeInsets.all(10.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
          content: Builder(builder: (context) {
            var height = MediaQuery.of(context).size.height;
            var width = MediaQuery.of(context).size.width;
            return Container(
              height: height - 500,
              width: width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        'Add Passenger',
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          fontSize: 18,
                        ),
                      ),
                      Spacer(),
                      GestureDetector(
                        onTap: () {
                          Navigator.of(context).pop(); // Close the dialog
                        },
                        child: SvgPicture.asset('assets/images/close_ring.svg'),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Radio<String>(
                              value: 'Male',
                              groupValue: selectedGender,
                              onChanged: (value) {
                                setState(() {
                                  selectedGender = value;
                                });
                              },
                            ),
                            Text(
                              'Male',
                              style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  color: Colors.black),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Radio<String>(
                              value: 'Female',
                              groupValue: selectedGender,
                              onChanged: (value) {
                                setState(() {
                                  selectedGender = value;
                                });
                              },
                            ),
                            Text(
                              'Female',
                              style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  color: Colors.black),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 0.0),
                    child: TextFormField(
                      cursorColor: Color(0xFF4181FF),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp('[a-zA-Z ]')),
                      ],
                      keyboardType: TextInputType.text,
                      style: TextStyle(
                        fontFamily: 'Poppins Medium',
                        fontSize: 15.0,
                        color: Colors.black,
                      ),
                      decoration: InputDecoration(
                        label: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Name',
                              style: TextStyle(
                                fontSize: 20,
                                fontFamily: 'Poppins Medium',
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        hintText: 'Enter your name',
                        hintStyle: TextStyle(
                          fontFamily: 'Poppins-Regular',
                          fontSize: 15.0,
                          color: Color(0xFFA5A5A5),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        filled: true,
                        fillColor: Colors.white,
                        contentPadding:
                            EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: Color(0xFFDDDDDD),
                            // Ensure this color is visible
                            width: 2,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: Color(0xFF9FC0FF),
                            width: 2,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 0.0),
                    child: TextFormField(
                      cursorColor: Color(0xFF4181FF),
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                        fontFamily: 'Poppins Medium',
                        fontSize: 15.0,
                        color: Colors.black,
                      ),
                      decoration: InputDecoration(
                        label: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Age',
                              style: TextStyle(
                                fontSize: 20,
                                fontFamily: 'Poppins Medium',
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        hintText: 'Enter your name',
                        hintStyle: TextStyle(
                          fontFamily: 'Poppins-Regular',
                          fontSize: 15.0,
                          color: Color(0xFFA5A5A5),
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.always,
                        filled: true,
                        fillColor: Colors.white,
                        contentPadding:
                            EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: Color(0xFFDDDDDD),
                            // Ensure this color is visible
                            width: 2,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                            color: Color(0xFF9FC0FF),
                            width: 2,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Align(
                    alignment: Alignment.center,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      // Centers the row horizontally
                      crossAxisAlignment: CrossAxisAlignment.center,
                      // Aligns children vertically
                      children: [
                        Checkbox(
                          value: false,
                          // Replace with a variable to manage the state
                          onChanged: (value) {
                            // Update the state here
                          },
                        ),
                        // Adds spacing between the Checkbox and Text
                        Text(
                          'Save this detail for future',
                          style: TextStyle(
                            fontSize: 14.0, 
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                            color: Color(0xFF282828)
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Center(
                    child:  Container(
                      height: 40,
                      width: 80.0,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Color(0xFF4181FF),
                            Color(0xFF274E99),
                          ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      child: ElevatedButton(
                        onPressed: () {
                          // Add your "Next" logic here
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Addpassengers()));
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          padding: EdgeInsets.symmetric(vertical: 12.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                                12.0), // Match with the container
                          ),
                        ),
                        child: Text(
                          'Add',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        );
      },
    );
  }
}

Widget boardingList(
  BuildContext context, {
  String? location,
  String? address,
  String? date,
  ValueChanged<bool?>? onChanged,
  bool? value,
}) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
    child: Container(
      height: MediaQuery.sizeOf(context).height * 0.09,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFA4BFF4), // Set the color of the border
          width: 1.5, // Set the width of the border
        ),
        borderRadius: BorderRadius.all(
          Radius.circular(10.0), // Curved corners with a radius of 10
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start, // Align elements to start
        children: [
          // Checkbox placed at the start of the row
          Padding(
            padding: EdgeInsets.only(left: 10),
            child: Checkbox(
              value: value ?? false,
              // Use the value to determine if the checkbox is checked
              onChanged: onChanged,
            ),
          ),
          // Column to display location, address, and date
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(right: 15.0),
              child: Row(
                children: [
                  Padding(
                    padding: EdgeInsets.only(
                        top: MediaQuery.sizeOf(context).height * 0.022),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          location!,
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            color: Color(0xFF282828),
                          ),
                        ),
                        SizedBox(height: 1),
                        Row(
                          children: [
                            Text(
                              address!,
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w400,
                                fontSize: 13,
                                color: Color(0xFF282828),
                              ),
                            ),
                            SizedBox(width: 10),
                            Text(
                              date!,
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                                color: Color(0xFF282828),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  SvgPicture.asset(
                    'assets/images/edit_icon.svg',
                    width: 20.0,
                  ),
                  SizedBox(width: 10),
                  SvgPicture.asset(
                    'assets/images/trash_svg.svg',
                    width: 20.0,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
