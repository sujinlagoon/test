import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertickect365/presentation/Bus/Controller/BusAvailabilityController.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:http/http.dart' as http;
import 'package:marquee/marquee.dart';
import 'dart:convert';

import '../../cab_homepage_screen/apiModel/sharedPref.dart';
import '../../cab_homepage_screen/cab_homepage_screen.dart';

class SelectArrivalScreen extends StatefulWidget {
  final bool isSelectingFrom;

  SelectArrivalScreen({required this.isSelectingFrom});

  @override
  _SelectArrivalScreenState createState() => _SelectArrivalScreenState();
}

class _SelectArrivalScreenState extends State<SelectArrivalScreen> {
  BusAvailabilityController controller = Get.put(BusAvailabilityController());
  String selectedCity = '';

  // final TextEditingController searchController = TextEditingController();
  @override
  void initState() {
    super.initState();
    print("--------------------------------------Inside");
   controller. getId();
   controller. selectArrivalDeparture('');
    controller.searchController.addListener(() {
     controller. filterCities(controller.searchController.text);
     controller. selectArrivalDeparture(controller.searchController.text);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              )),
          backgroundColor: Color(0xFF2684FF),
          title: Text(
            'Select Arrival',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600,
              fontSize: 19,
              color: Colors.white,
            ),
          )),
      body: Container(
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.center,
            colors: [Color(0xFF2684FF), Colors.white],
          ),
        ),
        child: GetBuilder<BusAvailabilityController>(builder: (v) {
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Container(
                      height: 50,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(top: 5.0, left: 15),
                              child: TextField(
                                controller: v.searchController,
                                decoration: InputDecoration(
                                  hintText: 'Select City / Place',
                                  hintStyle: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 16,
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w500,
                                  ),
                                  border: InputBorder.none,
                                  suffixIcon: GestureDetector(
                                    onTap: () {
                                      final enteredText =
                                          v.searchController.text;
                                      controller
                                          .selectArrivalDeparture(enteredText);
                                    },
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.only(right: 16.0),
                                      child: SvgPicture.asset(
                                          'assets/images/search.svg'),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              GetBuilder<BusAvailabilityController>(builder: (city) {
                return Flexible(
                  flex: 5,
                  child: city.isLoading ?CircularProgressIndicator():ListView.builder(
                    scrollDirection: Axis.vertical,
                    itemCount: city.filteredCities.length,
                    itemBuilder: (context, index) {
                      var data = city.filteredCities[index];
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10.0, vertical: 10.0),
                        child: GestureDetector(
                          // onTap: () async {
                          /*  selectedCity = data.cityName;
                                    await sharedPref().saveCheckID1(selectedCity);
                                    await sharedPref().saveCity(data.cityId);
                                    Get.back( result: selectedCity);
                                    //Navigator.pop(context);
                                    */ /*   Navigator.of(context).push(
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CabHomepageScreen()),
                                    );*/

                          //  },
                          onTap: () async {
                            if (widget.isSelectingFrom) {
                              controller.setFromLocation(
                                data.cityName!,
                                data.cityId.toString(),
                              );
                            } else {
                              controller.setToLocation(
                                data.cityName!,
                                data.cityId.toString(),
                              );
                            }
                            print(data.cityId);
                            controller.update();
                            Navigator.pop(context);
                          },
                          child: IntrinsicWidth(
                            child: IntrinsicHeight(
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(15.0),
                                  border: Border.all(
                                      color: Color(0xFFEBEBEB),
                                      width: 1.0), // Optional border
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15, vertical: 10),
                                  // Reduced padding
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SvgPicture.asset(
                                        'assets/images/bus_dest_sv.svg',
                                        height: 23.0,
                                        width: 23.0,
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            data.cityName,
                                            style: TextStyle(
                                                fontSize: 15.0,
                                                // Reduced font size
                                                fontFamily: 'Poppins',
                                                fontWeight: FontWeight.w500),
                                          ),
                                          Text(
                                            data.cityState,
                                            style: TextStyle(
                                                fontSize: 15.0,
                                                // Reduced font size
                                                fontFamily: 'Poppins Medium',
                                                color: Color(0xFF5F5F5F)),
                                          ),
                                        ],
                                      ),
                                      // Returns an empty widget if the condition is not met
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                );
              }),
            ],
          );
        }),
      ),
    );
  }
}
