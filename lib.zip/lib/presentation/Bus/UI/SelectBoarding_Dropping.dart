import 'package:flutter/material.dart';
import 'package:fluttertickect365/presentation/Bus/UI/AddPassengers.dart';

class SelectboardingDropping extends StatefulWidget {
  const SelectboardingDropping({Key? key}) : super(key: key);

  @override
  _SelectboardingDroppingState createState() => _SelectboardingDroppingState();
}

class _SelectboardingDroppingState extends State<SelectboardingDropping> with SingleTickerProviderStateMixin {

  late TabController _tabController;
  final List<Map<String, String>> boardingPoints = [
    {
      'name': 'Chirayankuzhi',
      'description': 'Opp to SS Cars',
      'time': '8:20 AM, Fri 28 June',
    },
    {
      'name': 'Thuckalay',
      'description': 'Opp to SS Cars',
      'time': '8:20 AM, Fri 28 June',
    },
    {
      'name': 'Thuckalay',
      'description': 'Opp to SS Cars',
      'time': '8:20 AM, Fri 28 June',
    },
    {
      'name': 'Thuckalay',
      'description': 'Opp to SS Cars',
      'time': '8:20 AM, Fri 28 June',
    },
    {
      'name': 'Chirayankuzhi',
      'description': 'Opp to SS Cars',
      'time': '8:20 AM, Fri 28 June',
    },
  ];
  final List<Map<String, String>> droppingPoints = [
    {
      'name': 'Chirayankuzhi1',
      'description': 'Opp to SS Cars1',
      'time': '8:20 AM, Fri 28 June1',
    },
    {
      'name': 'Thuckalay1',
      'description': 'Opp to SS Cars1',
      'time': '8:20 AM, Fri 28 June1',
    },
    {
      'name': 'Thuckalay1',
      'description': 'Opp to SS Cars1',
      'time': '8:20 AM, Fri 28 June1',
    },
    {
      'name': 'Thuckalay1',
      'description': 'Opp to SS Cars1',
      'time': '8:20 AM, Fri 28 June1',
    },
    {
      'name': 'Chirayankuzhi1',
      'description': 'Opp to SS Cars1',
      'time': '8:20 AM, Fri 28 June1',
    },
  ];
  bool _isDroppingTabActive = false;
  int? _boardingSelectedValue;
  int? _droppingSelectedValue;

  @override
  void initState() {
    _tabController = TabController(length: 2, vsync: this);
    super.initState();

    _tabController.animation!.addListener(() {
      setState(() {
        // Check if the current tab index is the dropping points tab
        _isDroppingTabActive = _tabController.index == 1;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(
              top: 60.0,
              left: 15.0,
              right: 15.0,
              bottom: 20.0,
            ),
            child: Row(
              children: [
                Image.asset(
                  'assets/images/arrow_left.png',
                  width: 20.0,
                ),
                const SizedBox(width: 15.0),
                const Text(
                  'Select boarding & dropping points',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    fontSize: 19.0,
                    color: Color(0xFF282828),
                  ),
                ),
              ],
            ),
          ),
          const Divider(
            thickness: 1, // Thickness of the line
            color: Color(0xFFE0E0E0), // Light gray color for the divider
          ),
          TabBar(
            controller: _tabController,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.blue,
            dividerColor: Colors.transparent,
            tabs: [
              Tab(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _tabController.animation!,
                      builder: (context, child) {
                        return Text(
                          "Boarding Points",
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: _tabController.index == 0
                                ? Colors.blue
                                : Colors.grey,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              Tab(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(width: 8.0),
                    AnimatedBuilder(
                      animation: _tabController.animation!,
                      builder: (context, child) {
                        return Text(
                          "Dropping Points",
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            color: _tabController.index == 1
                                ? Colors.blue
                                : Colors.grey,
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                ListView.builder(
                  itemCount: 3,
                  itemBuilder: (context, index) {
                    return boardingList(
                      context,
                      location: "Thuckalay ",
                      address: "Opp to SS Cars",
                      date: "8:20 AM, Fri 28 June",
                      groupValue: _boardingSelectedValue,
                      value: index,
                      onChanged: (int? newValue) {
                        setState(() {
                          _boardingSelectedValue = newValue;
                        });
                      },
                    );
                  },
                ),
                ListView.builder(
                  itemCount: 8,
                  itemBuilder: (context, index) {
                    return boardingList(
                      context,
                      location: "Nagercoil",
                      address: "Opp to SS Cars",
                      date: "8:20 AM, Fri 28 June",
                      groupValue: _droppingSelectedValue,
                      value: index,
                      onChanged: (int? newValue) {
                        setState(() {
                          _droppingSelectedValue = newValue;
                        });
                      },
                    );
                  },
                ),
              ],
            ),
          ),
          Visibility(
            visible: _isDroppingTabActive,  // Condition for visibility
            child: Column(
              children: [
                Divider(
                  thickness: 2, // Bottom divider
                  color: Color(0xFF8C8C8C), // Divider color
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10),
                  child: Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Seat No. L6,L7',
                            style: TextStyle(
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              color: Color(0xFF282828),
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Total fare',
                            style: TextStyle(
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              color: Color(0xFF4181FF),
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            '₹350',
                            style: TextStyle(
                              fontSize: 18,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF282828),
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      Container(
                        height: 40,
                        width: 130.0,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color(0xFF4181FF),
                              Color(0xFF274E99),
                            ],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        child: ElevatedButton(
                          onPressed: () {
                            // Add your "Next" logic here
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>Addpassengers()));
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            padding: EdgeInsets.symmetric(vertical: 12.0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0), // Match with the container
                            ),
                          ),
                          child: Text(
                            'Next',
                            style: TextStyle(
                              fontSize: 14,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 20),
        ],
      ),
    );
  }

}

Widget boardingList(
  BuildContext context, {
  String? location,
  String? address,
  String? date,
  int? groupValue,
  ValueChanged<int?>? onChanged,
  int? value,
}) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
    child: Container(
      height: MediaQuery.sizeOf(context).height * 0.09,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFA4BFF4), // Set the color of the border
          width: 1.5, // Set the width of the border
        ),
        borderRadius: BorderRadius.all(
          Radius.circular(10.0), // Curved corners with a radius of 10
        ),
      ),
      child: Row(
        children: [
          Radio<int>(
            value: value!,
            groupValue: groupValue,
            onChanged: onChanged, // Callback to handle value change
          ),
          SizedBox(width: 10),
          Padding(
            padding:
                EdgeInsets.only(top: MediaQuery.sizeOf(context).height * 0.014),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  location!,
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      color: Color(0xFF282828)),
                ),
                SizedBox(
                  height: 1,
                ),
                Text(
                  address!,
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                      fontSize: 13,
                      color: Color(0xFF282828)),
                ),
                SizedBox(
                  height: 1,
                ),
                Text(
                  date!,
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                      fontSize: 12,
                      color: Color(0xFF282828)),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}
