import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertickect365/presentation/cab_homepage_screen/apiModel/sharedPref.dart';
import 'package:get/get.dart';
import '../Controller/BusAvailabilityController.dart';

class SelectDepartureScreen extends StatefulWidget {
  @override
  _SelectDepartureScreenState createState() => _SelectDepartureScreenState();
}

class _SelectDepartureScreenState extends State<SelectDepartureScreen> {
  BusAvailabilityController controller = Get.put(BusAvailabilityController());
  String selectedCity = '';
  final TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      searchController.addListener(() {
        String searchText = searchController.text;
        controller.selectArrivalDeparture(
            searchText); // Trigger search on every change
      });
    });
  }

  @override
  Widget build(BuildContext context) {
/*    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Color(0xFF2684FF),
      statusBarBrightness: Brightness.dark, // Dark text for status bar
    ));*/

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF2684FF),
        title: Text(
          "Select Departure",
          style: TextStyle(fontWeight: FontWeight.normal, color: Colors.white),
        ),
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            )),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.center,
            colors: [Color(0xFF2684FF), Colors.white],
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: Offset(0, 3), // Shadow position
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 5.0, left: 15),
                        child: TextField(
                          controller: searchController,
                          decoration: InputDecoration(
                            hintText: 'Select City / Place',
                            hintStyle: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                            ),
                            border: InputBorder.none,
                            suffixIcon: GestureDetector(
                              onTap: () {
                                final enteredText = searchController.text;
                                controller.selectArrivalDeparture(enteredText);
                              },
                              child: Padding(
                                padding: const EdgeInsets.only(right: 16.0),
                                child: SvgPicture.asset(
                                    'assets/images/search.svg'),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            /*           Padding(
              padding: const EdgeInsets.only(left: 20.0, right: 20.0),
              child: Align(
                alignment: Alignment.topLeft,
                child: Text(
                  'Popular Cities',
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      color: Color(0xFF282828)),
                ),
              ),
            ),

            SizedBox(
              height: Get.height * 0.01,
            ),
            */ /* controller.isLoading
                ? CircularProgressIndicator()
                : Column(
                    children: [*/ /*
            GetBuilder<BusAvailabilityController>(
              builder: (controller) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0),
                  child: GridView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: controller.listCities.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      crossAxisSpacing: 5.0,
                      mainAxisSpacing: 10.0,
                      childAspectRatio: 1,
                    ),
                    itemBuilder: (context, index) {
                      var data = controller.listCities[index];
                      return GestureDetector(
                        onTap: () async {
                          selectedCity = data.cityName;
                          await sharedPref().saveCheckID(selectedCity);
                          await sharedPref().saveCityDeparture(data.cityId);
                          Get.back( result: selectedCity);
                          //Get.off(()=>CabHomepageScreen());
                          */ /* Navigator.of(context).push(
                            MaterialPageRoute(
                                builder: (context) => CabHomepageScreen()),
                          );*/ /*
                        },
                        child: Card(
                          margin: EdgeInsets.all(0.5),
                          elevation: 5.0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(15.0),
                              border: Border.all(
                                color: Color(0xFFe3ecff),
                                width: 0.0,
                              ),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8.0, vertical: 8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SvgPicture.asset(
                                    'assets/images/chennai.svg',
                                    height: 40.0,
                                    width: 40.0,
                                  ),
                                  SizedBox(height: 5.0),
                                  Flexible(
                                    child:Center(
                                      child: Marquee(
                                        text: data.cityName,
                                        style: TextStyle(
                                          fontSize: 12.0,
                                          fontWeight: FontWeight.w500,
                                          color: Color(0xFF9C9C9C),
                                        ),
                                        scrollAxis: Axis.horizontal,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        blankSpace: 50.0,
                                        velocity: 50.0,
                                        startPadding: 10.0,
                                        accelerationDuration: Duration(seconds: 2),
                                        accelerationCurve: Curves.easeInOut,
                                      ),
                                    )
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),*/
            GetBuilder<BusAvailabilityController>(builder: (city) {
              return Flexible(
                flex: 5,
                child: ListView.builder(
                  scrollDirection: Axis.vertical,
                  itemCount: city.listCities.length,
                  itemBuilder: (context, index) {
                    var data = city.listCities[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10.0, vertical: 10.0),
                      child: GestureDetector(
                        onTap: () async {
                          selectedCity = data.cityName;
                          await sharedPref().saveCheckID(selectedCity);
                          await sharedPref().saveCityDeparture(data.cityId);
                          Get.back(result: selectedCity);
                          /* Navigator.of(context).push(
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          CabHomepageScreen()),
                                );*/
                        },
                        child: IntrinsicWidth(
                          child: IntrinsicHeight(
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(15.0),
                                border: Border.all(
                                    color: Color(0xFFEBEBEB),
                                    width: 1.0), // Optional border
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 15, vertical: 10),
                                // Reduced padding
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SvgPicture.asset(
                                      'assets/images/bus_dest_sv.svg',
                                      height: 23.0,
                                      width: 23.0,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          data.cityName,
                                          style: TextStyle(
                                              fontSize: 15.0,
                                              // Reduced font size
                                              fontFamily: 'Poppins',
                                              fontWeight: FontWeight.w500),
                                        ),
                                        Text(
                                          data.cityState,
                                          style: TextStyle(
                                              fontSize: 15.0,
                                              // Reduced font size
                                              fontFamily: 'Poppins Medium',
                                              color: Color(0xFF5F5F5F)),
                                        ),
                                      ],
                                    ),
                                    // Returns an empty widget if the condition is not met
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              );
            }),
            /*],
                  )*/
            // Using GetBuilder or Obx to observe the loading state
          ],
        ),
      ),
    );
  }
}
