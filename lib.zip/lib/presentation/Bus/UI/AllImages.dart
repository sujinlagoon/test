import 'package:flutter/material.dart';

class AllImages extends StatefulWidget {
  const AllImages({Key? key}) : super(key: key);

  @override
  _AllImagesState createState() => _AllImagesState();
}

class _AllImagesState extends State<AllImages> {
  final List<String> imagePaths = [
    'assets/images/bus_img.png',
    'assets/images/bus_img.png',
    'assets/images/bus_img.png',
    'assets/images/bus_img.png',
    'assets/images/bus_img.png',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('All Images'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.builder(
          itemCount: imagePaths.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, // Number of columns
            crossAxisSpacing: 8.0, // Space between columns
            mainAxisSpacing: 8.0, // Space between rows
            childAspectRatio: 1.0, // Aspect ratio of each item
          ),
          itemBuilder: (context, index) {
            return ClipRRect(
              borderRadius: BorderRadius.circular(8.0), // Rounded corners
              child: Image.asset(
                imagePaths[index],
                fit: BoxFit.cover, // Ensures the image fits nicely in the grid
              ),
            );
          },
        ),
      ),
    );
  }
}
