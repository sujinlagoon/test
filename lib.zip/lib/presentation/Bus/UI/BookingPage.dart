import 'package:flutter/material.dart';
import 'package:fluttertickect365/presentation/Bus/UI/AllImages.dart';
import 'package:fluttertickect365/presentation/Bus/UI/SelectBoarding_Dropping.dart';

class BookingPage extends StatefulWidget {
  const BookingPage({Key? key}) : super(key: key);

  @override
  _BookingPageState createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  final List<String> imagePaths = [
    'assets/images/bus_img.png',
    'assets/images/bus_img.png',
    'assets/images/bus_img.png',
  ];

  final List<String> places = [
    "Nagercoil",
    "Place",
    "Place",
    "Place",
    "Place",
    "Place",
    "Place",
    "Place1",
    "Place",
    "Place",
    "Chennai",
  ];
  List<String> options = [];
  Map<String, bool> selectedOptions = {};

  final List<Map<String, String>> items = [
    {"icon": "assets/images/amenities.png", "title": "Wet Napkin"},
    {"icon": "assets/images/amenities.png", "title": "M-ticket"},
    {"icon": "assets/images/amenities.png", "title": "Charging Point"},
  ];

  @override
  void initState() {
    super.initState();
    fetchOptions(); // Populate the options dynamically on screen load
  }

  Future<List<String>> fetchFromAPI() async {
    // Simulate an API call
    await Future.delayed(
        const Duration(seconds: 2)); // Simulating network delay
    return ['Option 1', 'Option 2', 'Option 3']; // Sample options
  }

  void fetchOptions() async {
    List<String> fetchedOptions = await fetchFromAPI();
    setState(() {
      options = fetchedOptions;
      for (var option in options) {
        selectedOptions[option] = false;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet: Container(
        color: Colors.white,
        height: 100,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text("Selected Seats"),
                  SizedBox(height: 8),
                  Text("Total Fare"),
                  Text("\$350"),
                ],
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SelectboardingDropping(),
                  ),
                );
              },
              child: Container(
                color: Colors.blue,
                height: 45,
                width: 100,
                child: const Center(
                  child: Text(
                    "Proceed",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
      appBar: AppBar(
        leading: const Icon(Icons.arrow_back_ios),
        automaticallyImplyLeading: false,
        title: const Text("Select Seats"),
      ),
      body: Stack(
        children: [
          Row(
            children: [
              Expanded(
                flex: 1,
                child: Padding(
                  padding: EdgeInsets.only(
                    left: MediaQuery.of(context).size.width * 0.03,
                    bottom: MediaQuery.of(context).size.height * 0.13,
                    top: MediaQuery.of(context).size.height * 0.01,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black),
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [Text("Lower Deck"), FlutterLogo()],
                        ),
                        const SizedBox(height: 5),
                        Row(
                          children: [
                            Expanded(
                              flex: 3,
                              child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: 2,
                                itemBuilder: (context, index) {
                                  return SizedBox(
                                    height: 20,
                                    width: MediaQuery.of(context).size.width,
                                    child: Image.asset(
                                      "assets/images/seatt.png",
                                      width: 50,
                                    ),
                                  );
                                },
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              flex: 5,
                              child: Container(
                                color: Colors.blue[300],
                                child:
                                    const Center(child: Text("More content")),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 1,
                child: Padding(
                  padding: EdgeInsets.only(
                    right: MediaQuery.of(context).size.width * 0.03,
                    bottom: MediaQuery.of(context).size.height * 0.13,
                    top: MediaQuery.of(context).size.height * 0.01,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.black),
                    ),
                  ),
                ),
              )
            ],
          ),
          DraggableScrollableSheet(
            initialChildSize: 0.35,
            minChildSize: 0.25,
            maxChildSize: 1.0,
            builder: (context, scrollController) {
              return Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                child: ListView(
                  controller: scrollController,
                  padding: const EdgeInsets.all(16),
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(bottom: 10),
                      child: Text(
                        "Bus Details",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Poppins',
                          color: Color(0xFF282828),
                        ),
                      ),
                    ),
                    const Divider(thickness: 1),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'Tranzking',
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                                color: Color(0xFF282828),
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              '18:30 - 06:30 | Thu, 13 Jun',
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w400,
                                fontSize: 15,
                                color: Color(0xFF282828),
                              ),
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFF3EB557),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Row(
                            children: const [
                              Text(
                                '4.5',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(width: 4),
                              Icon(Icons.star, size: 14, color: Colors.white),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      height: 85,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: imagePaths.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12.0),
                              child: Image.asset(
                                imagePaths[index],
                                height: 150,
                                width: 200,
                                fit: BoxFit.cover,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    SizedBox(height: 15),
                    Align(
                      alignment: Alignment.topRight,
                      child: GestureDetector(
                        onTap: () {
                          // Handle the onPressed action here
                          print("VIEW ALL IMAGES clicked");
                          // For example, navigate to a new screen:
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const AllImages(),
                            ),
                          );
                        },
                        child: Text(
                          'VIEW ALL IMAGES',
                          style: TextStyle(
                            fontSize: 16,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF4181FF),
                          ),
                        ),
                      ),
                    ),

                    Text(
                      'Bus Route',
                      style: TextStyle(
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF282828),
                      ),
                    ),
                    SizedBox(height: 5),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: places.asMap().entries.map((entry) {
                          int index = entry.key;
                          String place = entry.value;
                          bool isFirst = index == 0;
                          bool isLast = index == places.length - 1;

                          return Row(
                            children: [
                              Text(
                                place,
                                style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: 'Poppins',
                                  fontWeight: isFirst || isLast
                                      ? FontWeight.bold
                                      : FontWeight.w400,
                                  color: isFirst || isLast
                                      ? const Color(0xFF282828)
                                      : const Color(0xFF737373),
                                ),
                              ),
                              if (!isLast)
                                const Padding(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 4.0),
                                  child: Text(
                                    '>',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w400,
                                      color: Color(0xFF737373),
                                    ),
                                  ),
                                ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                    SizedBox(height: 20),
                    _buildExpansionTile('Boarding Points'),
                    SizedBox(height: 20),
                    _buildExpansionTile('Dropping Points'),
                    SizedBox(height: 10),
                    Text(
                      'Amenities',
                      style: TextStyle(
                        fontSize: 15,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF282828),
                      ),
                    ),
                    ListView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: items.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          leading: Image.asset(
                            items[index]['icon']!,
                            width: 24,
                            height: 20,
                          ),
                          title: Text(
                            items[index]['title']!,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 20),
                    _buildExpansionTile('Ratings and Reviews'),
                    SizedBox(height: 20),
                    _buildExpansionTile('Cancellation Policy'),
                    SizedBox(
                      height: 180,
                    )
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildExpansionTile(String title) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: const Color(0xFFF1F6FF),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFD9D9D9)),
      ),
      child: ExpansionTile(
        shape: const Border(),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        children: options.map((option) {
          return ListTile(
            title: Text(option),
          );
        }).toList(),
      ),
    );
  }
}
