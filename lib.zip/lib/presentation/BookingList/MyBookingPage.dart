import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import '../../sujin_screen/CancelTicket/canel_controller/cancel_controller.dart';
import '../../sujin_screen/Screens/TicketDetails/particular_details.dart';
import '../../sujin_screen/controllers_/booking_history_controller.dart';
import '../../sujin_screen/modals/bookingHistory_modal.dart';
import '../utils/AppConstants.dart';

class MyBookingPage extends StatefulWidget {
  @override
  _MyBookingPageState createState() => _MyBookingPageState();
}

class _MyBookingPageState extends State<MyBookingPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String selectedTransport = 'Car';
 // List<dynamic> bookings = [];
  bool isLoading = true;

  final List<String> transportOptions = ['Bus', 'Flight', 'Car', 'Hotel'];

  BookingHistoryController controller = Get.put(BookingHistoryController());

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
/*    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        fetchBookings(); // Call API whenever a tab is selected
        print("Tab changed...");
      }
    });
    fetchBookings(); // Initial API call for the default tab*/
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

 /* Future<void> fetchBookings() async {
    String? token = await getToken();
    if (token == null) {
      showError('Authorization token not found.');
      return;
    }

    final bookingStatus = _getBookingStatus();
    final url = Uri.parse('${AppConstants.MAIN_URL}mybookings');
    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
    var body = jsonEncode({
      'page': "1",
      'booking_status': bookingStatus,
    });

    try {
      setState(() {
        isLoading = true;
      });
      var response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == true) {
          setState(() {
            bookings = data['Bookings'] ?? [];
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? 'Unknown error occurred.');
        }
      } else {
        showError('Failed to fetch data. Status code: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }*/

  String _getBookingStatus() {
    switch (_tabController.index) {
      case 0:
        return "1"; // Active Now
      case 1:
        return "2"; // Completed
      case 2:
        return "3"; // Cancelled
      default:
        return "1";
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        automaticallyImplyLeading: false,
        title: const Text(
          "My Booking",
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 17,
            color: Color(0xFF282828),
          ),
        ),
        bottom: TabBar(
          controller: _tabController,
          labelColor: const Color(0xFF4181FF),
          unselectedLabelColor: Colors.grey,
          indicatorColor: const Color(0xFF4181FF),
          tabs: const [
            Tab(text: "Active Now"),
            Tab(text: "Completed"),
            Tab(text: "Cancelled"),
          ],
        ),
      ),
      body: GetBuilder<BookingHistoryController>(builder: (v) {
        if (v.isLoadingg) {
          return Center(child: CircularProgressIndicator());
        }
        return TabBarView(
          controller: _tabController,
          children: [
            RefreshIndicator(
              onRefresh: () async {
                await v.bookingHistoryApi();
              },
              child: v.bookedBookings.isEmpty
                  ? Center(
                      child: Text("No Booking"),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: v.bookedBookings.length,
                      itemBuilder: (context, index) {
                        var data = v.bookedBookings[index];
                        return BookingItem(
                          passengerSeatName: data.buspassengerSeatName,
                          title: data.bbookingBusName!,
                          fromLocation: data.bbookingPickupLocation!,
                          toLocation: data.bbookingDropLocation!,
                          fromTime: data.bbookingPickupTime!,
                          toTime: data.bbookingDropTime!,
                          status: data.bbookingStatus!,
                          statusColor: Colors.yellow,
                          bookingData: data,
                        );
                      },
                    ),
            ),
            // Tab for "Completed"
            RefreshIndicator(
              onRefresh: () async {
                await v.bookingHistoryApi();
              },
              child: v.completedBookings.isEmpty
                  ? Center(
                      child: Text("No Completed Bookings"),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: v.completedBookings.length,
                      itemBuilder: (context, index) {
                        var data = v.completedBookings[index];
                        return BookingItem(
                          passengerSeatName: data.buspassengerSeatName,
                          title: data.bbookingBusName!,
                          fromLocation: data.bbookingPickupLocation!,
                          toLocation: data.bbookingDropLocation!,
                          fromTime: data.bbookingPickupTime!,
                          toTime: data.bbookingDropTime!,
                          status: data.bbookingStatus!,
                          statusColor: Colors.green,
                          bookingData: data,
                        );
                      },
                    ),
            ),
            // Tab for "Cancelled"
            RefreshIndicator(
              onRefresh: () async {
                await v.bookingHistoryApi();
              },
              child: v.cancelledBookings.isEmpty
                  ? Center(
                      child: Text("No Cancelled Bookings"),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: v.cancelledBookings.length,
                      itemBuilder: (context, index) {
                        var data = v.cancelledBookings[index];
                        return BookingItem(
                          passengerSeatName: data.buspassengerSeatName,
                          title: data.bbookingBusName!,
                          fromLocation: data.bbookingPickupLocation!,
                          toLocation: data.bbookingDropLocation!,
                          fromTime: data.bbookingPickupTime!,
                          toTime: data.bbookingDropTime!,
                          status: data.bbookingStatus!,
                          statusColor: Colors.red,
                          bookingData: data,
                        );
                      },
                    ),
            ),
          ],
        );
      }),
    );
  }
}

class BookingList extends StatelessWidget {
  final List<dynamic> bookings;
  final String statusText;
  final Color statusColor;

  BookingList(
      {required this.bookings,
      required this.statusText,
      required this.statusColor});

  BookingHistoryController controller = Get.put(BookingHistoryController());

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BookingHistoryController>(builder: (v) {
      return v.bookings.isEmpty
          ? const Center(child: Text("No bookings available"))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: v.bookings.length,
              itemBuilder: (context, index) {
                var data = v.bookings[index];
                return BookingItem(
                  passengerSeatName: data.buspassengerSeatName,
                  title: data.bbookingBusName!,
                  fromLocation: data.bbookingPickupLocation!,
                  toLocation: data.bbookingDropLocation!,
                  fromDetails: "data.",
                  toDetails: "toDetails",
                  fromTime: data.bbookingPickupTime!,
                  toTime: data.bbookingDropTime!,
                  status: data.bbookingStatus!,
                  statusColor: statusColor,
                  bookingData: data,
                );
              },
            );
    });
  }
}

class BookingItem extends StatelessWidget {
  final String title;
  final String fromLocation;
  final String toLocation;
  final String? fromDetails;
  final String? toDetails;
  final String fromTime;
  final String toTime;
  final String status;
  final Color statusColor;
  Booking? bookingData;
  String? passengerSeatName;

  BookingItem(
      {required this.title,
      required this.fromLocation,
      required this.toLocation,
      this.fromDetails,
      this.toDetails,
      required this.fromTime,
      required this.toTime,
      required this.status,
      required this.passengerSeatName,
      required this.statusColor,
      this.bookingData});

  CancelController controller = Get.put(CancelController());
  BookingHistoryController bookingHistoryController =
      Get.put(BookingHistoryController());

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BookingHistoryController>(builder: (v) {
      return Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.shade300),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade200,
              blurRadius: 4,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title and Status Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                    color: Color(0xFF282828),
                  ),
                ),
                Text(
                  status,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                    color: statusColor,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            // From and To Details

            Text(
              "Seat No ${passengerSeatName!}",
              style: TextStyle(
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
                fontSize: 14,
                color: Colors.black,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildLocationDetails(fromLocation, 'From', fromTime),
                _buildLocationDetails(toLocation, 'To', toTime),
              ],
            ),
            const SizedBox(height: 8),
            InkWell(
              onTap: () {
                print("data${bookingData!.bbookingId}");
                controller.viewBookingApi(bookingId: bookingData!.bbookingId);
                Get.to(()=>ParticularDetails(
                  bookingDetails: bookingData!,
                ));
              },
              child: Align(
                alignment: Alignment.center,
                child: Container(
                  color: Colors.blue.withOpacity(0.8),
                  padding: EdgeInsets.all(4.r),
                  child: Text(
                    "View Ticket",
                    style: TextStyle(color: Colors.black),
                  ),
                ),
              ),
            )
          ],
        ),
      );
    });
  }

  Widget _buildLocationDetails(String location, String label, String time) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          location,
          style: const TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            fontSize: 13,
            color: Color(0xFF282828),
          ),
        ),
        const SizedBox(height: 4),
        const SizedBox(height: 4),
        Text(
          '$label: $time',
          style: const TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            fontSize: 11,
            color: Color(0xFFB9B9B9),
          ),
        ),
      ],
    );
  }
}
