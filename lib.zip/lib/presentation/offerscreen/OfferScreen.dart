import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart'; // Import for Clipboard functionality
import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_html/flutter_html.dart';

class OfferScreen extends StatefulWidget {
  final int offerId;

  const OfferScreen({Key? key, required this.offerId}) : super(key: key);

  @override
  _OfferScreenState createState() => _OfferScreenState();
}

class _OfferScreenState extends State<OfferScreen> {
  bool isLoading = true;
  Map<String, dynamic>? offerDetails;
  String errorMessage = "";

  @override
  void initState() {
    super.initState();
    fetchOfferDetails();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchOfferDetails() async {
    String? token = await getToken();
    if (token == null) {
      showError('Authorization token not found.');
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}view_offer');
    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
    var body = jsonEncode({
      'offer_id': widget.offerId,
    });

    try {
      var response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == true) {
          setState(() {
            offerDetails = data['offer_details'];
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? 'Unknown error occurred.');
        }
      } else {
        showError('Failed to fetch data. Status code: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      errorMessage = message;
      isLoading = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Offers'),
        actions: [
          IconButton(
            icon: SvgPicture.asset(
              ImageConstant.discount,
              height: 24.0,
              width: 20.0,
            ),
            onPressed: () {
              // Handle settings action
            },
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage.isNotEmpty
              ? Center(child: Text(errorMessage))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Offer Image and Description
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                          color: Color(0xFF91B0EC), // Background color
                        ),
                        padding: const EdgeInsets.all(
                            8.0), // Padding around the entire container
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(
                                  8.0), // Padding around the image
                              child: offerDetails?['OfferImage'] != null
                                  ? Image.network(
                                      '${AppConstants.HOST}${offerDetails!['OfferImage']}',
                                      fit: BoxFit
                                          .contain, // Ensure the image fits without being cropped
                                      height: 150,
                                      width: double.infinity,
                                    )
                                  : Image.asset(
                                      'assets/images/bus_offer.png',
                                      fit: BoxFit
                                          .contain, // Ensure the image fits without being cropped
                                      height: 150,
                                      width: double.infinity,
                                    ),
                            ),
                            // Optionally, you can uncomment the following code if you want to display the offer name
                            // Padding(
                            //   padding: const EdgeInsets.all(8.0),
                            //   child: Text(
                            //     offerDetails?['OfferName'] ?? "Offer Details",
                            //     style: const TextStyle(
                            //       fontSize: 16,
                            //       fontWeight: FontWeight.bold,
                            //     ),
                            //   ),
                            // ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // Terms and Conditions (HTML rendering)
                      const Text(
                        "Terms and Conditions",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Html(
                        data: offerDetails?['OfferDescription'] ??
                            "<p>No details available</p>",
                      ),
                      const SizedBox(height: 24),

                      // Offer Code Section
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                          border: Border.all(color: Colors.grey.shade400),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        alignment: Alignment.center,
                        child: Text(
                          offerDetails?['CouponName'] ?? "No Coupon Code",
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      buildUpdateButton(),
                    ],
                  ),
                ),
    );
  }

  // Button that copies the coupon code to clipboard
  Widget buildUpdateButton() {
    return SizedBox(
      width: double.infinity,
      child: CustomElevatedButton(
        text: "Copy offer code",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          final couponCode = offerDetails?['CouponName'] ?? "No Coupon Code";
          Clipboard.setData(ClipboardData(text: couponCode)).then((_) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Coupon code copied to clipboard')),
            );
          });
        },
      ),
    );
  }
}

/*
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_html/flutter_html.dart';
//import 'package:flutter_html/style.dart';  // Import this for the Style class

class OfferScreen extends StatefulWidget {
  final int offerId;

  const OfferScreen({Key? key, required this.offerId}) : super(key: key);

  @override
  _OfferScreenState createState() => _OfferScreenState();
}

class _OfferScreenState extends State<OfferScreen> {
  bool isLoading = true;
  Map<String, dynamic>? offerDetails;
  String errorMessage = "";

  @override
  void initState() {
    super.initState();
    fetchOfferDetails();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchOfferDetails() async {
    String? token = await getToken();
    if (token == null) {
      showError('Authorization token not found.');
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}view_offer');
    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
    var body = jsonEncode({
      'offer_id': widget.offerId,
    });

    try {
      var response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == true) {
          setState(() {
            offerDetails = data['offer_details'];
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? 'Unknown error occurred.');
        }
      } else {
        showError('Failed to fetch data. Status code: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      errorMessage = message;
      isLoading = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Offers'),
        actions: [
          IconButton(
            icon: SvgPicture.asset(
              ImageConstant.discount,
              height: 24.0,
              width: 20.0,
            ),
            onPressed: () {
              // Handle settings action
            },
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage.isNotEmpty
              ? Center(child: Text(errorMessage))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Offer Image and Description
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                          color: Colors.teal.shade100,
                        ),
                        padding: const EdgeInsets.all(2.0),
                        child: Column(
                          children: [
                            offerDetails?['OfferImage'] != null
                                ? Image.network(
                                    '${AppConstants.HOST}${offerDetails!['OfferImage']}',
                                    fit: BoxFit.cover,
                                    height: 150,
                                    width: double.infinity,
                                  )
                                : Image.asset(
                                    'assets/images/bus_offer.png',
                                    fit: BoxFit.cover,
                                    height: 150,
                                    width: double.infinity,
                                  ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                offerDetails?['OfferName'] ?? "Offer Details",
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Terms and Conditions (HTML rendering)
                      const Text(
                        "Terms and Conditions",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Html(
                        data: offerDetails?['OfferDescription'] ??
                            "<p>No details available</p>",
                        */

/*   style: {
                "p": flutter_html.Style(
                  fontSize: flutter_html.FontSize(14.0),
                  margin: const EdgeInsets.only(bottom: 8.0),
                ),
                "body": flutter_html.Style(
                  fontSize: flutter_html.FontSize(14.0),
                  color: Colors.grey[800],
                ),
              },*/ /*

                      ),
                      const SizedBox(height: 24),

                      // Offer Code Section
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                          border: Border.all(color: Colors.grey.shade400),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        alignment: Alignment.center,
                        child: Text(
                          offerDetails?['CouponName'] ?? "No Coupon Code",
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      buildUpdateButton(),
                    ],
                  ),
                ),
    );
  }
}

Widget buildUpdateButton() {
  return SizedBox(
    width: double.infinity,
    child: CustomElevatedButton(
      text: "Copy offer code",
      buttonStyle: CustomButtonStyles.none,
      decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
      onPressed: () {
        // Add your logic here, e.g., copying the code to clipboard




      },
    ),
  );
}
*/

/*import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';

class OfferScreen extends StatelessWidget {
  const OfferScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Offers'),
        actions: [
          IconButton(
            icon: (SvgPicture.asset(
              ImageConstant.discount, // Your SVG asset path
              height: 24.0,
              width: 20.0,
            )),
            onPressed: () {
              // Handle settings action
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Offer Image and Description
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8.0),
                color: Colors.teal.shade100,
              ),
              padding: const EdgeInsets.all(2.0),
              child: Column(
                children: [
                  Image.asset(
                    'assets/images/bus_offer.png', // Replace with actual image path
                    fit: BoxFit.cover,
                    height: 150,
                    width: double.infinity,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Terms and Conditions
            const Text(
              "Terms and Conditions",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const TermsAndConditions(),

            const SizedBox(height: 24),

            // Offer Code Section
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8.0),
                border: Border.all(color: Colors.grey.shade400),
              ),
              padding: const EdgeInsets.symmetric(vertical: 16),
              alignment: Alignment.center,
              child: const Text(
                "BUSOFF100",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ),
            const SizedBox(height: 16),

            buildUpdateButton()
          ],
        ),
      ),
    );
  }
}

Widget buildUpdateButton() {
  return Container(
    width: double.infinity, // Make the button full width
    child: CustomElevatedButton(
      text: "Copy offer code",
      buttonStyle: CustomButtonStyles.none,
      decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
      onPressed: () {
        // Add your navigation or action logic here
        */ /*   Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => SearchingForCarScreen()),
        );*/ /*
      },
    ),
  );
}

class TermsAndConditions extends StatelessWidget {
  const TermsAndConditions({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const [
        Text(
          "1. Eligibility:",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Padding(
          padding: EdgeInsets.only(left: 16.0),
          child: Text(
            "• Offers may be restricted to certain routes, dates, or times.\n"
            "• Some discounts might be available only to specific groups, such as students, seniors, or frequent travelers.",
          ),
        ),
        SizedBox(height: 8),
        Text(
          "2. Booking and Payment:",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Padding(
          padding: EdgeInsets.only(left: 16.0),
          child: Text(
            "• Offers may only be valid for online bookings or through specific booking platforms.\n"
            "• A full payment or deposit might be required at the time of booking to secure the offer.",
          ),
        ),
        SizedBox(height: 8),
        Text(
          "3. Validity:",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Padding(
          padding: EdgeInsets.only(left: 16.0),
          child: Text(
            "• Offers may have an expiration date or be limited to a specific period.\n"
            "• There might be blackout dates when the offer is not valid (e.g., holidays or peak travel times).",
          ),
        ),
        SizedBox(height: 8),
        Text(
          "4. Refunds and Cancellations:",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Padding(
          padding: EdgeInsets.only(left: 16.0),
          child: Text(
            "• Special offers might have different refund and cancellation policies compared to standard tickets.\n"
            "• Some offers may be non-refundable or non-transferable.",
          ),
        ),
        SizedBox(height: 8),
        Text(
          "5. Changes and Modifications:",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Padding(
          padding: EdgeInsets.only(left: 16.0),
          child: Text(
            "• Restrictions may apply to changes in travel dates or passenger names.",
          ),
        ),
      ],
    );
  }
}*/
