import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../utils/AppConstants.dart';

class SavedPlacesScreen extends StatefulWidget {
  @override
  _SavedPlacesScreenState createState() => _SavedPlacesScreenState();
}

class _SavedPlacesScreenState extends State<SavedPlacesScreen> {
  List<dynamic> savedPlaces = [];
  bool isLoading = true;
  bool hasError = false;
  LatLng _initialPosition = LatLng(8.188957, 77.423601);

  @override
  void initState() {
    super.initState();
    fetchsavedPlaces(); // Fetch data when the screen is initialized
  }

  Future<LatLng> getCurrentLatLng() async {
    // Check if location services are enabled
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw Exception("Location services are disabled.");
    }

    // Request location permissions
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw Exception("Location permissions are denied.");
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception("Location permissions are permanently denied.");
    }

    // Get the current position
    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    return LatLng(position.latitude, position.longitude);
  }

  Future<void> _getCurrentLocation() async {
    setState(() {
      isLoading = true;
    });

    try {
      // Check if location services (GPS) are enabled
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        // If GPS is off, show the dialog to enable it
        _showGpsDialog();
        return;
      }

      // Check if location permission is granted
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        // If permission is denied, show the dialog to request permission
        _showPermissionDialog();
        return;
      }

      if (permission == LocationPermission.deniedForever) {
        // If permission is permanently denied, show the dialog to ask for permission again
        _showPermissionDialog();
        return;
      }

      // If permissions are granted, get the current location
      LatLng currentLatLng = await getCurrentLatLng();
      setState(() {
        _initialPosition = currentLatLng;
        isLoading = false;
      });

      // Reverse geocoding to get the address from the coordinates
      List<Placemark> placemarks = await placemarkFromCoordinates(
        currentLatLng.latitude,
        currentLatLng.longitude,
      );



      // Move the map camera to the current location

      // Call the API after fetching the location
      fetchsavedPlaces();
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      showError("Failed to get current location: $e");
    }
  }

  void _showGpsDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Enable GPS"),
          content: Text("Please enable your GPS to continue."),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
                // Open location settings for the user to enable GPS
                await Geolocator.openLocationSettings();
                // After the user returns from settings, try again
                _getCurrentLocation();
              },
              child: Text("Go to Settings"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                showError("GPS is required for this functionality.");
              },
              child: Text("Cancel"),
            ),
          ],
        );
      },
    );
  }

  void _showPermissionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Location Permission"),
          content: Text("Please grant location permission to continue."),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();

                // Request permission again
                LocationPermission permission =
                await Geolocator.requestPermission();

                // Check the permission status after requesting
                if (permission == LocationPermission.denied) {
                  // If permission is still denied, show dialog again
                  _showPermissionDialog();
                } else if (permission == LocationPermission.deniedForever) {
                  // If permission is denied forever, ask user to enable manually
                  _showPermissionDeniedForeverDialog();
                } else {
                  // If permission is granted, proceed to get the location
                  _getCurrentLocation();
                }
              },
              child: Text("Grant Permission"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                showError("Location permission is required.");
              },
              child: Text("Cancel"),
            ),
          ],
        );
      },
    );
  }

  void _showPermissionDeniedForeverDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Permission Denied Forever"),
          content: Text(
              "You have permanently denied location permission. Please enable it from settings to continue."),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();
                // Open app settings to allow the user to grant permission manually
                await Geolocator.openAppSettings();
              },
              child: Text("Open Settings"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                showError("Location permission is required.");
              },
              child: Text("Cancel"),
            ),
          ],
        );
      },
    );
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }
  Future<void> fetchsavedPlaces() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}saved_locations_list');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "pageNo": "1",
      "fromlatitude": _initialPosition.latitude.toString(),
      "fromlongitude": _initialPosition.longitude.toString(),
    });

    print("savedlocation in...");
    print("svfromlatitude..." + _initialPosition.latitude.toString());
    print("svfromlongitude..." + _initialPosition.longitude.toString());
    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        print("savedlocation 200...");

        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            print("savedlocation true...");

            savedPlaces = data['data']['All_Locations'] ?? [];
            isLoading = false;
            print("savedlocation last...");

            //    print(savedPlaces);
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
          print("savedlocation ="+data['message']);

        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');

      }
    } catch (e) {
      showError('An error occurred: $e');
      print("savedlocation error = $e");

    }
  }
  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Saved Places',
          style: TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w500),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0.5,
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : hasError
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Failed to load saved places",
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: fetchsavedPlaces,
              child: Text("Retry"),
            ),
          ],
        ),
      )
          : savedPlaces.isEmpty
          ? Center(
        child: Text(
          "No saved places available",
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
      )
          : Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: ListView.builder(
          itemCount: savedPlaces.length,
          itemBuilder: (context, index) {
            final place = savedPlaces[index];
            return ListTile(
              leading: Icon(Icons.bookmark, color: Color(0xFF4181FF)),
              title: Text(
                place['SLTitle'] ?? "No Title",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                place['SLAddress'] ?? "No Address",
                style: TextStyle(color: Colors.grey[600]),
              ),
              trailing: Text(
                "${place['distance']} km",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              contentPadding: EdgeInsets.symmetric(vertical: 8.0),
              onTap: () {
                // Perform actions like navigation or setting location
                print("Tapped on: ${place['SLTitle']}");
              },
            );
          },
        ),
      ),
    );
  }
}
