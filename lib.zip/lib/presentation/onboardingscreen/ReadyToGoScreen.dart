import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../login_screen/login_screen.dart';
import 'OnboardingScreentwo.dart';

class ReadyToGoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
      // Navigate to Login Page
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => OnboardingScreentwo(),
        ),
      );
      return false; // Prevent default back navigation
    },
    child:Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Icons Row
            SizedBox(height: 80),


            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Image.asset(
                    'assets/images/onb_bus.png', // Replace with your image asset
                    height: 60,
                  ),
                  Image.asset(
                    'assets/images/onb_flight.png', // Replace with your image asset
                    height: 60,
                  ),
                  Image.asset(
                    'assets/images/onb_hotel.png', // Replace with your image asset
                    height: 60,
                  ),
                  Image.asset(
                    'assets/images/onb_car.png', // Replace with your image asset
                    height: 60,
                  ),
                ],
              ),
            ),
            SizedBox(height: 40),
            // Logo
            Image.asset(
              'assets/images/onb_logo.png', // Replace with your logo asset
              height: 130,
            ),
            SizedBox(height: 30),
            // Title
            Text(
              'Ready to Go?',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 10),
            // Subtitle
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30.0),
              child: Text(
                'Start exploring now and plan your next adventure with Ticketapp365.',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Spacer(),
            // Page Indicator
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(width: 8),
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(width: 8),


                Container(
                  width: 25,
                  height: 8,
                  decoration: BoxDecoration(
                    color:  Color(0xFF4181FF),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ],
            ),
            SizedBox(height: 50),
            // Start Exploring Button
            Padding(
              padding: const EdgeInsets.only(right: 20.0, bottom: 20.0,left: 175.0),
              child: Align(
                alignment: Alignment.bottomRight,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => LoginScreen()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.zero, // Remove default padding for gradient
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Ink(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFF4181FF),
                          Color(0xFF274E99), // Define gradient colors here
                        ],
                       // begin: Alignment.topLeft,
                        //end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 12.w, horizontal: 25.h),
                      alignment: Alignment.center,
                      child: Text(
                        'Start Exploring',
                        style: TextStyle(
                          fontSize: 15.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            SizedBox(height: 20),
          ],
        ),
      ),
    ),
    );
  }
}
