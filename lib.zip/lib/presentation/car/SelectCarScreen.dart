import 'dart:convert';
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertickect365/presentation/cab_homepage_screen/cab_homepage_screen.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../theme/theme_helper.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';
import 'RideConfirmationScreen.dart';
import 'package:http/http.dart' as http;

class SelectCarScreen extends StatefulWidget {
  @override
  _SelectCarScreenState createState() => _SelectCarScreenState();
}

class _SelectCarScreenState extends State<SelectCarScreen> {
  int selectedCarIndex = -1; // Default to no car selected
  bool isLoading = true;
  List<dynamic> carList = []; // List to hold car data

  String distanceData = "";
  String durationData = "";
  String timeData = "";
  String clickamt = "0";

  @override
  void initState() {
    super.initState();
    fetchCarData();
    retrieveData();
    getSavedDurationText();
    getDistanceAndDuration();
  }

  Future<Map<String, String>> getDistanceAndDuration() async {
    final prefs = await SharedPreferences.getInstance();
    String distance = prefs.getString('saved_distance') ?? '0.0';
    String duration = prefs.getString('saved_duration') ?? '00:00:00';
    return {
      'distance': distance,
      'duration': duration,
    };
  }

  Future<String?> getSavedDurationText() async {
    final prefs = await SharedPreferences.getInstance();
    String? durationText = prefs.getString('timeText');
    print('Retrieved Duration Text: $durationText');
    timeData = durationText!;
  }

  void retrieveData() async {
    Map<String, String> data = await getDistanceAndDuration();
    print('Saved Distance: ${data['distance']}');
    print('Saved Duration: ${data['duration']}');

    // Assign the values to variables
    distanceData = data['distance'] ?? '0.0'; // Default to '0.0' if null
    durationData =
        data['duration'] ?? '00:00:00'; // Default to '00:00:00' if null

    print('Distance Data: $distanceData');
    print('Duration Data: $durationData');
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

// Function to calculate distance using the Haversine formula
  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const double earthRadius = 6371.0; // Radius of the Earth in kilometers

    // Convert degrees to radians
    double lat1Rad = _toRadians(lat1);
    double lon1Rad = _toRadians(lon1);
    double lat2Rad = _toRadians(lat2);
    double lon2Rad = _toRadians(lon2);

    // Differences in coordinates
    double deltaLat = lat2Rad - lat1Rad;
    double deltaLon = lon2Rad - lon1Rad;

    // Haversine formula
    double a = sin(deltaLat / 2) * sin(deltaLat / 2) +
        cos(lat1Rad) * cos(lat2Rad) * sin(deltaLon / 2) * sin(deltaLon / 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));

    // Calculate the distance
    double distance = earthRadius * c;

    return distance; // Distance in kilometers
  }

// Function to convert degrees to radians
  double _toRadians(double degree) {
    return degree * (pi / 180.0);
  }

  Future<void> fetchCarData() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}search_Driver');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    DateTime now = DateTime.now();
    String formattedTime = DateFormat('HH:mm:ss').format(now);
    print("Current Time: $formattedTime");
// Save current location and destination location to SharedPreferences
    final prefs = await SharedPreferences.getInstance();
    // Retrieve the saved values from SharedPreferences
    double currentLat = prefs.getDouble('current_lat') ?? 0.0;
    double currentLng = prefs.getDouble('current_lng') ?? 0.0;
    double destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
    double destinationLng = prefs.getDouble('destination_lng') ?? 0.0;

    //  final body = jsonEncode({
    //   "BookingFromLatitude": "8.188957",
    //   "BookingFromLongitude": "77.423601",
    //   "BookingToLatitude": "8.288957",
    //   "BookingToLongitude": "77.523601",
    //   "Distance": "10",
    //   //"Time": "04:10:20",
    //   "Time": formattedTime,
    // });
    final body = jsonEncode({
      "BookingFromLatitude": currentLat.toString(),
      "BookingFromLongitude": currentLng.toString(),
      "BookingToLatitude": destinationLat.toString(),
      "BookingToLongitude": destinationLng.toString(),
      "Distance":
          distanceData, // You can calculate the actual distance if needed
      //"Time": formattedTime,
      "Time": durationData,
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print("show all driver${data}");
        if (data['status'] == true) {
          setState(() {
            carList = data['data']['ResultArray'] ?? [];
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Select Car',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 17,
            color: Colors.black,
          ),
        ),
        elevation: 0,
      ),
/*
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? Center(
                child:
                    CircularProgressIndicator()) // Show loading indicator while fetching data
            : Column(
                children: [
                  // Display the car options with margin between list items
                  Expanded(
                    child: ListView.builder(
                      itemCount: carList.length,
                      itemBuilder: (context, index) {
                        final car = carList[index];
                        return Padding(
                          padding: const EdgeInsets.only(
                              bottom: 16.0), // Add margin between list items
                          child: _buildCarOption(
                            index: index,
                            title: car['VTModalName'],
                            price: '₹${car['totalPrice'].toStringAsFixed(2)}',
                            available: '${car['NoOfagents']} Available',
                            icon: SvgPicture.asset(
                              ImageConstant.toycar, // Your SVG asset path
                              height: 30.0,
                              width: 30.0,
                            ),
                            vtId: car['VTID'].toString(), // Pass VTID
                          ),
                        );
                      },
                    ),
                  ),
                  _buildBottomBar(),
                  SizedBox(height: 16),
                  buildUpdateButton(),
                ],
              ),
      ),
*/

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? Center(
                child: CircularProgressIndicator(), // Show loading indicator
              )
            : carList.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          'assets/images/no_cab_found.png', // Path to your image
                          height: 550, // Adjust the size as needed
                          width: 350,
                        ),

                        // SizedBox(height: 24),
                        Spacer(),
                        backtoHomeButton(),
                      ],
                    ),
                  )
                : Column(
                    children: [
                      Expanded(
                        child: ListView.builder(
                          itemCount: carList.length,
                          itemBuilder: (context, index) {
                            final car = carList[index];
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 16.0),
                              child: _buildCarOption(
                                index: index,
                                title: car['VTModalName'],
                                price:
                                    '₹${car['totalPrice'].toStringAsFixed(2)}',
                                available: '${car['NoOfagents']} Available',
                                icon: SvgPicture.asset(
                                  ImageConstant.toycar,
                                  height: 30.0,
                                  width: 30.0,
                                ),
                                vtId: car['VTID'].toString(),
                              ),
                            );
                          },
                        ),
                      ),
                      _buildBottomBar(),
                      SizedBox(height: 16),
                      buildUpdateButton(),
                    ],
                  ),
      ),
    );
  }

  // Widget buildUpdateButton() {
  //   return Container(
  //     child: CustomElevatedButton(
  //       text: "Continue",
  //       buttonStyle: CustomButtonStyles.none,
  //       decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
  //       onPressed: () async {
  //         // Check if a car is selected
  //         if (selectedCarIndex == -1) {
  //           // No car selected, show error message
  //           ScaffoldMessenger.of(context).showSnackBar(
  //             SnackBar(content: Text("Please select a car")),
  //           );
  //         } else {
  //           // Proceed to the next page if a car is selected
  //           Navigator.push(
  //             context,
  //             MaterialPageRoute(builder: (context) => RideConfirmationScreen()),
  //           );
  //         }
  //       },
  //     ),
  //   );
  // }

  Widget buildUpdateButton() {
    return Container(
      child: CustomElevatedButton(
        text: "Continue",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () async {
          if (selectedCarIndex == -1) {
            // No car selected
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Please select a car")),
            );
          } else {
            // Check if the selected car has available agents
            final selectedCar = carList[selectedCarIndex];

            if (selectedCar['NoOfagents'] == 0) {
              // Show a toast/snackbar for no availability
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    "No car is available for the selected option, please choose another car",
                  ),
                ),
              );
            } else {
              // Navigate to the next page if car is available
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => RideConfirmationScreen()),
              );
            }
            /*Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => RideConfirmationScreen()),
            );*/
          }
        },
      ),
    );
  }

  Widget backtoHomeButton() {
    return Container(
      child: CustomElevatedButton(
        text: "Back to Home",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          /*  Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => CabHomepageScreen()),
          );*/

          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => CabHomepageScreen()),
            (Route<dynamic> route) =>
                false, // This condition removes all routes
          );
        },
      ),
    );
  }

  Widget _buildCarOption({
    required int index,
    required String title, // This is car name
    required String price, // This is car price
    required String available,
    required Widget icon,
    required String vtId, // Add VTID parameter
  }) {
    return InkWell(
      onTap: () {
        setState(() {
          selectedCarIndex = index;
        });
        // Save VTID when car is selected
        _saveSelectedCar(vtId); // Save VTID to SharedPreferences
        _saveSelectedCarname(title); // Save carname to SharedPreferences
        _saveSelectedCarprice(price); // Save carprice to SharedPreferences

        setState(() {
          clickamt = price;
        });
      },
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selectedCarIndex == index ? Colors.blue : Colors.grey[300]!,
            width: selectedCarIndex == index ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            icon,
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 15,
                      color: Color(0xFF282828),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    available,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              price,
              style: TextStyle(
                fontSize: 15,
                color: Color(0xFF282828),
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(width: 8),
            Radio(
              value: index,
              groupValue: selectedCarIndex,
              onChanged: (value) {
                setState(() {
                  selectedCarIndex = value as int;
                });
                _saveSelectedCar(
                    vtId); // Save VTID to SharedPreferences when car is selected
                _saveSelectedCarname(
                    title); // Save carname to SharedPreferences
                _saveSelectedCarprice(
                    price); // Save carprice to SharedPreferences
                setState(() {
                  clickamt = price;
                });
              },
              activeColor: Colors.blue,
            ),
          ],
        ),
      ),
    );
  }

// Save VTID to SharedPreferences
  Future<void> _saveSelectedCar(String vtId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('vtId', vtId); // Save the VTID of the selected car
  }

  Future<void> _saveSelectedCarname(String carname) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        'carname', carname); // Save the name of the selected car
  }

  Future<void> _saveSelectedCarprice(String carprice) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        'carprice', carprice); // Save the price of the selected car
  }

  Widget _buildBottomBar() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Color(0xFFBDBDBD),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildInfoIcon(
                icon: SvgPicture.asset(
                  ImageConstant.greylocation,
                  height: 24.0,
                  width: 20.0,
                ),
                label: distanceData + " km",
              ),
              _buildInfoIcon(
                icon: SvgPicture.asset(
                  ImageConstant.greytime,
                  height: 24.0,
                  width: 20.0,
                ),
                label: timeData,
              ),
              _buildInfoIcon(
                icon: SvgPicture.asset(
                  ImageConstant.greywallet,
                  height: 24.0,
                  width: 20.0,
                ),
                label: clickamt,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoIcon({required Widget icon, required String label}) {
    return Row(
      children: [
        icon,
        SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 15,
            color: Color(0xFF282828),
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

/*  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Select Car',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 17,
            color: Colors.black,
          ),
        ),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isLoading
            ? Center(
                child:
                    CircularProgressIndicator()) // Show loading indicator while fetching data
            : Column(
                children: [
                  // Display the car options
                  Expanded(
                    child: ListView.builder(
                      itemCount: carList.length,
                      itemBuilder: (context, index) {
                        final car = carList[index];
                        return _buildCarOption(
                          index: index,
                          title: car['VTModalName'],
                          price: '₹${car['totalPrice'].toStringAsFixed(2)}',
                          available: '${car['NoOfagents']} Available',
                          */ /* icon: Image.network(
                            '${AppConstants.HOST}${car['VTImage']}', // Using network image
                            height: 30.0,
                            width: 30.0,
                            fit: BoxFit.cover,
                          ),*/ /*
                          icon: SvgPicture.asset(
                            ImageConstant.toycar, // Your SVG asset path
                            height: 30.0,
                            width: 30.0,
                          ),
                        );
                      },
                    ),
                  ),
                  _buildBottomBar(),
                  SizedBox(height: 16),
                  buildUpdateButton(),
                ],
              ),
      ),
    );
  }*/

/*import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../theme/theme_helper.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';
import 'RideConfirmationScreen.dart';
import 'package:http/http.dart' as http;

class SelectCarScreen extends StatefulWidget {
  @override
  _SelectCarScreenState createState() => _SelectCarScreenState();
}

class _SelectCarScreenState extends State<SelectCarScreen> {
  int selectedCarIndex = 1; // Default selected car
  bool isLoading = true;
  List<dynamic> recentPlaces = [];

  @override
  void initState() {
    super.initState();
    fetchRecentPlaces();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchRecentPlaces() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}search_Driver');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "BookingFromLatitude": "8.188957",
      "BookingFromLongitude": "77.423601",
      "BookingToLatitude": "8.288957",
      "BookingToLongitude": "77.523601",
      "Distance": "10",
      "Time": "04:10:20",
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            recentPlaces = data['data']['ResultArray'] ?? [];
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Select Car',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 17,
            color: Colors.black,
          ),
        ),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildCarOption(
              index: 0,
              title: 'Mini Car',
              price: '₹120',
              available: '7 Available',
              icon: SvgPicture.asset(
                ImageConstant.toycar, // Your SVG asset path
                height: 30.0,
                width: 30.0,
              ),
            ),
            SizedBox(height: 16),
            _buildCarOption(
              index: 1,
              title: 'Premium Car',
              price: '₹200',
              available: '7 Available',
              icon: SvgPicture.asset(
                ImageConstant.toycar, // Your SVG asset path
                height: 30.0,
                width: 30.0,
              ),
            ),
            SizedBox(height: 16),
            _buildCarOption(
              index: 2,
              title: 'Luxury Car',
              price: '₹300',
              available: '3 Available',
              icon: SvgPicture.asset(
                ImageConstant.toycar, // Your SVG asset path
                height: 30.0,
                width: 30.0,
              ),
            ),
            Spacer(),
            _buildBottomBar(),
            SizedBox(height: 16),
            buildUpdateButton()
          ],
        ),
      ),
    );
  }

  Widget buildUpdateButton() {
    return Container(
      // Horizontal margin if needed, uncomment below line
      // margin: EdgeInsets.symmetric(horizontal: 16.0),
      child: CustomElevatedButton(
        text: "Continue",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Navigate to the next page
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => RideConfirmationScreen()),
          );
        },
      ),
    );
  }

  Widget _buildCarOption({
    required int index,
    required String title,
    required String price,
    required String available,
    required Widget icon,
  }) {
    return InkWell(
      onTap: () {
        setState(() {
          selectedCarIndex = index;
        });
      },
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selectedCarIndex == index
                ? Colors.grey[300]!
                : Colors.grey[300]!,
            width: selectedCarIndex == index ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            icon, // This now accepts both Icon and SvgPicture
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 15,
                      color: Color(0xFF282828),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    available,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              price,
              style: TextStyle(
                fontSize: 15,
                color: Color(0xFF282828),
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(width: 8),
            Radio(
              value: index,
              groupValue: selectedCarIndex,
              onChanged: (value) {
                setState(() {
                  selectedCarIndex = value as int;
                });
              },
              activeColor: Colors.blue,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Color(0xFFBDBDBD), // Border color #BDBDBD
          width: 1, // Adjust the width as needed
        ),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildInfoIcon(
                icon: SvgPicture.asset(
                  ImageConstant.greylocation, // Your SVG asset path
                  height: 24.0,
                  width: 20.0,
                ),
                label: '4.5 km',
              ),
              _buildInfoIcon(
                icon: SvgPicture.asset(
                  ImageConstant.greytime, // Your SVG asset path
                  height: 24.0,
                  width: 20.0,
                ),
                label: '4 mins',
              ),
              _buildInfoIcon(
                icon: SvgPicture.asset(
                  ImageConstant.greywallet, // Your SVG asset path
                  height: 24.0,
                  width: 20.0,
                ),
                label: '₹200',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoIcon({required Widget icon, required String label}) {
    return Row(
      children: [
        icon,
        SizedBox(width: 4),
        Text(
          label,
          // style: TextStyle(color: Colors.grey[600]),
          style: TextStyle(
            fontSize: 15,
            color: Color(0xFF282828),
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}*/

/*
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SelectCarScreen extends StatefulWidget {
  @override
  _SelectCarScreenState createState() => _SelectCarScreenState();
}

class _SelectCarScreenState extends State<SelectCarScreen> {
  int selectedCarIndex = 1; // Default selected car

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Select Car'),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildCarOption(
              index: 0,
              title: 'Mini Car',
              price: '₹120',
              available: '7 Available',
              icon: Icons.directions_car,
            ),
            SizedBox(height: 16),
            _buildCarOption(
              index: 1,
              title: 'Premium Car',
              price: '₹200',
              available: '7 Available',
              icon: Icons.directions_car,
            ),
            SizedBox(height: 16),
            _buildCarOption(
              index: 2,
              title: 'Premium Car',
              price: '₹200',
              available: '7 Available',
              icon: Icons.directions_car,
            ),
            Spacer(),
            _buildBottomBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildCarOption({
    required int index,
    required String title,
    required String price,
    required String available,
    required IconData icon,
  }) {
    return InkWell(
      onTap: () {
        setState(() {
          selectedCarIndex = index;
        });
      },
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selectedCarIndex == index ? Colors.blue : Colors.grey[300]!,
            width: selectedCarIndex == index ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 40,
              color: Colors.orange,
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    available,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            Text(
              price,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(width: 8),
            Radio(
              value: index,
              groupValue: selectedCarIndex,
              onChanged: (value) {
                setState(() {
                  selectedCarIndex = value as int;
                });
              },
              activeColor: Colors.blue,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildInfoIcon(Icons.location_on, '4.5 km'),
              _buildInfoIcon(Icons.access_time, '4 mins'),
              _buildInfoIcon(Icons.attach_money, '₹200'),
            ],
          ),
          SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                // Handle continue action
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text(
                'Continue',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoIcon(IconData icon, String label) {
    return Row(
      children: [
        Icon(icon, size: 20, color: Colors.grey[600]),
        SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(color: Colors.grey[600]),
        ),
      ],
    );
  }
}
*/
