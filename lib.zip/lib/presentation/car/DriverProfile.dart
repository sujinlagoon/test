import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../../core/utils/image_constant.dart';
import '../chat/ChatScreen.dart';
import '../utils/AppConstants.dart';

class DriverProfile extends StatefulWidget {
  @override
  _DriverProfileState createState() => _DriverProfileState();
}

class _DriverProfileState extends State<DriverProfile> {
  String driverName = "";
  String phoneNumber = "";
  Uri? profileImageUri;

  double driverRating = 0;
  int tripsCompleted = 0;
  int yearsOfExperience = 0;
  String memberSince = "0";
  String AgentID = "";

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    fetchCarData();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<String?> getBookingID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('bookingid');
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri, mode: LaunchMode.externalApplication);
    } else {
      showError('Could not launch dialer');
    }
  }

  Future<void> fetchCarData() async {
    String? bookid = await getBookingID();

    setState(() {
      isLoading = true;
    });

    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }
    if (bookid == null) {
      showError("Authentication bookingid not found");
      return;
    }

    //final url = Uri.parse('${AppConstants.MAIN_URL}driver_details_trip');
    final url = Uri.parse('${AppConstants.MAIN_URL}driver_details');
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
     // "booking_id": "88",
      "booking_id": bookid,
    });

    try {
      final response = await http.post(url, headers: headers, body: body);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == true) {
          setState(() {
            final driverDetails = data['driver_details'];

            driverName = driverDetails['AgentName'] ?? "";
            phoneNumber = driverDetails['AgentPhone'] ?? "";
            AgentID = driverDetails['AgentID']?.toString() ?? "";
            driverRating =
                double.tryParse(driverDetails['AgentTotalRatings'] ?? '0.0') ??
                    0.0;
            tripsCompleted = data['driver_total_rides'] ?? 0;
            yearsOfExperience = 5;
            memberSince = driverDetails['AgentCreatedAt'] ?? 'Unknown';

            print("inside");
            print("profileImageUri = "+driverDetails['AgentProfImg']);


            profileImageUri = driverDetails['AgentProfImg'] != null
                ? Uri.parse(AppConstants.HOST + driverDetails['AgentProfImg'])
                : null;


          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void showError(String message) {
    setState(() {});
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(
                context); // This will navigate back to the previous screen
          },
        ),
        title: Text(
          "Driver Details",
          style: TextStyle(
            fontFamily: 'Poppins',
            color: Color(0XFF282828),
            fontWeight: FontWeight.w600,
            fontSize: 17,
          ),
        ),
     //   actions: [Icon(Icons.more_vert, color: Colors.black)],
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 16),
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: profileImageUri != null
                        ? NetworkImage(profileImageUri.toString())
                        : null,
                    child: profileImageUri == null
                        ? Icon(Icons.camera_alt,
                        size: 50, color: Colors.grey[700])
                        : null,
                  ),
                  SizedBox(height: 16),
                  Text(
                    driverName,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      color: Color(0XFF282828),
                    ),
                  ),
                  SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        phoneNumber,
                        style: TextStyle(
                          color: Color(0XFF282828),
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                        ),
                      ),
                      SizedBox(width: 8),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(ClipboardData(text: phoneNumber));
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                                content:
                                    Text('Phone number copied to clipboard')),
                          );
                        },
                        child: Icon(Icons.copy,
                            color: Color(0XFF282828), size: 16),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildInfoIcon(
                            Icons.star, driverRating.toString(), "Ratings"),
                        _buildInfoIcon(Icons.directions_car,
                            tripsCompleted.toString(), "Trips"),
                        /*_buildInfoIcon(Icons.access_time,
                            yearsOfExperience.toString(), "Years"),*/
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Member since",
                        style: TextStyle(
                          color: Color(0XFF404040),
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        memberSince,
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 16,
                          color: Color(0XFF282828),
                        ),
                      ),
                    ],
                  ),
                  Spacer(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildActionButton(
                          SvgPicture.asset(
                            ImageConstant.whitecomment,
                            height: 24.0,
                            width: 20.0,
                          ),
                          "Text", onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ChatScreen()),
                        );
                      }),
                      _buildActionButton(
                          SvgPicture.asset(
                            ImageConstant.whitephone,
                            height: 24.0,
                            width: 20.0,
                          ),
                          "Call",
                          onTap: () => _makePhoneCall(phoneNumber)),
                    ],
                  ),
                  SizedBox(height: 32),
                ],
              ),
      ),
    );
  }

  Widget _buildActionButton(Widget iconWidget, String label,
      {VoidCallback? onTap}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: onTap,
          child: CircleAvatar(
            radius: 30,
            backgroundColor: Color(0xFF4181FF),
            child: Center(child: iconWidget),
          ),
        ),
        SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: Color(0xFF7AA7FF),
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _buildInfoIcon(IconData icon, String value, String label) {
    return Column(
      children: [
        Icon(icon, color: Color(0XFF4181FF)),
        SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontFamily: 'Poppins',
            color: Color(0XFF282828),
            fontWeight: FontWeight.w500,
            fontSize: 14,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: Color(0XFF787878),
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            fontSize: 10,
          ),
        ),
      ],
    );
  }
}


