import 'dart:async';
import 'dart:convert';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import '../utils/AppConstants.dart';

class TripDetailsPage extends StatefulWidget {
  @override
  _TripDetailsPageState createState() => _TripDetailsPageState();
}

class _TripDetailsPageState extends State<TripDetailsPage> {
  late GoogleMapController mapController;
  Set<Polyline> _polylines = {}; // Set to store polyline routes
  //Set<Marker> _markers = {}; // Set to store markers for start and end points
  Map<String, Marker> _markersMap = {};
  double fare = 200;
  double rating = 4.5;
  String driverName = "";
  String carDetails = "";
  String fareamt = "";
  String startLocation = "Pothys, Nagercoil";
  String startAddress = "43N, Augusta St. Lorain, OH 44656";
  String endLocation = "50 Bucks, Nagercoil";
  String endAddress = "43N, Augusta St. Lorain, OH 44656";

  String distanceText = "";
  String durationText = "";

  late double currentLat;
  late double currentLng;
  late double destinationLat;
  late double destinationLng;
  late double thirdPlaceLat = 8.194301;
  late double thirdPlaceLng = 77.431377;

  String? carname;
  String? vtId;
  String? carprice;
  String? current_address;
  String? destination_address;
  String? fromename;
  String? fromaddress;
  String? toname;
  String? toaddress;
  bool isLoading = true;
  String? bookingID;
  Uri? profileImageUri;
  BitmapDescriptor? movingMarkerIcon;

  Map<String, dynamic>? driverDetails;

  // late GoogleMapController _mapController;
  // final LatLng _initialPosition =
  //     LatLng(37.7749, -122.4194); // Initial position for map

  // void _onMapCreated(GoogleMapController controller) {
  //   _mapController = controller;
  // }

  @override
  void initState() {
    super.initState();
    // fetchCarData();
    _loadSharedPreferences();
    fetchCarData();
    _loadCustomMarker();
  }

  void updateFare() {
    setState(() {
      fare += 50;
    });
  }

  Future<String?> getBookingID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('bookingid');
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Map<String, String> splitAddress(String fullAddress) {
    // Split the address by the first comma
    List<String> addressParts = fullAddress.split(', ');

    // Extract the main and secondary parts
    String mainAddress =
        addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
    String secondaryAddress = addressParts.length > 1
        ? addressParts
            .sublist(1)
            .join(', ') // Join the remaining parts with commas
        : "";

    return {
      "mainAddress": mainAddress,
      "secondaryAddress": secondaryAddress,
    };
  }

  Map<String, String> splitAddressto(String fullAddress) {
    // Split the address by the first comma
    List<String> addressParts = fullAddress.split(', ');

    // Extract the main and secondary parts
    String mainAddress =
        addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
    String secondaryAddress = addressParts.length > 1
        ? addressParts
            .sublist(1)
            .join(', ') // Join the remaining parts with commas
        : "";

    return {
      "mainAddress": mainAddress,
      "secondaryAddress": secondaryAddress,
    };
  }

  Future<void> _loadSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentLat = prefs.getDouble('current_lat') ?? 0.0;
      currentLng = prefs.getDouble('current_lng') ?? 0.0;
      destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
      destinationLng = prefs.getDouble('destination_lng') ?? 0.0;

      // currentLat = 8.189653;
      // currentLng = 77.401716;
      // destinationLat = 8.189753;
      // destinationLng = 77.401816;

      // carname = prefs.getString('carname');
      // vtId = prefs.getString('vtId');
      //carprice = prefs.getString('carprice');
      current_address = prefs.getString('current_address');
      destination_address = prefs.getString('destination_address');

      Map<String, String> addressParts = splitAddress(current_address!);
      Map<String, String> addressPartsto = splitAddressto(destination_address!);
      fromename = addressParts["mainAddress"];
      fromaddress = addressParts["secondaryAddress"];

      toname = addressPartsto["mainAddress"];
      toaddress = addressPartsto["secondaryAddress"];

      // Fetch the route and draw the polyline
      _getDirections();
      _startPeriodicUpdate();
    });
  }

  final CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(8.189653, 77.401716), // Coordinates for the initial position
    zoom: 12.0,
  );

/*  //polyen line:
  Future<void> _getDirections() async {
    String url =
        "https://maps.googleapis.com/maps/api/directions/json?origin=$currentLat,$currentLng&destination=$destinationLat,$destinationLng&key=AIzaSyBP5GUxTHqath5-maur0OZIUOf81dgZlTM";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      List<LatLng> polylineCoordinates = [];

      if (data['routes'].isNotEmpty) {
        var route = data['routes'][0]['legs'][0];

        // Get distance and duration
        String distance = route['distance']['text']; // e.g., '4.5 km'
        String duration = route['duration']['text']; // e.g., '10 mins'

        // Set the distance and duration in the UI
        setState(() {
          // Update the UI with distance and duration

          distanceText = distance;
          durationText = duration;

          print("distanceText = " + distanceText);
          print("durationText = " + durationText);

          var steps = route['steps'];
          for (var step in steps) {
            String encodedPolyline = step['polyline']['points'];
            polylineCoordinates.addAll(_decodePolyline(encodedPolyline));
          }

          // Add polyline and markers as usual
          _polylines.add(
            Polyline(
              polylineId: PolylineId("route"),
              color: Color(0xFF4181FF),
              width: 5,
              points: polylineCoordinates,
            ),
          );

          // Add markers for start and destination points
          _markers.add(
            Marker(
              markerId: MarkerId("start"),
              position: LatLng(currentLat, currentLng),
              infoWindow: InfoWindow(title: "Start Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueRed),
            ),
          );

          _markers.add(
            Marker(
              markerId: MarkerId("end"),
              position: LatLng(destinationLat, destinationLng),
              infoWindow: InfoWindow(title: "Destination Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueGreen),
            ),
          );
        });
      }
    } else {
      print('Failed to load directions');
    }
  }

  // Function to decode polyline points from the Directions API response
  List<LatLng> _decodePolyline(String encodedPolyline) {
    List<LatLng> polyline = [];
    int index = 0;
    int len = encodedPolyline.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int shift = 0;
      int result = 0;
      int byte;

      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lat += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      shift = 0;
      result = 0;
      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lng += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      polyline.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return polyline;
  }*/

/*  Future<void> _getDirections() async {
    String url =
        "https://maps.googleapis.com/maps/api/directions/json?origin=$currentLat,$currentLng&destination=$destinationLat,$destinationLng&key=AIzaSyBP5GUxTHqath5-maur0OZIUOf81dgZlTM";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      List<LatLng> polylineCoordinates = [];

      if (data['routes'].isNotEmpty) {
        var route = data['routes'][0]['legs'][0];

        // Get distance and duration
        String distance = route['distance']['text']; // e.g., '4.5 km'
        String duration = route['duration']['text']; // e.g., '10 mins'

        // Set the distance and duration in the UI
        setState(() {
          // Update the UI with distance and duration
          distanceText = distance;
          durationText = duration;

          print("distanceText = " + distanceText);
          print("durationText = " + durationText);

          var steps = route['steps'];
          for (var step in steps) {
            String encodedPolyline = step['polyline']['points'];
            polylineCoordinates.addAll(_decodePolyline(encodedPolyline));
          }

          // Add polyline and markers as usual
          _polylines.add(
            Polyline(
              polylineId: PolylineId("route"),
              color: Color(0xFF4181FF),
              width: 5,
              points: polylineCoordinates,
            ),
          );

          // Add markers for start and destination points
          _markers.add(
            Marker(
              markerId: MarkerId("start"),
              position: LatLng(currentLat, currentLng),
              infoWindow: InfoWindow(title: "Start Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueRed),
            ),
          );

          _markers.add(
            Marker(
              markerId: MarkerId("end"),
              position: LatLng(destinationLat, destinationLng),
              infoWindow: InfoWindow(title: "Destination Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueGreen),
            ),
          );

          // Adding a third marker at a specific point along the polyline 8.194301, 77.431377
          if (polylineCoordinates.isNotEmpty) {
            // Specify the latitude and longitude for the third marker
            double thirdPlaceLat = 8.194301; // Example latitude
            double thirdPlaceLng = 77.431377; // Example longitude

            LatLng thirdPlace = LatLng(thirdPlaceLat, thirdPlaceLng);

            // Add the third marker
            _markers.add(
              Marker(
                markerId: MarkerId("thirdPlace"),
                position: thirdPlace,
                infoWindow:
                    InfoWindow(title: "Third Place"), // You can customize this
                icon: BitmapDescriptor.defaultMarkerWithHue(
                    BitmapDescriptor.hueBlue),
              ),
            );
          }
        });
      }
    } else {
      print('Failed to load directions');
    }
  }

// Function to decode polyline points from the Directions API response
  List<LatLng> _decodePolyline(String encodedPolyline) {
    List<LatLng> polyline = [];
    int index = 0;
    int len = encodedPolyline.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int shift = 0;
      int result = 0;
      int byte;

      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lat += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      shift = 0;
      result = 0;
      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lng += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      polyline.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return polyline;
  }*/

  // Start the periodic update for every 10 seconds
  void _startPeriodicUpdate() {
    Timer.periodic(Duration(seconds: 10), (Timer timer) {
      _updateThirdMarker();

      print("running....");
    });
  }

  void _loadCustomMarker() async {
    movingMarkerIcon = await BitmapDescriptor.fromAssetImage(
      ImageConfiguration(size: Size(48, 48)),
      'assets/images/car_icon.png', // Path to your custom icon
    );
    setState(() {});

    print("in.....");
  }

  // Update third marker with new latitude and longitude
  Future<void> _updateThirdMarker() async {
    BitmapDescriptor carIcon;

    /* try {
      carIcon = await BitmapDescriptor.fromAssetImage(
        const ImageConfiguration(size: Size(48, 48)),
        'assets/car_icon.png', // Path to your car icon
      );
      print("okiamge");
    } catch (e) {
      print("Error loading car icon: $e");
      return;
    }*/

    setState(() {
      // Ensure you're fetching or calculating the new coordinates dynamically
      getBookingData(
          bookingID!); // Assuming this is fetching the latest coordinates

      print("lat===" + thirdPlaceLat.toString());
      print("thirdPlaceLng===" + thirdPlaceLng.toString());

      // Remove old third marker if it exists
      /* _markers.removeWhere((marker) => marker.markerId.value == 'thirdPlace');
      //_markers.clear(); // Clear old markers if necessary
      // Add new third marker with updated coordinates
      //_getDirections();
      _markers.add(
        Marker(
          markerId: MarkerId("thirdPlace"),
          position: LatLng(thirdPlaceLat, thirdPlaceLng), // New position
          infoWindow: InfoWindow(title: "Third Place"), // Info window title
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        ),
      );*/
      _markersMap["thirdPlace"] = Marker(
        markerId: MarkerId("thirdPlace"),
        position: LatLng(thirdPlaceLat, thirdPlaceLng),
        infoWindow: InfoWindow(title: "Third Place"),
        //icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        icon: movingMarkerIcon ?? BitmapDescriptor.defaultMarker,
      );
      /*  try {
        _markersMap["thirdPlace"] = Marker(
          markerId: MarkerId("thirdPlace"),
          position: LatLng(thirdPlaceLat, thirdPlaceLng),
          infoWindow: InfoWindow(title: "Third Place"),
          icon: carIcon,
        );
        print("okdonne");
      } catch (e) {
        print("Error updating marker: $e");
      }*/
      // Debugging to see the updated markers list
      /*  print("Updated markers count: ${_markers.length}");
      print("Markers: $_markers");*/
    });
  }

  Future<void> _getDirections() async {
    String url =
        "https://maps.googleapis.com/maps/api/directions/json?origin=$currentLat,$currentLng&destination=$destinationLat,$destinationLng&key=AIzaSyBP5GUxTHqath5-maur0OZIUOf81dgZlTM";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      List<LatLng> polylineCoordinates = [];

      if (data['routes'].isNotEmpty) {
        var route = data['routes'][0]['legs'][0];

        // Get distance and duration
        String distance = route['distance']['text']; // e.g., '4.5 km'
        String duration = route['duration']['text']; // e.g., '10 mins'

        // Set the distance and duration in the UI
        setState(() {
          distanceText = distance;
          durationText = duration;

          var steps = route['steps'];
          for (var step in steps) {
            String encodedPolyline = step['polyline']['points'];
            polylineCoordinates.addAll(_decodePolyline(encodedPolyline));
          }

          // Add polyline and markers as usual
          _polylines.add(
            Polyline(
              polylineId: PolylineId("route"),
              color: Color(0xFF4181FF),
              width: 5,
              points: polylineCoordinates,
            ),
          );

          // Add markers for start and destination points
          /* _markers.add(
            Marker(
              markerId: MarkerId("start"),
              position: LatLng(currentLat, currentLng),
              infoWindow: InfoWindow(title: "Start Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueRed),
            ),
          );

          _markers.add(
            Marker(
              markerId: MarkerId("end"),
              position: LatLng(destinationLat, destinationLng),
              infoWindow: InfoWindow(title: "Destination Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueGreen),
            ),
          );*/

          // Update markers for start, destination, and third place
          _markersMap["start"] = Marker(
            markerId: MarkerId("start"),
            position: LatLng(currentLat, currentLng),
            infoWindow: InfoWindow(title: "Start Location"),
            icon:
                BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          );
          _markersMap["end"] = Marker(
            markerId: MarkerId("end"),
            position: LatLng(destinationLat, destinationLng),
            infoWindow: InfoWindow(title: "Destination Location"),
            icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueGreen),
          );
        });
      }
    } else {
      print('Failed to load directions');
    }
  }

  // Function to decode polyline points from the Directions API response
  List<LatLng> _decodePolyline(String encodedPolyline) {
    List<LatLng> polyline = [];
    int index = 0;
    int len = encodedPolyline.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int shift = 0;
      int result = 0;
      int byte;

      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lat += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      shift = 0;
      result = 0;
      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lng += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      polyline.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return polyline;
  }

  //to get data from firebase:
  Future<void> getBookingData(String bookingID) async {
    try {
      // Reference to the specific bookingID under 'customers'
      DatabaseReference databaseRef =
          FirebaseDatabase.instance.ref('agent/$bookingID');

      // Retrieve the data
      DatabaseEvent event = await databaseRef.once();

      // Check if data exists
      if (event.snapshot.exists) {
        // Get the data as a Map
        Map<dynamic, dynamic>? data =
            event.snapshot.value as Map<dynamic, dynamic>?;

        // Extract specific fields and convert them to strings
        String customerID = data?['customerID'].toString() ?? "No ID available";
        String cusLatitude = data?['cusLatitude'].toString() ?? "0.0";
        String cusLongitude = data?['cusLongitude'].toString() ?? "0.0";

        print("getCustomer ID: $customerID");
        print("getLatitude: $cusLatitude");
        print("getLongitude: $cusLongitude");

        thirdPlaceLat = double.parse(
            cusLatitude); // For demonstration, slightly change the latitude
        thirdPlaceLng = double.parse(cusLongitude);
        print("getLatitude===" + thirdPlaceLat.toString());
        print("getLongitude===" + thirdPlaceLng.toString());

        // You can now use these variables as needed
      } else {
        print("No data found for bookingID: $bookingID");
      }
    } catch (e) {
      print("Error retrieving booking data: $e");
    }
  }

  Future<void> fetchCarData() async {
    String? token = await getToken();
    String? bookid = await getBookingID();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }
    if (bookid == null) {
      showError("Authentication bookingid not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}driver_details_trip');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      //"booking_id": "1", // Replace with dynamic booking_id if needed
      "booking_id": bookid, // Replace with dynamic booking_id if needed
    });
    //  Fluttertoast.showToast(
    //   msg: bookid,
    //   toastLength: Toast.LENGTH_SHORT,
    //   gravity: ToastGravity.BOTTOM,
    // );

    //print("bookid = " + bookid);
    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            print('in.....');

            driverDetails = data['driver_details'];

            driverName = data['AgentName'] ?? "";
            carDetails = data['AgentVehicleNumber'] ?? "";
            print(carDetails);
            fareamt = data['fareAmt'].toString() ?? "0";
            print("fareamt = " + fareamt);

            isLoading = false;

            profileImageUri = driverDetails?['AgentProfImg'] != null
                ? Uri.parse(AppConstants.HOST + driverDetails?['AgentProfImg'])
                : null;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            // Google Map as background
            /*       GoogleMap(
              onMapCreated: _onMapCreated,
              initialCameraPosition: CameraPosition(
                target: _initialPosition,
                zoom: 12.0,
              ),
              markers: {
                Marker(
                  markerId: MarkerId("start"),
                  position: _initialPosition,
                  infoWindow: InfoWindow(title: startLocation),
                ),
                Marker(
                  markerId: MarkerId("end"),
                  position: LatLng(
                      37.7849, -122.4094), // Example position for end location
                  infoWindow: InfoWindow(title: endLocation),
                ),
              },
            ),*/

            Padding(
              padding: const EdgeInsets.only(top: 5),
              child: GoogleMap(
                initialCameraPosition: _initialCameraPosition,
                mapType: MapType.normal,
                onMapCreated: (GoogleMapController controller) {
                  mapController = controller;
                },
                polylines: _polylines, // Display the polyline
                //  markers: _markers, // Display the markers
                markers: _markersMap.values.toSet(), // Display the markers
                zoomControlsEnabled: true, // Allow zoom controls
              ),
            ),
            Positioned(
              top: 10,
              left: 10,
              child: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ),
            // Trip Details Section
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Trip to Destination",
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w600,
                                fontSize: 17,
                                color: Color(0xFF282828)),
                          ),
                          Text(
                            distanceText,
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 13,
                                color: Color(0xFF282828)),
                          ),
                        ]),
                    SizedBox(height: 8),
                    Padding(
                      padding: EdgeInsets.only(
                          top: 16), // Set desired top margin value
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 30,
                            backgroundColor: Colors.grey[300],
                            backgroundImage: profileImageUri != null
                                ? NetworkImage(profileImageUri.toString())
                                : null,
                            child: profileImageUri == null
                                ? Icon(Icons.camera_alt,
                                    size: 30, color: Colors.grey[500])
                                : null,
                          ),
                          SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                // driverName,
                                driverDetails?['AgentName'] ?? "Driver Name",
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                  color: Color(0xFF282828),
                                ),
                              ),
                              Text(
                                //carDetails,
                                driverDetails?['AgentVehicleNumber'] ??
                                    "Vehicle Number",
                                style: TextStyle(color: Colors.grey[600]),
                              ),
                            ],
                          ),
                          Spacer(),
                          Column(
                            children: [
                              Icon(Icons.star, color: Color(0xFF4181FF)),
                              Text(
                                rating.toString(),
                                style: TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 24, height: 12),
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                            color: Color(0xFFBEBEBE)), // Grey border color
                        borderRadius: BorderRadius.circular(
                            8), // Optional: rounded corners
                      ),
                      padding: EdgeInsets.all(
                          8), // Optional: padding inside the border
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment
                                .spaceBetween, // Adjusts spacing between texts
                            children: [
                              Text(
                                "Total Fare ",
                                style: TextStyle(
                                  color: Color(0xFF282828),
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                              Text(
                                "₹$fareamt",
                                style: TextStyle(
                                  color: Color(0xFF4181FF),
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                          ElevatedButton(
                            onPressed: updateFare,
                            style: ElevatedButton.styleFrom(
                              shape: StadiumBorder(),
                              backgroundColor: Colors
                                  .white, // White background to match the border
                              //side: BorderSide(color: Colors.grey), // Optional: border around button
                            ),
                            child: Text(
                              "Pay now",
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                                color: Color(
                                    0xFFB7B7B7), // Blue text color for the button
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 16),
                    Row(
                      children: [
                        Column(
                          children: [
                            Icon(Icons.radio_button_checked,
                                color: Color(0xFF4181FF)),
                            Container(
                              height: 40,
                              width: 2,
                              color: Colors.grey[300],
                            ),
                            Icon(Icons.location_on, color: Color(0xFF4181FF)),
                          ],
                        ),
                        SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              fromename!,
                              //   "name..",
                              style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                  color: Color(0xFF282828)),
                            ),
                            Text(
                              fromaddress!,
                              //"name..",
                              style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                  color: Color(0xFFBDBDBD)),
                            ),
                            SizedBox(height: 16),
                            Text(
                              toname!,
                              //"name..",
                              style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                  color: Color(0xFF282828)),
                            ),
                            Text(
                              toaddress!,
                              // "name",
                              style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                  color: Color(0xFFBDBDBD)),
                            ),
                          ],
                        ),
                        /*   Spacer(),
                        Column(
                          children: [
                            Icon(Icons.bookmark_border, color: Colors.grey),
                            SizedBox(height: 40),
                            Icon(Icons.bookmark_border, color: Colors.grey),
                          ],
                        ),*/
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/*
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class TripDetailsPage extends StatefulWidget {
  @override
  _TripDetailsPageState createState() => _TripDetailsPageState();
}

class _TripDetailsPageState extends State<TripDetailsPage> {
  double fare = 200;
  double rating = 4.5;
  String driverName = "Daniel Austin";
  String carDetails = "Verna TN75AK9681";
  String startLocation = "Pothys, Nagercoil";
  String startAddress = "43N, Augusta St. Lorain, OH 44656";
  String endLocation = "50 Bucks, Nagercoil";
  String endAddress = "43N, Augusta St. Lorain, OH 44656";

  late GoogleMapController _mapController;
  final LatLng _initialPosition = LatLng(37.7749, -122.4194); // Initial position for map

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
  }

  void updateFare() {
    setState(() {
      fare += 50;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            // Google Map as background
            GoogleMap(
              onMapCreated: _onMapCreated,
              initialCameraPosition: CameraPosition(
                target: _initialPosition,
                zoom: 12.0,
              ),
              markers: {
                Marker(
                  markerId: MarkerId("start"),
                  position: _initialPosition,
                  infoWindow: InfoWindow(title: startLocation),
                ),
                Marker(
                  markerId: MarkerId("end"),
                  position: LatLng(37.7849, -122.4094), // Example position for end location
                  infoWindow: InfoWindow(title: endLocation),
                ),
              },
            ),
            Positioned(
              top: 10,
              left: 10,
              child: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () {},
              ),
            ),
            // Trip Details Section
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                  Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Trip to Destination",
                      style: TextStyle(fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 17,color: Color(0xFF282828)),
                    ),
                    Text(
                      "0km",
                      style: TextStyle(fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 13,color: Color(0xFF282828)),
                    ),
                    ]),

                    SizedBox(height: 8),
                  */
/*  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Total Fare ₹$fare",
                          style: TextStyle(
                            color: Color(0xFF282828), // Text color for user input
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w600,
                            fontSize: 17,
                          )),
                        ElevatedButton(
                          onPressed: updateFare,
                          style: ElevatedButton.styleFrom(
                            shape: StadiumBorder(),
                            backgroundColor: Colors.blue,
                          ),
                          child: Text("Pay now"),
                        ),
                      ],
                    ),*/ /*


                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Color(0xFFBEBEBE)), // Grey border color
                        borderRadius: BorderRadius.circular(8), // Optional: rounded corners
                      ),
                      padding: EdgeInsets.all(8), // Optional: padding inside the border
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Total Fare ₹$fare",
                            style: TextStyle(
                              color: Color(0xFF282828),
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                            ),
                          ),
                          ElevatedButton(
                            onPressed: updateFare,
                            style: ElevatedButton.styleFrom(
                              shape: StadiumBorder(),
                              backgroundColor: Colors.white, // White background to match the border
                              //side: BorderSide(color: Colors.grey), // Optional: border around button
                            ),
                            child: Text(
                              "Pay now",
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 14,color: Color(0xFF4181FF), // Blue text color for the button
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    SizedBox(width: 24),

                    Padding(
                      padding: EdgeInsets.only(top: 16), // Set desired top margin value
                      child: Row(
                        children: [
                          CircleAvatar(
                            backgroundImage: NetworkImage("https://via.placeholder.com/150"),
                            radius: 24,
                          ),
                          SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                driverName,
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                  color: Color(0xFF282828),
                                ),
                              ),
                              Text(
                                carDetails,
                                style: TextStyle(color: Colors.grey[600]),
                              ),
                            ],
                          ),
                          Spacer(),
                          Column(
                            children: [
                              Icon(Icons.star, color: Color(0xFF4181FF)),
                              Text(
                                rating.toString(),
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 16),
                    Row(
                      children: [
                        Column(
                          children: [
                            Icon(Icons.radio_button_checked, color: Color(0xFF4181FF)),
                            Container(
                              height: 40,
                              width: 2,
                              color: Colors.grey[300],
                            ),
                            Icon(Icons.location_on, color: Color(0xFF4181FF)),
                          ],
                        ),
                        SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              startLocation,
                              style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,color: Color(0xFF282828)),
                            ),
                            Text(
                              startAddress,
                              style: TextStyle(fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,color: Color(0xFFBDBDBD)),
                            ),
                            SizedBox(height: 16),
                            Text(
                              endLocation,
                              style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,color: Color(0xFF282828)),
                            ),
                            Text(
                              endAddress,
                              style: TextStyle(fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,color: Color(0xFFBDBDBD)),
                            ),
                          ],
                        ),
                        Spacer(),
                        Column(
                          children: [
                            Icon(Icons.bookmark_border, color: Colors.grey),
                            SizedBox(height: 40),
                            Icon(Icons.bookmark_border, color: Colors.grey),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}*/
