import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../cab_homepage_screen/cab_homepage_screen.dart';
import '../utils/AppConstants.dart';
import 'RideConfirmationScreen.dart';

class CabCancellation extends StatefulWidget {
  @override
  _CabCancellationState createState() => _CabCancellationState();
}

class _CabCancellationState extends State<CabCancellation> {
  String selectedCRIDsString = ""; // Global variable for selected CRIDs
  String otherReason = ""; // Global variable for other reason
  String IsNew = "1"; // Global variable for IsNew status
  // String bookingID = "1"; // Global variable for IsNew status

  List<Map<String, dynamic>> cancellationReasons = [];
  late List<bool> isSelected;
  TextEditingController otherReasonController = TextEditingController();

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchCancellationReasons();
  }

  // Fetch token
  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  // Fetch cancellation reasons
  Future<void> fetchCancellationReasons() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}cancel_reasons_list');
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      final response =
          await http.post(url, headers: headers, body: jsonEncode({}));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            cancellationReasons = (data['cancellation_reasons'] as List)
                .map((reason) => {
                      'CRID': reason['CRID'],
                      'CRName': reason['CRName'],
                    })
                .toList();
            isSelected = List<bool>.filled(cancellationReasons.length, false);
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "Cancel Cab",
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 17,
            color: Color(0xFF282828),
          ),
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Please select the reason for cancellation",
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 13,
                      color: Color(0xFF969696),
                    ),
                  ),
                  SizedBox(height: 16),
                  Expanded(
                    child: ListView.builder(
                      itemCount: cancellationReasons.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: EdgeInsets.symmetric(vertical: 4.0),
                          child: Theme(
                            data: Theme.of(context).copyWith(
                              unselectedWidgetColor: Color(0xFF4181FF),
                            ),
                            child: CheckboxListTile(
                              controlAffinity: ListTileControlAffinity.leading,
                              activeColor: Color(0xFF4181FF),
                              title: Text(
                                cancellationReasons[index]['CRName'],
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                  color: Color(0xFF282828),
                                ),
                              ),
                              value: isSelected[index],
                              onChanged: (bool? value) {
                                setState(() {
                                  isSelected[index] = value!;
                                });
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 24),
                  Text(
                    "Others",
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                      color: Color(0xFF282828),
                    ),
                  ),
                  SizedBox(height: 8),
                  TextField(
                    controller: otherReasonController,
                    decoration: InputDecoration(
                      hintText: "Other Reason",
                      hintStyle: TextStyle(
                        color: Color(0xFF717171),
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade200,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    style: TextStyle(
                      color: Colors.black,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(height: 24),
                  buildUpdateButton(),
                ],
              ),
            ),
    );
  }

  Widget buildUpdateButton() {
    return CustomElevatedButton(
      text: "Submit",
      buttonStyle: CustomButtonStyles.none,
      decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
      onPressed: () {
        handleCancellation();
      },
    );
  }

  void handleCancellation() {
    final selectedCRIDs = cancellationReasons
        .asMap()
        .entries
        .where((entry) => isSelected[entry.key])
        .map((entry) => entry.value['CRID'])
        .toList();

    selectedCRIDsString = selectedCRIDs.join(", "); // Assign to global variable
    otherReason =
        otherReasonController.text.trim(); // Assign to global variable

    if (selectedCRIDs.isEmpty && otherReason.isEmpty) {
      showError("Please select a reason or provide another reason");
      return;
    }

    IsNew = selectedCRIDs.isEmpty ? "1" : "0"; // Assign to global variable

    print("Selected CRIDs: $selectedCRIDsString");
    print("Other Reason: $otherReason");
    print("IsNew: $IsNew");
    // cancelTripApi();
    //_showSuccessPopup(context);

    cancelTripApi();

    // Perform the API call or further actions for submitting cancellation reasons
  }

  Future<String?> getBookingID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('bookingid');
  }

  Future<void> cancelTripApi() async {
    String? token = await getToken();
    String? bookid = await getBookingID();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }
    if (bookid == null) {
      showError("Authentication bookingid not found");
      return;
    }
    final url = Uri.parse('${AppConstants.MAIN_URL}cancel_trip');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      //"BookingID": bookingID,
      "BookingID": bookid,
      "IsNew": IsNew,
      "CRID": selectedCRIDsString,
      "NewReason": otherReason,
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            isLoading = false;
            //_showSuccessPopup(context);
            Fluttertoast.showToast(
              msg: "Success",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
            );

            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => CabHomepageScreen()),
              (Route<dynamic> route) =>
                  false, // This condition removes all routes
            );
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  /* void _showSuccessPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding:
              EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                'assets/images/tick.png', // Path to your tick image
                width: 60,
                height: 60,
              ),
              SizedBox(height: 20),
              Text(
                'Success',
                style: TextStyle(
                  fontSize: 20,
                  fontFamily: 'Poppins-SemiBold',
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                textAlign: TextAlign.center, // Center align the text
              ),
              SizedBox(height: 10),
              Text(
                'Cab Cancelled successfully',
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: 'Poppins-Regular',
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
        );
      },
    );

    // Wait for 2 seconds before closing the dialog and navigating to the next screen
    Future.delayed(Duration(seconds: 2), () {
      Navigator.of(context).pop(); // Dismiss the alert dialog
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => CabHomepageScreen(),
          //builder: (context) => RideConfirmationScreen(),
        ),
      );
    });
  }*/

  void _showSuccessPopup(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false, // Prevent dismissal by tapping outside
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding:
              EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                'assets/images/tick.png', // Path to your tick image
                width: 60,
                height: 60,
              ),
              SizedBox(height: 20),
              Text(
                'Success',
                style: TextStyle(
                  fontSize: 20,
                  fontFamily: 'Poppins-SemiBold',
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                textAlign: TextAlign.center, // Center align the text
              ),
              SizedBox(height: 10),
              Text(
                'Cab Cancelled successfully',
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: 'Poppins-Regular',
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
        );
      },
    );

    // Dismiss the dialog and navigate to the next screen after 2 seconds
    Future.delayed(Duration(seconds: 2), () {
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop(); // Dismiss the alert dialog
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => CabHomepageScreen(),
            //builder: (context) => RideConfirmationScreen(),
          ),
        );
      }
    });
  }
}

/*import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';

class CabCancellation extends StatefulWidget {
  @override
  _CabCancellationState createState() => _CabCancellationState();
}

class _CabCancellationState extends State<CabCancellation> {
  List<Map<String, dynamic>> cancellationReasons = [];
  late List<bool> isSelected;
  TextEditingController otherReasonController = TextEditingController();

  bool isLoading = true;
  final otherReason ="";
  @override
  void initState() {
    super.initState();
    fetchCancellationReasons();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchCancellationReasons() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}cancel_reasons_list');
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      final response =
          await http.post(url, headers: headers, body: jsonEncode({}));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            cancellationReasons = (data['cancellation_reasons'] as List)
                .map((reason) => {
                      'CRID': reason['CRID'],
                      'CRName': reason['CRName'],
                    })
                .toList();
            isSelected = List<bool>.filled(cancellationReasons.length, false);
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "Cancel Cab",
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 17,
            color: Color(0xFF282828),
          ),
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Please select the reason for cancellation",
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 13,
                      color: Color(0xFF969696),
                    ),
                  ),
                  SizedBox(height: 16),
                  Expanded(
                    child: ListView.builder(
                      itemCount: cancellationReasons.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: EdgeInsets.symmetric(vertical: 4.0),
                          child: Theme(
                            data: Theme.of(context).copyWith(
                              unselectedWidgetColor: Color(0xFF4181FF),
                            ),
                            child: CheckboxListTile(
                              controlAffinity: ListTileControlAffinity.leading,
                              activeColor: Color(0xFF4181FF),
                              title: Text(
                                cancellationReasons[index]['CRName'],
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                  color: Color(0xFF282828),
                                ),
                              ),
                              value: isSelected[index],
                              onChanged: (bool? value) {
                                setState(() {
                                  isSelected[index] = value!;
                                });
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 24),
                  Text(
                    "Others",
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                      color: Color(0xFF282828),
                    ),
                  ),
                  SizedBox(height: 8),
                  TextField(
                    controller: otherReasonController,
                    decoration: InputDecoration(
                      hintText: "Other Reason",
                      hintStyle: TextStyle(
                        color: Color(0xFF717171),
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade200,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    style: TextStyle(
                      color: Colors.black,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(height: 24),
                  buildUpdateButton(),
                ],
              ),
            ),
    );
  }

  Widget buildUpdateButton() {
    return CustomElevatedButton(
      text: "Submit",
      buttonStyle: CustomButtonStyles.none,
      decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
      onPressed: () {
        handleCancellation();
      },
    );
  }

  void handleCancellation() {
    var IsNew = "1";
    final selectedCRIDs = cancellationReasons
        .asMap()
        .entries
        .where((entry) => isSelected[entry.key])
        .map((entry) => entry.value['CRID'])
        .toList();
    final selectedCRIDsString =
        selectedCRIDs.join(", "); // Convert list to comma-separated string
    final otherReason = otherReasonController.text.trim();

    if (selectedCRIDs.isEmpty && otherReason.isEmpty) {
      showError("Please select a reason or provide another reason");
      return;
    }

    if (selectedCRIDs.isEmpty) {
      IsNew = "1";
    } else {
      IsNew = "0";
    }

    print("Selected CRIDs: $selectedCRIDsString");
    print("Other Reason: $otherReason");
    print("IsNew: $IsNew");

    // Perform the API call or further actions for submitting cancellation reasons
  }


}*/

/*
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';

class CabCancellation extends StatefulWidget {
  @override
  _CabCancellationState createState() => _CabCancellationState();
}

class _CabCancellationState extends State<CabCancellation> {
  List<String> cancellationReasons = [];
  late List<bool> isSelected;
  TextEditingController otherReasonController = TextEditingController();

  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchCancellationReasons();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchCancellationReasons() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}cancel_reasons_list');
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      final response =
          await http.post(url, headers: headers, body: jsonEncode({}));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            cancellationReasons = (data['cancellation_reasons'] as List)
                .map((reason) => reason['CRName'].toString())
                .toList();
            isSelected = List<bool>.filled(cancellationReasons.length, false);
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "Cancel Cab",
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w600,
            fontSize: 17,
            color: Color(0xFF282828),
          ),
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Please select the reason for cancellation",
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 13,
                      color: Color(0xFF969696),
                    ),
                  ),
                  SizedBox(height: 16),
                  Expanded(
                    child: ListView.builder(
                      itemCount: cancellationReasons.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: EdgeInsets.symmetric(vertical: 4.0),
                          child: Theme(
                            data: Theme.of(context).copyWith(
                              unselectedWidgetColor: Color(0xFF4181FF),
                            ),
                            child: CheckboxListTile(
                              controlAffinity: ListTileControlAffinity.leading,
                              activeColor: Color(0xFF4181FF),
                              title: Text(
                                cancellationReasons[index],
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 14,
                                  color: Color(0xFF282828),
                                ),
                              ),
                              value: isSelected[index],
                              onChanged: (bool? value) {
                                setState(() {
                                  isSelected[index] = value!;
                                });
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 24),
                  Text(
                    "Others",
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                      color: Color(0xFF282828),
                    ),
                  ),
                  SizedBox(height: 8),
                  TextField(
                    controller: otherReasonController,
                    decoration: InputDecoration(
                      hintText: "Other Reason",
                      hintStyle: TextStyle(
                        color: Color(0xFF717171),
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade200,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    style: TextStyle(
                      color: Colors.black,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(height: 24),
                  buildUpdateButton(),
                ],
              ),
            ),
    );
  }

  Widget buildUpdateButton() {
    return CustomElevatedButton(
      text: "Submit",
      buttonStyle: CustomButtonStyles.none,
      decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
      onPressed: () {
        handleCancellation();
      },
    );
  }

  void handleCancellation() {
    final selectedReasons = cancellationReasons
        .asMap()
        .entries
        .where((entry) => isSelected[entry.key])
        .map((entry) => entry.value)
        .toList();

    final otherReason = otherReasonController.text.trim();

    if (selectedReasons.isEmpty && otherReason.isEmpty) {
      showError("Please select a reason or provide another reason");
      return;
    }

    print("Selected Reasons: $selectedReasons");
    print("Other Reason: $otherReason");

    // Perform the API call or further actions for submitting cancellation reasons
  }
}
*/

/*
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;

class CabCancellation extends StatefulWidget {
  @override
  _CabCancellationState createState() => _CabCancellationState();
}

class _CabCancellationState extends State<CabCancellation> {
  final List<String> cancellationReasons = [
    "Waiting for long time",
    "Unable to contact driver",
    "Driver denied to go to destination",
    "Waiting for long time",
    "Unable to contact driver",
    "Waiting for long time",
    "Unable to contact driver",
    "Driver denied to go to destination",
    "Driver denied to go to destination",
  ];

  late List<bool> isSelected;
  TextEditingController otherReasonController = TextEditingController();

  bool isLoading = true;
  List<dynamic> cancelList = []; // List to hold car data

  @override
  void initState() {
    super.initState();
    isSelected = List<bool>.filled(cancellationReasons.length, false);
    fetchCarData();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchCarData() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}cancel_reasons_list');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      //final response = await http.post(url, headers: headers, body: body);
      var response =
          await http.post(url, headers: headers, body: jsonEncode({}));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            cancelList = data['cancellation_reasons'] ?? [];
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {},
        ),
        title: Text("Cancel Cab",
            style: TextStyle(
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                fontSize: 17,
                color: Color(0xFF282828))),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Please select the reason for cancellation",
              style: TextStyle(
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  fontSize: 13,
                  color: Color(0xFF969696)),
            ),
            SizedBox(height: 16),
            */
/*  Expanded(
              child: ListView.builder(
                itemCount: cancellationReasons.length,
                itemBuilder: (context, index) {
                  return CheckboxListTile(
                    controlAffinity: ListTileControlAffinity.leading,
                    activeColor: Color(0xFF4181FF),
                    title: Text(cancellationReasons[index]),
                    value: isSelected[index],
                    onChanged: (bool? value) {
                      setState(() {
                        isSelected[index] = value!;
                      });
                    },
                  );
                },
              ),
            ),*/ /*


            Expanded(
              child: ListView.builder(
                itemCount: cancellationReasons.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: 0.0), // Adjust padding for spacing
                    child: Theme(
                      data: Theme.of(context).copyWith(
                        unselectedWidgetColor: Color(
                            0xFF4181FF), // Border color for unchecked checkbox
                      ),
                      child: CheckboxListTile(
                        controlAffinity: ListTileControlAffinity.leading,
                        activeColor:
                            Color(0xFF4181FF), // Blue color when checked
                        title: Text(
                          cancellationReasons[index],
                          style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                              color: Color(0xFF282828)),
                        ),
                        value: isSelected[index],
                        onChanged: (bool? value) {
                          setState(() {
                            isSelected[index] = value!;
                          });
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 24),
            Text("Others",
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                    color: Color(0xFF282828))),
            SizedBox(height: 8),
            TextField(
              controller: otherReasonController,
              decoration: InputDecoration(
                hintText: "Other Reason",
                hintStyle: TextStyle(
                  color: Color(0xFF717171),
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
                filled: true,
                fillColor: Colors.grey.shade200,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
              style: TextStyle(
                color: Colors.black, // Text color for user input
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500,
                fontSize: 14,
              ),
            ),
            SizedBox(height: 24),
            buildUpdateButton()
          ],
        ),
      ),
    );
  }

  Widget buildUpdateButton() {
    return Container(
      // margin: EdgeInsets.all(16.0),
      child: CustomElevatedButton(
        text: "submit",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Handle continue button action
        },
      ),
    );
  }
}
*/
