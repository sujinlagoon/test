import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertickect365/presentation/cab_homepage_screen/cab_homepage_screen.dart';
import 'package:fluttertickect365/presentation/car/CabCancellation.dart';
import 'package:fluttertickect365/presentation/chat/ChatScreen.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart'; // Import url_launcher package

import '../../core/utils/image_constant.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;

import 'CabDriverRatings.dart';
import 'DriverProfile.dart';

class CabDriverDetails extends StatefulWidget {
  @override
  _CabDriverDetailsState createState() => _CabDriverDetailsState();
}

class _CabDriverDetailsState extends State<CabDriverDetails> {
  late GoogleMapController mapController;
  Set<Polyline> _polylines = {}; // Set to store polyline routes
  Set<Marker> _markers = {}; // Set to store markers for start and end points

  bool isLoading = true;
  Map<String, dynamic>? driverDetails;
  String otp = "";
  String agentPhone = "";

  String distanceText = "";
  String durationText = "";

  String? carname;
  String? vtId;
  String? carprice;
  String? current_address;
  String? destination_address;
  String? bookingID;
  late double currentLat;
  late double currentLng;
  late double destinationLat;
  late double destinationLng;

  Uri? profileImageUri;

  @override
  void initState() {
    super.initState();
    fetchCarData();
    _loadSharedPreferences();
  }

  Future<String?> getBookingID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('bookingid');
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchCarData() async {
    String? token = await getToken();
    String? bookid = await getBookingID();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }
    if (bookid == null) {
      showError("Authentication bookingid not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}driver_details_trip');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      //"booking_id": "1", // Replace with dynamic booking_id if needed
      "booking_id": bookid, // Replace with dynamic booking_id if needed
    });
    //  Fluttertoast.showToast(
    //   msg: bookid,
    //   toastLength: Toast.LENGTH_SHORT,
    //   gravity: ToastGravity.BOTTOM,
    // );

    //print("bookid = " + bookid);
    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            print('in.....');

            driverDetails = data['driver_details'];
            otp = data['BookingOTP'] ?? "";
            // agentPhone = driverDetails!['AgentPhone'].toString();
            print('BookingOTP : $otp');

            agentPhone = driverDetails?['AgentPhone']?.toString() ?? 'N/A';
            print('objectcheckingphone$agentPhone');
            isLoading = false;

            profileImageUri = driverDetails?['AgentProfImg'] != null
                ? Uri.parse(AppConstants.HOST + driverDetails?['AgentProfImg'])
                : null;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri, mode: LaunchMode.externalApplication);
    } else {
      showError('Could not launch dialer');
    }
  }

  Future<void> _loadSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentLat = prefs.getDouble('current_lat') ?? 0.0;
      currentLng = prefs.getDouble('current_lng') ?? 0.0;
      destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
      destinationLng = prefs.getDouble('destination_lng') ?? 0.0;
      vtId = prefs.getString('vtId');
      current_address = prefs.getString('current_address');
      destination_address = prefs.getString('destination_address');

      // Fetch the route and draw the polyline
      _getDirections();
    });
  }

  final CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(8.189653, 77.401716), // Coordinates for the initial position
    zoom: 12.0,
  );

  //polyen line:
  Future<void> _getDirections() async {
    String url =
        "https://maps.googleapis.com/maps/api/directions/json?origin=$currentLat,$currentLng&destination=$destinationLat,$destinationLng&key=AIzaSyBP5GUxTHqath5-maur0OZIUOf81dgZlTM";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      List<LatLng> polylineCoordinates = [];

      if (data['routes'].isNotEmpty) {
        var route = data['routes'][0]['legs'][0];

        // Get distance and duration
        String distance = route['distance']['text']; // e.g., '4.5 km'
        String duration = route['duration']['text']; // e.g., '10 mins'

        // Set the distance and duration in the UI
        setState(() {
          // Update the UI with distance and duration

          distanceText = distance;
          durationText = duration;

          print("distanceText = " + distanceText);
          print("durationText = " + durationText);

          var steps = route['steps'];
          for (var step in steps) {
            String encodedPolyline = step['polyline']['points'];
            polylineCoordinates.addAll(_decodePolyline(encodedPolyline));
          }

          // Add polyline and markers as usual
          _polylines.add(
            Polyline(
              polylineId: PolylineId("route"),
              color: Color(0xFF4181FF),
              width: 5,
              points: polylineCoordinates,
            ),
          );

          // Add markers for start and destination points
          _markers.add(
            Marker(
              markerId: MarkerId("start"),
              position: LatLng(currentLat, currentLng),
              infoWindow: InfoWindow(title: "Start Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueRed),
            ),
          );

          _markers.add(
            Marker(
              markerId: MarkerId("end"),
              position: LatLng(destinationLat, destinationLng),
              infoWindow: InfoWindow(title: "Destination Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueGreen),
            ),
          );
        });
      }
    } else {
      print('Failed to load directions');
    }
  }

  // Function to decode polyline points from the Directions API response
  List<LatLng> _decodePolyline(String encodedPolyline) {
    List<LatLng> polyline = [];
    int index = 0;
    int len = encodedPolyline.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int shift = 0;
      int result = 0;
      int byte;

      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lat += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      shift = 0;
      result = 0;
      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lng += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      polyline.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return polyline;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Navigate to Login Page
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => CabHomepageScreen()),
          (Route<dynamic> route) => false, // This condition removes all routes
        );
        return false; // Prevent default back navigation
      },
      child: Scaffold(
        body: isLoading
            ? Center(child: CircularProgressIndicator())
            : Stack(
                children: [
                  // Map background (for demonstration, using a placeholder)
                  /*      Container(
                  color: Colors.grey[300],
                  child: Center(
                    child: Text(
                      "Map View",
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  ),
                ),*/
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: GoogleMap(
                      initialCameraPosition: _initialCameraPosition,
                      mapType: MapType.normal,
                      onMapCreated: (GoogleMapController controller) {
                        mapController = controller;
                      },
                      polylines: _polylines, // Display the polyline
                      markers: _markers, // Display the markers
                      zoomControlsEnabled: true, // Allow zoom controls
                    ),
                  ),
                  // Back button
                  Positioned(
                    top: 40,
                    left: 16,
                    child: IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.black),
                      onPressed: () {
                        //Navigator.pop(context);
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                              builder: (context) => CabHomepageScreen()),
                          (Route<dynamic> route) =>
                              false, // This condition removes all routes
                        );
                      },
                    ),
                  ),
                  // Bottom Card
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.vertical(top: Radius.circular(20)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            blurRadius: 10.0,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // Driver is arriving message and time
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Driver is arriving....",
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w600,
                                  fontSize: 17,
                                  color: Colors.black,
                                ),
                              ),
                              Text(
                                distanceText,
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 13,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 16),
                          // Driver details
                          Row(
                            children: [
                              CircleAvatar(
                                radius: 30,
                                backgroundColor: Colors.grey[300],
                                backgroundImage: profileImageUri != null
                                    ? NetworkImage(profileImageUri.toString())
                                    : null,
                                child: profileImageUri == null
                                    ? Icon(Icons.camera_alt,
                                        size: 50, color: Colors.grey[700])
                                    : null,
                                /*  backgroundImage: AssetImage(
                                  'assets/images/profile.jpg'), */ // Replace with actual driver image
                              ),
                              SizedBox(width: 16),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    driverDetails?['AgentName'] ??
                                        "Driver Name",
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w500,
                                      fontSize: 15,
                                      color: Colors.black,
                                    ),
                                  ),
                                  Text(
                                    driverDetails?['AgentVehicleNumber'] ??
                                        "Vehicle Number",
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w500,
                                      fontSize: 13,
                                      color: Color(0xFFBDBDBD),
                                    ),
                                  ),
                                ],
                              ),
                              Spacer(),
                              // Rating
                              Row(
                                children: [
                                  Icon(Icons.star,
                                      color: Color(0xFF4181FF), size: 20),
                                  SizedBox(width: 4),
                                  Text(
                                    driverDetails?['AgentTotalRatings'] ??
                                        "0.0",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height: 16),
                          // OTP
                          Row(
                            children: [
                              Text(
                                "Your OTP",
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 15,
                                  color: Colors.black,
                                ),
                              ),
                              SizedBox(width: 8),
                              Text(
                                otp,
                                style: TextStyle(
                                  fontFamily: 'Poppins',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 25,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 16),
                          // Action buttons
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              _buildActionButton(
                                  SvgPicture.asset(
                                    ImageConstant.whitecancel,
                                    height: 24.0,
                                    width: 20.0,
                                  ),
                                  "Cancel", onTap: () {
                                // Navigate to the TextPage
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => CabCancellation()),
                                  // builder: (context) => CabDriverRatings()),
                                  //  builder: (context) => DriverProfile()),
                                );
                              }),
                              /*     _buildActionButton(
                                  SvgPicture.asset(
                                    ImageConstant.whitecomment,
                                    height: 24.0,
                                    width: 20.0,
                                  ),
                                  "Text", onTap: () {
                                // Navigate to the TextPage
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => ChatScreen()),
                                );
                              }),*/
                              _buildActionButton(
                                  SvgPicture.asset(
                                    ImageConstant.whitephone,
                                    height: 24.0,
                                    width: 20.0,
                                  ),
                                  "Call",
                                  onTap: () => _makePhoneCall(agentPhone)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  // Helper function to create action buttons
  Widget _buildActionButton(Widget iconWidget, String label,
      {VoidCallback? onTap}) {
    return Column(
      children: [
        GestureDetector(
          onTap: onTap,
          child: CircleAvatar(
            radius: 30,
            backgroundColor: Color(0xFF4181FF),
            child: iconWidget,
          ),
        ),
        SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: Color(0xFF7AA7FF),
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}

/*import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/utils/image_constant.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;

class CabDriverDetails extends StatefulWidget {
  @override
  _CabDriverDetailsState createState() => _CabDriverDetailsState();
}

class _CabDriverDetailsState extends State<CabDriverDetails> {
  bool isLoading = true;
  Map<String, dynamic>? driverDetails;
  String otp = "";
  String agentPhone = "";

  @override
  void initState() {
    super.initState();
    fetchCarData();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchCarData() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}driver_details_trip');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "booking_id": "1", // Replace with dynamic booking_id if needed
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            driverDetails = data['driver_details'];
            otp = data['BookingOTP'] ?? "";
            agentPhone = driverDetails!['AgentPhone'];
            isLoading = false;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                // Map background (for demonstration, using a placeholder)
                Container(
                  color: Colors.grey[300],
                  child: Center(
                    child: Text(
                      "Map View",
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  ),
                ),
                // Back button
                Positioned(
                  top: 40,
                  left: 16,
                  child: IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.black),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
                // Bottom Card
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(20)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10.0,
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Driver is arriving message and time
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Driver is arriving....",
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w600,
                                fontSize: 17,
                                color: Colors.black,
                              ),
                            ),
                            Text(
                              "5 mins",
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 13,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 16),
                        // Driver details
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 30,
                              backgroundImage: driverDetails?['AgentProfImg'] !=
                                          null &&
                                      driverDetails!['AgentProfImg'] != ''
                                  ? NetworkImage(AppConstants.HOST +
                                      driverDetails!['AgentProfImg'])
                                  : AssetImage('assets/images/img_fi300221.jpg')
                                      as ImageProvider, // Replace with actual driver image
                            ),

                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  driverDetails?['AgentName'] ?? "Driver Name",
                                  style: TextStyle(
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 15,
                                    color: Colors.black,
                                  ),
                                ),
                                Text(
                                  driverDetails?['AgentVehicleNumber'] ??
                                      "Vehicle Number",
                                  style: TextStyle(
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 13,
                                    color: Color(0xFFBDBDBD),
                                  ),
                                ),
                              ],
                            ),
                            Spacer(),
                            // Rating
                            Row(
                              children: [
                                Icon(Icons.star,
                                    color: Color(0xFF4181FF), size: 20),
                                SizedBox(width: 4),
                                Text(
                                  driverDetails?['AgentTotalRatings'] ?? "0.0",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ],
                        ),
                        SizedBox(height: 16),
                        // OTP
                        Row(
                          children: [
                            Text(
                              "Your OTP",
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 15,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(width: 8),
                            Text(
                              otp,
                              style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 25,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 16),
                        // Action buttons
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _buildActionButton(
                                SvgPicture.asset(
                                  ImageConstant.whitecancel,
                                  height: 24.0,
                                  width: 20.0,
                                ),
                                "Cancel"),
                            _buildActionButton(
                                SvgPicture.asset(
                                  ImageConstant.whitecomment,
                                  height: 24.0,
                                  width: 20.0,
                                ),
                                "Text"),
                            _buildActionButton(
                                SvgPicture.asset(
                                  ImageConstant.whitephone,
                                  height: 24.0,
                                  width: 20.0,
                                ),
                                "Call"),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  // Helper function to create action buttons
  Widget _buildActionButton(Widget iconWidget, String label) {
    return Column(
      children: [
        CircleAvatar(
          radius: 30,
          backgroundColor: Color(0xFF4181FF),
          child: iconWidget,
        ),
        SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: Color(0xFF7AA7FF),
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}*/

/*
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../../core/utils/image_constant.dart';

class CabDriverDetails extends StatefulWidget {
  @override
  _CabDriverDetailsState createState() => _CabDriverDetailsState();
}

class _CabDriverDetailsState extends State<CabDriverDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Map background (for demonstration, using a placeholder)
          Container(
            color: Colors.grey[300], // Replace with actual map widget
            child: Center(
              child: Text(
                "Map View",
                style: TextStyle(color: Colors.grey[600]),
              ),
            ),
          ),
          // Back button
          Positioned(
            top: 40,
            left: 16,
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ),
          // Bottom Card
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10.0,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Driver is arriving message and time
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Driver is arriving....",
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 17,
                          color: Colors.black,
                        ),
                      ),
                      Text(
                        "5 mins",
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 13,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  // Driver details
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundImage: AssetImage(
                            'assets/images/img_fi300221.jpg'), // Replace with actual driver image
                      ),
                      SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Daniel Austin",
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              fontSize: 15,
                              color: Colors.black,
                            ),
                          ),
                          Text(
                            "Verna TN75AK9681",
                            style: TextStyle(
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              fontSize: 13,
                              color: Color(0xFFBDBDBD),
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      // Rating
                      Row(
                        children: [
                          Icon(Icons.star, color: Color(0xFF4181FF), size: 20),
                          SizedBox(width: 4),
                          Text(
                            "4.5",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  // OTP
                  Row(
                    children: [
                      Text(
                        "Your OTP",
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 15,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(
                          width: 8), // Adjust the width as needed for spacing
                      Text(
                        "6281",
                        style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 25,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 16),
                  // Action buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildActionButton(
                          SvgPicture.asset(
                            ImageConstant.whitecancel, // Your SVG asset path
                            height: 24.0,
                            width: 20.0,
                          ),
                          "Cancel"),
                      //_buildActionButton(Icons.chat_bubble_outline, "Text"),
                      _buildActionButton(
                          SvgPicture.asset(
                            ImageConstant.whitecomment, // Your SVG asset path
                            height: 24.0,
                            width: 20.0,
                          ),
                          "Text"),
                      _buildActionButton(
                          SvgPicture.asset(
                            ImageConstant.whitephone, // Your SVG asset path
                            height: 24.0,
                            width: 20.0,
                          ),
                          "Call"),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


// Helper function to create action buttons
  Widget _buildActionButton(Widget iconWidget, String label) {
    return Column(
      children: [
        CircleAvatar(
          radius: 30,
          backgroundColor: Color(0xFF4181FF),
          child: iconWidget,
        ),
        SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: Color(0xFF7AA7FF),
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}*/
