import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertickect365/presentation/cab_homepage_screen/cab_homepage_screen.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';
import 'CabCancellation.dart';
import 'Cab_Driver_details.dart';
import 'package:http/http.dart' as http;

class SearchingForCarScreen extends StatefulWidget {
  @override
  _SearchingForCarScreenState createState() => _SearchingForCarScreenState();
}

class _SearchingForCarScreenState extends State<SearchingForCarScreen> {
  bool isSearching = true; // Example state to manage search status
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    //_startSearchProcess(); // Example: Simulate a search process
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<String?> getBookingID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('bookingid');
  }

  Future<void> cancelSearchApi() async {
    String? token = await getToken();
    String? bookid = await getBookingID();
    isLoading = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFF4181FF),
          ),
        );
      },
    );
    if (token == null) {
      showError("Authentication token not found");
      return;
    }
    if (bookid == null) {
      showError("Authentication bookingid not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}cancel_search');

    print('api called');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "booking_id": bookid,
    });

    /*   Fluttertoast.showToast(
      msg: bookid,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );*/

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        print('200 called');

        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          print('true called');
          setState(() {
            isLoading = false;
          });

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => CabHomepageScreen()),
          );
          Fluttertoast.showToast(
            msg: data['message'] ?? "search cancelled",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
          print(data['message'] ?? "Failed in search cancelation");
        } else {
          showError(data['message'] ?? "Failed to save location");
        }
      } else {
        showError('Failed to save data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  // Simulate a search process
  void _startSearchProcess() async {
    await Future.delayed(Duration(seconds: 10)); // Simulate network delay
    if (mounted) {
      setState(() {
        isSearching = false;
      });
      // Navigate to CabDriverDetails once a driver is found
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => CabDriverDetails()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
/*      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Searching for car',
            style: TextStyle(
              color: Colors.black,
              fontSize: 18.0,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),*/
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => CabHomepageScreen()),
              (Route<dynamic> route) =>
                  false, // This condition removes all routes
            );
          },
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Searching for car',
            style: TextStyle(
              color: Colors.black,
              fontSize: 18.0,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Spacer(),
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  'assets/images/cargif.gif',
                  height: 200.0,
                  width: 200.0,
                  fit: BoxFit.cover,
                ),
                SizedBox(height: 20.0),
                Text(
                  isSearching
                      ? 'Searching for a driver....'
                      : 'Driver found! Preparing your ride...',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
              ],
            ),
            Spacer(),
            buildUpdateButton(context),
          ],
        ),
      ),
    );
  }

  Widget buildUpdateButton(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
      child: CustomElevatedButton(
        text: "Cancel Search",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Cancel the search and navigate to CabCancellation
          cancelSearchApi();
          /* Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => CabCancellation()),
          );*/
        },
      ),
    );
  }
}

/*import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import 'CabCancellation.dart';
import 'Cab_Driver_details.dart';
import 'RideConfirmationScreen.dart'; // Ensure you have the correct import for SvgPicture

class SearchingForCarScreen extends StatelessWidget {
  String? bookingID;

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Align(
          alignment: Alignment.centerLeft, // Align text to the left
          child: Text(
            'Searching for car',
            style: TextStyle(
              color: Colors.black,
              fontSize: 18.0,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // Centering the content
          children: [
            // Car Icon and Searching Text at the center
            Spacer(), // Push the button to the bottom

            Column(
              mainAxisSize: MainAxisSize.min, // Minimize space taken
              children: [
                */ /*  SvgPicture.asset(
                  ImageConstant.searchcar, // Your SVG asset path
                  height: 200.0,
                  width: 200.0,
                ),*/ /*
                Image.asset(
                  'assets/images/cargif.gif', // Provide the correct path to your GIF
                  height: 200.0,
                  width: 200.0,
                  fit: BoxFit.cover, // Make sure it fits nicely
                ),
                SizedBox(height: 20.0),
                Text(
                  'Searching for a driver....',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
              ],
            ),

            Spacer(),
            buildUpdateButton(context) // Push the button to the bottom

            // Cancel Search Button at bottom
            //  SizedBox(height: 30.0),
          ],
        ),
      ),
    );
  }

  Widget buildUpdateButton(BuildContext context) {
    return Container(
      // Horizontal margin if needed, uncomment below line
      margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
      child: CustomElevatedButton(
        text: "Cancel Search",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Navigate to the next page

          Navigator.push(
            context,
            //MaterialPageRoute(builder: (context) => CabCancellation()),
            MaterialPageRoute(builder: (context) => CabDriverDetails()),
          );
        },
      ),
    );
  }
}*/

/*
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import 'CabCancellation.dart';
import 'Cab_Driver_details.dart';
import 'RideConfirmationScreen.dart'; // Ensure you have the correct import for SvgPicture

class SearchingForCarScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Align(
          alignment: Alignment.centerLeft, // Align text to the left
          child: Text(
            'Searching for car',
            style: TextStyle(
              color: Colors.black,
              fontSize: 18.0,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // Centering the content
          children: [
            // Car Icon and Searching Text at the center
            Spacer(), // Push the button to the bottom

            Column(
              mainAxisSize: MainAxisSize.min, // Minimize space taken
              children: [
                */
/*  SvgPicture.asset(
                  ImageConstant.searchcar, // Your SVG asset path
                  height: 200.0,
                  width: 200.0,
                ),*/ /*

                Image.asset(
                  'assets/images/cargif.gif', // Provide the correct path to your GIF
                  height: 200.0,
                  width: 200.0,
                  fit: BoxFit.cover, // Make sure it fits nicely
                ),
                SizedBox(height: 20.0),
                Text(
                  'Searching for a driver....',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
              ],
            ),

            Spacer(),
            buildUpdateButton(context) // Push the button to the bottom

            // Cancel Search Button at bottom
            //  SizedBox(height: 30.0),
          ],
        ),
      ),
    );
  }

  Widget buildUpdateButton(BuildContext context) {
    return Container(
      // Horizontal margin if needed, uncomment below line
      margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 16.0),
      child: CustomElevatedButton(
        text: "Cancel Search",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Navigate to the next page

          Navigator.push(
            context,
            //MaterialPageRoute(builder: (context) => CabCancellation()),
            MaterialPageRoute(builder: (context) => CabDriverDetails()),
          );
        },
      ),
    );
  }
}*/
