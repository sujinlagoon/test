import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertickect365/presentation/cab_homepage_screen/cab_homepage_screen.dart';
import 'package:fluttertickect365/presentation/car/DriverProfile.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;

class CabDriverRatings extends StatefulWidget {
  @override
  _CabDriverRatingsState createState() => _CabDriverRatingsState();
}

class _CabDriverRatingsState extends State<CabDriverRatings> {
  late GoogleMapController mapController;
  int selectedRating = 0;
  String rating = "";
  String feedback = "";

  Map<String, dynamic>? driverDetails;
  String otp = "";
  String agentPhone = "";
  bool isLoading = false;
  TextEditingController feedbackController =
      TextEditingController(); // Controller for feedback text
  Uri? profileImageUri;

  Set<Polyline> _polylines = {}; // Set to store polyline routes
  Set<Marker> _markers = {}; // Set to store markers for start and end points

  late double currentLat;
  late double currentLng;
  late double destinationLat;
  late double destinationLng;

  String distanceText = "";
  String durationText = "";

  @override
  void initState() {
    super.initState();
    fetchCarData();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  // Load SharedPreferences asynchronously
  Future<void> _loadSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentLat = prefs.getDouble('current_lat') ?? 0.0;
      currentLng = prefs.getDouble('current_lng') ?? 0.0;
      destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
      destinationLng = prefs.getDouble('destination_lng') ?? 0.0;

      // Fetch the route and draw the polyline
      _getDirections();
    });
  }

  final CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(8.189653, 77.401716), // Coordinates for the initial position
    zoom: 12.0,
  );

  //polyen line:
  Future<void> _getDirections() async {
    String url =
        "https://maps.googleapis.com/maps/api/directions/json?origin=$currentLat,$currentLng&destination=$destinationLat,$destinationLng&key=AIzaSyBP5GUxTHqath5-maur0OZIUOf81dgZlTM";

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      List<LatLng> polylineCoordinates = [];

      if (data['routes'].isNotEmpty) {
        var route = data['routes'][0]['legs'][0];

        // Get distance and duration
        String distance = route['distance']['text']; // e.g., '4.5 km'
        String duration = route['duration']['text']; // e.g., '10 mins'

        // Set the distance and duration in the UI
        setState(() {
          // Update the UI with distance and duration

          distanceText = distance;
          durationText = duration;

          print("distanceText = " + distanceText);
          print("durationText = " + durationText);

          var steps = route['steps'];
          for (var step in steps) {
            String encodedPolyline = step['polyline']['points'];
            polylineCoordinates.addAll(_decodePolyline(encodedPolyline));
          }

          // Add polyline and markers as usual
          _polylines.add(
            Polyline(
              polylineId: PolylineId("route"),
              color: Color(0xFF4181FF),
              width: 5,
              points: polylineCoordinates,
            ),
          );

          // Add markers for start and destination points
          _markers.add(
            Marker(
              markerId: MarkerId("start"),
              position: LatLng(currentLat, currentLng),
              infoWindow: InfoWindow(title: "Start Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueRed),
            ),
          );

          _markers.add(
            Marker(
              markerId: MarkerId("end"),
              position: LatLng(destinationLat, destinationLng),
              infoWindow: InfoWindow(title: "Destination Location"),
              icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueGreen),
            ),
          );
        });
      }
    } else {
      print('Failed to load directions');
    }
  }

  // Function to decode polyline points from the Directions API response
  List<LatLng> _decodePolyline(String encodedPolyline) {
    List<LatLng> polyline = [];
    int index = 0;
    int len = encodedPolyline.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int shift = 0;
      int result = 0;
      int byte;

      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lat += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      shift = 0;
      result = 0;
      do {
        byte = encodedPolyline.codeUnitAt(index++) - 63;
        result |= (byte & 0x1f) << shift;
        shift += 5;
      } while (byte >= 0x20);

      lng += (result & 0x1) != 0 ? ~(result >> 1) : (result >> 1);

      polyline.add(LatLng(lat / 1E5, lng / 1E5));
    }
    return polyline;
  }

  void _submitRating() {
    // Validate if rating and feedback are provided
    if (selectedRating == 0 || feedbackController.text.isEmpty) {
      showError("Please provide a rating and feedback.");
      return;
    }

    // Logic to submit the rating and feedback to the server
    // You can make another API call here to submit the rating and feedback
    String rating1 = selectedRating.toString();
    String feedback1 = feedbackController.text;

    print("rating 1= " + rating1);
    print("feedback 1= " + feedback1);

    rating = rating1;
    feedback = feedback1;

    // For now, we just show a success message after submitting
    //showError("Rating and feedback submitted successfully.");
    addRatingApi();

    // Clear the fields after submission
    setState(() {
      selectedRating = 0;
      feedbackController.clear();
    });
  }

  Future<String?> getBookingID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('bookingid');
  }

  void _showSuccessPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding:
              EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                'assets/images/tick.png', // Path to your tick image
                width: 60,
                height: 60,
              ),
              SizedBox(height: 20),
              Text(
                'Success',
                style: TextStyle(
                  fontSize: 20,
                  fontFamily: 'Poppins-SemiBold',
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                textAlign: TextAlign.center, // Center align the text
              ),
              SizedBox(height: 10),
              Text(
                'Review submitted successfully',
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: 'Poppins-Regular',
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
        );
      },
    );

    // Wait for 2 seconds before closing the dialog and navigating to the next screen
    Future.delayed(Duration(seconds: 2), () {
      Navigator.of(context).pop(); // Dismiss the alert dialog
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => CabHomepageScreen()),
        (Route<dynamic> route) => false, // This condition removes all routes
      );
    });
  }

  Future<void> fetchCarData() async {
    setState(() {
      isLoading = true; // Show the loading spinner
    });

    String? token = await getToken();
    String? bookid = await getBookingID();
    if (bookid == null) {
      showError("Authentication bookingid not found");
      return;
    }

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}driver_details_trip');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "booking_id": bookid, // Replace with dynamic booking_id if needed
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            driverDetails = data['driver_details'];
            otp = data['BookingOTP'] ?? "";
            agentPhone = driverDetails!['AgentPhone'] ?? '';

            profileImageUri = driverDetails?['AgentProfImg'] != null
                ? Uri.parse(AppConstants.HOST + driverDetails?['AgentProfImg'])
                : null;
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    } finally {
      setState(() {
        isLoading = false; // Hide the loading spinner once the request is done
      });
    }
  }

  Future<void> addRatingApi() async {
    setState(() {
      isLoading = true; // Show the loading spinner
    });

    String? token = await getToken();

    String? bookid = await getBookingID();
    if (bookid == null) {
      showError("Authentication bookingid not found");
      return;
    }

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}review_submit');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    print("rating = " + rating);
    print("feedback = " + feedback);
    print("booking_id = " + bookid);

    final body = jsonEncode({
      "booking_id": bookid, // Replace with dynamic booking_id if needed
      "rating": rating, // Replace with dynamic booking_id if needed
      "feedback": feedback, // Replace with dynamic booking_id if needed
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            // _showSuccessPopup(context);

            Fluttertoast.showToast(
              msg: "Thankyou for yours feedback",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.BOTTOM,
            );

            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => CabHomepageScreen()),
              (Route<dynamic> route) =>
                  false, // This condition removes all routes
            );
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    } finally {
      setState(() {
        isLoading = false; // Hide the loading spinner once the request is done
      });
    }
  }

  void showError(String message) {
    setState(() {});
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  void _setRating(int rating) {
    setState(() {
      selectedRating = rating;
    });
  }

  void _cancelRating() {
    // Navigate to home page
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => CabHomepageScreen()),
      (Route<dynamic> route) => false, // This condition removes all routes
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Navigate to Login Page
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => CabHomepageScreen()),
          (Route<dynamic> route) => false, // This condition removes all routes
        );
        return false; // Prevent default back navigation
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black),
            onPressed: _cancelRating,
          ),
        ),
        extendBodyBehindAppBar: true,
        body: Stack(
          children: [
            // Interactive Google Map background
            Padding(
              padding: const EdgeInsets.only(top: 5),
              child: GoogleMap(
                initialCameraPosition: _initialCameraPosition,
                mapType: MapType.normal,
                onMapCreated: (GoogleMapController controller) {
                  mapController = controller;
                },
                polylines: _polylines, // Display the polyline
                markers: _markers, // Display the markers
                zoomControlsEnabled: true, // Allow zoom controls
              ),
            ),
            // Loading Indicator
            if (isLoading)
              Center(
                child: CircularProgressIndicator(),
              ),
            // Rating container
            if (!isLoading)
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(16)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(height: 8),
                      Container(
                        height: 4,
                        width: 40,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        "Rate Driver",
                        style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w600,
                            fontSize: 17,
                            color: Colors.black),
                      ),
                      SizedBox(height: 16),
                      driverDetails != null
/*
                          ? Row(
                              children: [
                                CircleAvatar(
                                  radius: 30,
                                  backgroundColor: Colors.grey[300],
                                  backgroundImage: profileImageUri != null
                                      ? NetworkImage(profileImageUri.toString())
                                      : null,
                                  child: profileImageUri == null
                                      ? Icon(Icons.camera_alt,
                                          size: 50, color: Colors.grey[700])
                                      : null, // Fallback image
                                ),
                                SizedBox(width: 16),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      driverDetails?['AgentName'] ??
                                          "Driver Name",
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 14,
                                        color: Color(0xFF282828),
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    Text(
                                      driverDetails?['AgentVehicleNumber'] ??
                                          "Vehicle Number",
                                      style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          color: Color(0xFFBDBDBD)),
                                    ),
                                  ],
                                ),
                                Spacer(),
                                Row(
                                  children: [
                                    Icon(Icons.star, color: Color(0xFF4181FF)),
                                    SizedBox(width: 4),
                                    Text(
                                        driverDetails?['AgentTotalRatings'] ??
                                            "0.0",
                                        style: TextStyle(
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14,
                                            color: Color(0xFF282828))),
                                  ],
                                ),
                              ],
                            )
*/

                          ? GestureDetector(
                              onTap: () {
                                // Action to perform when the row is clicked
                                print("Driver clicked!");
                                // You can navigate to a detailed page or show a dialog, for example:
                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //     builder: (context) => DriverDetailsPage(driver: driverDetails),
                                //   ),
                                // );

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => DriverProfile()),
                                );
                              },
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    radius: 30,
                                    backgroundColor: Colors.grey[300],
                                    backgroundImage: profileImageUri != null
                                        ? NetworkImage(
                                            profileImageUri.toString())
                                        : null,
                                    child: profileImageUri == null
                                        ? Icon(Icons.camera_alt,
                                            size: 50, color: Colors.grey[700])
                                        : null, // Fallback image
                                  ),
                                  SizedBox(width: 16),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        driverDetails?['AgentName'] ??
                                            "Driver Name",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          color: Color(0xFF282828),
                                        ),
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        driverDetails?['AgentVehicleNumber'] ??
                                            "Vehicle Number",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          color: Color(0xFFBDBDBD),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Spacer(),
                                  Row(
                                    children: [
                                      Icon(Icons.star,
                                          color: Color(0xFF4181FF)),
                                      SizedBox(width: 4),
                                      Text(
                                        driverDetails?['AgentTotalRatings'] ??
                                            "0.0",
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          color: Color(0xFF282828),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            )
                          : SizedBox(),
                      SizedBox(height: 24),
                      Text(
                        "How is your Driver?",
                        style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            color: Color(0xFF282828)),
                      ),
                      Text(
                        "Please rate your driver...",
                        style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                            fontSize: 11,
                            color: Color(0xFF282828)),
                      ),
                      SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          5,
                          (index) => GestureDetector(
                            onTap: () => _setRating(index + 1),
                            child: Icon(
                              Icons.star,
                              color: index < selectedRating
                                  ? Color(0xFF4181FF)
                                  : Colors.black54,
                              size: 36,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                      TextField(
                        controller: feedbackController,
                        decoration: InputDecoration(
                          hintText: "Feedback",
                          hintStyle: TextStyle(
                            color: Color(0xFF8A8A8A),
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                            fontSize: 12,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(color: Color(0xFFECECEC)),
                          ),
                          contentPadding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 12),
                        ),
                        style: TextStyle(
                          color: Colors.black, // Text color for user input
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),
                      ),
                      SizedBox(height: 32),
                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                color:
                                    Color(0xFFEEF4FF), // Set background color
                                borderRadius: BorderRadius.circular(
                                    8), // Match the border radius
                              ),
                              child: OutlinedButton(
                                onPressed: _cancelRating,
                                style: OutlinedButton.styleFrom(
                                  padding: EdgeInsets.symmetric(vertical: 30),
                                  side: BorderSide(color: Color(0xFF4181FF)),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: Text("Cancel",
                                    style: TextStyle(color: Colors.black)),
                              ),
                            ),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                gradient: LinearGradient(
                                  colors: [
                                    Color(0xFF4181FF),
                                    Color(0xFF274E99)
                                  ], // Gradient colors
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                              ),
                              child: ElevatedButton(
                                onPressed: _submitRating,
                                style: ElevatedButton.styleFrom(
                                  padding: EdgeInsets.symmetric(vertical: 30),
                                  backgroundColor: Colors
                                      .transparent, // Make button background transparent
                                  shadowColor:
                                      Colors.transparent, // Remove shadow
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: Text(
                                  "Submit",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/*import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;

class CabDriverRatings extends StatefulWidget {
  @override
  _CabDriverRatingsState createState() => _CabDriverRatingsState();
}

class _CabDriverRatingsState extends State<CabDriverRatings> {
  late GoogleMapController mapController;
  int selectedRating = 0;

  Map<String, dynamic>? driverDetails;
  String otp = "";
  String agentPhone = "";
  bool isLoading = false; // Add a loading state

  @override
  void initState() {
    super.initState();
    fetchCarData();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchCarData() async {
    setState(() {
      isLoading = true; // Show the loading spinner
    });

    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}driver_details_trip');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "booking_id": "1", // Replace with dynamic booking_id if needed
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            driverDetails = data['driver_details'];
            otp = data['BookingOTP'] ?? "";
            agentPhone = driverDetails!['AgentPhone'] ?? '';
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    } finally {
      setState(() {
        isLoading = false; // Hide the loading spinner once the request is done
      });
    }
  }

  void showError(String message) {
    setState(() {});
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  void _setRating(int rating) {
    setState(() {
      selectedRating = rating;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {},
        ),
      ),
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          // Interactive Google Map background
          GoogleMap(
            onMapCreated: _onMapCreated,
            initialCameraPosition: CameraPosition(
              target: LatLng(37.7749, -122.4194),
              zoom: 13,
            ),
          ),
          // Loading Indicator
          if (isLoading)
            Center(
              child: CircularProgressIndicator(),
            ),
          // Rating container
          if (!isLoading)
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 8),
                    Container(
                      height: 4,
                      width: 40,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      "Rate Driver",
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 17,
                          color: Colors.black),
                    ),
                    SizedBox(height: 16),
                    driverDetails != null
                        ? Row(
                            children: [
                              CircleAvatar(
                                radius: 30,
                                backgroundImage: driverDetails![
                                            'AgentProfImg'] !=
                                        null
                                    ? NetworkImage(AppConstants.HOST +
                                        driverDetails!['AgentProfImg'])
                                    : AssetImage(
                                        'assets/images/img_fi300221.jpg'), // Fallback image
                              ),
                              SizedBox(width: 16),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    driverDetails?['AgentName'] ??
                                        "Driver Name",
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      color: Color(0xFF282828),
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    driverDetails?['AgentVehicleNumber'] ??
                                        "Vehicle Number",
                                    style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 14,
                                        color: Color(0xFFBDBDBD)),
                                  ),
                                ],
                              ),
                              Spacer(),
                              Row(
                                children: [
                                  Icon(Icons.star, color: Color(0xFF4181FF)),
                                  SizedBox(width: 4),
                                  Text(
                                      driverDetails?['AgentTotalRatings'] ??
                                          "0.0",
                                      style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          color: Color(0xFF282828))),
                                ],
                              ),
                            ],
                          )
                        : SizedBox(),
                    SizedBox(height: 24),
                    Text(
                      "How is your Driver?",
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                          color: Color(0xFF282828)),
                    ),
                    Text(
                      "Please rate your driver...",
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          fontSize: 11,
                          color: Color(0xFF282828)),
                    ),
                    SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        5,
                        (index) => GestureDetector(
                          onTap: () => _setRating(index + 1),
                          child: Icon(
                            Icons.star,
                            color: index < selectedRating
                                ? Color(0xFF4181FF)
                                : Colors.black54,
                            size: 36,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 16),
                    TextField(
                      decoration: InputDecoration(
                        hintText: "Feedback",
                        hintStyle: TextStyle(
                          color: Color(0xFF8A8A8A),
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: Color(0xFFECECEC)),
                        ),
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      ),
                      style: TextStyle(
                        color: Colors.black, // Text color for user input
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: 32),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              color: Color(0xFFEEF4FF), // Set background color
                              borderRadius: BorderRadius.circular(
                                  8), // Match the border radius
                            ),
                            child: OutlinedButton(
                              onPressed: () {},
                              style: OutlinedButton.styleFrom(
                                padding: EdgeInsets.symmetric(vertical: 15),
                                side: BorderSide(color: Color(0xFF4181FF)),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: Text("Close",
                                  style: TextStyle(color: Colors.black)),
                            ),
                          ),
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              gradient: LinearGradient(
                                colors: [
                                  Color(0xFF4181FF),
                                  Color(0xFF274E99)
                                ], // Gradient colors
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                            child: ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.symmetric(vertical: 15),
                                backgroundColor: Colors
                                    .transparent, // Make button background transparent
                                shadowColor:
                                    Colors.transparent, // Remove shadow
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: Text(
                                "Submit",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}*/

/*
import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;

class CabDriverRatings extends StatefulWidget {
  @override
  _CabDriverRatingsState createState() => _CabDriverRatingsState();
}
class _CabDriverRatingsState extends State<CabDriverRatings> {
  late GoogleMapController mapController;
  int selectedRating = 0;

  Map<String, dynamic>? driverDetails;
  String otp = "";
  String agentPhone = "";

  @override
  void initState() {
    super.initState();
    fetchCarData();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchCarData() async {
    String? token = await getToken();

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}driver_details_trip');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      "booking_id": "1", // Replace with dynamic booking_id if needed
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            print('in.....');

            driverDetails = data['driver_details'];
            otp = data['BookingOTP'] ?? "";
            agentPhone = driverDetails!['AgentPhone'];
            print('objectcheckingphone$agentPhone');
          });
        } else {
          showError(data['message'] ?? "Unknown error occurred");
        }
      } else {
        showError('Failed to fetch data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }



  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  void _setRating(int rating) {
    setState(() {
      selectedRating = rating;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {},
        ),
      ),
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          // Interactive Google Map background
          GoogleMap(
            onMapCreated: _onMapCreated,
            initialCameraPosition: CameraPosition(
              target: LatLng(37.7749, -122.4194),
              zoom: 13,
            ),
          ),
          // Rating container
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 8),
                  Container(
                    height: 4,
                    width: 40,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    "Rate Driver",
                    style: TextStyle(fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        fontSize: 17,color: Colors.black),
                  ),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundImage: NetworkImage(
                            'https://example.com/driver_profile_image.jpg'), // Replace with actual driver image URL
                      ),
                      SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Daniel Austin",
                            style: TextStyle(
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 14,color: Color(0xFF282828)),
                          ),
                          SizedBox(height: 4),
                          Text(
                            "Verna TN75AK9681",
                            style: TextStyle(fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                                fontSize: 14,color: Color(0xFFBDBDBD)),
                          ),
                        ],
                      ),
                      Spacer(),
                      Row(
                        children: [
                          Icon(Icons.star, color: Color(0xFF4181FF)),
                          SizedBox(width: 4),
                          Text("4.5", style: TextStyle(fontFamily: 'Poppins',
                              fontWeight: FontWeight.w500,
                              fontSize: 14,color: Color(0xFF282828))),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 24),
                  Text(
                    "How is your Driver?",
                    style: TextStyle(fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        fontSize: 14,color: Color(0xFF282828)),
                  ),
                  Text(
                    "Please rate your driver...",
                    style: TextStyle(fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 11,color: Color(0xFF282828)),
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      5,
                          (index) => GestureDetector(
                        onTap: () => _setRating(index + 1),
                        child: Icon(
                          Icons.star,
                          color: index < selectedRating ? Color(0xFF4181FF) : Colors.black54,
                          size: 36,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 16),


                  TextField(
                    decoration: InputDecoration(
                      hintText: "Feedback",
                      hintStyle: TextStyle(
                        color: Color(0xFF8A8A8A),
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 12,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Color(0xFFECECEC)),
                      ),
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                    style: TextStyle(
                      color: Colors.black, // Text color for user input
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                      fontSize: 12,
                    ),
                  ),

                  SizedBox(height: 32),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFEEF4FF), // Set background color
                            borderRadius: BorderRadius.circular(8), // Match the border radius
                          ),
                        child: OutlinedButton(
                          onPressed: () {},
                          style: OutlinedButton.styleFrom(
                            padding: EdgeInsets.symmetric(vertical: 30),
                            side: BorderSide(color: Color(0xFF4181FF)),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: Text("Close", style: TextStyle(color: Colors.black)),
                        ),
                      ),
                      ),
                      SizedBox(width: 16),


                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            gradient: LinearGradient(
                              colors: [Color(0xFF4181FF), Color(0xFF274E99)], // Gradient colors
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                          child: ElevatedButton(
                            onPressed: () {},
                            style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.symmetric(vertical: 30),
                              backgroundColor: Colors.transparent, // Make button background transparent
                              shadowColor: Colors.transparent, // Remove shadow
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: Text(
                              "Submit",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ),


                    ],
                  ),
                  SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}




*/
