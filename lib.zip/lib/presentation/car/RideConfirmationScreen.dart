import 'dart:convert';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertickect365/presentation/map_location/SetLocationScreen.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';
import 'SearchingForCarScreen.dart';
import 'package:http/http.dart' as http;

class RideConfirmationScreen extends StatefulWidget {
  @override
  _RideConfirmationScreenState createState() => _RideConfirmationScreenState();
}

class _RideConfirmationScreenState extends State<RideConfirmationScreen> {
  late double currentLat;
  late double currentLng;
  late double destinationLat;
  late double destinationLng;
  String? carname;
  String? vtId;
  String? carprice;
  String? current_address;
  String? destination_address;
  String? fromename;
  String? fromaddress;
  String? toname;
  String? toaddress;
  bool isLoading = true;
  String? bookingID;

  String distanceData = "";
  String durationData = "";

  String? userID;

  @override
  void initState() {
    super.initState();
    _loadSharedPreferences();
    getDistanceAndDuration();
    retrieveData();
    userIdFunction();
  }

  void userIdFunction() async {
    userID = await getUserID();
    if (userID != null) {
      print("UserID is: $userID");
    } else {
      print("UserID not found");
    }
  }

  Future<String?> getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('username');
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<bool> setBookingID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setString(
        'bookingid', bookingID!); // Returns a boolean indicating success
  }

  Future<Map<String, String>> getDistanceAndDuration() async {
    final prefs = await SharedPreferences.getInstance();
    String distance = prefs.getString('saved_distance') ?? '0.0';
    String duration = prefs.getString('saved_duration') ?? '00:00:00';
    return {
      'distance': distance,
      'duration': duration,
    };
  }

  void retrieveData() async {
    Map<String, String> data = await getDistanceAndDuration();
    print('Saved Distance: ${data['distance']}');
    print('Saved Duration: ${data['duration']}');

    // Assign the values to variables
    distanceData = data['distance'] ?? '0.0'; // Default to '0.0' if null
    durationData =
        data['duration'] ?? '00:00:00'; // Default to '00:00:00' if null

    print('Distance Data: $distanceData');
    print('Duration Data: $durationData');
  }

  Future<void> savePlace() async {
    String? token = await getToken();
    String? CustomerName = await getUsername();
    isLoading = true;
    bool isDialogVisible = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFF4181FF),
          ),
        );
      },
    );

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}create_trip');

    print('api called');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      //  "BookingDistance": "10",
      "BookingDistance": distanceData,
      "BookingFromLatitude": currentLat,
      "BookingFromLongitude": currentLng,
      "BookingToLatitude": destinationLat,
      "BookingToLongitude": destinationLng,
      "BookingBkdLatitude": currentLat,
      "BookingBkdLongitude": currentLng,
      "BookingFromName": fromename,
      "BookingFromAddress": fromaddress,
      "BookingVTID": vtId,
      "BookingToName": toname,
      "BookingToAddress": toaddress,
      //"BookingEstimatedRideTime": "04:25:00",
      "BookingEstimatedRideTime": durationData,
    });
    print("------------------->create trip body${body}");

    try {
      final response = await http.post(url, headers: headers, body: body);

      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true).pop();
        isDialogVisible = false;
      }
      if (response.statusCode == 200) {
        print('200 called');

        final data = jsonDecode(response.body);
        print("---------------?${data}");
        if (data['status'] == true) {
          print('true called');
          setState(() {
            isLoading = false;
          });

          bookingID = data['data']['bookingID'].toString();
          setBookingID();
          print("bookingID one = " + bookingID!);

          storeBookingData(
            customerID: userID!,
            customerName: CustomerName!,
            bookingID: bookingID!,
            // Example booking ID
            cusLatitude: currentLat,
            // Example latitude
            cusLongitude: currentLng, // Example longitude
          );
          String currentLatString = currentLat.toString();
          print("success");
          print("customerName = " + CustomerName);
          print("userID = " + userID!);
          print("bookingID = " + bookingID!);
          print("currentLat = " + currentLatString);

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => SearchingForCarScreen()),
          );
          Fluttertoast.showToast(
            msg: data['message'] ?? "Cab is booking success",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
          print(data['message'] ?? "Failed to save location");
        } else {
          showError(data['message'] ?? "Failed to save location");
        }
      } else {
        showError('Failed to save data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true).pop();
        isDialogVisible = false;
      }
    } /* finally {
      Navigator.of(context, rootNavigator: true).pop();
      isLoading = false;
    }*/
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  // Load SharedPreferences asynchronously
  Future<void> _loadSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentLat = prefs.getDouble('current_lat') ?? 0.0;
      currentLng = prefs.getDouble('current_lng') ?? 0.0;
      destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
      destinationLng = prefs.getDouble('destination_lng') ?? 0.0;
      carname = prefs.getString('carname');
      vtId = prefs.getString('vtId');
      carprice = prefs.getString('carprice');
      current_address = prefs.getString('current_address');
      destination_address = prefs.getString('destination_address');

      Map<String, String> addressParts = splitAddress(current_address!);
      Map<String, String> addressPartsto = splitAddressto(destination_address!);
      fromename = addressParts["mainAddress"];
      fromaddress = addressParts["secondaryAddress"];

      toname = addressPartsto["mainAddress"];
      toaddress = addressPartsto["secondaryAddress"];
    });
  }

  Future<String?> getUserID() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userID = prefs.getString('UserID');
    return userID;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Ride Confirmation",
          style: TextStyle(
            color: Colors.black,
            fontSize: 17.0,
            fontWeight: FontWeight.w600,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            LocationTile(
              locationName: fromename ??
                  "Current Location", // Null check for location name
              //  address: "43N, Augusta St. Lorain, OH 44656",
              address: fromaddress ?? "Current Location",
              icon: SvgPicture.asset(
                ImageConstant.bluedot, // Your SVG asset path
                height: 30.0,
                width: 30.0,
              ),
            ),
            SizedBox(height: 8),
            LocationTile(
              locationName:
                  toname ?? "Current Location", // Null check for location name
              address: toaddress ?? "Current Location",
              icon: SvgPicture.asset(
                ImageConstant.bluelocation, // Your SVG asset path
                height: 30.0,
                width: 30.0,
              ),
            ),
            SizedBox(height: 20),
            CarSelectionTile(
              carname: carname ?? "No Car Selected", // Null check for car name
              carprice: carprice ?? "0", // Null check for car price
            ),
            Expanded(child: Container()), // Push the button to the bottom
            buildUpdateButton(),
          ],
        ),
      ),
    );
  }

  Widget buildUpdateButton() {
    return Container(
      width: double.infinity, // Make the button full width
      child: CustomElevatedButton(
        text: "Continue",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () async {
          // Print the saved values from SharedPreferences
          final prefs = await SharedPreferences.getInstance();
          double currentLat = prefs.getDouble('current_lat') ?? 0.0;
          double currentLng = prefs.getDouble('current_lng') ?? 0.0;
          double destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
          double destinationLng = prefs.getDouble('destination_lng') ?? 0.0;
          String? carname = prefs.getString('carname');
          String? vtId = prefs.getString('vtId');
          String? carprice = prefs.getString('carprice');

          print("inn..");

          print("Current Location: Lat: $currentLat, Lng: $currentLng");
          print(
              "Destination Location: Lat: $destinationLat, Lng: $destinationLng");
          print("Car Name: $carname");
          print("VTID: $vtId");
          print("Car Price: $carprice");
          print("current_address: $current_address");

          print("destination_address: $destination_address");

          savePlace();
        },
      ),
    );
  }
}

Map<String, String> splitAddress(String fullAddress) {
  // Split the address by the first comma
  List<String> addressParts = fullAddress.split(', ');

  // Extract the main and secondary parts
  String mainAddress =
      addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
  String secondaryAddress = addressParts.length > 1
      ? addressParts
          .sublist(1)
          .join(', ') // Join the remaining parts with commas
      : "";

  return {
    "mainAddress": mainAddress,
    "secondaryAddress": secondaryAddress,
  };
}

Map<String, String> splitAddressto(String fullAddress) {
  // Split the address by the first comma
  List<String> addressParts = fullAddress.split(', ');

  // Extract the main and secondary parts
  String mainAddress =
      addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
  String secondaryAddress = addressParts.length > 1
      ? addressParts
          .sublist(1)
          .join(', ') // Join the remaining parts with commas
      : "";

  return {
    "mainAddress": mainAddress,
    "secondaryAddress": secondaryAddress,
  };
}

class LocationTile extends StatelessWidget {
  final String locationName;
  final String address;
  final Widget icon;

  LocationTile({
    required this.locationName,
    required this.address,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        icon,
        SizedBox(width: 10),
        Expanded(
          // Use Expanded to prevent overflow
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                locationName,
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                  color: Colors.black,
                ),
                overflow:
                    TextOverflow.ellipsis, // Ensure long text is truncated
              ),
              Text(
                address,
                style: TextStyle(color: Colors.grey),
                overflow:
                    TextOverflow.ellipsis, // Ensure long text is truncated
              ),
            ],
          ),
        ),
        IconButton(
          icon: SvgPicture.asset(
            ImageConstant.liteblueedit, // Your SVG asset path
            height: 30.0,
            width: 30.0,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => SetLocationScreen(
                    // Pass initial address
                    ),
              ),
            );
          },
        ),
      ],
    );
  }
}

Future<void> storeBookingData({
  required String customerID,
  required String customerName,
  required String bookingID,
  required double cusLatitude, // Latitude of the customer
  required double cusLongitude, // Longitude of the customer
}) async {
  try {
    // Reference to the Firebase Realtime Database path for bookings
    DatabaseReference databaseRef =
        FirebaseDatabase.instance.ref('customers/$bookingID');

    // Set the booking data in Realtime Database
    await databaseRef.set({
      'customername': customerName,
      'customerID': customerID,
      'bookingID': bookingID,
      'cusLatitude': cusLatitude, // Store latitude
      'cusLongitude': cusLongitude, // Store longitude
      'status': 'booked', // Example field
      'created_at': ServerValue.timestamp, // Timestamp for record creation
    });

    print("Booking data stored successfully under bookingID: $bookingID!");
  } catch (e) {
    print("Error storing booking data: $e");
  }
}

class CarSelectionTile extends StatelessWidget {
  final String carname;
  final String carprice;

  CarSelectionTile({required this.carname, required this.carprice});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xFFFAFAFA),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Color(0xFFEBEBEB), // Border color #EBEBEB
          width: 1,
        ),
      ),
      child: Row(
        children: [
          SvgPicture.asset(
            ImageConstant.toycar, // Your SVG asset path
            height: 60.0,
            width: 60.0,
          ),
          SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                carname,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 15.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          Spacer(),
          Column(
            children: [
              Text(
                "Estimated Fare",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 11.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                "$carprice",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 15.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/*
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertickect365/presentation/map_location/SetLocationScreen.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/utils/image_constant.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../utils/AppConstants.dart';
import 'SearchingForCarScreen.dart';
import 'package:http/http.dart' as http;

class RideConfirmationScreen extends StatefulWidget {
  @override
  _RideConfirmationScreenState createState() => _RideConfirmationScreenState();
}

class _RideConfirmationScreenState extends State<RideConfirmationScreen> {
  late double currentLat;
  late double currentLng;
  late double destinationLat;
  late double destinationLng;
  String? carname;
  String? vtId;
  String? carprice;
  String? current_address;
  String? destination_address;
  String? fromename;
  String? fromaddress;
  String? toname;
  String? toaddress;
  bool isLoading = true;
  String? bookingID;

  String distanceData = "";
  String durationData = "";

  @override
  void initState() {
    super.initState();
    _loadSharedPreferences();
    getDistanceAndDuration();
    retrieveData();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<bool> setBookingID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setString(
        'bookingid', bookingID!); // Returns a boolean indicating success
  }

  Future<Map<String, String>> getDistanceAndDuration() async {
    final prefs = await SharedPreferences.getInstance();
    String distance = prefs.getString('saved_distance') ?? '0.0';
    String duration = prefs.getString('saved_duration') ?? '00:00:00';
    return {
      'distance': distance,
      'duration': duration,
    };
  }

  void retrieveData() async {
    Map<String, String> data = await getDistanceAndDuration();
    print('Saved Distance: ${data['distance']}');
    print('Saved Duration: ${data['duration']}');

    // Assign the values to variables
    distanceData = data['distance'] ?? '0.0'; // Default to '0.0' if null
    durationData =
        data['duration'] ?? '00:00:00'; // Default to '00:00:00' if null

    print('Distance Data: $distanceData');
    print('Duration Data: $durationData');
  }

  Future<void> savePlace() async {
    String? token = await getToken();
    isLoading = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFF4181FF),
          ),
        );
      },
    );

    if (token == null) {
      showError("Authentication token not found");
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}create_trip');

    print('api called');

    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    final body = jsonEncode({
      //  "BookingDistance": "10",
      "BookingDistance": distanceData,
      "BookingFromLatitude": currentLat,
      "BookingFromLongitude": currentLng,
      "BookingToLatitude": destinationLat,
      "BookingToLongitude": destinationLng,
      "BookingBkdLatitude": currentLat,
      "BookingBkdLongitude": currentLng,
      "BookingFromName": fromename,
      "BookingFromAddress": fromaddress,
      "BookingVTID": vtId,
      "BookingToName": toname,
      "BookingToAddress": toaddress,
      //"BookingEstimatedRideTime": "04:25:00",
      "BookingEstimatedRideTime": durationData,
    });
    print(body);

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        print('200 called');

        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          print('true called');
          setState(() {
            isLoading = false;
          });

          bookingID = data['data']['bookingID'].toString();
          setBookingID();
          print("bookingID = " + bookingID!);

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => SearchingForCarScreen()),
          );
          Fluttertoast.showToast(
            msg: data['message'] ?? "Cab is booking success",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
          print(data['message'] ?? "Failed to save location");
        } else {
          showError(data['message'] ?? "Failed to save location");
        }
      } else {
        showError('Failed to save data: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {
      isLoading = false;
    });
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  // Load SharedPreferences asynchronously
  Future<void> _loadSharedPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      currentLat = prefs.getDouble('current_lat') ?? 0.0;
      currentLng = prefs.getDouble('current_lng') ?? 0.0;
      destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
      destinationLng = prefs.getDouble('destination_lng') ?? 0.0;
      carname = prefs.getString('carname');
      vtId = prefs.getString('vtId');
      carprice = prefs.getString('carprice');
      current_address = prefs.getString('current_address');
      destination_address = prefs.getString('destination_address');

      Map<String, String> addressParts = splitAddress(current_address!);
      Map<String, String> addressPartsto = splitAddressto(destination_address!);
      fromename = addressParts["mainAddress"];
      fromaddress = addressParts["secondaryAddress"];

      toname = addressPartsto["mainAddress"];
      toaddress = addressPartsto["secondaryAddress"];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Ride Confirmation",
          style: TextStyle(
            color: Colors.black,
            fontSize: 17.0,
            fontWeight: FontWeight.w600,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            LocationTile(
              locationName: fromename ??
                  "Current Location", // Null check for location name
              //  address: "43N, Augusta St. Lorain, OH 44656",
              address: fromaddress ?? "Current Location",
              icon: SvgPicture.asset(
                ImageConstant.bluedot, // Your SVG asset path
                height: 30.0,
                width: 30.0,
              ),
            ),
            SizedBox(height: 8),
            LocationTile(
              locationName:
                  toname ?? "Current Location", // Null check for location name
              address: toaddress ?? "Current Location",
              icon: SvgPicture.asset(
                ImageConstant.bluelocation, // Your SVG asset path
                height: 30.0,
                width: 30.0,
              ),
            ),
            SizedBox(height: 20),
            CarSelectionTile(
              carname: carname ?? "No Car Selected", // Null check for car name
              carprice: carprice ?? "0", // Null check for car price
            ),
            Expanded(child: Container()), // Push the button to the bottom
            buildUpdateButton(),
          ],
        ),
      ),
    );
  }

  Widget buildUpdateButton() {
    return Container(
      width: double.infinity, // Make the button full width
      child: CustomElevatedButton(
        text: "Continue",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () async {
          // Print the saved values from SharedPreferences
          final prefs = await SharedPreferences.getInstance();
          double currentLat = prefs.getDouble('current_lat') ?? 0.0;
          double currentLng = prefs.getDouble('current_lng') ?? 0.0;
          double destinationLat = prefs.getDouble('destination_lat') ?? 0.0;
          double destinationLng = prefs.getDouble('destination_lng') ?? 0.0;
          String? carname = prefs.getString('carname');
          String? vtId = prefs.getString('vtId');
          String? carprice = prefs.getString('carprice');

          print("inn..");

          print("Current Location: Lat: $currentLat, Lng: $currentLng");
          print(
              "Destination Location: Lat: $destinationLat, Lng: $destinationLng");
          print("Car Name: $carname");
          print("VTID: $vtId");
          print("Car Price: $carprice");
          print("current_address: $current_address");

          print("destination_address: $destination_address");

          savePlace();
        },
      ),
    );
  }
}

Map<String, String> splitAddress(String fullAddress) {
  // Split the address by the first comma
  List<String> addressParts = fullAddress.split(', ');

  // Extract the main and secondary parts
  String mainAddress =
      addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
  String secondaryAddress = addressParts.length > 1
      ? addressParts
          .sublist(1)
          .join(', ') // Join the remaining parts with commas
      : "";

  return {
    "mainAddress": mainAddress,
    "secondaryAddress": secondaryAddress,
  };
}

Map<String, String> splitAddressto(String fullAddress) {
  // Split the address by the first comma
  List<String> addressParts = fullAddress.split(', ');

  // Extract the main and secondary parts
  String mainAddress =
      addressParts.isNotEmpty ? addressParts[0] : "Unknown Address";
  String secondaryAddress = addressParts.length > 1
      ? addressParts
          .sublist(1)
          .join(', ') // Join the remaining parts with commas
      : "";

  return {
    "mainAddress": mainAddress,
    "secondaryAddress": secondaryAddress,
  };
}

class LocationTile extends StatelessWidget {
  final String locationName;
  final String address;
  final Widget icon;

  LocationTile({
    required this.locationName,
    required this.address,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        icon,
        SizedBox(width: 10),
        Expanded(
          // Use Expanded to prevent overflow
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                locationName,
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                  color: Colors.black,
                ),
                overflow:
                    TextOverflow.ellipsis, // Ensure long text is truncated
              ),
              Text(
                address,
                style: TextStyle(color: Colors.grey),
                overflow:
                    TextOverflow.ellipsis, // Ensure long text is truncated
              ),
            ],
          ),
        ),
        IconButton(
          icon: SvgPicture.asset(
            ImageConstant.liteblueedit, // Your SVG asset path
            height: 30.0,
            width: 30.0,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => SetLocationScreen(
                    // Pass initial address
                    ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class CarSelectionTile extends StatelessWidget {
  final String carname;
  final String carprice;

  CarSelectionTile({required this.carname, required this.carprice});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xFFFAFAFA),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Color(0xFFEBEBEB), // Border color #EBEBEB
          width: 1,
        ),
      ),
      child: Row(
        children: [
          SvgPicture.asset(
            ImageConstant.toycar, // Your SVG asset path
            height: 60.0,
            width: 60.0,
          ),
          SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                carname,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 15.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          Spacer(),
          Column(
            children: [
              Text(
                "Estimated Fare",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 11.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                "$carprice",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 15.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
*/
