import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../cab_homepage_screen/cab_homepage_screen.dart';
import '../utils/AppConstants.dart';
import 'package:http/http.dart' as http;

class NotificationPage extends StatefulWidget {
  @override
  _NotificationPageState createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<dynamic> notificationList = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    fetchBookings();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> fetchBookings() async {
    String? token = await getToken();
    // String? token =
    //     "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiZTg5Y2QxMWIzOGUxOTNkNTU2ZDM2ZWE0MDEzMDg5YWU5Y2JlNzVjODc3YjAwZjlkODQ5MzBkZmYxNTcxNWVmOGE4NDBhZjRjNDkwMjg4YzgiLCJpYXQiOjE3MzIxOTA5MTUuMjYyNjk2MDI3NzU1NzM3MzA0Njg3NSwibmJmIjoxNzMyMTkwOTE1LjI2MjcwMDA4MDg3MTU4MjAzMTI1LCJleHAiOjE3NjM3MjY5MTUuMjQ1NDAzMDUxMzc2MzQyNzczNDM3NSwic3ViIjoiMTciLCJzY29wZXMiOltdfQ.Ve99XLlQQKe_NS22KE2wHMjb_txxas1qUpA6XglARfxj3iA3kIudfMYOnISW9uKTLukvXybrCuAl7Xblh5iAuqWFFqsW8uGkFgu6-zRKqjogXEWJJZ78_RoHDzj7StG9QH3RRtIieralWCi9lTdDET7EM5CGp855H4hVGT6qAHZkgrAVU1Jk_BQwJlxFFFSeqPN6pfZbkXmmdOZ04KgUjtiShYpQPmLTD30t1mzCPnax012UK3u018S5OnDZvsYMf-W-NjEas53Op5poA9s_CNnr9eKlmk3FN-xEqB-5LXRKRQOsubVFtYF8CfeP_sQmZQkceT_bj1wcIEUVh37q-8Z1_7IOkpXBW4Xe_iUVTE5gouvVSoWfmIV-NTxn1goKzxQC5JyyskeLpUIAB8X84Kc3HRlHw6sIAmlCgik-97_w2XvYawPRGH3VZ03W8CFWyMOU21Hs0ig4kvSw2z47fyfni1oIUR-Jpj_S13r6ZOshs7oyR9h5T7-6AiTiHItbhZuhRaE7d3xS_Si9W_FgU1YDpewJEjbvCF6OWxiSlj_QtSC4epdsih02X1mHHgbQHfLbu6cmAMUBkI6U1WovhjXyR2K9ZEOE9JWhT_7Wu_3XzT0XVftfio5hhQ7XH4EQ2LcHxrfsrN52QieXbQBDNJKOHg6fw5lO1RDoPUgp_Lc";
    //

    if (token == null) {
      showError('Authorization token not found.');
      return;
    }

    final url = Uri.parse('${AppConstants.MAIN_URL}notifications');
    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      setState(() {});
      var response =
          await http.post(url, headers: headers, body: jsonEncode({}));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == true) {
          setState(() {
            notificationList = data['notifications'] ?? [];
          });
        } else {
          showError(data['message'] ?? 'Unknown error occurred.');
        }
      } else {
        showError('Failed to fetch data. Status code: ${response.statusCode}');
      }
    } catch (e) {
      showError('An error occurred: $e');
    }
  }

  void showError(String message) {
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return /*WillPopScope(
      onWillPop: () async {
        // Navigate to Login Page
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => CabHomepageScreen(),
          ),
        );
        return false; // Prevent default back navigation
      },
      child:*/ Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 1,
          title: const Text(
            "Notification",
            style: TextStyle(
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
                fontSize: 17,
                color: Color(0xFF282828)),
          ),
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
              Get.back();
           /*   Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => CabHomepageScreen(),
                ),
              );*/
            },
          ),

          /*    bottom: TabBar(
            controller: _tabController,
            labelColor: Color(0xFF4181FF),
            unselectedLabelColor: Color(0xFF9C9C9C),
            indicatorColor: Color(0xFF4181FF),
            tabs: [
              Tab(text: "Bus"),
              Tab(text: "Flight"),
              Tab(text: "Hotel"),
              Tab(text: "Cab"),
            ],
          ),*/
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            /*        Center(child: Text("No Bus Notifications")),
            Center(child: Text("No Flight Notifications")),
            Center(child: Text("No Hotel Notifications")),*/
            NotificationList(notificationList: notificationList),
          ],
        ),
      );
   // );
  }
}

class NotificationList extends StatelessWidget {
  final List<dynamic> notificationList;

  NotificationList({required this.notificationList});

  String formatDate(String dateString) {
    try {
      // Parse the input string to a DateTime object
      DateTime dateTime = DateTime.parse(dateString);

      // Format the DateTime object to the desired string format
      String formattedTime =
          DateFormat('h:mm a').format(dateTime); // For time (6:40 PM)
      String formattedDate =
          DateFormat('d MMMM').format(dateTime); // For date (27 June)

      // Combine both time and date into one formatted string
      return '$formattedTime, $formattedDate';
    } catch (e) {
      return 'Invalid date format';
    }
  }

  @override
  Widget build(BuildContext context) {
    return notificationList.isEmpty
        ? Center(
            child: Text(
              'No data found',
              style: TextStyle(
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                  color: Color(0xFF9C9C9C)),
            ),
          )
        : ListView.builder(
            padding: EdgeInsets.all(16),
            itemCount: notificationList.length,
            itemBuilder: (context, index) {
              var notification = notificationList[index];
              return NotificationItem(
                message: notification['NotificationTitle'] ?? 'No message',
                carDes: notification['NotificationDesc'] ?? 'No message',
                //message: notification['NotificationDesc'] ?? 'No message',
                time: formatDate(notification['NotificationCreatedAt']) ??
                    'Unknown time',
                driverName: notification['AgentName'] ?? 'Unknown',
                carDetails:
                    notification['AgentVehicleNumber'] ?? 'Unknown vehicle',
                rating:
                    double.tryParse(notification['AgentTotalRatings'] ?? '0.0'),
                profileImageUrl: "https://via.placeholder.com/150",
              );
            },
          );
  }
}

class NotificationItem extends StatelessWidget {
  final String message;
  final String time;
  final String driverName;
  final String carDetails;
  final String carDes;
  final double? rating;
  final String profileImageUrl;

  NotificationItem({
    required this.message,
    required this.time,
    required this.driverName,
    required this.carDetails,
    required this.carDes,
    this.rating,
    required this.profileImageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue[50],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  message,
                  style: TextStyle(
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                      color: Color(0xFF282828)),
                ),
              ),
              Text(
                time,
                style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 11,
                    color: Color(0xFF9C9C9C)),
              ),
            ],
          ),
          SizedBox(height: 8),
          Row(
            children: [
              CircleAvatar(
                backgroundImage: NetworkImage(profileImageUrl),
                radius: 24,
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      driverName,
                      style: TextStyle(
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                          color: Color(0xFF282828)),
                    ),
                    Text(
                      carDetails,
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 13,
                        color: Color(0xFFBDBDBD),
                      ),
                    ),
                  ],
                ),
              ),
              if (rating != null)
                Row(
                  children: [
                    Icon(Icons.star, color: Color(0xFF4181FF)),
                    SizedBox(width: 4),
                    Text(
                      rating.toString(),
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                        color: Color(0xFF282828),
                      ),
                    ),
                  ],
                ),
            ],
          ),
          SizedBox(height: 5),
          Text(
            carDes,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w500,
              fontSize: 13,
              color: Color(0xFF9C9C9C),
            ),
          ),
        ],
      ),
    );
  }
}
