import 'dart:developer';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertickect365/presentation/cab_homepage_screen/apiModel/sharedPref.dart';
import 'package:fluttertickect365/sujin_screen/SharedPref/sharedPref.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/sizes.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart'; // For Toast messages
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/app_export.dart';
import '../../core/utils/validation_functions.dart';
import '../../domain/googleauth/google_auth_helper.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_outlined_button.dart';
import '../../widgets/custom_text_form_field.dart';
import '../car/SearchingForCarScreen.dart';
import '../otp_screen/Otp.dart';
import '../utils/AppConstants.dart';
import '../utils/AppSignatureHelper.dart';
import 'bloc/login_bloc.dart';
import 'models/login_model.dart';

class LoginScreen extends StatefulWidget {
  final String? number; // Added to receive phone number

  LoginScreen({Key? key, this.number}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late TextEditingController _phoneNumberController;

  String? signature;
  String? token;

  @override
  void initState() {
    super.initState();
    _phoneNumberController = TextEditingController();

    if (widget.number != null) {
      _phoneNumberController.text = widget.number!;
    }

    getSignature();
    getFirebaseToken();
    setloginstatus();
    // Request notification permission when the screen is initialized
    requestNotificationPermission();
  }

  Future<void> requestNotificationPermission() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;

    // Request permission for iOS
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted notification permission');
    } else if (settings.authorizationStatus ==
        AuthorizationStatus.provisional) {
      print('User granted provisional notification permission');
    } else {
      print('User denied notification permission');
    }
  }

  Future<bool> setloginstatus() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setString(
        'login', 'login'); // Returns a boolean indicating success
  }

  @override
  void dispose() {
    _phoneNumberController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _formKey,
        child: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: SizedBox(
              width: double.maxFinite,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildTicketAppStack(context),
                  SizedBox(height: 44),
                  SizedBox(
                    width: double.maxFinite,
                    child: Align(
                      alignment: Alignment.center,
                      child: Container(
                        width: double.maxFinite,
                        margin: EdgeInsets.symmetric(horizontal: 22),
                        padding: EdgeInsets.symmetric(horizontal: 14),
                        child: Column(
                          children: [
                            Text(
                              "Login to Your Account",
                              style: TextStyle(
                                fontFamily: 'Poppins-SemiBold',
                                fontSize: 23.0,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF282828),
                              ),
                            ),
                            SizedBox(height: 38),
                            CustomTextFormField(
                              controller: _phoneNumberController,
                              hintText: "Enter your phone number",
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.phone,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(10),
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              prefix: Container(
                                margin: EdgeInsets.fromLTRB(16, 8, 12, 8),
                                child: CustomImageView(
                                  imagePath: ImageConstant.imgFirrphonecall,
                                  height: 24,
                                  width: 24,
                                  fit: BoxFit.contain,
                                ),
                              ),
                              prefixConstraints: BoxConstraints(maxHeight: 40),
                              contentPadding: EdgeInsets.fromLTRB(16, 8, 12, 8),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "Please enter a valid phone number.";
                                } else if (!RegExp(r'^\d+$').hasMatch(value)) {
                                  return "Phone number should contain only digits.";
                                } else if (value.length < 10) {
                                  return "Phone number should be at least 10 digits.";
                                }
                                return null;
                              },
                              textStyle: TextStyle(
                                  color: Color(
                                      0xFF858585)), // Change text color here
                            ),
                            kHeight30,

                            CustomElevatedButton(
                              text: "Get OTP",
                              buttonStyle: CustomButtonStyles.none,
                              decoration: CustomButtonStyles
                                  .gradientBlueAToPrimaryDecoration,
                              onPressed: () {
                                onTapGetotp(context);
                              },
                            ),
                            SizedBox(height: 24),
                            /*  Text(
                              "Or",
                              style: CustomTextStyles.titleSmallSemiBold,
                            ),*/
                            SizedBox(height: 24),
                            /*
                            CustomOutlinedButton(
                              text: "Continue with Google",
                              leftIcon: Container(
                                margin: EdgeInsets.only(right: 12.h),
                                child: CustomImageView(
                                  imagePath: ImageConstant.imgFi300221,
                                  height: 24.h,
                                  width: 24.h,
                                  fit: BoxFit.contain,
                                ),
                              ),
                              buttonStyle: CustomButtonStyles.outlineGray,
                              buttonTextStyle: theme.textTheme.bodyMedium!,
                              onPressed: () {
                                onTapContinuewith(context);
                              },
                            ),
    */
                            // SizedBox(height: 76.h),
                            SizedBox(height: 106),
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20.0), // Adjust the padding
                                child: RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text:
                                            "By continuing, you agree to our ",
                                        style: theme.textTheme.labelLarge,
                                      ),
                                      TextSpan(
                                        text: "Terms of Service",
                                        style: theme.textTheme.labelLarge!
                                            .copyWith(
                                          decoration: TextDecoration.underline,
                                        ),
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = () async {
                                            // Handle the tap action for "Terms of Service"
                                            print("Terms of Service clicked");
                                            final Uri url = Uri.parse(
                                                'https://pub.dev/packages/url_launcher/versions');
                                            if (!await launchUrl(url)) {
                                              throw Exception(
                                                  'Could not launch $url');
                                            }
                                          },
                                      ),
                                      TextSpan(text: ", "),
                                      TextSpan(
                                        text: "Privacy Policy",
                                        style: theme.textTheme.labelLarge!
                                            .copyWith(
                                          decoration: TextDecoration.underline,
                                        ),
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = () async {
                                            // Handle the tap action for "Privacy Policy"
                                            print("Privacy Policy clicked");
                                            final Uri url = Uri.parse(
                                                'https://pub.dev/packages/url_launcher/versions');
                                            if (!await launchUrl(url)) {
                                              throw Exception(
                                                  'Could not launch $url');
                                            }
                                          },
                                      ),
                                      TextSpan(
                                        text: ", and ",
                                        style: theme.textTheme.labelLarge!
                                            .copyWith(
                                          decoration: TextDecoration.underline,
                                        ),
                                      ),
                                      TextSpan(
                                        text: "Content Policy",
                                        style: theme.textTheme.labelLarge!
                                            .copyWith(
                                          decoration: TextDecoration.underline,
                                        ),
                                        recognizer: TapGestureRecognizer()
                                          ..onTap = () async {
                                            // Handle the tap action for "Content Policy"
                                            print("Content Policy clicked");

                                            final Uri url = Uri.parse(
                                                'https://pub.dev/packages/url_launcher/versions');
                                            if (!await launchUrl(url)) {
                                              throw Exception(
                                                  'Could not launch $url');
                                            }
                                          },
                                      ),
                                    ],
                                  ),
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ),
                            SizedBox(height: 44),
                            // SizedBox(
                            //   width: 112.h,
                            //   child: Divider(),
                            // ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 6),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTicketAppStack(BuildContext context) {
    return Container(
      height: 302,
      width: double.maxFinite,
      margin: EdgeInsets.only(left: 64),
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgFrame1716775383,
            height: 240,
            width: 270,
            alignment: Alignment.topRight,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgTicketapp36501,
            height: 65,
            width: 246,
          ),
        ],
      ),
    );
  }

  void getSignature() async {
    signature = await AppSignatureHelper.getAppSignatures();
    if (signature != null) {
      print("App Signature: $signature");
    } else {
      print("Failed to get app signature");
    }
  }

  void getFirebaseToken() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    token = await messaging.getToken();
    print("Firebase Token: $token");
  }

  void onTapGetotp(BuildContext context) {
    if (_formKey.currentState?.validate() ?? false) {
      final phoneNumber = _phoneNumberController?.text ?? '';
      loginAPI(context, phoneNumber);
    }
  }

  void loginAPI(BuildContext context, String phNum) async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'sendOTP');
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    String? token1 = await messaging.getToken();
    print("Firebase Token: $token1");
    //log(token1!);
    //log("-------${url}");
    final requestBody = {
      'phone': phNum,
      'firebaseToken': token1,
      'signkey': signature
    };

    // print("apitoken = " + token1!);
    //  print("apisignkey = " + signature!);

    bool isDialogVisible = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child:  LoadingAnimationWidget.beat(
           color: Colors.blue,
            size: 50.sp,
          ),
        );
      },
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(requestBody),
      );

      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true).pop();
        isDialogVisible = false;
      }

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == true) {
          print('Login successful: $data');
          String otp = data['otp'].toString();

          // Save token and UserID in SharedPreferences
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('phone', phNum);

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => OtpScreen(otp: otp, number: phNum),
            ),
            //builder: (context) => SearchingForCarScreen()),
          );
        } else {
          String errorMessage = '';
          if (data['message'] is List && data['message'].isNotEmpty) {
            errorMessage = data['message'][0];
          }

          Fluttertoast.showToast(
            msg: errorMessage,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
      } else {
        print('Login failed with status: ${response.statusCode}');
      }
    } catch (e) {
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true).pop();
        isDialogVisible = false;
      }
      print('An error occurred: $e');
    }
  }

  void onTapContinuewith(BuildContext context) async {
    await GoogleAuthHelper().googleSignInProcess().then((googleUser) {
      if (googleUser != null) {
        // Handle successful Google Sign-In
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('User data is empty')));
      }
    }).catchError((onError) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(onError.toString())));
    });
  }
}

/*import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Import this for LengthLimitingTextInputFormatter
import '../../core/app_export.dart';
import '../../core/utils/validation_functions.dart';
import '../../domain/googleauth/google_auth_helper.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_outlined_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/login_bloc.dart';
import 'models/login_model.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => LoginBloc(LoginState(
        loginModelObj: LoginModel(),
      ))
        ..add(LoginInitialEvent()),
      child: LoginScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTicketAppStack(context),
                    SizedBox(height: 44.h),
                    SizedBox(
                      width: double.maxFinite,
                      child: Align(
                        alignment: Alignment.center,
                        child: Container(
                          width: double.maxFinite,
                          margin: EdgeInsets.symmetric(horizontal: 22.h),
                          padding: EdgeInsets.symmetric(horizontal: 14.h),
                          child: Column(
                            children: [
                              Text(
                                "Login to Your Account",
                                style: TextStyle(
                                  fontFamily: 'Poppins-SemiBold',
                                  fontSize: 23.0,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFF282828),
                                ),
                              ),
                              SizedBox(height: 38.h),
                              BlocSelector<LoginBloc, LoginState,
                                  TextEditingController?>(
                                selector: (state) =>
                                    state.phoneNumberController,
                                builder: (context, phoneNumberController) {
                                  return CustomTextFormField(
                                    controller: phoneNumberController,
                                    hintText: "msg_enter_your_phone".tr,
                                    textInputAction: TextInputAction.done,
                                    textInputType: TextInputType.phone,
                                    inputFormatters: [
                                      LengthLimitingTextInputFormatter(
                                          10), // Maximum length set to 10
                                      FilteringTextInputFormatter
                                          .digitsOnly, // Only allow digits
                                    ],
                                    prefix: Container(
                                      margin: EdgeInsets.fromLTRB(
                                          16.h, 8.h, 12.h, 8.h),
                                      child: CustomImageView(
                                        imagePath:
                                            ImageConstant.imgFirrphonecall,
                                        height: 24.h,
                                        width: 24.h,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                    prefixConstraints:
                                        BoxConstraints(maxHeight: 40.h),
                                    contentPadding: EdgeInsets.fromLTRB(
                                        16.h, 8.h, 12.h, 8.h),
                                    validator: (value) {
                                      if (value == null || value.isEmpty) {
                                        return "Please enter a valid phone number.";
                                      } else if (!RegExp(r'^\d+$')
                                          .hasMatch(value)) {
                                        return "Phone number should contain only digits.";
                                      } else if (value.length < 10) {
                                        return "Phone number should be at least 10 digits.";
                                      }
                                      return null;
                                    },
                                  );
                                },
                              ),
                              SizedBox(height: 24.h),
                              CustomElevatedButton(
                                text: "lbl_get_otp".tr,
                                buttonStyle: CustomButtonStyles.none,
                                decoration: CustomButtonStyles
                                    .gradientBlueAToPrimaryDecoration,
                                onPressed: () {
                                  onTapGetotp(context);
                                },
                              ),
                              SizedBox(height: 24.h),
                              Text(
                                "lbl_or".tr,
                                style: CustomTextStyles.titleSmallSemiBold,
                              ),
                              SizedBox(height: 24.h),
                              CustomOutlinedButton(
                                text: "msg_continue_with_google".tr,
                                leftIcon: Container(
                                  margin: EdgeInsets.only(right: 12.h),
                                  child: CustomImageView(
                                    imagePath: ImageConstant.imgFi300221,
                                    height: 24.h,
                                    width: 24.h,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                                buttonStyle: CustomButtonStyles.outlineGray,
                                buttonTextStyle: theme.textTheme.bodyMedium!,
                                onPressed: () {
                                  onTapContinuewith(context);
                                },
                              ),
                              SizedBox(height: 76.h),
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "msg_by_continuing_you2".tr,
                                      style: theme.textTheme.labelLarge,
                                    ),
                                    TextSpan(
                                      text: "msg_terms_of_service".tr,
                                      style:
                                          theme.textTheme.labelLarge!.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                    TextSpan(text: ""),
                                    TextSpan(
                                      text: "lbl_privacy_policy".tr,
                                      style:
                                          theme.textTheme.labelLarge!.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                    TextSpan(text: ""),
                                    TextSpan(
                                      text: "lbl_content_policy".tr,
                                      style:
                                          theme.textTheme.labelLarge!.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    )
                                  ],
                                ),
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              SizedBox(height: 44.h),
                              SizedBox(
                                width: 112.h,
                                child: Divider(),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 6.h),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTicketAppStack(BuildContext context) {
    return Container(
      height: 302.h,
      width: double.maxFinite,
      margin: EdgeInsets.only(left: 64.h),
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgFrame1716775383,
            height: 240.h,
            width: 270.h,
            alignment: Alignment.topRight,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgTicketapp36501,
            height: 65.h,
            width: 246.h,
          ),
        ],
      ),
    );
  }

  void onTapGetotp(BuildContext context) {
    if (_formKey.currentState?.validate() ?? false) {
      NavigatorService.pushNamed(AppRoutes.otpScreen);
    }
  }

  void onTapContinuewith(BuildContext context) async {
    await GoogleAuthHelper().googleSignInProcess().then((googleUser) {
      if (googleUser != null) {
        // Handle successful Google Sign-In
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('User data is empty')));
      }
    }).catchError((onError) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(onError.toString())));
    });
  }
}*/

/*
import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../core/utils/validation_functions.dart';
import '../../domain/googleauth/google_auth_helper.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_outlined_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/login_bloc.dart';
import 'models/login_model.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => LoginBloc(LoginState(
        loginModelObj: LoginModel(),
      ))
        ..add(LoginInitialEvent()),
      child: LoginScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTicketAppStack(context),
                    SizedBox(height: 44.h),
                    SizedBox(
                      width: double.maxFinite,
                      child: Align(
                        alignment: Alignment.center,
                        child: Container(
                          width: double.maxFinite,
                          margin: EdgeInsets.symmetric(
                            horizontal: 22.h,
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 14.h,
                          ),
                          child: Column(
                            children: [
                              Text(
                                "Login to Your Account",
                                style: TextStyle(
                                  fontFamily: 'Poppins-SemiBold',
                                  fontSize: 23.0,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFF282828),
                                ),
                              ),
                              SizedBox(height: 38.h),
                              BlocSelector<LoginBloc, LoginState,
                                  TextEditingController?>(
                                selector: (state) =>
                                    state.phoneNumberController,
                                builder: (context, phoneNumberController) {
                                  return CustomTextFormField(
                                    controller: phoneNumberController,
                                    hintText: "msg_enter_your_phone".tr,
                                    textInputAction: TextInputAction.done,
                                    textInputType: TextInputType.phone,
                                    prefix: Container(
                                      margin: EdgeInsets.fromLTRB(
                                        16.h,
                                        8.h,
                                        12.h,
                                        8.h,
                                      ),
                                      child: CustomImageView(
                                        imagePath:
                                            ImageConstant.imgFirrphonecall,
                                        height: 24.h,
                                        width: 24.h,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                    prefixConstraints: BoxConstraints(
                                      maxHeight: 40.h,
                                    ),
                                    contentPadding: EdgeInsets.fromLTRB(
                                      16.h,
                                      8.h,
                                      12.h,
                                      8.h,
                                    ),
                                    validator: (value) {
                                      if (value == null || value.isEmpty) {
                                        return "Please enter a valid phone number.";
                                      } else if (!RegExp(r'^\d+$')
                                          .hasMatch(value)) {
                                        return "Phone number should contain only digits.";
                                      } else if (value.length < 10) {
                                        return "Phone number should be at least 10 digits.";
                                      }
                                      return null;
                                    },
                                  );
                                },
                              ),
                              SizedBox(height: 24.h),
                              CustomElevatedButton(
                                text: "lbl_get_otp".tr,
                                buttonStyle: CustomButtonStyles.none,
                                decoration: CustomButtonStyles
                                    .gradientBlueAToPrimaryDecoration,
                                onPressed: () {
                                  onTapGetotp(context);
                                },
                              ),
                              SizedBox(height: 24.h),
                              Text(
                                "lbl_or".tr,
                                style: CustomTextStyles.titleSmallSemiBold,
                              ),
                              SizedBox(height: 24.h),
                              CustomOutlinedButton(
                                text: "msg_continue_with_google".tr,
                                leftIcon: Container(
                                  margin: EdgeInsets.only(right: 12.h),
                                  child: CustomImageView(
                                    imagePath: ImageConstant.imgFi300221,
                                    height: 24.h,
                                    width: 24.h,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                                buttonStyle: CustomButtonStyles.outlineGray,
                                buttonTextStyle: theme.textTheme.bodyMedium!,
                                onPressed: () {
                                  onTapContinuewith(context);
                                },
                              ),
                              SizedBox(height: 76.h),
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "msg_by_continuing_you2".tr,
                                      style: theme.textTheme.labelLarge,
                                    ),
                                    TextSpan(
                                      text: "msg_terms_of_service".tr,
                                      style:
                                          theme.textTheme.labelLarge!.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                    TextSpan(
                                      text: "",
                                    ),
                                    TextSpan(
                                      text: "lbl_privacy_policy".tr,
                                      style:
                                          theme.textTheme.labelLarge!.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                    TextSpan(
                                      text: "",
                                    ),
                                    TextSpan(
                                      text: "lbl_content_policy".tr,
                                      style:
                                          theme.textTheme.labelLarge!.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    )
                                  ],
                                ),
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              SizedBox(height: 44.h),
                              SizedBox(
                                width: 112.h,
                                child: Divider(),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 6.h)
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTicketAppStack(BuildContext context) {
    return Container(
      height: 302.h,
      width: double.maxFinite,
      margin: EdgeInsets.only(left: 64.h),
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgFrame1716775383,
            height: 240.h,
            width: 270.h,
            alignment: Alignment.topRight,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgTicketapp36501,
            height: 65.h,
            width: 246.h,
          )
        ],
      ),
    );
  }

  void onTapGetotp(BuildContext context) {
    if (_formKey.currentState?.validate() ?? false) {
      NavigatorService.pushNamed(
        AppRoutes.otpScreen,
      );
    }
  }

  void onTapContinuewith(BuildContext context) async {
    await GoogleAuthHelper().googleSignInProcess().then((googleUser) {
      if (googleUser != null) {
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('user data is empty')));
      }
    }).catchError((onError) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(onError.toString())));
    });
  }
}
*/

/*
import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../core/utils/validation_functions.dart';
import '../../domain/googleauth/google_auth_helper.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_outlined_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/login_bloc.dart';
import 'models/login_model.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => LoginBloc(LoginState(
        loginModelObj: LoginModel(),
      ))
        ..add(LoginInitialEvent()),
      child: LoginScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTicketAppStack(context),
                    SizedBox(height: 44.h),
                    SizedBox(
                      width: double.maxFinite,
                      child: Align(
                        alignment: Alignment.center,
                        child: Container(
                          width: double.maxFinite,
                          margin: EdgeInsets.symmetric(
                            horizontal: 22.h,
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 14.h,
                          ),
                          child: Column(
                            children: [
                              Text(
                                "Login to Your Account",
                                style: TextStyle(
                                  fontFamily: 'Poppins-SemiBold',
                                  fontSize: 23.0,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFF282828),
                                ),
                              ),
                              SizedBox(height: 38.h),
                              BlocSelector<LoginBloc, LoginState,
                                  TextEditingController?>(
                                selector: (state) =>
                                    state.phoneNumberController,
                                builder: (context, phoneNumberController) {
                                  return CustomTextFormField(
                                    controller: phoneNumberController,
                                    hintText: "msg_enter_your_phone".tr,
                                    textInputAction: TextInputAction.done,
                                    textInputType: TextInputType.phone,
                                    prefix: Container(
                                      margin: EdgeInsets.fromLTRB(
                                        16.h,
                                        8.h,
                                        12.h,
                                        8.h,
                                      ),
                                      child: CustomImageView(
                                        imagePath:
                                            ImageConstant.imgFirrphonecall,
                                        height: 24.h,
                                        width: 24.h,
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                    prefixConstraints: BoxConstraints(
                                      maxHeight: 40.h,
                                    ),
                                    contentPadding: EdgeInsets.fromLTRB(
                                      16.h,
                                      8.h,
                                      12.h,
                                      8.h,
                                    ),
                                    validator: (value) {
                                      //  if (!isValidPhone(value)) {
                                      if (value == null || value.isEmpty) {
                                        return "err_msg_please_enter_valid_phone_number";
                                      }
                                      return null;
                                    },
                                  );
                                },
                              ),
                              SizedBox(height: 24.h),
                              CustomElevatedButton(
                                text: "lbl_get_otp".tr,
                                buttonStyle: CustomButtonStyles.none,
                                decoration: CustomButtonStyles
                                    .gradientBlueAToPrimaryDecoration,
                                onPressed: () {
                                  onTapGetotp(context);
                                },
                              ),
                              SizedBox(height: 24.h),
                              Text(
                                "lbl_or".tr,
                                style: CustomTextStyles.titleSmallSemiBold,
                              ),
                              SizedBox(height: 24.h),
                              CustomOutlinedButton(
                                text: "msg_continue_with_google".tr,
                                leftIcon: Container(
                                  margin: EdgeInsets.only(right: 12.h),
                                  child: CustomImageView(
                                    imagePath: ImageConstant.imgFi300221,
                                    height: 24.h,
                                    width: 24.h,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                                buttonStyle: CustomButtonStyles.outlineGray,
                                buttonTextStyle: theme.textTheme.bodyMedium!,
                                onPressed: () {
                                  onTapContinuewith(context);
                                },
                              ),
                              SizedBox(height: 76.h),
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "msg_by_continuing_you2".tr,
                                      style: theme.textTheme.labelLarge,
                                    ),
                                    TextSpan(
                                      text: "msg_terms_of_service".tr,
                                      style:
                                          theme.textTheme.labelLarge!.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                    TextSpan(
                                      text: "",
                                    ),
                                    TextSpan(
                                      text: "lbl_privacy_policy".tr,
                                      style:
                                          theme.textTheme.labelLarge!.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                    TextSpan(
                                      text: "",
                                    ),
                                    TextSpan(
                                      text: "lbl_content_policy".tr,
                                      style:
                                          theme.textTheme.labelLarge!.copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    )
                                  ],
                                ),
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              SizedBox(height: 44.h),
                              SizedBox(
                                width: 112.h,
                                child: Divider(),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 6.h)
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTicketAppStack(BuildContext context) {
    return Container(
      height: 302.h,
      width: double.maxFinite,
      margin: EdgeInsets.only(left: 64.h),
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgFrame1716775383,
            height: 240.h,
            width: 270.h,
            alignment: Alignment.topRight,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgTicketapp36501,
            height: 65.h,
            width: 246.h,
          )
        ],
      ),
    );
  }

  void onTapGetotp(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.otpScreen,
    );
  }

  void onTapContinuewith(BuildContext context) async {
    await GoogleAuthHelper().googleSignInProcess().then((googleUser) {
      if (googleUser != null) {
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('user data is empty')));
      }
    }).catchError((onError) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(onError.toString())));
    });
  }
}
*/
