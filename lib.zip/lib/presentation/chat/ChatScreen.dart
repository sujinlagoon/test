import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_svg/svg.dart';
import 'package:intl/intl.dart';

import '../../core/utils/image_constant.dart'; // Import the intl package for date formatting

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final String currentUser = 'User1'; // Change as per the actual user data

  final DatabaseReference _messagesRef =
      FirebaseDatabase.instance.ref('chats'); // Realtime DB reference

  final ScrollController _scrollController =
      ScrollController(); // Add scroll controller

  void _sendMessage() {
    final message = _controller.text.trim();
    if (message.isNotEmpty) {
      final currentTime = DateTime.now();
      final formattedTime =
          DateFormat('yyyy-MM-dd HH:mm:ss').format(currentTime); // Format date

      _messagesRef.push().set({
        'text': message,
        'user': currentUser,
        'messagedBy': "user",
        'userId': "1", // Store userId at the top
        'createdAt': formattedTime, // Store formatted time
      });
      _controller.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            /*CircleAvatar(
              radius: 40.0,  // Optional: You can set a specific radius for the avatar
              backgroundImage: AssetImage('assets/images/profileimage.png'), // Local image
            ),*/
            CircleAvatar(
              radius: 30.0, // Set the size of the CircleAvatar
              /*backgroundImage:
                  AssetImage('assets/images/profilepic.jpg'),*/ // Local image
              backgroundColor:
                  Colors.transparent, // Optional: Set a transparent background
              child: ClipOval(
                child: Image.asset(
                  // 'assets/images/profileimage.png',
                  'assets/images/profilepic.jpg',
                  width: 60.0, // Set the width of the image to make it smaller
                  height:
                      60.0, // Set the height of the image to make it smaller
                  fit: BoxFit
                      .cover, // This will ensure the image covers the circle without distortion
                ),
              ),
            ),
            //SizedBox(width: 2),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Daniel Austin',
                    style: TextStyle(
                      color: Color(0xFF282828), // Text color for user input
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 15,
                    )),
                Text('Driver',
                    style: TextStyle(
                      color: Color(0xFF858585), // Text color for user input
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 13,
                    )),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<DatabaseEvent>(
              stream: _messagesRef
                  .orderByChild('createdAt')
                  .onValue, // Order messages by 'createdAt'
              builder: (ctx, chatSnapshot) {
                if (chatSnapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }
                if (!chatSnapshot.hasData ||
                    chatSnapshot.data!.snapshot.value == null) {
                  return Center(child: Text('No messages available.'));
                }

                // Cast snapshot value to Map<dynamic, dynamic>
                final chatData = Map<dynamic, dynamic>.from(
                    chatSnapshot.data!.snapshot.value as Map);
                final chatDocs = chatData.values.toList();

                // Sort the messages based on 'createdAt' in descending order
                chatDocs.sort((a, b) => b['createdAt']
                    .compareTo(a['createdAt'])); // Descending order

                return ListView.builder(
                  controller: _scrollController, // Use ScrollController
                  reverse:
                      true, // Reverse the list to show the most recent message at the bottom
                  itemCount: chatDocs.length,
                  itemBuilder: (ctx, index) {
                    final message = chatDocs[index]['text'];
                    final user = chatDocs[index]['user'];
                    final createdAt =
                        chatDocs[index]['createdAt']; // Get formatted time

                    return MessageBubble(
                      message: message,
                      isMe: user == currentUser,
                      createdAt: createdAt, // Pass formatted time
                    );
                  },
                );
              },
            ),
          ),
          // Input box and send button section at the bottom
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Send a message...',
                      hintStyle: TextStyle(
                        color: Color(0xFF717171),
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide: BorderSide(
                            color: Colors.blue, width: 2.0), // Blue border
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide: BorderSide(
                            color: Colors.blue,
                            width: 1.0), // Blue border when focused
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide: BorderSide(
                            color: Colors.blue,
                            width: 1.0), // Blue border when enabled
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    ),
                    style: TextStyle(
                      color: Colors.black, // Text color for user input
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                    ),
                  ),
                ),
                IconButton(
                  icon: (SvgPicture.asset(
                    ImageConstant.chatsent, // Your SVG asset path
                    height: 50.0,
                    width: 50.0,
                  )),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MessageBubble extends StatelessWidget {
  final String message;
  final bool isMe;
  final String createdAt;

  MessageBubble(
      {required this.message, required this.isMe, required this.createdAt});

  @override
  Widget build(BuildContext context) {
    final time = DateTime.parse(createdAt); // Parse the time string

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 14),
        decoration: BoxDecoration(
          color: isMe ? Colors.blue[100] : Colors.grey[300],
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(12),
            topRight: Radius.circular(12),
            bottomLeft: isMe ? Radius.circular(12) : Radius.circular(0),
            bottomRight: isMe ? Radius.circular(0) : Radius.circular(12),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              message,
              style: TextStyle(color: Colors.black),
            ),
            SizedBox(height: 4),
            Text(
              '${time.hour}:${time.minute.toString().padLeft(2, '0')}',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

/*
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_svg/svg.dart';
import 'package:intl/intl.dart';

import '../../core/utils/image_constant.dart'; // Import the intl package for date formatting

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final String currentUser = 'User1'; // Change as per the actual user data

  final DatabaseReference _messagesRef =
      FirebaseDatabase.instance.ref('chats'); // Realtime DB reference

  final ScrollController _scrollController =
      ScrollController(); // Add scroll controller

  void _sendMessage() {
    final message = _controller.text.trim();
    if (message.isNotEmpty) {
      final currentTime = DateTime.now();
      final formattedTime =
          DateFormat('yyyy-MM-dd HH:mm:ss').format(currentTime); // Format date

      _messagesRef.push().set({
        'text': message,
        'user': currentUser,
        'messagedBy': "user",
        'userId': "1", // Store userId at the top
        'createdAt': formattedTime, // Store formatted time
      });
      _controller.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              backgroundImage: NetworkImage(
                  'https://example.com/user-profile.jpg'), // Replace with actual image URL
            ),
            SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Daniel Austin',
                    style: TextStyle(
                      color: Color(0xFF282828), // Text color for user input
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 15,
                    )),
                Text('Driver',
                    style: TextStyle(
                      color: Color(0xFF858585), // Text color for user input
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                      fontSize: 13,
                    )),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<DatabaseEvent>(
              stream: _messagesRef
                  .orderByChild('createdAt')
                  .onValue, // Order messages by 'createdAt'
              builder: (ctx, chatSnapshot) {
                if (chatSnapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }
                if (!chatSnapshot.hasData ||
                    chatSnapshot.data!.snapshot.value == null) {
                  return Center(child: Text('No messages available.'));
                }

                // Cast snapshot value to Map<dynamic, dynamic>
                final chatData = Map<dynamic, dynamic>.from(
                    chatSnapshot.data!.snapshot.value as Map);
                final chatDocs = chatData.values.toList();

                // Sort the messages based on 'createdAt' in descending order
                chatDocs.sort((a, b) => b['createdAt']
                    .compareTo(a['createdAt'])); // Descending order

                return ListView.builder(
                  controller: _scrollController, // Use ScrollController
                  reverse:
                      true, // Reverse the list to show the most recent message at the bottom
                  itemCount: chatDocs.length,
                  itemBuilder: (ctx, index) {
                    final message = chatDocs[index]['text'];
                    final user = chatDocs[index]['user'];
                    final createdAt =
                        chatDocs[index]['createdAt']; // Get formatted time

                    return MessageBubble(
                      message: message,
                      isMe: user == currentUser,
                      createdAt: createdAt, // Pass formatted time
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Send a message...',
                      hintStyle: TextStyle(
                        color: Color(0xFF717171),
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide: BorderSide(
                            color: Colors.blue, width: 2.0), // Blue border
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide: BorderSide(
                            color: Colors.blue,
                            width: 1.0), // Blue border when focused
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide: BorderSide(
                            color: Colors.blue,
                            width: 1.0), // Blue border when enabled
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    ),
                    style: TextStyle(
                      color: Colors.black, // Text color for user input
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                    ),
                  ),
                ),
                IconButton(
                  icon: (SvgPicture.asset(
                    ImageConstant.chatsent, // Your SVG asset path
                    height: 50.0,
                    width: 50.0,
                  )),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MessageBubble extends StatelessWidget {
  final String message;
  final bool isMe;
  final String createdAt;

  MessageBubble(
      {required this.message, required this.isMe, required this.createdAt});

  @override
  Widget build(BuildContext context) {
    final time = DateTime.parse(createdAt); // Parse the time string

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 14),
        decoration: BoxDecoration(
          color: isMe ? Colors.blue[100] : Colors.grey[300],
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(12),
            topRight: Radius.circular(12),
            bottomLeft: isMe ? Radius.circular(12) : Radius.circular(0),
            bottomRight: isMe ? Radius.circular(0) : Radius.circular(12),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              message,
              style: TextStyle(color: Colors.black),
            ),
            SizedBox(height: 4),
            Text(
              '${time.hour}:${time.minute.toString().padLeft(2, '0')}',
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
*/
