import 'dart:convert';
import 'dart:io';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart'; // Ensure you have flutter_svg in your pubspec.yaml
import 'package:fluttertickect365/sujin_screen/Profile/profile__controller.dart';
import 'package:fluttertickect365/sujin_screen/SharedPref/sharedPref.dart';
import 'package:fluttertickect365/sujin_screen/orbit_Api/reuse_widget/sizes.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import '../../core/utils/image_constant.dart'; // Ensure this is correctly set up
import '../Edit_profile/EditProfilePage.dart';
import '../Notification/NotificationPage.dart';
import '../login_screen/login_screen.dart';
import '../offerscreen/OfferScreen.dart';
import '../saved_places/savedpaces.dart';
import '../utils/AppConstants.dart';

class AccountScreen extends StatefulWidget {
  @override
  _AccountScreenState createState() => _AccountScreenState();
}

Future<String?> getToken() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('auth_token');
}

Future<String?> getuserId() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('UserID');
}

class _AccountScreenState extends State<AccountScreen> {
  final ImagePicker _picker = ImagePicker();
  String? _authToken;
  String? _UserId;

  // State variables for user details
  String userName = "Loading...";
  String userPhone = "Loading...";
  Uri? profileImageUri;

  @override
  void initState() {
    super.initState();
    _checkAuthToken();
    // fetchUserDetails();

    storeBookingData(
      customerID: "11",
      customerName: "anu",
      bookingID: "2",
      // Example booking ID
      cusLatitude: 77.7749,
      // Example latitude
      cusLongitude: 822.4194, // Example longitude
    );

    getBookingData('1');

    print("success");
  }

  Future<void> _checkAuthToken() async {
    String? token = await getToken();
    String? userId = await getuserId();
    setState(() {
      _authToken = token;
      _UserId = userId;
    });
    print("Auth Token: $_authToken");
    print("User ID: $_UserId");
  }

/*  Future<void> fetchUserDetails() async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'view_profile');
    String? token = await getToken();

    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Center(
            child: CircularProgressIndicator(color: Color(0xFF4181FF)),
          );
        },
      );

      var response = await http.post(url, headers: headers, body: jsonEncode(""));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            userName = data['data']['UserName'] ?? "N/A";
            userPhone = data['data']['UserPhone'] ?? "N/A";
            profileImageUri = data['data']['UserProfImg'] != null
                ? Uri.parse(AppConstants.HOST + data['data']['UserProfImg'])
                : null;
          });
        } else {
          Fluttertoast.showToast(
            msg: data['message'] ?? 'An error occurred. Please try again.',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
      } else {
        print(
            'Failed to fetch user details. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('An error occurred: $e');
    } finally {
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
      }
    }
  }*/
  // ProfileController controller = Get.put(ProfileController());
  ProfileController controller = Get.find<ProfileController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('Profile', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          // Profile Information Card
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blueAccent),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Center(
                      child: GestureDetector(
                        onTap: () {}, // Placeholder for image change action
                        child: Stack(
                          alignment: Alignment.bottomRight,
                          children: [
                            GetBuilder<ProfileController>(builder: (context) {
                              return CircleAvatar(
                                radius: 50,
                                backgroundImage:
                                    controller.profile?.data?.userProfImg !=
                                            null
                                        ? NetworkImage(
                                            AppConstants.HOST +
                                                controller.profile!.data!
                                                    .userProfImg!,
                                          )
                                        : null,
                                child: controller.profile?.data?.userProfImg ==
                                        null
                                    ? Icon(Icons.person, size: 50)
                                    : null,
                              );
                            }),

                            /*         Container(
                              padding: EdgeInsets.all(4.0),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black26,
                                    blurRadius: 4,
                                    offset: Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: SvgPicture.asset(
                                ImageConstant.imgEdit,
                                height: 24.0,
                                width: 24.0,
                              ),
                            ),*/
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 8),
                    GetBuilder<ProfileController>(builder: (v) {
                      return Text(
                        v.profile?.data.userName ?? 'Guest', // Fallback value
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      );
                    }),
                    kHeight5,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Clipboard.setData(ClipboardData(text: userPhone))
                                .then((_) {
                              Fluttertoast.showToast(
                                msg: "Phone number copied to clipboard",
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.BOTTOM,
                              );
                            });
                          },
                          child: Row(
                            children: [
                              GetBuilder<ProfileController>(builder: (v) {
                                return Text(
                                  v.profile?.data?.userPhone ??
                                      'No phone number available',
                                  // Fallback text
                                  style: TextStyle(
                                    fontSize: 18,
                                  ),
                                );
                              }),
                              SizedBox(width: 8),
                              Icon(Icons.copy, size: 16, color: Colors.grey),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // List of Options
          Expanded(
            child: ListView(
              children: [
                buildAccountOption(
                  ImageConstant.accUser,
                  'Profile',
                  onTap: () {
                    Get.to(() => PersonalInfoScreen());
                  },
                ),
                buildAccountOption(ImageConstant.saveicon, 'Saved Places',
                    //onTap: () => showSavedPlacesBottomSheet(context),
                    //onTap: () => showArrivalDialog(context),
                    onTap: () {
                  Get.to(() => SavedPlacesScreen());
                }),
                buildAccountOption(
                  ImageConstant.accnotification,
                  'Notification',
                  onTap: () {
                    Get.to(() => NotificationPage());
                  },
                ),
                buildAccountOption(
                  ImageConstant.acclogout,
                  'Logout',
                  onTap: () => showLogoutDialog(context),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildAccountOption(dynamic icon, String title,
      {void Function()? onTap}) {
    return ListTile(
      leading: icon is IconData
          ? Icon(icon, color: Colors.black)
          : SvgPicture.asset(
              icon,
              width: 24,
              height: 24,
            ),
      title: Text(
        title,
        style: TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.w500,
        ),
      ),
      trailing: Icon(Icons.chevron_right, color: Colors.grey),
      onTap: onTap,
    );
  }

//to set data to firebase:
  Future<void> storeBookingData({
    required String customerID,
    required String customerName,
    required String bookingID,
    required double cusLatitude, // Latitude of the customer
    required double cusLongitude, // Longitude of the customer
  }) async {
    try {
      // Reference to the Firebase Realtime Database path for bookings
      DatabaseReference databaseRef =
          FirebaseDatabase.instance.ref('customers/$bookingID');

      // Set the booking data in Realtime Database
      await databaseRef.set({
        'customername': customerName,
        'customerID': customerID,
        'bookingID': bookingID,
        'cusLatitude': cusLatitude, // Store latitude
        'cusLongitude': cusLongitude, // Store longitude
        'status': 'booked', // Example field
        'created_at': ServerValue.timestamp, // Timestamp for record creation
      });

      print("Booking data stored successfully under bookingID: $bookingID!");
    } catch (e) {
      print("Error storing booking data: $e");
    }
  }

  //to get data from firebase:
  Future<void> getBookingData(String bookingID) async {
    try {
      // Reference to the specific bookingID under 'customers'
      DatabaseReference databaseRef =
          FirebaseDatabase.instance.ref('customers/$bookingID');

      // Retrieve the data
      DatabaseEvent event = await databaseRef.once();

      // Check if data exists
      if (event.snapshot.exists) {
        // Get the data as a Map
        Map<dynamic, dynamic>? data =
            event.snapshot.value as Map<dynamic, dynamic>?;

        // Extract specific fields and convert them to strings
        String customerID = data?['customerID'].toString() ?? "No ID available";
        String cusLatitude = data?['cusLatitude'].toString() ?? "0.0";
        String cusLongitude = data?['cusLongitude'].toString() ?? "0.0";

        print("getCustomer ID: $customerID");
        print("getLatitude: $cusLatitude");
        print("getLongitude: $cusLongitude");

        // You can now use these variables as needed
      } else {
        print("No data found for bookingID: $bookingID");
      }
    } catch (e) {
      print("Error retrieving booking data: $e");
    }
  }

//logout:
  void showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ),
          child: Padding(
            padding:
                const EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Are you sure want to\nLogout?',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 20),
                SvgPicture.asset(
                  ImageConstant.popupLogout, // Your SVG asset path
                  height: 40.0,
                  width: 40.0,
                ),
                SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // No button
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop(); // Dismiss the dialog
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        side: BorderSide(color: Colors.red),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        padding:
                            EdgeInsets.symmetric(horizontal: 40, vertical: 25),
                      ),
                      child: Text(
                        'No',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16.0,
                        ),
                      ),
                    ),
                    // Yes button
                    ElevatedButton(
                      onPressed: () async {
                        setloginstatus();
                        //  Navigator.of(context).pop();

                        /* Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => LoginScreen()),
                        );*/
                        await sharedPrefer().clearAll();
                        Get.deleteAll();
                        Get.offAll(() => LoginScreen());
                        /*     Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(
                              builder: (context) => LoginScreen()),
                          (Route<dynamic> route) =>
                              false, // This condition removes all routes
                        );*/
                        // Handle logout action here
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        padding:
                            EdgeInsets.symmetric(horizontal: 40, vertical: 25),
                      ),
                      child: Text(
                        'Yes',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.0,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<bool> setloginstatus() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.setString(
        'login', 'login'); // Returns a boolean indicating success
  }

//SavedPlacesBottomSheet:
  void showSavedPlacesBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
      ),
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 50,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              SizedBox(height: 10),
              Text(
                'Saved Places',
                style: TextStyle(
                  fontSize: 18,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: ListView.builder(
                  itemCount: 10, // Replace with your list length
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: Icon(Icons.bookmark, color: Colors.blue),
                      title: Text(
                        index % 2 == 0
                            ? "Pothys, Nagercoil"
                            : "50 Bucks, Nagercoil",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        "43N, Augusta St. Lorain, OH 44656",
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      trailing: Text(
                        index % 2 == 0 ? "1.5 km" : "2.5 km",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      contentPadding: EdgeInsets.symmetric(vertical: 8.0),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

//dialog for destination
  void showArrivalDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible:
          false, // Prevent closing the dialog by tapping outside
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          contentPadding: EdgeInsets.zero,
          // Wrap the content in a container to adjust width
          content: Container(
            width: 300, // Set the desired width here
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(height: 20),
                // Circle with a location icon
                Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    //color: Colors.blue[100],
                  ),
                  child: Image.asset(
                    'assets/images/arrival_image.png',
                    height: 40, // Adjust the size as needed
                    width: 40,
                    //color: Colors.blue, // If you want to apply a color filter
                    fit: BoxFit
                        .cover, // Adjust how the image fits within the container
                  ),
                ),
                SizedBox(height: 20),
                // Title
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16.0,
                      vertical: 8.0), // Adjust padding as needed
                  child: Text(
                    'You have arrived at your destination!',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF000000)),
                  ),
                ),

                SizedBox(height: 8),
                // Subtitle
                Text(
                  'See you on the next trip.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    color: Color(0xFF404040),
                  ),
                ),
                SizedBox(height: 20),
                // Button
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).pop(); // Close the dialog
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 35.0), // Horizontal margin
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Color(0xFF4181FF),
                            Color(0xFF274E99)
                          ], // Define your gradient colors
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius:
                            BorderRadius.circular(8), // Rounded corners
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 10), // Padding inside the button
                      child: Center(
                        child: Text(
                          'Ok',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.white, // Text color
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 16),
              ],
            ),
          ),
        );
      },
    );
  }
}

/*import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart'; // Ensure you have flutter_svg in your pubspec.yaml
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/utils/image_constant.dart'; // Ensure this is correctly set up
import '../Edit_profile/EditProfilePage.dart';
import '../Notification/NotificationPage.dart';
import '../car/CabCancellation.dart';
import '../car/CabDriverRatings.dart';
import '../car/Cab_Driver_details.dart';
import '../car/DriverProfile.dart';
import '../car/SelectCarScreen.dart';
import '../car/TripDetailsPage.dart';
import '../chat/ChatScreen.dart';
import '../map_location/MapScreen.dart';
import '../map_location/SetLocationScreen.dart';
import '../offerscreen/OfferScreen.dart';
import '../payment_page/PaymentMethodsPage.dart';
import 'package:http/http.dart' as http;

import '../utils/AppConstants.dart';

class AccountScreen extends StatefulWidget {
  @override
  _AccountScreenState createState() => _AccountScreenState();
}

Future<String?> getToken() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('auth_token');
}

Future<String?> getuserId() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('UserID');
}

class _AccountScreenState extends State<AccountScreen> {
  final ImagePicker _picker = ImagePicker();
  File? _image;
  String? _authToken;
  String? _UserId;

  // New state variables
  String userName = "Loading...";
  String userPhone = "Loading...";

  @override
  void initState() {
    super.initState();
    _checkAuthToken();
    fetchUserDetails(); // Fetch user details on initialization

    Fluttertoast.showToast(
      msg: "errorMessage",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  Future<void> _checkAuthToken() async {
    String? token = await getToken();
    String? userId = await getuserId();
    setState(() {
      _authToken = token;
      _UserId = userId;
    });

    if (_authToken != null) {
      print("Auth Token first: $_authToken");
    } else {
      print("No auth token found");
    }

    if (_UserId != null) {
      print("Auth _UserId: $_UserId");
    } else {
      print("No auth UserId found");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
        automaticallyImplyLeading: false, // This will hide the back button
      ),
      body: Column(
        children: [
          // Profile Information Card
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blueAccent),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Center(
                      child: GestureDetector(
                        onTap: _pickImage, // Trigger image picker
                        child: Stack(
                          alignment: Alignment.bottomRight,
                          // Position the icon at the bottom right
                          children: [
                            CircleAvatar(
                              radius: 60,
                              backgroundColor: Colors.grey[300],
                              backgroundImage:
                                  _image != null ? FileImage(_image!) : null,
                              child: _image == null
                                  ? Icon(Icons.camera_alt,
                                      size: 50, color: Colors.grey[700])
                                  : null,
                            ),
                            if (_image != null)

                              // Show edit icon only when an image is present
                              Container(
                                padding:
                                    EdgeInsets.all(4.0), // Add padding here
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors
                                      .white, // Background color for the icon
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black26,
                                      blurRadius: 4,
                                      offset: Offset(0, 2), // Shadow position
                                    ),
                                  ],
                                ),
                                // child: Icon(
                                //   Icons.edit,
                                //   color: Color(0xFF1230AE), // Icon color
                                //   size: 25, // Icon size
                                // ),

                                child: SvgPicture.asset(
                                  ImageConstant
                                      .imgEdit, // Your back button image
                                  height: 24.0,
                                  width: 24.0,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      userName,
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 4),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          userPhone,
                          style: TextStyle(color: Colors.grey),
                        ),
                        SizedBox(width: 8),
                        Icon(Icons.copy, size: 16, color: Colors.grey),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // List of Options
          Expanded(
            child: ListView(
              children: [
                buildAccountOption(Icons.person, 'Profile', onTap: () {
                  // Navigate to EditProfilePage
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => EditProfilePage()),
                  );
                }),
                // Uncomment and use ImageConstant if you have it set up
                // buildAccountOption(ImageConstant.accUser, 'Airplane'), // Use image constant
                buildAccountOption(Icons.location_on, 'Address'),
                buildAccountOption(Icons.notifications, 'Notification'),
                buildAccountOption(Icons.account_circle, 'Account'),
                buildAccountOption(Icons.logout, 'Logout', isLogout: true),
              ],
            ),
          ),

          Expanded(
            child: ListView(
              children: [
                buildAccountOption(
                  ImageConstant.accUser, // SVG asset path or IconData
                  'Profile',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          //builder: (context) => EditProfilePage()),
                          builder: (context) => OfferScreen()),
                    );
                  },
                ),
                buildAccountOption(
                  //  ImageConstant.acclocation, // SVG asset path or IconData
                  ImageConstant.saveicon, // SVG asset path or IconData
                  'Saved Places',
                  onTap: () {
                    showSavedPlacesBottomSheet(context);

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => SelectCarScreen()),
                    );
                  },
                ),
                buildAccountOption(
                  ImageConstant.accnotification, // SVG asset path or IconData
                  'Notification',
                  onTap: () {
                    //showSavedPlacesBottomSheet(context);

                    Navigator.push(
                      context,
                      //MaterialPageRoute(builder: (context) => MapScreen()),

                      //MaterialPageRoute(builder: (context) => ChatScreen()),
                      MaterialPageRoute(
                          builder: (context) => NotificationPage()),
                      //MaterialPageRoute(builder: (context) => TripDetailsPage()),//do
                      //MaterialPageRoute(builder: (context) => CabCancellation()),//do
                      //MaterialPageRoute(builder: (context) => CabDriverRatings()),//do
                      //MaterialPageRoute(builder: (context) => DriverProfile()),//do

                      //MaterialPageRoute(builder: (context) => PaymentMethodsPage()),//do


                      // MaterialPageRoute(
                      //     builder: (context) => CabDriverDetails()),
                      //
                      //    MaterialPageRoute(
                      //     builder: (context) => SetLocationScreen()),
                    );
                  },
                ),
                buildAccountOption(
                  ImageConstant.accUser, // SVG asset path or IconData
                  'Account',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => EditProfilePage()),
                    );
                  },
                ),
                buildAccountOption(
                  ImageConstant.acclogout, // SVG asset path or IconData
                  'Logout',
                  onTap: () {
                    showLogoutDialog(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => EditProfilePage()),
                    );
                  },
                ),
                buildAccountOption(
                  Icons.logout,
                  'Logout',
                  isLogout: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildAccountOption(dynamic icon, String title,
      {bool isLogout = false, void Function()? onTap}) {
    return ListTile(
      leading: icon is IconData
          ? Icon(icon, color: isLogout ? Colors.red : Colors.black)
          : SvgPicture.asset(
              icon, // Use image path if it's not an IconData
              width: 24,
              height: 24,
              color: isLogout ? Colors.red : null, // Color for images if needed
            ),
      title: Text(
        title,
        style: TextStyle(
          color: isLogout ? Colors.red : Colors.black,
          fontWeight: FontWeight.w500,
        ),
      ),
      trailing: Icon(Icons.chevron_right, color: Colors.grey),
      onTap: onTap ??
          () {
            // Default onTap action if not provided
          },
    );
  }

  Future<void> _pickImage() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Choose Image Source'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              ListTile(
                leading: Icon(Icons.camera_alt),
                title: Text('Camera'),
                onTap: () {
                  _getImageFromCamera();
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_album),
                title: Text('Gallery'),
                onTap: () {
                  _getImageFromGallery();
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _getImageFromCamera() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _getImageFromGallery() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> fetchUserDetails() async {
    // Prepare the API URL
    final url = Uri.parse(AppConstants.MAIN_URL + 'view_profile');
    String? token = await getToken();
    // Prepare the headers
    var headers = {
      'Content-Type': 'application/json',
      //'Authorization': 'Bearer $_authToken', // Pass the auth token

      'Authorization': 'Bearer $token', // Pass the auth token
    };
    print('UserID: $_UserId');
    print('_authTokenapi: $_authToken');

    // Prepare the body of the request
    var body = jsonEncode("");

    // Send the request to update the profile
    try {
      // Using addPostFrameCallback to ensure dialog is shown after the build phase
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        // Show loading dialog
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return Center(
              child: CircularProgressIndicator(
                color: Color(0xFF4181FF),
              ),
            );
          },
        );
      });

      var response = await http.post(url, headers: headers, body: body);
      // Ensure the loading dialog is dismissed if widget is still mounted
      if (response.statusCode == 200) {
        // Success: Profile updated
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          // Update state with user details
          setState(() {
            userName = data['data']['UserName'] ?? "N/A";
            userPhone = "+91 ${data['data']['UserPhone'] ?? "N/A"}";
          });
        } else {
          String errorMessage =
              data['message'] ?? 'An error occurred. Please try again.';
          Fluttertoast.showToast(
            msg: errorMessage,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
      } else {
        print('Login failed with status: ${response.statusCode}');
      }
    } catch (e) {
      // Handle network or other errors
      print('An error occurred: $e');
    } finally {
      // Dismiss the loading dialog only if widget is still mounted
      if (mounted) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog
      }
    }
  }

//logout:
  void showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ),
          child: Padding(
            padding:
                const EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Are you sure want to\nLogout?',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 20),
                Icon(
                  Icons.logout,
                  color: Colors.red,
                  size: 40.0,
                ),
                SvgPicture.asset(
                  ImageConstant.popupLogout, // Your SVG asset path
                  height: 40.0,
                  width: 40.0,
                ),
                SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // No button
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop(); // Dismiss the dialog
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        side: BorderSide(color: Colors.red),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        padding:
                            EdgeInsets.symmetric(horizontal: 40, vertical: 25),
                      ),
                      child: Text(
                        'No',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16.0,
                        ),
                      ),
                    ),
                    // Yes button
                    ElevatedButton(
                      onPressed: () {
                        // Handle logout action here
                        Navigator.of(context).pop();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        padding:
                            EdgeInsets.symmetric(horizontal: 40, vertical: 25),
                      ),
                      child: Text(
                        'Yes',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.0,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

//SavedPlacesBottomSheet:
  void showSavedPlacesBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
      ),
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 50,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              SizedBox(height: 10),
              Text(
                'Saved Places',
                style: TextStyle(
                  fontSize: 18,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: ListView.builder(
                  itemCount: 10, // Replace with your list length
                  itemBuilder: (context, index) {
                    return ListTile(
                      leading: Icon(Icons.bookmark, color: Colors.blue),
                      title: Text(
                        index % 2 == 0
                            ? "Pothys, Nagercoil"
                            : "50 Bucks, Nagercoil",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        "43N, Augusta St. Lorain, OH 44656",
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      trailing: Text(
                        index % 2 == 0 ? "1.5 km" : "2.5 km",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      contentPadding: EdgeInsets.symmetric(vertical: 8.0),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}*/
