import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import '../../core/utils/image_constant.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';
import '../utils/AppConstants.dart';

/*class EditProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: Colors.black,
      statusBarBrightness: Brightness.dark,
    ));
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PersonalInfoScreen(),
    );
  }
}*/

Future<String?> getToken() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('auth_token');
}

Future<String?> getuserId() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('UserID');
}

class PersonalInfoScreen extends StatefulWidget {
  @override
  _PersonalInfoScreenState createState() => _PersonalInfoScreenState();
}

class _PersonalInfoScreenState extends State<PersonalInfoScreen> {
  DateTime? _selectedDate;
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  String? _authToken;
  String? _UserId;
  String? phoneNUM;
  String? _selectedGender = 'Male';
  File? _image;
  final ImagePicker _picker = ImagePicker();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Uri? profileImageUri;
   String ?netimage;

/*  void _loadPhoneNumber() async {
    final prefs = await SharedPreferences.getInstance();
    String? phoneNumber = prefs.getString('phone');
    if (phoneNumber != null) {
      setState(() {
        _phoneController.text =
            phoneNumber; // Set the value to _phoneController
      });
    }
  }*/

  @override
  void initState() {
    super.initState();
    _checkAuthToken();
    //  _loadPhoneNumber();
    fetchUserDetails();
  }

  Future<void> _checkAuthToken() async {
    String? token = await getToken();
    String? userId = await getuserId();
    setState(() {
      _authToken = token;
      _UserId = userId;
    });

    if (_authToken != null) {
      print("Auth Token: $_authToken");
    } else {
      print("No auth token found");
    }

    if (_UserId != null) {
      print("Auth _UserId: $_UserId");
    } else {
      print("No auth UserId found");
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );

    if (pickedDate != null) {
      setState(() {
        _selectedDate = pickedDate;
        _dateController.text =
            "${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}";
      });
    }
  }

  Future<void> _pickImage() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Choose Image Source'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              ListTile(
                leading: Icon(Icons.camera_alt),
                title: Text('Camera'),
                onTap: () {
                  _getImageFromCamera();
                  Navigator.of(context).pop();
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_album),
                title: Text('Gallery'),
                onTap: () {
                  _getImageFromGallery();
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _getImageFromCamera() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _getImageFromGallery() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return /*WillPopScope(
      onWillPop: () async {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => CabHomepageScreen(),
          ),
        );
        return false;
      },
      child:*/
        Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: Icon(Icons.arrow_back_ios)),
        centerTitle: true,
        title: Text(
          'Personal Information',
          style: TextStyle(
            fontFamily: 'Poppins-SemiBold',
            fontSize: 20.sp,
            color: Color(0xFF282828),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            minHeight: MediaQuery.of(context).size.height,
          ),
          child: IntrinsicHeight(
            child: Center(
              child: Form(
                key: _formKey,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 15.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(height: 30.0),
                      GestureDetector(
                        onTap: _pickImage,
                        child: Stack(
                          alignment: Alignment.bottomRight,
                          children: [
                            /*
                              CircleAvatar(
                                radius: 60,
                                backgroundColor: Colors.grey[300],
                                backgroundImage: _image != null
                                    ? FileImage(_image!)
                                    : null,
                                child: _image == null
                                    ? Icon(Icons.camera_alt,
                                        size: 50, color: Colors.grey[700])
                                    : null,
                              ),
        */

                            /*      CircleAvatar(
                                radius: 60,
                                backgroundColor: Colors.grey[300],
                                backgroundImage: _image != null
                                    ? (_image is String && netimage.isNotEmpty
                                        ? NetworkImage(profileImageUri
                                            .toString()) // Use netimage for network image
                                        : FileImage(
                                            _image!)) // Use FileImage if _image is a file
                                    : (netimage.isNotEmpty
                                        ? NetworkImage(netimage)
                                        : null), // Show network image if _image is null but netimage is available
                                child: _image == null && netimage.isEmpty
                                    ? Icon(Icons.camera_alt,
                                        size: 50, color: Colors.grey[700])
                                    : null,
                              ),*/

                            CircleAvatar(
                              radius: 60,
                              backgroundColor: Colors.grey[300],
                              backgroundImage: _image != null
                                  ? FileImage(
                                      _image!) // Use _image (FileImage) if it's not null
                                  : profileImageUri != null
                                      ? NetworkImage(profileImageUri
                                          .toString()) // Fallback to profileImageUri if _image is null
                                      : null,
                              child: (_image == null && profileImageUri == null)
                                  ? Icon(Icons.camera_alt,
                                      size: 50,
                                      color: Colors.grey[
                                          700]) // Show camera icon if both are null
                                  : null,
                            ),
                            Container(
                              padding: EdgeInsets.all(4.0),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black26,
                                    blurRadius: 4,
                                    offset: Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: SvgPicture.asset(
                                ImageConstant.imgEdit,
                                height: 24.0,
                                width: 24.0,
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.all(4.0),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black26,
                                    blurRadius: 4,
                                    offset: Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: SvgPicture.asset(
                                ImageConstant.imgEdit,
                                height: 24.0,
                                width: 24.0,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 30.0),
                      _buildTextField('Name', 'Enter your name',
                          controller: _nameController, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Name is required';
                        }
                        return null;
                      }),
                      SizedBox(height: 30.0),
                      _buildTextField(
                        'Email',
                        'Enter your email',
                        controller: _emailController,
                        validator: (value) {
                          if (value != null && value.isNotEmpty) {
                            final emailRegex = RegExp(
                                r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
                            if (!emailRegex.hasMatch(value)) {
                              return 'Enter a valid email';
                            }
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 30.0),
                      _buildTextFieldphone(
                          'Phone number', 'Enter your phone number',
                          controller: _phoneController, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Phone number is required';
                        }
                        /* if (value.length != 10) {
                          return 'Phone number must be 10 digits';
                        }*/
                        return null;
                      }, inputType: TextInputType.phone),
                      SizedBox(height: 30.0),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15.0),
                        child: TextFormField(
                          controller: _dateController,
                          readOnly: true,
                          onTap: () => _selectDate(context),
                          // Opens date picker on tap
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please select your date of birth';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            labelText: 'Date of Birth',
                            labelStyle: TextStyle(
                              fontSize: 20,
                              fontFamily: 'Poppins Medium',
                              color: Colors.black,
                            ),
                            hintText: 'Select your date of birth',
                            hintStyle: TextStyle(
                              fontFamily: 'Poppins-Regular',
                              fontSize: 15.0,
                              color: Color(0xFFA5A5A5),
                            ),
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 20, horizontal: 16),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Color(0xFF9FC0FF),
                                width: 2,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Color(0xFF9FC0FF),
                                width: 2,
                              ),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Colors.red,
                                width: 2,
                              ),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Colors.red,
                                width: 2,
                              ),
                            ),
                            suffixIcon: GestureDetector(
                              onTap: () => _selectDate(context),
                              child: Image.asset(
                                'assets/images/cal1.png',
                                // Calendar icon asset
                                width: 5.0,
                                height: 10.0,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 30.0),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15.0),
                        child: DropdownButtonFormField<String>(
                          value: _selectedGender,
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedGender = newValue!;
                            });
                          },
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Gender is required';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            labelText: 'Gender',
                            labelStyle: TextStyle(
                              fontSize: 20,
                              fontFamily: 'Poppins Medium',
                              color: Colors.black,
                            ),
                            hintText: 'Select your gender',
                            hintStyle: TextStyle(
                              fontFamily: 'Poppins-Regular',
                              fontSize: 15.0,
                              color: Color(0xFFA5A5A5),
                            ),
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 20, horizontal: 16),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Color(0xFF9FC0FF),
                                width: 2,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Color(0xFF9FC0FF),
                                width: 2,
                              ),
                            ),
                          ),
                          items: ['Male', 'Female', 'Other']
                              .map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      ),
                      SizedBox(height: 30.0),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 25.0),
                        child: SizedBox(
                          width: double.infinity,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Color(0xFF4181FF), Color(0xFF274E99)],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                              ),
                              borderRadius: BorderRadius.circular(15.0),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 10,
                                  offset: Offset(0, 5),
                                ),
                              ],
                            ),
                            child: ElevatedButton(
                              onPressed: _isLoading ? null : _updateProfile, // Disable button when loading
                          /*    onPressed: () {
                                if (_formKey.currentState!.validate()) {
                                  *//*  NavigatorService.pushReplacementNamed(
                                      AppRoutes.cabHomepageScreen);*//*

                                  //updateProfileAPI(); // Call the API when pressed
                                  updateProfileAPI(_image, _UserId!);
                                  Get.back();// Call the API when pressed
                                }
                              },*/
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                shadowColor: Colors.transparent,
                                padding: EdgeInsets.symmetric(vertical: 10.0),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                              ),
                              child: /*Text(
                                'Update',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontFamily: 'Poppins-SemiBold',
                                  color: Colors.white,
                                ),
                              ),*/
                              _isLoading
                                  ? SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                                  : Text(
                                'Update',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontFamily: 'Poppins-SemiBold',
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 30.0),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
    // );
  }

  Widget _buildTextFieldphone(
    String label,
    String hintText, {
    TextEditingController? controller,
    FormFieldValidator<String>? validator,
    TextInputType inputType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TextFormField(
        controller: controller,
        keyboardType: inputType,
        validator: validator,
        style: TextStyle(
          fontFamily: 'Poppins-Regular',
          fontSize: 15.0,
          color: Colors.black,
        ),
        readOnly: true,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            fontSize: 20,
            fontFamily: 'Poppins Medium',
            color: Colors.black,
          ),
          hintText: hintText,
          hintStyle: TextStyle(
            fontFamily: 'Poppins-Regular',
            fontSize: 15.0,
            color: Color(0xFFA5A5A5),
          ),
          floatingLabelBehavior: FloatingLabelBehavior.always,
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Color(0xFF9FC0FF), // Original border color
              width: 2,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Color(0xFF9FC0FF),
              width: 2,
            ),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Colors.red, // Red border for error state
              width: 2,
            ),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Colors.red, // Red border when focused and error
              width: 2,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
    String label,
    String hintText, {
    TextEditingController? controller,
    FormFieldValidator<String>? validator,
    TextInputType inputType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TextFormField(
        controller: controller,
        keyboardType: inputType,
        validator: validator,
        style: TextStyle(
          fontFamily: 'Poppins-Regular',
          fontSize: 15.0,
          color: Colors.black,
        ),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            fontSize: 20,
            fontFamily: 'Poppins Medium',
            color: Colors.black,
          ),
          hintText: hintText,
          hintStyle: TextStyle(
            fontFamily: 'Poppins-Regular',
            fontSize: 15.0,
            color: Color(0xFFA5A5A5),
          ),
          floatingLabelBehavior: FloatingLabelBehavior.always,
          filled: true,
          fillColor: Colors.white,
          contentPadding: EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Color(0xFF9FC0FF), // Original border color
              width: 2,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Color(0xFF9FC0FF),
              width: 2,
            ),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Colors.red, // Red border for error state
              width: 2,
            ),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Colors.red, // Red border when focused and error
              width: 2,
            ),
          ),
        ),
      ),
    );
  }

  String convertDate(String dateStr) {
    // Define the original format (dd/MM/yyyy)
    DateFormat originalFormat = DateFormat('dd/MM/yyyy');

    // Parse the input string to a DateTime object
    DateTime dateTime = originalFormat.parse(dateStr);

    // Define the desired format (yyyy/MM/dd)
    DateFormat newFormat = DateFormat('yyyy/MM/dd');

    // Return the formatted date
    return newFormat.format(dateTime);
  }

  String convertDatetoorginal(String dateStr) {
    // Parse the original date string to a DateTime object
    DateTime date = DateTime.parse(dateStr);

    // Format the DateTime object to 'dd-MM-yyyy' format
    String formattedDate = DateFormat('dd/MM/yyyy').format(date);

    return formattedDate;
  }

  Future<void> fetchUserDetails() async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'view_profile');
    String? token = await getToken();

    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return Center(
            child: CircularProgressIndicator(color: Color(0xFF4181FF)),
          );
        },
      );

      var response =
          await http.post(url, headers: headers, body: jsonEncode(""));
      print("inside..");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          print("true..");

          setState(() {
            String userName = data['data']['UserName'] ?? "N/A";
            //  String userPhone = "+91 ${data['data']['UserPhone'] ?? "N/A"}";
            String userPhone = data['data']['UserPhone'] ?? "N/A";
            String mail = data['data']['UserMail'] ?? "N/A";
            String UserDob = data['data']['UserDob'] ?? "N/A";
            String UserGender = data['data']['UserGender'] ?? "N/A";
        /*     profileImageUri = data['data']['UserProfImg'] != null
                ? Uri.parse(AppConstants.MAIN_URL + data['data']['UserProfImg'])
                : null;*/
            // Set the fetched data to the text controllers
            _nameController.text = userName;
            _phoneController.text = userPhone;
            _emailController.text = mail;
            _dateController.text = convertDatetoorginal(UserDob);
            phoneNUM = data['data']['UserPhone'] ?? "N/A";
            // Optionally, set the selected gender from the API response
            if (UserGender == "Male") {
              _selectedGender = 'Male';
            } else if (UserGender == "Female") {
              _selectedGender = 'Female';
            } else {
              _selectedGender = 'Other';
            }
            print("userName.." + userName);
            print("mail.." + mail);
            print("UserDob.." + convertDatetoorginal(UserDob));
            print("UserGender.." + UserGender);
          });

          profileImageUri = data['data']['UserProfImg'] != null
              ? Uri.parse(AppConstants.HOST + data['data']['UserProfImg'])
              : Uri.parse("https://img.freepik.com/premium-vector/default-avatar-profile-icon-social-media-user-image-gray-avatar-icon-blank-profile-silhouette-vector-illustration_561158-3383.jpg");

         /* netimage = data['data']['UserProfImg'];
          print("-------------$netimage");*/
        } else {
          Fluttertoast.showToast(
            msg: data['message'] ?? 'An error occurred. Please try again.',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
      } else {
        print(
            'Failed to fetch user details. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('An error occurred: $e');
    } finally {
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
      }
    }
  }

/*
  Future<void> updateProfileAPI() async {
    // Check if the form is valid
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // Collect the data from the form fields
    String name = _nameController.text;
    String email = _emailController.text;
    //String phone = _phoneController.text;
    String? phone = phoneNUM;
    String gender = _selectedGender!;
    String dateOfBirth = _dateController.text;

    print("Name: $name");
    print("Email: $email");
    print("Phone: $phone");
    print("Gender: $gender");
    print("Date of Birth: $dateOfBirth");

    // Prepare the image for upload (if any)
    String? base64Image;
    if (_image != null) {
      List<int> imageBytes = await _image!.readAsBytes();
      base64Image = base64Encode(imageBytes);
    } else {
      base64Image = "";
    }

    // Prepare the API URL
    // String apiUrl = 'https://your-api-url.com/update-profile';
    final url = Uri.parse(AppConstants.MAIN_URL + 'update_profile');

    // Show loading dialog
    bool isDialogVisible = true; // Flag to track dialog visibility
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFF4181FF),
          ),
        );
      },
    );

    // Prepare the headers
    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_authToken', // Pass the auth token
    };
    print('UserID: $_UserId');
    print('name: $name');
    print('email: $email');
    print('phone: $phone');
    print('gender: $gender');
    print('profile_pic: $base64Image');
    print('dob: ' + convertDate(dateOfBirth));
    print('Bearer: $_authToken');

    // Prepare the body of the request
    var body = jsonEncode({
      'name': name,
      'email': email,
      'phone': phone,
      'gender': gender,
      'dob': convertDate(dateOfBirth),
      'profile_pic': base64Image, // Pass the image as base64 if exists
      'UserID': _UserId
    });

    // Send the request to update the profile
    try {
      var response = await http.post(url, headers: headers, body: body);
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog
        isDialogVisible = false;
      }
      print('in...');

      if (response.statusCode == 200) {
        print('200...');

        // Success: Profile updated
        //print('Profile updated successfully');
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          print('true');

          _showSuccessPopup(context);
        } else {
          print('false...');

          String errorMessage =
              data['message'] ?? 'An error occurred. Please try again.';
          Fluttertoast.showToast(
            msg: errorMessage,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
        //NavigatorService.pushReplacementNamed(AppRoutes.cabHomepageScreen);
      } else {
        // Failure: Handle errors (e.g., invalid token or other issues)
        // print('Error: ${response.statusCode} - ${response.body}');
        print('Login failed with status: ${response.statusCode}');
      }
    } catch (e) {
      // Handle network or other errors
      //print('Error: $e');
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog on error
        isDialogVisible = false;
      }
      print('An error occurred: $e');
    }
  }
*/
  bool _isLoading = false;
  void _updateProfile() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        await updateProfileAPI(_image, _UserId!);
      } finally {
        setState(() {
          _isLoading = false;
        });
      }

      Get.back();
    }
  }
  Future<void> updateProfileAPI(File? image, String usId) async {
    final url = Uri.parse(AppConstants.MAIN_URL + 'update_profile');

    // Show loading dialog
    bool isDialogVisible = true; // Flag to track dialog visibility
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            color: Color(0xFF4181FF),
          ),
        );
      },
    );

    // Collect the data from the form fields
    String name = _nameController.text;
    String email = _emailController.text;
    String phone = _phoneController.text;
    String gender = _selectedGender!;
    String dateOfBirth = _dateController.text;

    // Prepare the headers
    var headers = {
      'Authorization': 'Bearer $_authToken', // Pass the auth token
    };

    print('name: ' + name);
    print('email:' + email);
    print('phone:' + phone);
    print('gender: ' + gender);
    print('dob:' + dateOfBirth);
    print('UserID:' + usId);

    // Prepare the body of the request (excluding the image part)
    var body = {
      'name': name,
      'UserID': usId,
      'email': email,
      'phone': phone,
      'gender': gender,
      'dob': convertDate(dateOfBirth),
    };

    // Send the request to update the profile
    try {
      // Create a multipart request
      var request = http.MultipartRequest('POST', url)..headers.addAll(headers);

      // If an image is selected, add it as part of the request
      if (image != null) {
        request.files.add(
          await http.MultipartFile.fromPath('profile_pic', image.path),
        );
      }

      // Add the rest of the fields to the request body
      request.fields.addAll(body);

      // Send the request
      var response = await request.send();

      // Close the dialog after request completion
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog
        isDialogVisible = false;
      }
      print("in...");

      // Handle the response
      if (response.statusCode == 200) {
        print("200...");

        final responseData = await response.stream.bytesToString();
        final data = jsonDecode(responseData);

        if (data['status'] == true) {
          print("success");

          Fluttertoast.showToast(
            msg: "Profile is Created Successfully",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
          //_showSuccessPopup(context);
     //     Navigator.pop(context);
        /*  Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => CabHomepageScreen(),
            ),
          );*/
        } else {
          String errorMessage = data['message'] ?? 'An error occurred. Please try again.';
          Fluttertoast.showToast(
            msg: errorMessage,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        }
      } else if (response.statusCode == 500) {
        Fluttertoast.showToast(
          msg: "Request failed with status: ${response.statusCode}",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      } else {
        Fluttertoast.showToast(
          msg: "Request failed with status: ${response.statusCode}",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    } catch (e) {
      // Handle network or other errors
      if (isDialogVisible) {
        Navigator.of(context, rootNavigator: true)
            .pop(); // Dismiss loading dialog on error
        isDialogVisible = false;
      }
      print('An error occurred: $e');
    }
  }

 /* void _showSuccessPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding:
              EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                'assets/images/tick.png', // Path to your tick image
                width: 60,
                height: 60,
              ),
              SizedBox(height: 20),
              Text(
                'Success',
                style: TextStyle(
                  fontSize: 20,
                  fontFamily: 'Poppins-SemiBold',
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                textAlign: TextAlign.center, // Center align the text
              ),
              SizedBox(height: 10),
              Text(
                'Your profile has been updated successfully!',
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: 'Poppins-Regular',
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
        );
      },
    );

    // Wait for 2 seconds before closing the dialog and navigating to the next screen
    Future.delayed(Duration(seconds: 2), () {
      Navigator.of(context).pop(); // Close the dialog
      *//* NavigatorService.pushReplacementNamed(
          AppRoutes.cabHomepageScreen); // Navigate to next screen*//*

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => CabHomepageScreen(),
        ),
      );
    });
  }*/
}

/*
import 'package:flutter/material.dart';
import 'package:fluttertickect365/core/app_export.dart';
import '../../core/utils/navigator_service.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';

class EditProfilePage extends StatefulWidget {
  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _dobController = TextEditingController();
  String? _selectedGender;
  DateTime? _selectedDate;

  // Define the color
  final Color borderColor = Color(0xFF9FC0FF);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Profile"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    buildTextField("Name", "Enter your name", _nameController),
                    SizedBox(height: 16),
                    buildTextField(
                        "Email", "Enter your email", _emailController),
                    SizedBox(height: 16),
                    buildTextField("Phone number", "Enter your Phone number",
                        _phoneController,
                        keyboardType: TextInputType.phone),
                    SizedBox(height: 16),
                    buildDateField("Date of birth"),
                    SizedBox(height: 16),
                    buildGenderDropdown(),
                  ],
                ),
              ),
            ),
          ),
          buildUpdateButton(),
        ],
      ),
    );
  }

  Widget buildTextField(
      String label, String hint, TextEditingController controller,
      {TextInputType keyboardType = TextInputType.text}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            fontSize: 14,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 8),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w400,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
              color: Colors.black54,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
            ),
            // Set up the border colors
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(color: borderColor),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(color: borderColor),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(color: Colors.red),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(color: Colors.red),
            ),
          ),
        ),
      ],
    );
  }

  Widget buildDateField(String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            fontSize: 14,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 8),
        TextFormField(
          controller: _dobController,
          readOnly: true,
          onTap: () async {
            _selectedDate = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime(1900),
              lastDate: DateTime.now(),
            );
            if (_selectedDate != null) {
              _dobController.text =
                  "${_selectedDate!.month}/${_selectedDate!.day}/${_selectedDate!.year}";
            }
          },
          decoration: InputDecoration(
            hintText: "MM/DD/YYYY",
            hintStyle: TextStyle(
              color: Colors.black54,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
            ),
            suffixIcon: Icon(Icons.calendar_today),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(color: borderColor),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(color: borderColor),
            ),
          ),
        ),
      ],
    );
  }

  Widget buildGenderDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Gender",
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            fontSize: 14,
            color: Colors.black,
          ),
        ),
        SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedGender,
          hint: Text(
            "Select Gender",
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: Colors.black54,
            ),
          ),
          items: ["Male", "Female", "Other"].map((gender) {
            return DropdownMenuItem(
              value: gender,
              child: Text(
                gender,
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                  color: Colors.black,
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              _selectedGender = value;
            });
          },
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w500,
            fontSize: 14,
            color: Colors.black,
          ),
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(color: borderColor),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(color: borderColor),
            ),
          ),
        ),
      ],
    );
  }

  Widget buildUpdateButton() {
    return Container(
      margin: EdgeInsets.all(16.0),
      child: CustomElevatedButton(
        text: "Update",
        buttonStyle: CustomButtonStyles.none,
        decoration: CustomButtonStyles.gradientBlueAToPrimaryDecoration,
        onPressed: () {
          // Handle continue button action
        },
      ),
    );
  }
}
*/
